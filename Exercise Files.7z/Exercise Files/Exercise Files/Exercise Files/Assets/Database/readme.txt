Exercise Files/Assets/Database
Readme
2/20/2009

This folder contains an SQL file that defines database structure
and data for this lynda.com video series:

ASP.NET 3.5 Essential Training

