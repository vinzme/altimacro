﻿
Partial Class HelloFromVB
    Inherits System.Web.UI.Page
    Protected var1 As String = "Hello from VB"
End Class
