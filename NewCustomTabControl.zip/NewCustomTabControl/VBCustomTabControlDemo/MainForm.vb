
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Security.Permissions
Imports System.Windows.Forms

Public Partial Class MainForm
	Inherits System.Windows.Forms.Form

	Public Sub New()

		InitializeComponent()
	End Sub

End Class
