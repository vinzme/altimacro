﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace VMS_SUPPORT
{
    public partial class Searchno : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtcat.Items.Clear();
                txtcat.Items.Insert(0, "Select");
                SqlDataReader reader, rdr, streader;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                String qry = "select * from Category order by Category_Name";
                SqlCommand cmd = new SqlCommand(qry, conn);
                cmd.CommandText = qry;
                rdr = cmd.ExecuteReader();
                txtcat.DataSource = rdr;
                txtcat.DataValueField = "Category_id";
                txtcat.DataTextField = "Category_Name";
                txtcat.DataBind();
                rdr.Close();
                txttyp.Items.Clear();
                txttyp.Items.Insert(0, "Select");
                String query = "select * from Request1 order by Request_type";
                SqlCommand typ = new SqlCommand(query, conn);
                typ.CommandText = query;
                reader = typ.ExecuteReader();
                txttyp.DataSource = reader;
                txttyp.DataValueField = "Request_id";
                txttyp.DataTextField = "Request_type";
                txttyp.DataBind();
                reader.Close();
                txtStatus.Items.Clear();
                txtStatus.Items.Insert(0, "Select");
                String querytxtStatus = "select * from Status";
                SqlCommand typtxtStatus = new SqlCommand(querytxtStatus, conn);
                typtxtStatus.CommandText = querytxtStatus;
                streader = typtxtStatus.ExecuteReader();
                txtStatus.DataSource = streader;
                txtStatus.DataValueField = "Status_ID";
                txtStatus.DataTextField = "Status";
                txtStatus.DataBind();
                streader.Close();
                conn.Close();
            }
        }

        protected void txtcat_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            String id;
            if (txtcat.SelectedItem.Text == "Select")
            {                
                txttyp.Items.Clear();
                txttyp.Items.Insert(0, "Select");
                SqlDataReader reader;
                String qury = "select * from Request1 order by Request_type ";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                txttyp.DataSource = reader;
                txttyp.DataValueField = "Request_id";
                txttyp.DataTextField = "Request_type";
                txttyp.DataBind();
                conn.Close();
            }
            else
            {
                id = txtcat.SelectedValue;
                txttyp.Items.Clear();
                txttyp.Items.Insert(0, "Select");
                SqlDataReader reader;
                String qury = "select * from Request1 where Request_category = @Req_category order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.Parameters.Add("@Req_category", SqlDbType.Int).Value = id;
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                txttyp.DataSource = reader;
                txttyp.DataValueField = "Request_id";
                txttyp.DataTextField = "Request_type";
                txttyp.DataBind();
                conn.Close();
            }                    
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //Search Ticket
            String ticketno, Category, Netid, requestor, Department, Types, Status;
            if (txtticketno.Text == "")
            { ticketno = "%"; }
            else
            { ticketno = txtticketno.Text; }
            if (txtnet.Text == "")
            {
                Netid = "%";
            }
            else
            {
                Netid = txtnet.Text;
            }
            if (txtreq.Text == "")
            {
                requestor = "%";
            }
            else
            {
                requestor = txtreq.Text;
            }

            if (txtdep.Text == "")
            {
                Department = "%";
            }
            else
            {
                Department = txtdep.Text;
            }

            if (txtcat.SelectedItem.Text == "Select")
            {
                Category = "%";
            }
            else
            {
                Category = txtcat.SelectedValue;
            }

            if (txttyp.SelectedItem.Text == "Select")
            {
                Types = "%";
            }
            else
            {
                Types = txttyp.SelectedValue;
            }
            if(txtStatus.SelectedItem.Text == "Select")
            {
                Status = "%";
            }
            else
            {
                Status = txtStatus.SelectedValue;
            }

            SqlDataReader Reader = null;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String qry = "select tblticket.Ticket_id,tblticket.Req_name,tblticket.Req_netid,tblticket.Req_dept,Category.Category_Name,Request1.Request_type,us.Name[Representative],usb.Name[BackupRepresentative],Status.Status  from tblticket join Category on Category.Category_id=tblticket.Req_category join Request1 on Request1.Request_id=tblticket.Req_type join Status on status.Status_ID=tblticket.Status Left join users us on us.Uid=tblticket.Representative Left join users usb on usb.Uid = tblticket.BackupRepresentative where tblticket.Ticket_id Like '%' + @Req_ticket + '%' and tblticket.Req_name  LIKE '%' + @Req_name + '%' and tblticket.Req_netid  LIKE '%' + @Req_netid + '%' and tblticket.Req_dept  LIKE '%' + @Req_dept + '%'  and tblticket.Req_category  LIKE '%' + @Req_category + '%' and tblticket.Req_type  LIKE '%' + @Req_type + '%' and tblticket.Status  LIKE '%' + @Status + '%' order by 1 DESC ";
            SqlCommand SLCOM = new SqlCommand(qry, conn);
            SLCOM.Parameters.Add("@Req_ticket", SqlDbType.NVarChar).Value = ticketno;
            SLCOM.Parameters.Add("@Req_name", SqlDbType.NVarChar).Value = requestor;
            SLCOM.Parameters.Add("@Req_netid", SqlDbType.NVarChar).Value = Netid;
            SLCOM.Parameters.Add("@Req_dept", SqlDbType.NVarChar).Value = Department;
            SLCOM.Parameters.Add("@Req_category", SqlDbType.NVarChar).Value = Category;
            SLCOM.Parameters.Add("@Req_type", SqlDbType.NVarChar).Value = Types;
            SLCOM.Parameters.Add("@Status", SqlDbType.NVarChar).Value = Status;
            try
            {
                conn.Open();
                Reader = SLCOM.ExecuteReader();
                if (Reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(Reader);
                    dt.Columns["Ticket_id"].ColumnName = "Ticket#";
                    dt.Columns["Req_name"].ColumnName = "Requestor Name";
                    dt.Columns["Req_netid"].ColumnName = "Network ID";
                    dt.Columns["Req_dept"].ColumnName = "Department";
                    dt.Columns["Category_Name"].ColumnName = "category";
                    dt.Columns["Request_type"].ColumnName = "Type";
                    Session["items"] = dt;
                    Srchres.DataSource = dt;
                    Srchres.DataBind();
                    foreach (GridViewRow gr in Srchres.Rows)
                    {
                        HyperLink hp = new HyperLink();
                        hp.Text = gr.Cells[0].Text;
                        hp.NavigateUrl = "~/ticketview.aspx?str=Search&name=" + hp.Text;
                        gr.Cells[0].Controls.Add(hp);
                    }
                }
                else
                {
                    string myStringVariable = "No Records Found";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
                }

            }
            finally
            {

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
            //Response.Redirect("ticketview.aspx?str='search'");
        }

        protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (Page.IsPostBack)
            {
                Srchres.PageIndex = e.NewPageIndex;

                Srchres.DataSource = Session["items"];
                Srchres.DataBind();
                foreach (GridViewRow gr in Srchres.Rows)
                {
                    HyperLink hp = new HyperLink();
                    hp.Text = gr.Cells[0].Text;
                    hp.NavigateUrl = "~/ticketview.aspx?str=Search&name="+ hp.Text;
                    gr.Cells[0].Controls.Add(hp);
                }
                
            }

        }

       
    }
}
