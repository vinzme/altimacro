﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace VMS_SUPPORT
{
    public partial class Template : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                txttyp.Items.Clear();
                txttyp.Items.Insert(0, "Select");
                SqlDataReader reader;
                String qury = "select * from Request1 order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                txttyp.DataSource = reader;
                txttyp.DataValueField = "Request_id";
                txttyp.DataTextField = "Request_type";
                txttyp.DataBind();
                conn.Close();
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txttyp.SelectedItem.Text == "Select")
            {
                string myStringVariable = "Select a category";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
            }
            else
            {
                String insquery;
            HttpFileCollection hfc = HttpContext.Current.Request.Files;
            HttpPostedFile hpf;
            String id = txttyp.SelectedValue;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand chtemp = conn.CreateCommand();
            chtemp.CommandText = "Select * from Template where Request_id=@Request_id";
            chtemp.Parameters.AddWithValue("@Request_id", id);//Ticket_id
            conn.Open();
            SqlDataReader rdr = chtemp.ExecuteReader();            
            
                if (rdr.HasRows)
                {
                    insquery = "Update Template set File_Name=@Name,File_type=@type,data=@Data where Request_id = @Request_id";
                }
                else
                {
                    insquery = "INSERT INTO Template (File_Name,File_type,data,Request_id) VALUES (@Name, @type, @Data,@Request_id)"; //insert query
                }
                conn.Close();
                 for (int i = 0; i < hfc.Count; i++)
                 {
                     hpf = hfc[i];
                     if (hpf.ContentLength > 0)
                     {
                         string filePath = hpf.FileName;
                         string filename = System.IO.Path.GetFileName(filePath);
                         string ext = System.IO.Path.GetExtension(filename);
                         hpf.SaveAs(Server.MapPath("~/Template/") + id + filename);
                         String path = id + filename;
                         SqlCommand cone = conn.CreateCommand();
                         cone.CommandText = insquery;
                         cone.Parameters.AddWithValue("@Name", filename);//name of the file
                         cone.Parameters.AddWithValue("@type", ext);//file extion
                         cone.Parameters.AddWithValue("@Data", path);//file Path
                         cone.Parameters.AddWithValue("@Request_id", id);//Ticket_id
                         conn.Open();
                         cone.ExecuteNonQuery();//excute query
                         conn.Close();
                     }
                     else
                     {
                         string myStringVariable = "No files attatched";
                         ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
                     }

                 }
           
            }
        }
    }
}