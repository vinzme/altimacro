﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace VMS_SUPPORT
{
    public partial class Workflow : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtcat.Items.Clear();
                txtcat.Items.Insert(0, "Select");
                SqlDataReader reader, rdr, streader,reprdr,backrep;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                String qry = "select * from Category order by Category_Name";
                SqlCommand cmd = new SqlCommand(qry, conn);
                cmd.CommandText = qry;
                rdr = cmd.ExecuteReader();
                txtcat.DataSource = rdr;
                txtcat.DataValueField = "Category_id";
                txtcat.DataTextField = "Category_Name";
                txtcat.DataBind();
                rdr.Close();
                //Request Type Binding
                String query = "select * from Request1 order by Request_type";
                SqlCommand typ = new SqlCommand(query, conn);
                typ.CommandText = query;
                reader = typ.ExecuteReader();
                 if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reader);
                    txttyp.CreateCheckBox(dt, "Request_type", "Request_id", 1);
                }
                reader.Close();
                //Status Binding
                 String querytxtStatus = "select * from Status";
                SqlCommand typtxtStatus = new SqlCommand(querytxtStatus, conn);
                typtxtStatus.CommandText = querytxtStatus;
                streader = typtxtStatus.ExecuteReader();
                if (streader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(streader);
                    txtStatus.CreateCheckBox(dt, "Status", "Status_ID", 1);                  
                }               
                streader.Close();
                
                // Representative binding                
                String queryRepresentative = "select * from users order by Name";
                SqlCommand cRepresentative = new SqlCommand(queryRepresentative, conn);
                cRepresentative.CommandText = queryRepresentative;
                reprdr = cRepresentative.ExecuteReader();
                if (reprdr.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reprdr);
                    chkRepresentative.CreateCheckBox(dt, "Name", "Uid", 1);
                } 
                reprdr.Close();
                backrep = cRepresentative.ExecuteReader();
                if (backrep.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(backrep);
                    BCKRepresentative.CreateCheckBox(dt, "Name", "Uid", 1);
                } 
                backrep.Close();
                conn.Close();

            }
        }

        protected void txtcat_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            String id;
            if (txtcat.SelectedItem.Text == "Select")
            {
                SqlDataReader reader;
                String qury = "select * from Request1 order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.CommandText = qury;
                reader = comd.ExecuteReader();                
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reader);
                    txttyp.CreateCheckBox(dt, "Request_type", "Request_id", 1);
                }
                reader.Close();
            }
            else
            {
                id = txtcat.SelectedValue;
                
                SqlDataReader reader;
                String qury = "select * from Request1 where Request_category = @Req_category order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.Parameters.Add("@Req_category", SqlDbType.Int).Value = id;
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                 if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reader);
                    txttyp.CreateCheckBox(dt, "Request_type", "Request_id", 1);
                }
                reader.Close();
                conn.Close();
            }

        }

        protected void Search_Click(object sender, EventArgs e)
        {
            
            String ticketno, Category, Netid, requestor, Department, Types, Status, rep, bkrep;
            Status = chkRepresentative.sValue;
            if (txtticketno.Text == "")
            {
                ticketno = "%";
            }
            else
            {
                ticketno = txtticketno.Text;
            }
            if (txtnet.Text == "")
            {
                Netid = "%";
            }
            else
            {
                Netid = txtnet.Text;
            }
            if (txtreq.Text == "")
            {
                requestor = "%";
            }
            else
            {
                requestor = txtreq.Text;
            }

            if (txtdep.Text == "")
            {
                Department = "%";
            }
            else
            {
                Department = txtdep.Text;
            }

            if (txtcat.SelectedItem.Text == "Select")
            {
                Category = "%";
            }
            else
            {
                Category = txtcat.SelectedValue;
            }

            if (txttyp.sValue == "")
            {
                Types = txttyp.allsValue; 
            }
            else
            {
                Types = txttyp.sValue;
            }
            if (txtStatus.sValue == "")
            {
                Status = txtStatus.allsValue;
            }
            else
            {
                Status = txtStatus.sValue;
            }

            if (chkRepresentative.sValue == "")
            {
                rep = chkRepresentative.allsValue;
            }
            else
            {
                rep = chkRepresentative.sValue;
            }
            if (BCKRepresentative.sValue == "")
            {
                bkrep = BCKRepresentative.allsValue;
            }
            else
            {
                bkrep = BCKRepresentative.sValue;
            }               
         
            SqlDataReader Reader = null;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String qry = "select tblticket.Ticket_id,tblticket.Req_name,tblticket.Req_netid,tblticket.Req_dept,Category.Category_Name,Request1.Request_type,us.Name[Representative],usb.Name[Backup],Status.Status,Convert(nvarchar(10),tblticket.eta_date,110)[ETA],Convert(nvarchar(10),tblticket.Follow_up_date,110)[Follow up date] from tblticket join Category on Category.Category_id=tblticket.Req_category join Request1 on Request1.Request_id=tblticket.Req_type join Status on status.Status_ID=tblticket.Status Left join users us (nolock) on us.Uid=tblticket.Representative  Left join users usb (nolock) on usb.Uid = tblticket.BackupRepresentative where tblticket.Ticket_id Like '%' + @Req_ticket + '%' and tblticket.Req_name  LIKE '%' + @Req_name + '%' and tblticket.Req_netid  LIKE '%' + @Req_netid + '%' and tblticket.Req_dept  LIKE '%' + @Req_dept + '%' and tblticket.Req_category  LIKE '%' + @Req_category + '%' and tblticket.Req_type in  (SELECT * FROM dbo.split(@Req_type)) and tblticket.Status  in  (SELECT * FROM dbo.split(@Status)) and tblticket.Representative in (SELECT * FROM dbo.split(@Representative)) and tblticket.BackupRepresentative  in (SELECT * FROM dbo.split(@BackupRepresentative)) order by 1 DESC";
            SqlCommand SLCOM = new SqlCommand(qry, conn);
            SLCOM.Parameters.Add("@Req_ticket", SqlDbType.NVarChar).Value = ticketno;
            SLCOM.Parameters.Add("@Req_name", SqlDbType.NVarChar).Value = requestor;
            SLCOM.Parameters.Add("@Req_netid", SqlDbType.NVarChar).Value = Netid;
            SLCOM.Parameters.Add("@Req_dept", SqlDbType.NVarChar).Value = Department;
            SLCOM.Parameters.Add("@Req_category", SqlDbType.NVarChar).Value = Category;
            SLCOM.Parameters.Add("@Req_type", SqlDbType.NVarChar).Value = Types;
            SLCOM.Parameters.Add("@Status", SqlDbType.NVarChar).Value = Status;
            SLCOM.Parameters.Add("@Representative", SqlDbType.NVarChar).Value = rep;
            SLCOM.Parameters.Add("@BackupRepresentative", SqlDbType.NVarChar).Value = bkrep;
            try
            {
                conn.Open();
                Reader = SLCOM.ExecuteReader();
                if(Reader.HasRows)
                {
                DataTable dt = new DataTable();
                dt.Reset();
                dt.Load(Reader);
                Session["items"] = dt;
                Srchres.DataSource = dt;
                Srchres.DataBind();
                foreach (GridViewRow gr in Srchres.Rows)
                {
                    HyperLink hp = new HyperLink();
                    hp.Text = gr.Cells[0].Text;
                    hp.NavigateUrl = "~/Ticketwork.aspx?name=" + hp.Text;
                    gr.Cells[0].Controls.Add(hp);
                }
                }
                else
                {
                    string myStringVariable = "No Records Found";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
                }
            }
            finally
            {

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (Page.IsPostBack)
            {
                Srchres.PageIndex = e.NewPageIndex;
                Srchres.DataSource = Session["items"];
                Srchres.DataBind();
                foreach (GridViewRow gr in Srchres.Rows)
                {
                    HyperLink hp = new HyperLink();
                    hp.Text = gr.Cells[0].Text;
                    hp.NavigateUrl = "~/Ticketwork.aspx?name=" + hp.Text;
                    gr.Cells[0].Controls.Add(hp);
                }
                Srchres.PageIndex = e.NewPageIndex;
            }
         
        }
      
    }
}
