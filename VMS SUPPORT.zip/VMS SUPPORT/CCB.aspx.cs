﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.DirectoryServices;

namespace VMS_SUPPORT
{
    public partial class CCB : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                string catid = Request.QueryString["str"];//To get the Category
                int id = Int32.Parse(catid);
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                String qry = "select Category_Name from Category where Category_id = @category";
                SqlCommand cmd = new SqlCommand(qry, conn);
                cmd.Parameters.Add("@category", SqlDbType.Int).Value = id;
                cmd.CommandText = qry;
                string cate = cmd.ExecuteScalar().ToString();
                CCBReq_category.Text = cate;
                //AD information of user//
                string s = HttpContext.Current.User.Identity.Name;
                string username = s.Substring(s.IndexOf(@"\") + 1);
                string[] domain = s.Split('\\');
                string Department, TELE;
                CCBReqnetid.Text = username;
                string connection;
                if (domain[0] == "ASCORP")
                {

                    connection = ConfigurationManager.ConnectionStrings["Ascorp"].ToString();
                }
                else
                {
                    connection = ConfigurationManager.ConnectionStrings["corp"].ToString();

                }
                DirectoryEntry de = new DirectoryEntry();
                de.Path = connection;
                DirectorySearcher dssearch = new DirectorySearcher();
                dssearch.SearchRoot = de;
                dssearch.Filter = "(sAMAccountName=" + username + ")";
                SearchResult sresult = dssearch.FindOne();
                DirectoryEntry dsresult = sresult.GetDirectoryEntry();

                if (dsresult.Properties.Contains("displayName"))
                {
                    CCBReq_name.Text = dsresult.Properties["displayName"][0].ToString();
                }
                else
                {
                    CCBReq_name.Text = "";
                }

                if (dsresult.Properties.Contains("department"))
                {
                    String Depart = dsresult.Properties["department"][0].ToString();
                    Department = Depart.Substring(Depart.IndexOf(@"-") + 1);
                }
                else
                {
                    Department = "";
                }
                if (dsresult.Properties.Contains("mail"))
                {
                    CCBReq_email.Text = dsresult.Properties["mail"][0].ToString();
                }
                else
                {
                    CCBReq_email.Text = "";
                }
                if (dsresult.Properties.Contains("physicalDeliveryOfficeName"))
                {
                    CCBLocation.Text = dsresult.Properties["physicalDeliveryOfficeName"][0].ToString();
                }
                else
                {
                    CCBLocation.Text = "";
                }
                if (dsresult.Properties.Contains("assistant"))
                {
                    String TELEP = dsresult.Properties["assistant"][0].ToString();
                    TELE = TELEP;

                }
                else
                {
                    TELE = "";

                }

                CCBReq_ext.Text = TELE;
                CCBReq_dept.Text = Department;

                //Populating The Type Drop down.
                SqlDataReader reader;
                String qury = "select * from Request1 where Request_category = @Req_category  order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.Parameters.Add("@Req_category", SqlDbType.Int).Value = id;
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reader);
                    CCBReq_type.CreateCheckBox(dt, "Request_type", "Request_id", 1);
                }
                reader.Close();
                // populating Prority

                CCBreq_priority.Items.Insert(0, "Select");
                SqlDataReader piorityreader;
                String pioqury = "select * from ref_piority";
                SqlCommand piocomd = new SqlCommand(pioqury, conn);
                piocomd.CommandText = pioqury;
                piorityreader = piocomd.ExecuteReader();
                CCBreq_priority.DataSource = piorityreader;
                CCBreq_priority.DataValueField = "piority_id";
                CCBreq_priority.DataTextField = "ccbpiority";
                CCBreq_priority.DataBind();
                CCBreq_priority.SelectedIndex = 0;
            }
        }

        protected void CCBSOP_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ccbsop.SelectedValue == "1")
            {
                ccblistimpactsop.Visible = true;
                lblsop.Visible = true;
            }
            else
            {
                ccblistimpactsop.Visible = false;
                lblsop.Visible = false;
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            HttpFileCollection hfc = HttpContext.Current.Request.Files;
            HttpPostedFile hpf;
            string myStringVariable;
            if (CCBReq_ext.Text == "" || CCBReq_type.sValue == "Select" || CCBreq_priority.SelectedItem.Text == "Select" || CCBchangetitle.Text == "" || txtDate.Text == "" || ccb_description_impact.Text == "" || ccb_implication_NMC.Text == "" || ccb_ppi_up_downstrem.Text == "" || ccb_cost_implications.Text == "" || ccbsop.SelectedItem.Text == "Select" || ccbtraining.SelectedItem.Text == "Select" || ccbaxentis.SelectedItem.Text == "Select" || ccbvendorguide.SelectedItem.Text == "Select" || ccbvendortraining.SelectedItem.Text == "Select")
            {
                myStringVariable = "All Fields Are Mandatory";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert1", "alert('" + myStringVariable + "');", true);
            }
            else if (hfc.Count<1)
            {
                myStringVariable = "Document required";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert2", "alert('" + myStringVariable + "');", true);
            }
            else if (ccbsop.SelectedItem.Text == "Yes" && ccblistimpactsop.Text == "")
            {
                myStringVariable = "Please Specify the List Impacted SOPs ";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert2", "alert('" + myStringVariable + "');", true);
            }
            else
            {
                string Types; 

                if (CCBReq_type.sValue == "")
                {
                    Types = CCBReq_type.allsValue;
                }
                else
                {
                    Types = CCBReq_type.sValue;
                }
                //Saving Ticket
                string catid = Request.QueryString["str"];
                int stat = 1;
                string s = HttpContext.Current.User.Identity.Name;
                string username = s.Substring(s.IndexOf(@"\") + 1);
                DateTime now = DateTime.Now;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                SqlCommand com = new SqlCommand("spccbrequest", conn);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.Add("@ccbReq_name", SqlDbType.NVarChar).Value = CCBReq_name.Text;
                com.Parameters.Add("@ccbReq_netid", SqlDbType.NVarChar).Value = CCBReqnetid.Text;
                com.Parameters.Add("@ccbReq_email", SqlDbType.NVarChar).Value = CCBReq_email.Text;
                com.Parameters.Add("@ccbReq_ext", SqlDbType.NVarChar).Value = CCBReq_ext.Text;
                com.Parameters.Add("@ccbReq_dept", SqlDbType.NVarChar).Value = CCBReq_dept.Text;
                com.Parameters.Add("@ccbReq_location", SqlDbType.NVarChar).Value = CCBLocation.Text;
                com.Parameters.Add("@ccbReq_category", SqlDbType.Int).Value = catid;
                com.Parameters.Add("@ccbReq_type", SqlDbType.NVarChar).Value = Types;
                com.Parameters.Add("@ccbpiority", SqlDbType.Int).Value = CCBreq_priority.SelectedValue;
                com.Parameters.Add("@ccbchangetitle", SqlDbType.NVarChar).Value = CCBchangetitle.Text;
                com.Parameters.Add("@ccbcreated", SqlDbType.DateTime).Value = now;
                com.Parameters.Add("@ccbimplementation", SqlDbType.DateTime).Value = txtDate.Text;
                com.Parameters.Add("@ccb_description_impact", SqlDbType.NVarChar).Value = ccb_description_impact.Text;
                com.Parameters.Add("@ccb_implication_NMC", SqlDbType.NVarChar).Value = ccb_implication_NMC.Text;
                com.Parameters.Add("@ccb_ppi_up_downstrem", SqlDbType.NVarChar).Value = ccb_ppi_up_downstrem.Text;
                com.Parameters.Add("@ccb_cost_implications", SqlDbType.NVarChar).Value = ccb_cost_implications.Text;
                com.Parameters.Add("@ccbsop", SqlDbType.Int).Value = ccbsop.SelectedValue;
                com.Parameters.Add("@ccbtraining", SqlDbType.Int).Value = ccbtraining.SelectedValue;
                com.Parameters.Add("@ccbaxentis", SqlDbType.Int).Value = ccbaxentis.SelectedValue;
                com.Parameters.Add("@ccbvendorguide", SqlDbType.Int).Value = ccbvendorguide.SelectedValue;
                com.Parameters.Add("@ccbvendortraining", SqlDbType.Int).Value = ccbvendortraining.SelectedValue;
                com.Parameters.Add("@ccblistimpactsop", SqlDbType.NVarChar).Value = ccblistimpactsop.Text;
                com.Parameters.Add("@ccb_status", SqlDbType.Int).Value = stat;
                com.Parameters.Add("@username", SqlDbType.NVarChar).Value = username;
                com.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;

                conn.Open();
                com.ExecuteNonQuery();
                string idcat = com.Parameters["@id"].Value.ToString();
                int id = Convert.ToInt32(idcat);
                conn.Close();
                for (int i = 0; i < hfc.Count; i++)
                {
                    hpf = hfc[i];
                    if (hpf.ContentLength > 0)
                    {

                        string filePath = hpf.FileName;
                        string filename = System.IO.Path.GetFileName(filePath);
                        string ext = System.IO.Path.GetExtension(filename);
                        String path = "ccb_" + id + "_" + filename;
                        hpf.SaveAs(Server.MapPath("~/Files/") + path);
                        SqlCommand cone = conn.CreateCommand();
                        cone.CommandText = "INSERT INTO Files (File_Name,File_type,data,ccbid) VALUES (@Name, @type, @Data,@ccbid)"; //insert query for Files
                        cone.Parameters.AddWithValue("@Name", filename);//name of the file
                        cone.Parameters.AddWithValue("@type", ext);//file extion
                        cone.Parameters.AddWithValue("@Data", path);//file Path
                        cone.Parameters.AddWithValue("@ccbid", id);//Ticket_id
                        conn.Open();
                        cone.ExecuteNonQuery();// insert query for files is executed on For Loop
                        conn.Close();
                        CCBERROR.ForeColor = System.Drawing.Color.Green;
                        CCBERROR.Text = "File Uploaded Successfully :" + i; //if insert was success full.                                            

                    }
                    else
                    {
                        CCBERROR.ForeColor = System.Drawing.Color.Red;
                        CCBERROR.Text = "Please Select File";  //if file uploader has no file selected
                    }
                }
                conn.Open();
                String qryq = "select ccb_request_number from ccb_request where ccbid = @ccbid";
                SqlCommand cmd = new SqlCommand(qryq, conn);
                cmd.Parameters.Add("@ccbid", SqlDbType.Int).Value = id;
                cmd.CommandText = qryq;
                string ccbno = cmd.ExecuteScalar().ToString();
                conn.Close();
                myStringVariable = "CCB filed " + ccbno;                
                String ccb= "CCBRequest.aspx?ccbid=" + id;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('" + myStringVariable + "'); window.location='" + Request.ApplicationPath + ccb + "';", true);

            }           


        }

        protected void Calenbt_Click(object sender, ImageClickEventArgs e)
        {
            DateTime date = new DateTime();
            //Flip the visibility attribute
            this.cal1.Visible = !(this.cal1.Visible);
            //If the calendar is visible try assigning the date from the textbox
            if (this.cal1.Visible)
            {
                //If the Conversion was successfull assign the textbox's date
                if (DateTime.TryParse(txtDate.Text, out date))
                {
                    cal1.SelectedDate = date;
                }
                this.cal1.Attributes.Add("style", "POSITION: absolute");
            }
        }

        protected void cal1_SelectionChanged(object sender, EventArgs e)
        {
            txtDate.Text = this.cal1.SelectedDate.Date.ToString();
            this.cal1.Visible = false;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select File_Name,File_type,data from Template where File_id=@id", conn);
            cmd.Parameters.AddWithValue("id", GridView1.SelectedRow.Cells[1].Text);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                string path = Server.MapPath("~/Template/") + dr["data"].ToString(); //get file object as FileInfo  
                Response.Clear();
                System.IO.FileInfo file = new System.IO.FileInfo(path); //-- if the file exists on the server  
                // to open file prompt Box open or Save file
                Response.AddHeader("Content-Disposition", "attachment; filename=" + dr["File_Name"].ToString());
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/vnd.ms-excel";
                Response.WriteFile(path);//File open
                Response.Flush();
                //context.Response.Close();               
                Response.End();
            }

        }

        protected void CCBReq_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Types;

            if (CCBReq_type.sValue == "")
            {
                Types = CCBReq_type.allsValue;
            }
            else
            {
                Types = CCBReq_type.sValue;
            }
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            GridView1.Visible = true;
            String query = "Select File_id,File_Name from Template where Request_id in @Requestid";
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            SqlCommand CMD = new SqlCommand(query, conn);
            CMD.Parameters.Add("@Requestid", SqlDbType.Int).Value = Types;
            da.SelectCommand = CMD;
            da.Fill(ds, "Files");
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            conn.Close();
        }
    }
}