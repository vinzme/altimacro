﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mail;
using System.Data.SqlClient;
using System.Data;

namespace VMS_SUPPORT
{
    public partial class CCBRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();

                if (Request.QueryString["str"] == "Search")
                {


                }
                else
                {
                    SqlDataReader rdr = null;

                    String qry = "SELECT ccbr.ccbReq_name[RequestorName], ccbr.ccbReq_netid[RequestorNetworkid],ccbr.ccbReq_email[RequestorEmail],ccbr.ccbReq_ext[RequestorExt],ccbr.ccbReq_dept[RequestorDepartment],ccbr.ccbReq_location[Location],cate.Category_Name[RequestorCategory],stuff((select Request_type+',' from Request1 where  Request_id in (SELECT * FROM dbo.split(ccbr.vms_request_types)) for xml path('') ), 1, 0, '' )  as [Requestortype],pior.ccbpiority[Piority],ccbr.ccbchangetitle[ChangeTitle],ccbr.ccbcreated[Created],ccbr.ccbimplementation[Implementation],ccbr.ccb_description_impact[Descriptionimpact],ccbr.ccb_implication_NMC[ImplicationChange],ccbr.ccb_ppi_up_downstrem[PPIUpstream],ccbr.ccb_cost_implications[Cost],case when ccbr.ccbsop=1 then 'Yes' else 'No'end[SOP], case when ccbr.ccbtraining=1 then 'Yes' else 'No'end [TrainingSession],case when ccbr.ccbaxentis=1 then 'Yes' else 'No'end[Axentis], case when ccbr.ccbvendorguide=1 then 'Yes' else 'No'end [VendorGuide],case when ccbr.ccbvendortraining=1 then 'Yes' else 'No'end [VendorTraining], ccbr.ccblistimpactsop[ListImpacted],ccbr.ccb_request_number [ChangeRequestNumber],ccbst.ccbstatus[ChangerequestStatus] FROM ccb_request ccbr(nolock) join Category cate(nolock)on cate.Category_id=ccbr.ccbReq_category join ref_ccbstatus ccbst(nolock)on ccbst.ccbstatus_id=ccbr.ccb_status join ref_piority pior (nolock)on pior.piority_id=ccbr.ccbpiority WHERE ([ccbid] = @ccbid)";
                    SqlCommand cmd = new SqlCommand(qry, conn);
                    cmd.Parameters.Add("@ccbid", SqlDbType.Int).Value = Request.QueryString["ccbid"];
                    cmd.CommandText = qry;
                    try
                    {
                        conn.Open();
                        rdr = cmd.ExecuteReader();

                        while (rdr.Read())
                        {
                            String RequestorName = rdr["RequestorName"].ToString();
                            String RequestorNetworkid = rdr["RequestorNetworkid"].ToString();
                            String RequestorEmail = rdr["RequestorEmail"].ToString();
                            String RequestorExt = rdr["RequestorExt"].ToString();
                            String RequestorDepartment = rdr["RequestorDepartment"].ToString();
                            String Location = rdr["Location"].ToString();
                            String RequestorCategory = rdr["RequestorCategory"].ToString();
                            String Requestortype = rdr["Requestortype"].ToString();
                            String Piority = rdr["Piority"].ToString();
                            String ChangeTitle = rdr["ChangeTitle"].ToString();
                            String Created = rdr["Created"].ToString();
                            String ImplementationDate = rdr["Implementation"].ToString();
                            String Descriptionimpact = rdr["Descriptionimpact"].ToString();
                            String ImplicationofNotMakingChange = rdr["ImplicationChange"].ToString();
                            String PPIUpstreamDownstreamImpacts = rdr["PPIUpstream"].ToString();
                            String CostImplications = rdr["Cost"].ToString();
                            String SOP = rdr["SOP"].ToString();
                            String TrainingSession = rdr["TrainingSession"].ToString();
                            String Axentis = rdr["Axentis"].ToString();
                            String VendorGuide = rdr["VendorGuide"].ToString();
                            String VendorTraining = rdr["VendorTraining"].ToString();
                            String ListImpactedSOP = rdr["ListImpacted"].ToString();
                            String ChangeRequestNumber = rdr["ChangeRequestNumber"].ToString();
                            String ChangerequestStatus = rdr["ChangerequestStatus"].ToString();
                            MailMessage Msg = new MailMessage();
                            Msg.From = "Ronald.Priest@altisource.com";
                            Msg.To = RequestorEmail;
                            Msg.Subject = "VMS Change Request/Incident :: Change Request # " + ChangeRequestNumber;
                            Msg.Cc = "Ronald.Priest@altisource.com;Akshay.Samuel@altisource.com";
                            Msg.BodyFormat = MailFormat.Html;
                            Msg.Body = "<p class=MsoNormal><span lang=EN-US style='mso-ansi-language:EN-US'>Greetings <o:p></o:p></span></p> <p class=MsoNormal><span lang=EN-US style='mso-ansi-language:EN-US'><br> This is an automated response, please don't reply back.<o:p></o:p></span></p> <p class=MsoNormal><span lang=EN-US style='mso-ansi-language:EN-US'><br> We are in receipt of your Change Request which will be reviewed &nbsp;by the board this coming Friday. We will keep you notified in case there are changes to the schedule and if we require additional information.<o:p></o:p></span></p>" +

                                "<Table> " +
                                "<tr><td>Change Request Number :</td> <td>" + ChangeRequestNumber + "</td></tr>" +
                               "<tr><td>Requestor Name :</td> <td>" + RequestorName + "</td></tr>" +
                                "<tr><td>Requestor Network id :</td> <td>" + RequestorNetworkid + "</td></tr>" +
                                "<tr><td>Requestor Email :</td> <td>" + RequestorEmail + "</td></tr>" +
                                "<tr><td>Requestor Ext :</td> <td>" + RequestorExt + "</td></tr>" +
                                "<tr><td>Requestor Department :</td> <td>" + RequestorDepartment + "</td></tr>" +
                                "<tr><td>Location  : </td> <td>" + Location + "</td></tr>" +
                                "<tr><td>Requestor Category :</td> <td>" + RequestorCategory + "</td></tr>" +
                                "<tr><td>Requestor type :</td> <td>" + Requestortype + "</td></tr>" +
                                "<tr><td>Piority :</td> <td>" + Piority + "</td></tr>" +
                                "<tr><td>Change Title :</td> <td>" + ChangeTitle + "</td></tr>" +
                                "<tr><td>Created :</td> <td>" + Created + "</td></tr>" +
                                "<tr><td>Implementation Date :</td> <td>" + ImplementationDate + "</td></tr>" +
                                 "<tr><td>Change Description and Impact :</td> <td>" + Descriptionimpact + "</td></tr>" +
                                "<tr><td>Implication of Not Making Change  : </td> <td>" + ImplicationofNotMakingChange + "</td></tr>" +
                                "<tr><td>PPI & Upstream/Downstream Impacts :</td> <td>" + PPIUpstreamDownstreamImpacts + "</td></tr>" +
                                "<tr><td>Cost Implications :</td> <td>" + CostImplications + "</td></tr>" +
                                "<tr><td>SOP</td> <td>" + SOP + "</td></tr>" +
                                "<tr><td>Training Session (Associates)</td> <td>" + TrainingSession + "</td></tr>" +
                                "<tr><td>Axentis</td> <td>" + Axentis + "</td></tr>" +
                                "<tr><td>Vendor Guide</td> <td>" + VendorGuide + "</td></tr>" +
                                "<tr><td>Vendor Training</td> <td>" + VendorTraining + "</td></tr>" +
                                "<tr><td>List Impacted SOP's</td> <td>" + ListImpactedSOP + "</td></tr>" +
                                "<tr><td>Change request Status</td> <td>" + ChangerequestStatus + "</td></tr>" +
                              " </Table>" + "</br></br>For Immediate assistance please reach out to Ronald.priest@altisource.com Extn: 254907 or Akshay.samuel@altisource.com Extn: 297248 </br> Warm Regards,</br> Change Control Coordinator";
                            SmtpMail.SmtpServer = "Internal-Mail.ascorp.com";
                            SmtpMail.Send(Msg);
                            Msg = null;
                        }

                    }
                    finally
                    {
                        if (rdr != null)
                        {
                            rdr.Close();// close the reader
                        }

                        if (conn != null)
                        {
                            conn.Close();// close the connection
                        }
                    }


                }

                GridView1.Visible = true;
                String query = "Select File_Name[File Name] from Files where ccbid=@ccbid order by File_id desc";
                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();
                SqlCommand CMDg = new SqlCommand(query, conn);
                CMDg.Parameters.Add("@ccbid", SqlDbType.Int).Value = Request.QueryString["ccbid"];
                da.SelectCommand = CMDg;
                da.Fill(ds, "Files");
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
            }

        }
    }
}