﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using OfficeOpenXml;


namespace VMS_SUPPORT
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlDataReader Reader = null;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String Query = "Select report_name,report_query,report_path,Date_Source,Initial_Catalog,User_ID,Password from ref_report";
            SqlCommand cmd = new SqlCommand(Query, conn);
            conn.Open();
            Reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (Reader.HasRows)
            {
                dt.Reset();
                dt.Load(Reader);
            }

            foreach (DataRow rw in dt.Rows)
            {
                String name = rw["report_name"].ToString();
                String qry = rw["report_query"].ToString();
                String path = rw["report_path"].ToString() + name + ".xlsx"; 
                string constr = "Data Source=" + rw["Date_Source"].ToString() + ";Initial Catalog=" + rw["Initial_Catalog"].ToString() +";User ID=" + rw["User_ID"].ToString() + ";Password=" + rw["Password"].ToString();
                 runquery(qry, name, constr, path);                    
            }
            
            

        }


        public static void runquery(string Query, string name, string constr, string path)
        {
               
            SqlDataReader Reader = null;
            SqlConnection conn = new SqlConnection(constr);  
            String qry = Query;
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.CommandTimeout = 0;
            conn.Open();
            Reader = cmd.ExecuteReader();
            DataTable trans = new DataTable();
            if (Reader.HasRows)
            {
                trans.Reset();
                trans.Load(Reader);
            }
            DataTable inputTable = trans;
                     
            //MemoryStream ms = 
            DataTableToExcelXlsx(trans, "Sheet1", path);
            //HttpContext context = HttpContext.Current;
            //ms.WriteTo(context.Response.OutputStream);
            //context.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            //context.Response.AddHeader("Content-Disposition", "attachment;filename=EasyEditCmsGridData.xlsx");
            //context.Response.StatusCode = 200;
            //context.Response.End();               
            conn.Close();
        }


        public static void DataTableToExcelXlsx(DataTable table, string sheetName, string path)
        {
            //MemoryStream Result = new MemoryStream();
            FileInfo newFile = new FileInfo(@path);             
            ExcelPackage pack = new ExcelPackage(newFile);
            ExcelWorksheet ws = pack.Workbook.Worksheets.Add(sheetName);
            int col = 1;
            int row = 1;
            foreach (DataColumn c in table.Columns)
            {                
                ws.Cells[row, col].Value = c.ColumnName;
                col++;
            }
            row++;
            col = 1;            
            
            foreach (DataRow rw in table.Rows)
            {
                foreach (DataColumn cl in table.Columns)
                {
                    if (rw[cl.ColumnName] != DBNull.Value)
                        ws.Cells[row, col].Value = rw[cl.ColumnName].ToString();
                    col++;
                }
                row++;
                col = 1;
            }
            pack.Save();
            
            //pack.SaveAs(Result);
            //return Result;
        }

        

    }
}