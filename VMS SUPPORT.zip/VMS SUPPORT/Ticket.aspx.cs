﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.DirectoryServices;
    using System.DirectoryServices.ActiveDirectory;
    using System.DirectoryServices.AccountManagement;
    using System.Windows.Forms;
    using System.Configuration;

namespace VMS_SUPPORT.Ticketlog
{
    public partial class Ticket : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                string catid = Request.QueryString["str"];//To get the Category
                int id = Int32.Parse(catid);
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                String qry = "select Category_Name from Category where Category_id = @category";
                SqlCommand cmd = new SqlCommand(qry, conn);
                cmd.Parameters.Add("@category", SqlDbType.Int).Value = id;
                cmd.CommandText = qry;
                string cate = cmd.ExecuteScalar().ToString();
                TXTReq_category.Text = cate;
                //AD information of user//
                string s = HttpContext.Current.User.Identity.Name;
                string username = s.Substring(s.IndexOf(@"\") + 1);
                string[] domain = s.Split('\\');
                string Department, TELE;

                txtReqnetid.Text = username;
                string connection;
                if (domain[0] == "ASCORP")
                {

                    connection = ConfigurationManager.ConnectionStrings["Ascorp"].ToString();
                }
                else
                {
                    connection = ConfigurationManager.ConnectionStrings["corp"].ToString();

                }
                DirectoryEntry de = new DirectoryEntry();
                de.Path = connection;
                DirectorySearcher dssearch = new DirectorySearcher();
                dssearch.SearchRoot = de;
                dssearch.Filter = "(sAMAccountName=" + username + ")";
                SearchResult sresult = dssearch.FindOne();
                DirectoryEntry dsresult = sresult.GetDirectoryEntry();

                if (dsresult.Properties.Contains("displayName"))
                {
                    txtReq_name.Text = dsresult.Properties["displayName"][0].ToString();
                }
                else
                {
                    txtReq_name.Text = "";
                }

                if (dsresult.Properties.Contains("department"))
                {
                    String Depart = dsresult.Properties["department"][0].ToString();
                    Department = Depart.Substring(Depart.IndexOf(@"-") + 1);
                }
                else
                {
                    Department = "";
                }
                if (dsresult.Properties.Contains("mail"))
                {
                    txtReq_email.Text = dsresult.Properties["mail"][0].ToString();
                }
                else
                {
                    txtReq_email.Text = "";
                }
                if (dsresult.Properties.Contains("telephoneNumber"))
                {
                    String TELEP = dsresult.Properties["telephoneNumber"][0].ToString();
                    TELE = TELEP;
                    
                }
                else
                {
                    TELE = "";
                   
                }

                txtReq_ext.Text = TELE;
                txtReq_dept.Text = Department;
                //Populating The Type Drop down.
                txtReq_type.Items.Insert(0, "Select");
                SqlDataReader reader;
                String qury = "select * from Request1 where Request_category = @Req_category  order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.Parameters.Add("@Req_category", SqlDbType.Int).Value = id;
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                txtReq_type.DataSource = reader;
                txtReq_type.DataValueField = "Request_id";
                txtReq_type.DataTextField = "Request_type";
                txtReq_type.DataBind();
                txtReq_type.SelectedIndex = 0;
            }
        }




        protected void txtReq_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtReq_type.SelectedItem.Text == "Select")
            {
                lbletadate.Text = "";
            }
            else
            {
                SqlDataReader rdr = null;
                String ReportName = txtReq_type.SelectedValue;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                SqlCommand SLCOM = new SqlCommand("[dbo].[SLA]", conn);
                SLCOM.CommandType = System.Data.CommandType.StoredProcedure;
                SLCOM.Parameters.Add("@category", SqlDbType.Int).Value = txtReq_type.SelectedValue;
                try
                {
                    conn.Open();
                    rdr = SLCOM.ExecuteReader();
                    while (rdr.Read())
                    {
                        string SLAVA = rdr["SLA"].ToString();
                        int SLAVAL = Convert.ToInt32(SLAVA);
                        string Rep1 = rdr["Representative"].ToString();
                        string BackUpRep1 = rdr["BackUpRepresentative"].ToString();
                        Session["Rep"] = Rep1;
                        Session["BackUpRep"] = BackUpRep1;
                        Session["statusd"] = rdr["is_default_training"].ToString();//Added for default status
                        DateTime fromDate = DateTime.Now;
                        DateTime toDate = fromDate.AddDays(SLAVAL);
                        var weekendDayCount = 0;

                        while (fromDate < toDate)
                        {
                            fromDate = fromDate.AddDays(1);
                            if (fromDate.DayOfWeek == DayOfWeek.Saturday || fromDate.DayOfWeek == DayOfWeek.Sunday)
                            {
                                ++weekendDayCount;
                            }
                        }

                        DateTime ETA = toDate.AddDays(weekendDayCount);

                        if (ETA.DayOfWeek == DayOfWeek.Saturday)
                        {
                            ETA = ETA.AddDays(2);
                        }
                        else
                            if (ETA.DayOfWeek == DayOfWeek.Sunday)
                            {
                                ETA = ETA.AddDays(1);
                            }

                        lbletadate.Text = ETA.ToString();
                    }
                    rdr.Close();
                    GridView1.Visible = true;
                    String query = "Select File_id,File_Name from Template where Request_id=@Requestid";
                    SqlDataAdapter da = new SqlDataAdapter();
                    DataSet ds = new DataSet();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@Requestid", SqlDbType.Int).Value = txtReq_type.SelectedValue;
                    da.SelectCommand = CMD;
                    da.Fill(ds, "Files");
                    GridView1.DataSource = ds.Tables[0];
                    GridView1.DataBind();
                }
                finally
                {
                    if (rdr != null)
                    {
                        rdr.Close();// close the reader
                    }

                    if (conn != null)
                    {
                        conn.Close();// close the connection
                    }
                }
            }
        }

        public object filename { get; set; }


        protected void btnsubmit_Click(object sender, EventArgs e)
        {

            HttpFileCollection hfc = HttpContext.Current.Request.Files;
            HttpPostedFile hpf;
            if (txtReq_type.SelectedItem.Text == "Select" || txtreq_priority.SelectedItem.Text == "Select" || txtReq_comments.Text == "" || txtReq_ext.Text == "" || txtReq_approved.Text == "")
            {
                string myStringVariable = "All Fields Are Mandatory";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);

            }
            else
            {

                //Saving Ticket
                int stat;
                string catid = Request.QueryString["str"];
                String rep = Session["Rep"].ToString();
                String BackUpRepresentative = Session["BackUpRep"].ToString();
                int statusto = Convert.ToInt16(Session["statusd"]);
                switch (statusto)
                {
                    case 1: stat = 8;
                        break;
                    default: stat = 1;
                        break;
                }
                DateTime now = DateTime.Now;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                SqlCommand com = new SqlCommand("SPtblticket", conn);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.Add("@Req_name", SqlDbType.NVarChar).Value = txtReq_name.Text;
                com.Parameters.Add("@Req_netid", SqlDbType.NVarChar).Value = txtReqnetid.Text;
                com.Parameters.Add("@Req_email", SqlDbType.NVarChar).Value = txtReq_email.Text;
                com.Parameters.Add("@Req_ext", SqlDbType.NVarChar).Value = txtReq_ext.Text;
                com.Parameters.Add("@Req_dept", SqlDbType.NVarChar).Value = txtReq_dept.Text;
                com.Parameters.Add("@Req_approved", SqlDbType.NVarChar).Value = txtReq_approved.Text;
                com.Parameters.Add("@Req_category", SqlDbType.Int).Value = catid;
                com.Parameters.Add("@Req_type", SqlDbType.Int).Value = txtReq_type.SelectedValue;
                com.Parameters.Add("@Req_comments", SqlDbType.NVarChar).Value = txtReq_comments.Text;
                com.Parameters.Add("@created", SqlDbType.DateTime).Value = now;
                com.Parameters.Add("@ETA_date", SqlDbType.DateTime).Value = lbletadate.Text;
                com.Parameters.Add("@Piority", SqlDbType.NVarChar).Value = txtreq_priority.SelectedValue;
                com.Parameters.Add("@Representative", SqlDbType.Int).Value = rep;
                com.Parameters.AddWithValue("@BackupRepresentative", SqlDbType.Int).Value = BackUpRepresentative;
                com.Parameters.AddWithValue("@Status", stat);
                com.Parameters.AddWithValue("@Last_updated_by", SqlDbType.NVarChar).Value = txtReqnetid.Text;
                com.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;
                conn.Open();
                com.ExecuteNonQuery();
                string idcat = com.Parameters["@id"].Value.ToString();
                int id = Convert.ToInt32(idcat);
                conn.Close();
                for (int i = 0; i < hfc.Count; i++)
                {
                    hpf = hfc[i];
                    if (hpf.ContentLength > 0)
                    {

                        string filePath = hpf.FileName;
                        string filename = System.IO.Path.GetFileName(filePath);
                        string ext = System.IO.Path.GetExtension(filename);
                        hpf.SaveAs(Server.MapPath("~/Files/") + id + filename);
                        String path = id + filename;
                        SqlCommand cone = conn.CreateCommand();
                        cone.CommandText = "INSERT INTO Files (File_Name,File_type,data,Ticket_id) VALUES (@Name, @type, @Data,@Ticket_id)"; //insert query for Files
                        cone.Parameters.AddWithValue("@Name", filename);//name of the file
                        cone.Parameters.AddWithValue("@type", ext);//file extion
                        cone.Parameters.AddWithValue("@Data", path);//file Path
                        cone.Parameters.AddWithValue("@Ticket_id", id);//Ticket_id
                        conn.Open();
                        cone.ExecuteNonQuery();// insert query for files is executed on For Loop
                        conn.Close();
                        fileerr.ForeColor = System.Drawing.Color.Green;
                        fileerr.Text = "File Uploaded Successfully :" + i; //if insert was success full.                                            

                    }
                    else
                    {
                        fileerr.ForeColor = System.Drawing.Color.Red;
                        fileerr.Text = "Please Select File";  //if file uploader has no file selected
                    }
                }

                Response.Redirect("ticketview.aspx?name=" + id); // Redirect when all files have been updated sucesfully.
            }


        }


        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select File_Name,File_type,data from Template where File_id=@id", conn);
            cmd.Parameters.AddWithValue("id", GridView1.SelectedRow.Cells[1].Text);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                string path = Server.MapPath("~/Template/") + dr["data"].ToString(); //get file object as FileInfo  
                Response.Clear();
                System.IO.FileInfo file = new System.IO.FileInfo(path); //-- if the file exists on the server  
                // to open file prompt Box open or Save file
                Response.AddHeader("Content-Disposition", "attachment; filename=" + dr["File_Name"].ToString());
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/vnd.ms-excel";
                Response.WriteFile(path);//File open
                Response.Flush();
                //context.Response.Close();               
                Response.End();
            }

        }

    }
}


     
        
