﻿using System;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.Web.UI.HtmlControls;

namespace VMS_SUPPORT.MS_Control
{
    public partial class WebUserControl1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hdnpostback.Value = "1";
            }
            else
            {
                hdnpostback.Value = "0";
            }

            LoadJScript();
            LoadCss();
            //add attributes
            CheckBoxlistCtrl1.Attributes.Add("onclick", "readCheckBoxList('" + CheckBoxlistCtrl1.ClientID + "','" + MultiSelectDDL.ClientID + "','" + hf_checkBoxText.ClientID + "','" + hf_checkBoxValue.ClientID + "','" + hf_checkBoxSelIndex.ClientID + "');");
            MultiSelectDDL.Attributes.Add("onmousemove", "showIE6Tooltip();");
            MultiSelectDDL.Attributes.Add("onmouseout", "hideIE6Tooltip();");

            if (!string.IsNullOrEmpty(hf_checkBoxValue.Value))
            {
                SetDropDownListText(hf_checkBoxText.Value);
            }
            else
            {
                SetDropDownListText("All");
            }


            if (!string.IsNullOrEmpty(hf_checkBoxText.Value))
            {
                SetToolTip(hf_checkBoxText.Value);
            }
            else
            {
                SetToolTip("All");
            }

        }
        //load style css
        internal void LoadCss()
        {
            //prevent loading multiple css style sheet
            HtmlControl css = null;
            if (Session["MultipleSelectionDDLCSSID"] != null)
            {
                css = Page.Header.FindControl(Session["MultipleSelectionDDLCSSID"] as string) as HtmlControl;
            }

            if (css == null)
            {
                //load the style sheet
                HtmlLink cssLink = new HtmlLink();
                cssLink.ID = "MultipleSelectionDDLCSSID";
                cssLink.Href = ResolveUrl("~/MS_Control/MultipleSelectionDDLCSS.css");

                cssLink.Attributes.Add("rel", "stylesheet");
                cssLink.Attributes.Add("type", "text/css");

                // Add the HtmlLink to the Head section of the page.
                Page.Header.Controls.Add(cssLink);

                Session["MultipleSelectionDDLCSSID"] = cssLink.ID;
            }
        }
        //load the javascript
        internal void LoadJScript()
        {
            ClientScriptManager script = Page.ClientScript;
            //prevent duplicate script
            if (!script.IsStartupScriptRegistered(this.GetType(), "MultipleSelectionDDLJS"))
            {
                script.RegisterStartupScript(this.GetType(), "MultipleSelectionDDLJS",
                "<script type='text/javascript' src='" + ResolveUrl("~/MS_Control/MultipleSelectionDDLJS.js") + "'></script>");
            }
        }
        //selected checkbox value
        public string sValue
        {
            get { return hf_checkBoxValue.Value; }
        }
           public string allsValue
        {
            get { return hf_checkBoxallValue.Value; }
        }

        
        //selected checkbox text
        public string sText
        {
            get { return hf_checkBoxText.Value; }
        }
        //selected checkbox text
        public string selectedIndex
        {
            get { return hf_checkBoxSelIndex.Value; }
            set { SetCheckBoxList(value); }
        }
        public DropDownList dropdownlist
        {
            get
            {
                return MultiSelectDDL;
            }
        }
        public CheckBoxlistCtrl.CheckBoxlistCtrl checkboxlist
        {
            get
            {
                return CheckBoxlistCtrl1;
            }
        }

        public void CreateCheckBox(DataTable dt, string dataTextField, string dataValueField, int PageId)
        {
            CheckBoxlistCtrl1.DataSource = dt;
            CheckBoxlistCtrl1.DataTextField = dataTextField; // "Text";
            CheckBoxlistCtrl1.DataValueField = dataValueField;// "Value";
            CheckBoxlistCtrl1.DataBind();
            CheckBoxlistCtrl1.Items.Insert(0, new ListItem("All", "0"));
            CheckBoxlistCtrl1.Style.Add("nowrap", "nowrap");
            foreach (ListItem lt in CheckBoxlistCtrl1.Items)
            {
                if (PageId != 0 && PageId != -1)
                {
                    lt.Selected = true;
                    if (lt.Selected)
                    {
                        if (Convert.ToString(hf_checkBoxValue.Value) == string.Empty)
                        {
                            hf_checkBoxValue.Value = lt.Value;
                            hf_checkBoxallValue.Value = lt.Value;
                        }
                        else
                        {
                            hf_checkBoxValue.Value += "," + lt.Value;
                            hf_checkBoxallValue.Value += "," + lt.Value;
                        }
                        if (Convert.ToString(hf_checkBoxText.Value) == string.Empty)
                        {
                            hf_checkBoxText.Value = lt.Text;
                        }
                        else
                        {
                            hf_checkBoxText.Value += "," + lt.Text;
                        }                       
                    }
                }
                    
                else if (PageId != -1)
                {
                    lt.Selected = true;
                }
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Showpopup" + CheckBoxlistCtrl1.ClientID, "readCheckBoxList('" +
                       CheckBoxlistCtrl1.ClientID + "','" + MultiSelectDDL.ClientID + "','" +
                       hf_checkBoxText.ClientID + "','" +
                       hf_checkBoxValue.ClientID + "','" + hf_checkBoxSelIndex.ClientID + "');", true);
            
        }

      

        public void EmptyCheckBox()
        {
            try
            {
                CheckBoxlistCtrl1.DataSource = string.Empty;
                CheckBoxlistCtrl1.DataBind();
                CheckBoxlistCtrl1.Items.Insert(0, new ListItem("All", "0"));
                if (string.IsNullOrEmpty(Convert.ToString(MultiSelectDDL.Items.FindByText("All"))))
                {
                    MultiSelectDDL.Items.Insert(0, new ListItem("All", "0"));
                }
                SetToolTip("All");
                
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        internal void SetDropDownListText(string txt)
        {
            MultiSelectDDL.Items.Clear();
            MultiSelectDDL.Items.Add(new ListItem(txt));
        }

        internal void SetToolTip(string title)
        {
            MultiSelectDDL.Attributes.Add("title", title);
        }

        //check the checkboxlist
        public void SetCheckBoxList(string index)
        {
            string[] strArray;
            strArray = index.Split(@",".ToCharArray());
            string chkBoxIndex = string.Empty;
            string chkBoxValue = string.Empty;
            string chkBoxText = string.Empty;
            if (strArray.Length > 0)
            {
                int result;
                foreach (string s in strArray)
                {
                    result = 0;

                    if (int.TryParse(s, out result))
                    {
                        CheckBoxlistCtrl1.Items[result].Selected = true;

                        //index
                        if (chkBoxIndex.Length > 0)
                            chkBoxIndex += ", ";

                        chkBoxIndex += result.ToString();

                        //value
                        if (chkBoxValue.Length > 0)
                            chkBoxValue += ", ";

                        chkBoxValue += CheckBoxlistCtrl1.Items[result].Value;

                        //text
                        if (chkBoxText.Length > 0)
                            chkBoxText += ", ";

                        chkBoxText += CheckBoxlistCtrl1.Items[result].Text;

                    }
                }

                SetDropDownListText(chkBoxText);
                SetToolTip(chkBoxText);
                hf_checkBoxSelIndex.Value = chkBoxIndex;
                hf_checkBoxText.Value = chkBoxText;
                hf_checkBoxValue.Value = chkBoxValue;
            }
        }

        public void SetAloneCheckBoxList(string index)
        {
            string[] Status = index.Split(',');
            for (int i = 0; i < Status.Length; i++)
            {
                Status[i] = Status[i].Trim();
            }
            hf_checkBoxValue.Value = string.Empty;
            hf_checkBoxText.Value = string.Empty;
            foreach (ListItem lt in CheckBoxlistCtrl1.Items)
            {

                lt.Selected = Status.Contains(lt.Value);
                if (lt.Selected)
                {
                    if (Convert.ToString(hf_checkBoxValue.Value) == string.Empty)
                    {
                        hf_checkBoxValue.Value = lt.Value;
                    }
                    else
                    {
                        hf_checkBoxValue.Value += "," + lt.Value;
                    }
                    if (Convert.ToString(hf_checkBoxText.Value) == string.Empty)
                    {
                        hf_checkBoxText.Value = lt.Text;
                    }
                    else
                    {
                        hf_checkBoxText.Value += "," + lt.Text;
                    }
                }
            }
            SetDropDownListText(hf_checkBoxText.Value);
            SetToolTip(hf_checkBoxText.Value);
        }

        public void SetAloneCheckBoxList(string[] Status)
        {
            for (int i = 0; i < Status.Length; i++)
            {
                Status[i] = Status[i].Trim();
                Status[i] = Status[i].ToUpper();
            }
            hf_checkBoxValue.Value = string.Empty;
            hf_checkBoxText.Value = string.Empty;
            foreach (ListItem lt in CheckBoxlistCtrl1.Items)
            {

                lt.Selected = Status.Contains(lt.Text.ToUpper());
                if (lt.Selected)
                {
                    if (Convert.ToString(hf_checkBoxValue.Value) == string.Empty)
                    {
                        hf_checkBoxValue.Value = lt.Value;
                    }
                    else
                    {
                        hf_checkBoxValue.Value += "," + lt.Value;
                    }
                    if (Convert.ToString(hf_checkBoxText.Value) == string.Empty)
                    {
                        hf_checkBoxText.Value = lt.Text;
                    }
                    else
                    {
                        hf_checkBoxText.Value += "," + lt.Text;
                    }
                }
            }
            SetDropDownListText(hf_checkBoxText.Value);
            SetToolTip(hf_checkBoxText.Value);
        }

        public short TabIndexForDropdown
        {
            set { MultiSelectDDL.TabIndex = value; }
        }
        public Boolean Enabled
        {
            get { return Convert.ToBoolean(MultiSelectDDL.Enabled); }
            set { MultiSelectDDL.Enabled = value; }
        }

        //public int Width
        //{
        //    set
        //    {
        //        MultiSelectDDL.Width = Unit.Pixel(value);
        //        if (value < 90)
        //        {
        //            divContainer.Style.Add("width", Unit.Pixel(value).ToString());
        //            PanelPopUp_.Width = Unit.Pixel(value - 2);
        //        }
        //        else
        //            PanelPopUp_.Width = Unit.Pixel(value - 2);
        //    }
        //    get
        //    {
        //        return Convert.ToInt32(MultiSelectDDL.Width);
        //    }
        //}

        public void SetCheckBoxListValue(string value)
        {
            string[] strArray;
            strArray = value.Split(@",".ToCharArray());
            string chkBoxIndex = string.Empty;
            string chkBoxValue = string.Empty;
            string chkBoxText = string.Empty;
            for (int j = 0; j < CheckBoxlistCtrl1.Items.Count; j++)
            {
                CheckBoxlistCtrl1.Items[j].Selected = false;
            }
            if (strArray.Length > 0)
            {
                int result;
                foreach (string s in strArray)
                {
                    result = 0;

                    if (int.TryParse(s, out result))
                    {
                        for (int j = 0; j < CheckBoxlistCtrl1.Items.Count; j++)
                        {
                            if (Convert.ToInt32(CheckBoxlistCtrl1.Items[j].Value) == result)
                            {
                                CheckBoxlistCtrl1.Items[j].Selected = true;
                                //index
                                if (chkBoxIndex.Length > 0)
                                    chkBoxIndex += ", ";

                                chkBoxIndex += result.ToString();

                                //value
                                if (chkBoxValue.Length > 0)
                                    chkBoxValue += ", ";

                                chkBoxValue += CheckBoxlistCtrl1.Items[j].Value;

                                //text
                                if (chkBoxText.Length > 0)
                                    chkBoxText += ", ";

                                chkBoxText += CheckBoxlistCtrl1.Items[j].Text;
                            }
                        }
                    }
                }

                SetDropDownListText(chkBoxText);
                SetToolTip(chkBoxText);
                hf_checkBoxSelIndex.Value = chkBoxIndex;
                hf_checkBoxText.Value = chkBoxText;
                hf_checkBoxValue.Value = chkBoxValue;
            }
        }

        public void RemoveCheckBoxListValue(string value)
        {
           
                int j = 1;
                while (0 < CheckBoxlistCtrl1.Items.Count)
                {
                    if (j < CheckBoxlistCtrl1.Items.Count)
                    {
                        if (CheckBoxlistCtrl1.Items[j].Selected == false)
                        {
                            CheckBoxlistCtrl1.Items.Remove(CheckBoxlistCtrl1.Items[j]);
                            j = 1;
                        }
                        else
                        {
                            j = j + 1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }

      
           
        }

    }
