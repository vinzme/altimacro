﻿/*
09042009 Bryian Tan.
*/

/*detect the browser version and name*/
var Browser = {
    Version: function () {
        var version = 999; // we assume a sane browser
        if (navigator.appVersion.indexOf("MSIE") != -1)
        // bah, IE again, lets downgrade version number
            version = parseFloat(navigator.appVersion.split("MSIE")[1]);
        return version;
    }
}

function showIE6Tooltip(e) {
    //we only want this to execute if ie6
    if (navigator.appName == 'Microsoft Internet Explorer' && Browser.Version() == 6) {
        if (!e) { var e = window.event; }
        var obj = e.srcElement;

        tempX = event.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft);
        tempY = event.clientY + (document.documentElement.scrollTop || document.body.scrollTop);

        var tooltip = document.getElementById('ie6SelectTooltip');
        tooltip.innerHTML = obj.options.title; //set the title to the div
        //display the tooltip based on the mouse location
        tooltip.style.left = tempX;
        tooltip.style.top = tempY + 10;
        tooltip.style.width = '100%';
        tooltip.style.display = 'block';
    }
}
function hideIE6Tooltip(e) {
    //we only want this to execute if ie6
    if (navigator.appName == 'Microsoft Internet Explorer' && Browser.Version() == 6) {
        var tooltip = document.getElementById('ie6SelectTooltip');
        tooltip.innerHTML = '';
        tooltip.style.display = 'none';
    }
}

function getCheckBoxListItemsChecked(elementId, checkValue) {
    //var
    var elementRef = document.getElementById(elementId);
    var checkBoxArray = elementRef.getElementsByTagName('input');
    var checkedValues = '';
    var checkedText = '';
    var checkedSelIndex = '';
    var myCheckBox = new Array();
    
    for (var i = 0; i < checkBoxArray.length; i++) {
        var checkBoxRef = checkBoxArray[i];

        if (checkBoxRef.checked == true) {

            //selected index
            if (checkedSelIndex.length > 0)
                checkedSelIndex += ',';
            checkedSelIndex += i;

            //value
            if (checkedValues.length > 0)
                checkedValues += ',';

            checkedValues += checkBoxRef.value.trim();

            //text
            var labelArray = checkBoxRef.parentNode.getElementsByTagName('label');

            if (labelArray.length > 0) {
                if (checkedText.length > 0)
                    checkedText += ',';
                checkedText += labelArray[0].innerHTML.trim();
            }

        }
    }
    var splitValue1 = checkValue.split(',');
    var splitValue2 = checkedValues.split(',');
    if (splitValue1.toString().indexOf('-1') != -1 || splitValue2.toString().indexOf('-1') != -1) { 
        if (checkBoxArray[0].checked && splitValue1.toString().indexOf('0') != -1) {
            checkBoxArray[0].checked = false;
            checkBoxArray[1].checked = true;
        }
        else if (checkBoxArray[1] != null && splitValue1.toString().indexOf('-1') != -1) {
            checkBoxArray[0].checked = true;
            checkBoxArray[1].checked = false;
        }
        else if (checkBoxArray[0].checked && checkBoxArray[1].checked) {
            checkBoxArray[0].checked = false;
            checkBoxArray[1].checked = true;
        }
    }
    else if (splitValue1[0] == '0' && splitValue2[0] == '0' && splitValue1.length != 1) {
        for (var i = 0; i < checkBoxArray.length; i++) {
            checkBoxArray[0].checked = checkBoxArray[i].checked ? checkBoxArray[0].checked : i == 0 ? checkBoxArray[0].checked : false;
        }
    }
    else if ((splitValue1[0] == 0 || splitValue2[0] == 0) && (splitValue1.length != 1 || (splitValue1.length == 1 && splitValue2[0] == 0))) {
        if (checkBoxArray != null) {
            for (var i = 0; i < checkBoxArray.length; i++) {
                checkBoxArray[i].checked = checkBoxArray[0].checked
            }
        }
    }
    else if (splitValue1[0] != 0 && splitValue2[0] != 0) {
        if (splitValue2[0] > 1) {
            var verifycheck = 0;
            for (var i = 1; i < checkBoxArray.length; i++) {
                verifycheck = !checkBoxArray[i].checked ? 1 : verifycheck;
                if (i == checkBoxArray.length - 1)
                    checkBoxArray[0].checked = verifycheck != 1 ? true : false;
            }
        }
    }
    checkedValues = '';
    checkedText = '';
    checkedSelIndex = '';
    for (var i = 0; i < checkBoxArray.length; i++) {
        var checkBoxRef = checkBoxArray[i];
        if (checkBoxRef.checked == true) {

            //selected index
            if (checkedSelIndex.length > 0)
                checkedSelIndex += ',';
            checkedSelIndex += i;

            //value
            if (checkedValues.length > 0)
                checkedValues += ',';

            checkedValues += checkBoxRef.value.trim();

            //text
            var labelArray = checkBoxRef.parentNode.getElementsByTagName('label');

            if (labelArray.length > 0) {
                if (checkedText.length > 0)
                    checkedText += ',';
                checkedText += labelArray[0].innerHTML.trim();
            }
        }

    }
    var checkall = checkedText.split(',');
    if (checkall[0] == "All")
        checkedText = "All";
    if (checkall[0] == "")
        checkedText = '';
    myCheckBox[0] = checkedText;
    myCheckBox[1] = checkedValues;
    myCheckBox[2] = checkedSelIndex;

    return myCheckBox;
}



function readCheckBoxList(chkBox, ddlList, hiddenFieldText, hiddenFieldValue, hiddenFieldSelIndex)
 {
    var checkValue = $get(hiddenFieldValue).value;
    var checkedItems = getCheckBoxListItemsChecked(chkBox, checkValue);
    var ddl = document.getElementById(ddlList);
    ddl.text = checkedItems[0];
    if (checkedItems[0] == '') {
        if (CheckBrowser() == 1) {
            $get(ddlList).options[0].innerHTML = '';
        }
        else {
            $get(ddlList).innerHTML = '<option value ="0"></option>'; //set the dropdownlist value
        }
        $get(ddlList).title = 'All';
        $get(hiddenFieldText).value = 'All';
    }
    else {
        if (CheckBrowser() == 1) {
            $get(ddlList).options[0].innerHTML = checkedItems[0]; //set the dropdownlist value
        }
        else {
            $get(ddlList).innerHTML = '<option value ="0">' + checkedItems[0] + '</option>'; //set the dropdownlist value
        }
        $get(ddlList).title = checkedItems[0]; //set the title for the dropdownlist
        $get(hiddenFieldText).value = checkedItems[0];
    }
    //set hiddenfield value
    $get(hiddenFieldValue).value = checkedItems[1];
    $get(hiddenFieldSelIndex).value = checkedItems[2];
    var substring = hiddenFieldValue.substring(0, hiddenFieldValue.substring(0, hiddenFieldValue.lastIndexOf('_')).lastIndexOf('_'));
    if ($get(substring + '_hdnpostback').value == '1') {
        $get(substring + '_hf_check_checkBoxValue').value = $get(hiddenFieldValue).value;
        $get(substring + '_hdnpostback').value = '0'
    }
}
function CheckBrowser() {
    var BrowserName = navigator.appName;
    if (BrowserName == 'Microsoft Internet Explorer') {
        return 1;
    }

    return 0;
}
function getstatus(obj, x, y, ex, ey, eventname) {
    var cx = CheckBrowser() == 1 ? parseInt(event.x) : ex;
    var cy = CheckBrowser() == 1 ? parseInt(event.y) : ey;
    if (cx < parseInt(findPosx(obj)) || cx > (parseInt(findPosx(obj)) + (x))) {
        var substring = obj.id.substring(0, obj.id.substring(0, obj.id.length - 2).lastIndexOf('_'));
        var checkValue1 = $get(substring + '_hf_checkBoxValue').value;
        var checkValue2 = $get(substring + '_hf_check_checkBoxValue').value;
        if (checkValue1 != checkValue2) {
            $get(substring + '_hf_check_checkBoxValue').value = $get(substring + '_hf_checkBoxValue').value;
            return true;
        }
        return false;
    }
    if (cy < parseInt(findPosy(obj)) || cy > ((parseInt(findPosy(obj)) + (y)))) {
        var substring = obj.id.substring(0, obj.id.substring(0, obj.id.length - 2).lastIndexOf('_'));
        var checkValue1 = $get(substring + '_hf_checkBoxValue').value;
        var checkValue2 = $get(substring + '_hf_check_checkBoxValue').value;
        if (checkValue1 != checkValue2) {
            $get(substring + '_hf_check_checkBoxValue').value = $get(substring + '_hf_checkBoxValue').value;
            return true;
        }
        return false;
    }
}
function findPosx(obj) {
    var curleft = curtop = 0;
    if (obj.offsetParent) {
        curleft = obj.offsetLeft

        curtop = obj.offsetTop

        while (obj = obj.offsetParent) {
            curleft += obj.offsetLeft

            curtop += obj.offsetTop

        }

    }

    return [curleft];
}

function findPosy(obj) {
    var curleft = curtop = 0;

    if (obj.offsetParent) {
        curleft = obj.offsetLeft

        curtop = obj.offsetTop

        while (obj = obj.offsetParent) {
            curleft += obj.offsetLeft

            curtop += obj.offsetTop

        }

    }

    return [curtop];
}
