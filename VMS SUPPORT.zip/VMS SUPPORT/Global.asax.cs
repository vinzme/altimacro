﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Globalization;
using System.IO;

namespace VMS_SUPPORT
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

            string path = "~/Error/" + DateTime.Today.ToString("dd-MM-yy") + ".txt";
            if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
            }
            using (StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                w.WriteLine("\r\nLog Entry : " + DateTime.Now.ToString(CultureInfo.InvariantCulture));
                Exception objErr = System.Web.HttpContext.Current.Server.GetLastError().GetBaseException();
                w.WriteLine("Error in: " + System.Web.HttpContext.Current.Request.Url.ToString() + ".");
                w.WriteLine("Error Message:" + objErr.Message.ToString());
                w.WriteLine("user:" + HttpContext.Current.User.Identity.Name);
                string err = "Error in: " + System.Web.HttpContext.Current.Request.Url.ToString() +
                          ". Error Message:" + objErr.Source;
                w.WriteLine(err);

                w.WriteLine("__________________________");
                w.Flush();
                w.Close();
            }
            Response.Redirect("error.aspx");

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}