﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Data;

namespace VMS_SUPPORT
{
    public partial class Administrator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public static void ExportToSpreadsheet(DataTable tblPeople, string name)
        {
            HttpContext context = HttpContext.Current;
            context.Response.Clear();
            foreach (DataColumn column in tblPeople.Columns)
            {
                context.Response.Write(column.ColumnName + ",");
            }
            context.Response.Write(Environment.NewLine);
            foreach (DataRow row in tblPeople.Rows)
            {
                for (int i = 0; i < tblPeople.Columns.Count; i++)
                {
                    context.Response.Write(row[i].ToString().Replace(",", string.Empty) + ",");
                }
                context.Response.Write(Environment.NewLine);
            }
            context.Response.ContentType = "text/csv";
            context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + name + ".csv");
            context.Response.End();
        }

        protected void export_Click(object sender, EventArgs e)
        {
            string connection;
            if (Domains.SelectedItem.Text == "ASCORP")
            {

                connection = ConfigurationManager.ConnectionStrings["Ascorp"].ToString();
            }
            else
            {
                connection = ConfigurationManager.ConnectionStrings["corp"].ToString();

            }

            DirectoryEntry searchRoot = new DirectoryEntry();
            searchRoot.Path = connection;
            searchRoot.AuthenticationType = AuthenticationTypes.Secure;
            string[] loadProps = new string[] { "cn", "samaccountname", "name", "distinguishedname" };
            DirectorySearcher deSearch = new DirectorySearcher();
            deSearch.SearchRoot = searchRoot;
            deSearch.Filter = "(&(objectClass=person)(objectClass=user)(!userAccountControl:1.2.840.113556.1.4.803:=2))";
            deSearch.PageSize = 1000;
            var results = deSearch.FindAll();


            using (SearchResultCollection searchResults = deSearch.FindAll())
            {

                if (searchResults.Count > 0)
                {
                    // make the People table and its columns
                    DataTable tblPeople = new DataTable("People");

                    // Holds the columns and rows as they are being
                    DataColumn col = null;
                    DataRow row = null;

                    // Create LogonName column
                    col = new DataColumn("LogonName", System.Type.GetType("System.String"));
                    col.DefaultValue = "";
                    tblPeople.Columns.Add(col);

                    // Create FullName column
                    col = new DataColumn("FullName", System.Type.GetType("System.String"));
                    col.DefaultValue = "";
                    tblPeople.Columns.Add(col);

                    // Create Email column
                    col = new DataColumn("Email", System.Type.GetType("System.String"));
                    col.DefaultValue = "";
                    tblPeople.Columns.Add(col);

                    // Create Department column
                    col = new DataColumn("Department", System.Type.GetType("System.String"));
                    col.DefaultValue = "";
                    tblPeople.Columns.Add(col);


                    // Iterate over all the results in the resultset.
                    foreach (SearchResult result in searchResults)
                    {
                        row = tblPeople.NewRow();
                        // Getting values
                        // Display Name

                        if (result.Properties.Contains("samaccountname"))
                        {
                            row["LogonName"] = result.Properties["samaccountname"][0].ToString();
                        }

                        // Display Name
                        if (result.Properties.Contains("displayName"))
                        {
                            row["FullName"] = result.Properties["displayName"][0].ToString();
                        }




                        // Email addresss (and format it)
                        if (result.Properties.Contains("mail"))
                        {
                            row["Email"] = result.Properties["mail"][0].ToString(); ;

                        }


                        // Department
                        if (result.Properties.Contains("department"))
                        {
                            row["Department"] = result.Properties["department"][0].ToString();
                        }

                        // If there is actually something to display, create a new table row.
                        if (!string.IsNullOrEmpty(row["Email"].ToString()) || !string.IsNullOrEmpty(row["Department"].ToString()))
                        {
                            tblPeople.Rows.Add(row);
                        }


                    }

                    // instantiate a new DataSet object that
                    DataSet dataSet = new DataSet();
                    dataSet.Tables.Add(tblPeople);
                    ExportToSpreadsheet(tblPeople, "AD"); 

                }




            }
          

        }
        
        public override void VerifyRenderingInServerForm(Control control)
        {

        } 

    }
}