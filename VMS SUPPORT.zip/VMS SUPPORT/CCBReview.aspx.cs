﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Mail;

namespace VMS_SUPPORT
{
    public partial class CCBReview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string n = Request.QueryString["ChangeRequestNumber"];
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                SqlDataReader rdr, rdrtyp;

                String id = "7";
                //Populating The Type Drop down.
                SqlDataReader reader;
                String qury = "select * from Request1 where Request_category = @Req_category  order by Request_type";
                SqlCommand comd = new SqlCommand(qury, conn);
                comd.Parameters.Add("@Req_category", SqlDbType.Int).Value = id;
                comd.CommandText = qury;
                reader = comd.ExecuteReader();
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(reader);
                    CCBReq_type.CreateCheckBox(dt, "Request_type", "Request_id", 1);
                }
                reader.Close();
                CCBreq_priority.Items.Clear();
                String qurypio = "select * from ref_piority";
                SqlCommand comdpi = new SqlCommand(qurypio, conn);
                comdpi.CommandText = qurypio;
                rdrtyp = comdpi.ExecuteReader();
                CCBreq_priority.DataSource = rdrtyp;
                CCBreq_priority.DataValueField = "piority_id";
                CCBreq_priority.DataTextField = "ccbpiority";
                CCBreq_priority.DataBind();
                rdrtyp.Close();
                String qry = "SELECT ccbr.ccbid,ccbr.ccbReq_name[RequestorName], ccbr.ccbReq_netid[RequestorNetworkid], ccbr.ccbReq_email[RequestorEmail], ccbr.ccbReq_ext[RequestorExt],  ccbr.ccbReq_dept[RequestorDepartment],  ccbr.ccbReq_location[Location],  cate.Category_Name[RequestorCategory], ccbr.vms_request_types[Requestortype], ccbr.ccbpiority[Piority],  ccbr.ccbchangetitle[ChangeTitle], ccbr.ccbcreated[Created], ccbr.ccbimplementation[Implementation], ccbr.ccb_description_impact[ImplicationChange],ccbr.ccb_implication_NMC[impnmc],  ccbr.ccb_ppi_up_downstrem[PPIUpstream], ccbr.ccb_cost_implications[Cost], case when ccbr.ccbsop=1 then 'Yes' else 'No'end[SOP], case when ccbr.ccbtraining=1 then 'Yes' else 'No'end [TrainingSession], case when ccbr.ccbaxentis=1 then 'Yes' else 'No'end[Axentis], case when ccbr.ccbvendorguide=1 then 'Yes' else 'No'end [VendorGuide], case when ccbr.ccbvendortraining=1 then 'Yes' else 'No'end [VendorTraining], ccbr.ccblistimpactsop[ListImpacted], ccbr.ccb_request_number [ChangeRequestNumber],  ccbr.ccb_status[ChangerequestStatus],ccbst.ccbstatus[status] FROM ccb_request ccbr(nolock) join Category cate(nolock)on cate.Category_id=ccbr.ccbReq_category join ref_ccbstatus ccbst(nolock)on ccbst.ccbstatus_id=ccbr.ccb_status join ref_piority pior (nolock)on pior.piority_id=ccbr.ccbpiority WHERE ([ccb_request_number] = @ChangeRequestNumber)";
                SqlCommand cmd = new SqlCommand(qry, conn);
                cmd.Parameters.Add("@ChangeRequestNumber", SqlDbType.NVarChar).Value = Request.QueryString["ChangeRequestNumber"];
                cmd.CommandText = qry;
                try
                {

                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {

                        Session["ccbid"] = rdr["ccbid"].ToString();
                        String RequestorName = rdr["RequestorName"].ToString();
                        String RequestorNetworkid = rdr["RequestorNetworkid"].ToString();
                        String RequestorEmail = rdr["RequestorEmail"].ToString();
                        String RequestorExt = rdr["RequestorExt"].ToString();
                        String RequestorDepartment = rdr["RequestorDepartment"].ToString();
                        String Location = rdr["Location"].ToString();
                        String RequestorCategory = rdr["RequestorCategory"].ToString();
                        String Requestortype = rdr["Requestortype"].ToString();
                        String Piority = rdr["Piority"].ToString();
                        String ChangeTitle = rdr["ChangeTitle"].ToString();
                        String Created = rdr["Created"].ToString();
                        String ImplementationDate = rdr["Implementation"].ToString();
                        String ImplicationChange = rdr["ImplicationChange"].ToString();
                        String impnmc = rdr["impnmc"].ToString();
                        String PPIUpstreamDownstreamImpacts = rdr["PPIUpstream"].ToString();
                        String CostImplications = rdr["Cost"].ToString();
                        String SOP = rdr["SOP"].ToString();
                        String TrainingSession = rdr["TrainingSession"].ToString();
                        String Axentis = rdr["Axentis"].ToString();
                        String VendorGuide = rdr["VendorGuide"].ToString();
                        String VendorTraining = rdr["VendorTraining"].ToString();
                        String ListImpactedSOP = rdr["ListImpacted"].ToString();
                        String ChangeRequestNumber = rdr["ChangeRequestNumber"].ToString();
                        String ChangerequestStatus = rdr["ChangerequestStatus"].ToString();
                        String status = rdr["status"].ToString();
                        ccbrequestno.Text = ChangeRequestNumber;
                        CCBReq_name.Text = RequestorName;
                        CCBReqnetid.Text = RequestorNetworkid;
                        CCBReq_email.Text = RequestorEmail;
                        CCBReq_ext.Text = RequestorExt;
                        CCBReq_dept.Text = RequestorDepartment;
                        CCBLocation.Text = Location;
                        CCBReq_category.Text = RequestorCategory;
                        CCBReq_type.SetCheckBoxListValue(Requestortype);
                        CCBreq_priority.SelectedValue = Piority;
                        CCBchangetitle.Text = ChangeTitle;
                        ccbcreateddt.Text = Created;
                        txtDate.Text = ImplementationDate;
                        ccb_description_impact.Text = ImplicationChange;
                        ccb_implication_NMC.Text = impnmc;
                        ccb_ppi_up_downstrem.Text = PPIUpstreamDownstreamImpacts;
                        ccb_cost_implications.Text = CostImplications;
                        ccbsop.Text = SOP;
                        ccbtraining.Text = TrainingSession;
                        ccbaxentis.Text = Axentis;
                        ccbvendorguide.Text = VendorGuide;
                        ccbvendortraining.Text = VendorTraining;
                        ccblistimpactsop.Text = ListImpactedSOP;
                        CCBst.Text = status;
                        if (ChangerequestStatus == "2" || ChangerequestStatus == "3" || ChangerequestStatus == "5")
                        {
                            ccbapprove.Enabled = false;
                            ccbwith.Enabled = false;
                            ccbonhold.Enabled = false;
                            ccbdeclined.Enabled = false;
                            Calenbt.Enabled = false;
                            CCBReq_type.Enabled = false;
                            CCBreq_priority.Enabled = false;
                            btnsubmit.Enabled = false;
                            save.Enabled = false;
                            CCBFileUpload.Enabled = false;
                        }

                    }

                    rdr.Close();
                    GridView1.Visible = true;
                    String query = "Select File_id, File_Name from Files where ccbid=@ccbid order by File_id desc";
                    SqlDataAdapter da = new SqlDataAdapter();
                    DataSet ds = new DataSet();
                    SqlCommand CMDg = new SqlCommand(query, conn);
                    CMDg.Parameters.Add("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
                    da.SelectCommand = CMDg;
                    da.Fill(ds, "Files");
                    GridView1.DataSource = ds.Tables[0];
                    GridView1.DataBind();
                    GridView2.Visible = true;
                    String Comment = "Select ccbcoordcomment[Coordinator Comments],ccbmembername[CCb Memeber Name],ccbcomment,Last_update[Updated By] from ccbcomment where ccbid=@ccbid order by ccbcomment_id desc";
                    SqlDataAdapter Commentda = new SqlDataAdapter();
                    DataSet Commentds = new DataSet();
                    SqlCommand CommentCMD = new SqlCommand(Comment, conn);
                    CommentCMD.Parameters.Add("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
                    Commentda.SelectCommand = CommentCMD;
                    Commentda.Fill(Commentds, "ccbcomment");
                    GridView2.DataSource = Commentds.Tables[0];
                    GridView2.DataBind();

                }
                finally
                {

                    // close the connection
                    if (conn != null)
                    {
                        conn.Close();
                    }
                }

            }

        }
        protected void Calenbt_Click(object sender, ImageClickEventArgs e)
        {
            DateTime date = new DateTime();
            //Flip the visibility attribute
            this.cal1.Visible = !(this.cal1.Visible);
            //If the calendar is visible try assigning the date from the textbox
            if (this.cal1.Visible)
            {
                //If the Conversion was successfull assign the textbox's date
                if (DateTime.TryParse(txtDate.Text, out date))
                {
                    cal1.SelectedDate = date;
                }
                this.cal1.Attributes.Add("style", "POSITION: absolute");
            }

        }
        protected void cal1_SelectionChanged(object sender, EventArgs e)
        {
            txtDaterec.Text = this.cal1.SelectedDate.Date.ToString();
            this.cal1.Visible = false;
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select File_Name,File_type,data from Files where File_id=@id", conn);
            cmd.Parameters.AddWithValue("id", GridView1.SelectedRow.Cells[1].Text);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                string path = Server.MapPath("~/Files/") + dr["data"].ToString(); //get file object as FileInfo  
                Response.Clear();
                System.IO.FileInfo file = new System.IO.FileInfo(path); //-- if the file exists on the server  
                // to open file prompt Box open or Save file
                Response.AddHeader("Content-Disposition", "attachment; filename=" + dr["File_Name"].ToString());
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/vnd.ms-excel";
                Response.WriteFile(path);//File open
                Response.Flush();
                //context.Response.Close();               
                Response.End();
            }
        }
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
           

            DateTime daterec;
            string s = HttpContext.Current.User.Identity.Name;
            string username = s.Substring(s.IndexOf(@"\") + 1);
            string[] domain = s.Split('\\');
            String ccbReq_type;
            if (CCBReq_type.sValue == "")
            {
                ccbReq_type = CCBReq_type.allsValue;
            }
            else
            {
                ccbReq_type = CCBReq_type.sValue;
            }
            String ccbpiority = CCBreq_priority.SelectedValue;            
            String ccb_request_number = ccbrequestno.Text;
            String datere = txtDaterec.Text;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand upd = conn.CreateCommand();
            if (datere != "")
            {
                 daterec = Convert.ToDateTime(datere);

                 upd.CommandText = "update ccb_request set ccbpiority=@ccbpiority,Recom_implementation_date=@Recom_implementation_date,Last_update=@user,vms_request_types=@ccbReq_type where ccb_request_number=@ccb_request_number"; //Update query
                upd.Parameters.AddWithValue("@ccbReq_type", ccbReq_type);//Ticket_id
                upd.Parameters.AddWithValue("@ccbpiority", ccbpiority);//category
                upd.Parameters.AddWithValue("@Recom_implementation_date", SqlDbType.DateTime).Value = daterec;//Type
                upd.Parameters.AddWithValue("@ccb_request_number", SqlDbType.NVarChar).Value = ccb_request_number;//Type    
                upd.Parameters.AddWithValue("@user", SqlDbType.NVarChar).Value = username;//Type
               
            }
            else
            {
                
                upd.CommandText = "update ccb_request set vms_request_types=@ccbReq_type,ccbpiority=@ccbpiority,Last_update=@user where ccb_request_number=@ccb_request_number"; //Update query
                upd.Parameters.AddWithValue("@ccbReq_type", ccbReq_type);//Ticket_id
                upd.Parameters.AddWithValue("@ccbpiority", ccbpiority);//category               
                upd.Parameters.AddWithValue("@ccb_request_number", SqlDbType.NVarChar).Value = ccb_request_number;//Type    
                upd.Parameters.AddWithValue("@user", SqlDbType.NVarChar).Value = username;//Type
             
            }
                  conn.Open();
                upd.ExecuteNonQuery();//excute query
                conn.Close();

                String myStringVariable = "Priority, Request Type, CCB Recommended Implementation Date was Succesfully updated";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert10", "alert('" + myStringVariable + "');", true);
           
        }
        protected void save_Click(object sender, EventArgs e)
        {
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            HttpFileCollection hfc = HttpContext.Current.Request.Files;
            HttpPostedFile hpf;
            if (cccor.Text != "" || ccbmeb.Text != "" || ccbcom.Text != "" || hfc.Count!=-1)
            {
                if (cccor.Text != "" || ccbmeb.Text != "" || ccbcom.Text != "")
                {
                    string s = HttpContext.Current.User.Identity.Name;
                    string username = s.Substring(s.IndexOf(@"\") + 1);
                    String ccb_request_number = ccbrequestno.Text;
                   
                    SqlCommand comme = conn.CreateCommand();
                    comme.CommandText = " Insert into ccbcomment (ccbcoordcomment,ccbmembername,ccbcomment,Last_update,ccbid) values (@ccbcoordcomment,@ccbmembername,@ccbcomment,@Last_update,@ccbid) "; //Update query
                    comme.Parameters.AddWithValue("@ccbcoordcomment", SqlDbType.NVarChar).Value = cccor.Text;
                    comme.Parameters.AddWithValue("@ccbmembername", SqlDbType.NVarChar).Value = ccbmeb.Text;
                    comme.Parameters.AddWithValue("@ccbcomment", SqlDbType.NVarChar).Value = ccbcom.Text;
                    comme.Parameters.AddWithValue("@Last_update", SqlDbType.NVarChar).Value = username;
                    comme.Parameters.AddWithValue("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
                    conn.Open();
                    comme.ExecuteNonQuery();//excute query  
                    cccor.Text = ""; ccbmeb.Text = ""; ccbcom.Text = "";
                    String myStringVariable = "Comment updated";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert10", "alert('" + myStringVariable + "');", true);                  
                    conn.Close();
                }
                String id  = Session["ccbid"].ToString();
                for (int i = 0; i < hfc.Count; i++)
                {
                    hpf = hfc[i];
                    if (hpf.ContentLength > 0)
                    {

                        string filePath = hpf.FileName;
                        string filename = System.IO.Path.GetFileName(filePath);
                        string ext = System.IO.Path.GetExtension(filename);
                        String path = "ccb_" + id + "_" + filename;
                        hpf.SaveAs(Server.MapPath("~/Files/") + path);
                        SqlCommand cone = conn.CreateCommand();
                        cone.CommandText = "INSERT INTO Files (File_Name,File_type,data,ccbid) VALUES (@Name, @type, @Data,@ccbid)"; //insert query for Files
                        cone.Parameters.AddWithValue("@Name", filename);//name of the file
                        cone.Parameters.AddWithValue("@type", ext);//file extion
                        cone.Parameters.AddWithValue("@Data", path);//file Path
                        cone.Parameters.AddWithValue("@ccbid", id);//Ticket_id
                        conn.Open();
                        cone.ExecuteNonQuery();// insert query for files is executed on For Loop
                        conn.Close();
                        CCBERROR.ForeColor = System.Drawing.Color.Green;
                        CCBERROR.Text = "File Uploaded Successfully "; //if insert was success full.                                            

                    }
                   
                }

                Response.Redirect(Request.RawUrl);

            }
            else
            {
                String my = "Please Enter CHANGE COORDINATOR COMMENTS or CCB Member Names or CCB Comments";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert15", "alert('" + my + "');", true);
            }
        }
        protected void ccbapprove_Click(object sender, EventArgs e)
        {
            if (statuscomments.Text != "")
            {
                ccbapprove.Enabled = false;
                SqlDataReader rdr;
                string comments = statuscomments.Text;
                string s = HttpContext.Current.User.Identity.Name;
                string username = s.Substring(s.IndexOf(@"\") + 1);
                String ccb_request_number = ccbrequestno.Text;
                string index;
                if (CCBReq_type.sValue == "")
                {
                    index = CCBReq_type.allsValue;
                }
                else
                {
                    index = CCBReq_type.sValue;
                }
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                SqlCommand comme = conn.CreateCommand();

                comme.CommandText = "update ccb_request set ccb_status=2,statuscomment=@statcomment, Last_update=@Last_update where  ccbid=@ccbid"; //Update query
                comme.Parameters.AddWithValue("@statcomment", SqlDbType.NVarChar).Value = comments;
                comme.Parameters.AddWithValue("@ccbmembername", SqlDbType.NVarChar).Value = ccbmeb.Text;
                comme.Parameters.AddWithValue("@Last_update", SqlDbType.NVarChar).Value = username;
                comme.Parameters.AddWithValue("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
                conn.Open();
                comme.ExecuteNonQuery();//excute query
                conn.Close();
                ModalPopupExtender1.Hide();
                CCBSTATUS();
                string[] strArray;
                strArray = index.Split(@",".ToCharArray());
                if (strArray.Length > 0)
                {
                    int result;
                    foreach (string Str in strArray)
                    {
                        result = 0;

                        if (int.TryParse(Str, out result))
                        {
                            SqlCommand cre = conn.CreateCommand();
                            cre.CommandText = "Select * from request1 where Request_id=@Request_id and is_vmssupport=1";
                            cre.Parameters.AddWithValue("@Request_id", SqlDbType.Int).Value = result;
                            conn.Open();
                            rdr = cre.ExecuteReader(); //excute query
                            if (rdr.HasRows)
                            {
                                createticket(result);
                            }
                            conn.Close();
                        }
                    }
                }
                Response.Redirect(Request.RawUrl);
            }
            else
            {
                String my = " Comments Mandatory";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert25", "alert('" + my + "');", true);
            }

        }
        protected void decline_Click(object sender, EventArgs e)
        {
            if (declinecomment.Text!="")
            {
                decline.Enabled = false;
            string comments = declinecomment.Text;
            string s = HttpContext.Current.User.Identity.Name;
            string username = s.Substring(s.IndexOf(@"\") + 1);
            String ccb_request_number = ccbrequestno.Text;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand comme = conn.CreateCommand();
            comme.CommandText = " update ccb_request set ccb_status=3,statuscomment=@statcomment, Last_update=@Last_update where  ccbid=@ccbid "; //Update query
            comme.Parameters.AddWithValue("@statcomment", SqlDbType.NVarChar).Value = comments;
            comme.Parameters.AddWithValue("@ccbmembername", SqlDbType.NVarChar).Value = ccbmeb.Text;
            comme.Parameters.AddWithValue("@Last_update", SqlDbType.NVarChar).Value = username;
            comme.Parameters.AddWithValue("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
            conn.Open();
            comme.ExecuteNonQuery();//excute query
            conn.Close();
            ModalPopupExtender2.Hide();
            CCBSTATUS();            
            Response.Redirect(Request.RawUrl);

             }
            else
            {
                String my = " Comments Mandatory";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert25", "alert('" + my + "');", true);
            }
        }       
        protected void ccbonhold_Click(object sender, EventArgs e)
        {
            if (onholcomment.Text != "")
            {
                ccbonhold.Enabled = false;
                string comments = onholcomment.Text;
                string s = HttpContext.Current.User.Identity.Name;
                string username = s.Substring(s.IndexOf(@"\") + 1);
                String ccb_request_number = ccbrequestno.Text;
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                SqlCommand comme = conn.CreateCommand();
                comme.CommandText = " update ccb_request set ccb_status=4,statuscomment=@statcomment, Last_update=@Last_update where  ccbid=@ccbid "; //Update query
                comme.Parameters.AddWithValue("@statcomment", SqlDbType.NVarChar).Value = comments;
                comme.Parameters.AddWithValue("@ccbmembername", SqlDbType.NVarChar).Value = ccbmeb.Text;
                comme.Parameters.AddWithValue("@Last_update", SqlDbType.NVarChar).Value = username;
                comme.Parameters.AddWithValue("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
                conn.Open();
                comme.ExecuteNonQuery();//excute query
                conn.Close();
                ModalPopupExtender3.Hide();
                CCBSTATUS();
                Response.Redirect(Request.RawUrl);
            }
            else
            {
                String my = " Comments Mandatory";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert25", "alert('" + my + "');", true);
            }

        }
        private void CCBSTATUS()
        {
            String ccb_request_number = ccbrequestno.Text;
            SqlDataReader rdr = null;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String qry = "SELECT ccbr.ccbReq_name[RequestorName], ccbr.ccbReq_netid[RequestorNetworkid], ccbr.ccbReq_email[RequestorEmail], ccbr.ccbReq_ext[RequestorExt],  ccbr.ccbReq_dept[RequestorDepartment],  ccbr.ccbReq_location[Location],  cate.Category_Name[RequestorCategory], stuff((select Request_type+',' from Request1 where  Request_id in (SELECT * FROM dbo.split(ccbr.vms_request_types)) for xml path('') ), 1, 0, '' )  as [Requestortype], pior.ccbpiority[Piority],  ccbr.ccbchangetitle[ChangeTitle], ccbr.ccbcreated[Created], ccbr.ccbimplementation[Implementation], ccbr.ccb_description_impact[Descriptionimpact],ccbr.ccb_implication_NMC[ImplicationChange],  ccbr.ccb_ppi_up_downstrem[PPIUpstream], ccbr.ccb_cost_implications[Cost], case when ccbr.ccbsop=1 then 'Yes' else 'No'end[SOP], case when ccbr.ccbtraining=1 then 'Yes' else 'No'end [TrainingSession], case when ccbr.ccbaxentis=1 then 'Yes' else 'No'end[Axentis], case when ccbr.ccbvendorguide=1 then 'Yes' else 'No'end [VendorGuide], case when ccbr.ccbvendortraining=1 then 'Yes' else 'No'end [VendorTraining], ccbr.ccblistimpactsop[ListImpacted], ccbr.ccb_request_number [ChangeRequestNumber],  ccbst.ccbstatus[ChangerequestStatus] FROM ccb_request ccbr(nolock) join Category cate(nolock)on cate.Category_id=ccbr.ccbReq_category join ref_ccbstatus ccbst(nolock)on ccbst.ccbstatus_id=ccbr.ccb_status join ref_piority pior (nolock)on pior.piority_id=ccbr.ccbpiority WHERE ([ccb_request_number] = @ccb_request_number)";
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.Parameters.Add("@ccb_request_number", SqlDbType.NVarChar).Value = ccb_request_number;
            cmd.CommandText = qry;
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    String RequestorName = rdr["RequestorName"].ToString();
                    String RequestorNetworkid = rdr["RequestorNetworkid"].ToString();
                    String RequestorEmail = rdr["RequestorEmail"].ToString();
                    String RequestorExt = rdr["RequestorExt"].ToString();
                    String RequestorDepartment = rdr["RequestorDepartment"].ToString();
                    String Location = rdr["Location"].ToString();
                    String RequestorCategory = rdr["RequestorCategory"].ToString();
                    String Requestortype = rdr["Requestortype"].ToString();
                    String Piority = rdr["Piority"].ToString();
                    String ChangeTitle = rdr["ChangeTitle"].ToString();
                    String Created = rdr["Created"].ToString();
                    String ImplementationDate = rdr["Implementation"].ToString();
                    String Descriptionimpact = rdr["Descriptionimpact"].ToString();
                    String ImplicationofNotMakingChange = rdr["ImplicationChange"].ToString();
                    String PPIUpstreamDownstreamImpacts = rdr["PPIUpstream"].ToString();
                    String CostImplications = rdr["Cost"].ToString();
                    String SOP = rdr["SOP"].ToString();
                    String TrainingSession = rdr["TrainingSession"].ToString();
                    String Axentis = rdr["Axentis"].ToString();
                    String VendorGuide = rdr["VendorGuide"].ToString();
                    String VendorTraining = rdr["VendorTraining"].ToString();
                    String ListImpactedSOP = rdr["ListImpacted"].ToString();
                    String ChangeRequestNumber = rdr["ChangeRequestNumber"].ToString();
                    String ChangerequestStatus = rdr["ChangerequestStatus"].ToString();
                    MailMessage Msg = new MailMessage();
                    Msg.From = "Ronald.Priest@altisource.com";
                    Msg.Cc = "Ronald.Priest@altisource.com;Akshay.Samuel@altisource.com";
                    Msg.To = RequestorEmail;
                    Msg.Subject = "VMS Change Request/Incident :: Change Request # " + ChangeRequestNumber;
                    Msg.BodyFormat = MailFormat.Html;
                    Msg.Body = "<Table> " +
                        "<tr><td>Change Request Number </td> <td>" + ChangeRequestNumber + "</td></tr>" +
                        "<tr><td>Change request Status</td> <td>" + ChangerequestStatus + "</td></tr>" +
                       "<tr><td>Requestor Name</td> <td>" + RequestorName + "</td></tr>" +
                        "<tr><td>Requestor Network id </td> <td>" + RequestorNetworkid + "</td></tr>" +
                        "<tr><td>Requestor Email</td> <td>" + RequestorEmail + "</td></tr>" +
                        "<tr><td>Requestor Ext </td> <td>" + RequestorExt + "</td></tr>" +
                        "<tr><td>Requestor Department </td> <td>" + RequestorDepartment + "</td></tr>" +
                        "<tr><td>Location </td> <td>" + Location + "</td></tr>" +
                        "<tr><td>Requestor Category</td> <td>" + RequestorCategory + "</td></tr>" +
                        "<tr><td>Requestor type</td> <td>" + Requestortype + "</td></tr>" +
                        "<tr><td>Piority </td> <td>" + Piority + "</td></tr>" +
                        "<tr><td>Change Title</td> <td>" + ChangeTitle + "</td></tr>" +
                        "<tr><td>Created</td> <td>" + Created + "</td></tr>" +
                        "<tr><td>Implementation Date</td> <td>" + ImplementationDate + "</td></tr>" +
                        "<tr><td>Change Description and Impact :</td> <td>" + Descriptionimpact + "</td></tr>" +
                        "<tr><td>Implication of Not Making Change  : </td> <td>" + ImplicationofNotMakingChange + "</td></tr>" +
                        "<tr><td>PPI & Upstream/Downstream Impacts :</td> <td>" + PPIUpstreamDownstreamImpacts + "</td></tr>" +
                        "<tr><td>Cost Implications :</td> <td>" + CostImplications + "</td></tr>" +
                        "<tr><td>SOP</td> <td>" + SOP + "</td></tr>" +
                        "<tr><td>Training Session (Associates)</td> <td>" + TrainingSession + "</td></tr>" +
                        "<tr><td>Axentis</td> <td>" + Axentis + "</td></tr>" +
                        "<tr><td>Vendor Guide</td> <td>" + VendorGuide + "</td></tr>" +
                        "<tr><td>Vendor Training</td> <td>" + VendorTraining + "</td></tr>" +
                        "<tr><td>List Impacted SOP's</td> <td>" + ListImpactedSOP + "</td></tr>" +                        
                      " </Table>";
                    SmtpMail.SmtpServer = "Internal-Mail.ascorp.com";
                    SmtpMail.Send(Msg);
                    Msg = null;


                }

            }
            finally
            {

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public void createticket(int str)
        {

            string s = HttpContext.Current.User.Identity.Name;
            string username = s.Substring(s.IndexOf(@"\") + 1);
            SqlDataReader rdr = null;

            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand SLCOM = new SqlCommand("[dbo].[SLA]", conn);
            SLCOM.CommandType = System.Data.CommandType.StoredProcedure;
            SLCOM.Parameters.Add("@category", SqlDbType.Int).Value = str;
            try
            {
                conn.Open();
                rdr = SLCOM.ExecuteReader();
                while (rdr.Read())
                {
                    string SLAVA = rdr["SLA"].ToString();
                    int SLAVAL = Convert.ToInt32(SLAVA);
                    string Rep1 = rdr["Representative"].ToString();
                    string BackUpRep1 = rdr["BackUpRepresentative"].ToString();
                    Session["Rep"] = Rep1;
                    Session["BackUpRep"] = BackUpRep1;
                    DateTime fromDate = DateTime.Now;
                    DateTime toDate = fromDate.AddDays(SLAVAL);
                    var weekendDayCount = 0;

                    while (fromDate < toDate)
                    {
                        fromDate = fromDate.AddDays(1);
                        if (fromDate.DayOfWeek == DayOfWeek.Saturday || fromDate.DayOfWeek == DayOfWeek.Sunday)
                        {
                            ++weekendDayCount;
                        }
                    }

                    DateTime ETA = toDate.AddDays(weekendDayCount);

                    if (ETA.DayOfWeek == DayOfWeek.Saturday)
                    {
                        ETA = ETA.AddDays(2);
                    }
                    else
                        if (ETA.DayOfWeek == DayOfWeek.Sunday)
                        {
                            ETA = ETA.AddDays(1);
                        }
                    Session["ETA"] = ETA;
                }
                rdr.Close();
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();// close the reader
                }

                if (conn != null)
                {
                    conn.Close();// close the connection
                }
            }

            string catid = "7";
            String rep = Session["Rep"].ToString();
            String BackUpRepresentative = Session["BackUpRep"].ToString();
            String ETADA = Session["ETA"].ToString();
            int stat = 1;
            DateTime now = DateTime.Now;
            SqlCommand com = new SqlCommand("SPtblticket", conn);
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.Add("@Req_name", SqlDbType.NVarChar).Value = CCBReq_name.Text;
            com.Parameters.Add("@Req_netid", SqlDbType.NVarChar).Value = CCBReqnetid.Text;
            com.Parameters.Add("@Req_email", SqlDbType.NVarChar).Value = CCBReq_email.Text;
            com.Parameters.Add("@Req_ext", SqlDbType.NVarChar).Value = CCBReq_ext.Text;
            com.Parameters.Add("@Req_dept", SqlDbType.NVarChar).Value = CCBReq_dept.Text;
            com.Parameters.Add("@Req_approved", SqlDbType.NVarChar).Value = ccbrequestno.Text;
            com.Parameters.Add("@Req_category", SqlDbType.Int).Value = catid;
            com.Parameters.Add("@Req_type", SqlDbType.Int).Value = str;
            com.Parameters.Add("@Req_comments", SqlDbType.NVarChar).Value = ccb_description_impact.Text;
            com.Parameters.Add("@created", SqlDbType.DateTime).Value = now;
            com.Parameters.Add("@ETA_date", SqlDbType.DateTime).Value = ETADA;
            com.Parameters.Add("@Piority", SqlDbType.NVarChar).Value = CCBreq_priority.Text;
            com.Parameters.Add("@Representative", SqlDbType.Int).Value = rep;
            com.Parameters.AddWithValue("@BackupRepresentative", SqlDbType.Int).Value = BackUpRepresentative;
            com.Parameters.AddWithValue("@Status", stat);
            com.Parameters.AddWithValue("@Last_updated_by", SqlDbType.NVarChar).Value = username;
            com.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;
            conn.Open();
            com.ExecuteNonQuery();
            string idcat = com.Parameters["@id"].Value.ToString();
            int id = Convert.ToInt32(idcat);
            conn.Close();
            SqlCommand comfi = conn.CreateCommand();
            comfi.CommandText = " update files set Ticket_id=@Ticket_id where  ccbid=@ccbid ";
            comfi.Parameters.AddWithValue("@Ticket_id", SqlDbType.Int).Value = id;
            comfi.Parameters.AddWithValue("@ccbid", SqlDbType.NVarChar).Value = Session["ccbid"];
            conn.Open();
            comfi.ExecuteNonQuery();//excute query
            conn.Close();
            String qry = "SELECT tblticket.Ticket_id, tblticket.Req_comments,us.Name[Representative],usb.Name[BackupRepresentative],us.uemail[Repemail],usb.uemail[bkRepemail],Status.Status, tblticket.Req_name,tblticket.Created,tblticket.Req_comments,tblticket.ETA_date,ref_piority.vmspiority[Piority],tblticket.Req_email,Request1.Request_type FROM [tblticket](nolock) Left join Status (nolock) on Status.Status_ID=tblticket.Status Left join users us (nolock) on us.Uid=tblticket.Representative Left Join ref_piority (nolock) on ref_piority.piority_id=tblticket.Piority Left join users usb (nolock) on usb.Uid = tblticket.BackupRepresentative left join Request1 on Request1.Request_id=tblticket.Req_category WHERE ([Ticket_id] = @Ticket_id)";
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.Parameters.Add("@Ticket_id", SqlDbType.Int).Value = id;
            cmd.CommandText = qry;
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    String Ticketno = rdr["Ticket_id"].ToString();
                    String Description = rdr["Req_comments"].ToString();
                    String Representative = rdr["Representative"].ToString();
                    String BackupRepresentative = rdr["BackupRepresentative"].ToString();
                    String Status = rdr["Status"].ToString();
                    String Requestor = rdr["Req_name"].ToString();
                    String created = rdr["Created"].ToString();
                    String Comment = rdr["Req_comments"].ToString();
                    String eta = rdr["ETA_date"].ToString();
                    String Priority = rdr["Piority"].ToString();
                    String email = rdr["Req_email"].ToString();
                    String Repemail = rdr["Repemail"].ToString();
                    String bkRepemail = rdr["bkRepemail"].ToString();
                    String category = rdr["Request_type"].ToString();
                    MailMessage Msg = new MailMessage();
                    Msg.From = "vms-support@altisource.com";
                    Msg.Bcc = Repemail + ";" + bkRepemail;
                    Msg.To = email;
                    Msg.Subject = "VMS Change Request/Incident :: Ticket # " + Ticketno;
                    Msg.BodyFormat = MailFormat.Html;
                    Msg.Body = "Greetings <br />This is an automated response, please don’t reply back.<br />We are in receipt of your request. If you need to speak with VMS Support Representative, please call 297375 or contact VMS-Support@altisource.com for any queries." +
                                "<br /><br />Ticket number              :   " + Ticketno +
                                "<br />      Description                :   " + Comment +
                                "<br />      VMS Support Representative :   " + Representative +
                                " <br />     Ticket Status              :   " + Status +
                                "<br />      Requestor Name             :   " + Requestor +
                                "<br />      Received Date              :   " + created +
                                "<br />      Estimated Completion Date  :   " + eta +
                                "<br />      Priority                   :   " + Priority +
                                "<br /><br />Warm Regards,<br />VMS Support Team ";
                    SmtpMail.SmtpServer = "Internal-Mail.ascorp.com";
                    SmtpMail.Send(Msg);
                    Msg = null;
                }

            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();// close the reader
                }

                if (conn != null)
                {
                    conn.Close();// close the connection
                }
            }
        }
        protected void ccbwith_Click(object sender, EventArgs e)
        {
            if(withcomment.Text!="")
            {
                ccbwith.Enabled = false;
            string comments = withcomment.Text;
            string s = HttpContext.Current.User.Identity.Name;
            string username = s.Substring(s.IndexOf(@"\") + 1);
            String ccb_request_number = ccbrequestno.Text;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand comme = conn.CreateCommand();
            comme.CommandText = " update ccb_request set ccb_status=5,statuscomment=@statcomment, Last_update=@Last_update where  ccbid=@ccbid "; //Update query
            comme.Parameters.AddWithValue("@statcomment", SqlDbType.NVarChar).Value = comments;
            comme.Parameters.AddWithValue("@ccbmembername", SqlDbType.NVarChar).Value = ccbmeb.Text;
            comme.Parameters.AddWithValue("@Last_update", SqlDbType.NVarChar).Value = username;
            comme.Parameters.AddWithValue("@ccbid", SqlDbType.Int).Value = Session["ccbid"];
            conn.Open();
            comme.ExecuteNonQuery();//excute query
            conn.Close();
            ModalPopupExtender4.Hide();
            CCBSTATUS();
            Response.Redirect(Request.RawUrl);
              }
            else
            {
                String my = " Comments Mandatory";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert25", "alert('" + my + "');", true);
            }

        }

        protected void back_Click(object sender, EventArgs e)
        {
            Response.Redirect("CCBReviewsearch.aspx?");
        }
    }
}