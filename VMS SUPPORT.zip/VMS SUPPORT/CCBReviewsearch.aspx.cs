﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using OfficeOpenXml;

using System.Globalization;
using System.IO;

namespace VMS_SUPPORT
{
    public partial class CCBReviewsearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string n = Request.QueryString["ChangeRequestNumber"];
                SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
                conn.Open();
                SqlDataReader  Reader;
                String query = "select * from ref_ccbstatus";
                SqlCommand typ = new SqlCommand(query, conn);
                typ.CommandText = query;
                Reader = typ.ExecuteReader();
                if (Reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Reset();
                    dt.Load(Reader);
                    ccbStatus.CreateCheckBox(dt, "ccbstatus", "ccbstatus_id", 1);
                }
                Reader.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String ticketno,  Netid, requestor, Department, Types, Status;            
            if (ccbno.Text == "")
            {
                ticketno = "%";
            }
            else
            {
                ticketno = ccbno.Text;
            }
            if (ccbnet.Text == "")
            {
                Netid = "%";
            }
            else
            {
                Netid = ccbnet.Text;
            }
            if (txtreq.Text == "")
            {
                requestor = "%";
            }
            else
            {
                requestor = txtreq.Text;
            }

            if (txtdep.Text == "")
            {
                Department = "%";
            }
            else
            {
                Department = txtdep.Text;
            }


          
            if (ccbStatus.sValue == "")
            {
                Status = ccbStatus.allsValue;
            }
            else
            {
                Status = ccbStatus.sValue;
            }


            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String qry = "SELECT ccbr.ccb_request_number [CBB Number],ccbr.ccbReq_name[Requestor Name], ccbr.ccbReq_netid[Network id],ccbr.ccbReq_ext[IP Ext], ccbr.ccbReq_dept[Department], stuff(( select Request_type+',' from Request1 where  Request_id in (SELECT * FROM dbo.split(ccbr.vms_request_types)) for xml path('') ), 1, 0, '' )  as[Request type], pior.ccbpiority[Piority], ccbr.ccbchangetitle[ChangeTitle], ccbr.ccbcreated[Created], ccbr.ccbimplementation[Implementation], ccbst.ccbstatus[status] FROM ccb_request ccbr(nolock) join Category cate(nolock)on cate.Category_id=ccbr.ccbReq_category  join ref_ccbstatus ccbst(nolock)on ccbst.ccbstatus_id=ccbr.ccb_status join ref_piority pior (nolock)on pior.piority_id=ccbr.ccbpiority WHERE  ccbr.ccb_request_number Like '%' + @Req_ticket + '%' and ccbr.ccbReq_name  LIKE '%' + @Req_name + '%' and ccbr.ccbReq_netid  LIKE '%' + @Req_netid + '%' and ccbr.ccbReq_dept  LIKE '%' + @Req_dept + '%' and ccbr.ccb_status  in  (SELECT * FROM dbo.split(@Status)) order by ccbr.ccbid DESC  ";
            SqlCommand SLCOM = new SqlCommand(qry, conn);
            SLCOM.Parameters.Add("@Req_ticket", SqlDbType.NVarChar).Value = ticketno;
            SLCOM.Parameters.Add("@Req_name", SqlDbType.NVarChar).Value = requestor;
            SLCOM.Parameters.Add("@Req_netid", SqlDbType.NVarChar).Value = Netid;
            SLCOM.Parameters.Add("@Req_dept", SqlDbType.NVarChar).Value = Department;           
            SLCOM.Parameters.Add("@Status", SqlDbType.NVarChar).Value = Status;
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(SLCOM);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds != null)
                {
                    Session["ccbgr"] = ds.Tables[0];
                    Srchres.DataSource = ds.Tables[0];
                    Srchres.DataBind();
               
                    foreach (GridViewRow gr in Srchres.Rows)
                    {

                        HyperLink hp = new HyperLink();
                        hp.Text = gr.Cells[1].Text;
                        hp.NavigateUrl = "~/CCBReview.aspx?ChangeRequestNumber=" + hp.Text;
                        gr.Cells[1].Controls.Add(hp);
                    }                    
                }

                else
                {
                    string myStringVariable = "No Records Found";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
                }

              
            }
            finally
            {

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (Page.IsPostBack)
            {
                Srchres.PageIndex = e.NewPageIndex;
                Srchres.DataSource = Session["ccbgr"];
                Srchres.DataBind();
                foreach (GridViewRow gr in Srchres.Rows)
                {
                    HyperLink hp = new HyperLink();
                    hp.Text = gr.Cells[1].Text;
                    hp.NavigateUrl = "~/CCBReview.aspx?ChangeRequestNumber=" + hp.Text;
                    gr.Cells[1].Controls.Add(hp);
                }
                Srchres.PageIndex = e.NewPageIndex;
            }
        }

        protected void Srchres_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            Srchres.SelectedIndex = e.NewSelectedIndex;
        }
        protected void Srchres_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = ((DataTable)Session["ccbgr"]);
            String numb = dt.Rows[Srchres.SelectedIndex]["CBB Number"].ToString();           
            SqlDataReader Reader = null;
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            String qry = "SELECT ccbr.ccbReq_name[Requestor Name], ccbr.ccbReq_netid[Requestor Networkid], ccbr.ccbReq_email[Requestor Email], ccbr.ccbReq_ext[Requestor Ext],  ccbr.ccbReq_dept[Requestor Department], ccbr.ccbReq_location[Location],  cate.Category_Name[Request Category],   stuff(( select Request_type+',' from Request1 where  Request_id in (SELECT * FROM dbo.split(ccbr.vms_request_types)) for xml path('') ), 1, 0, '' ) as[Request type], pior.ccbpiority[Piority],  ccbr.ccbchangetitle[Change Title],ccbr.ccb_request_number [Change Request Number],ccbr.ccbcreated[Created], ccbr.ccbimplementation[Implementation], ccbr.ccb_description_impact[Description impact], ccbr.ccb_implication_NMC[Implication Change],  ccbr.ccb_ppi_up_downstrem[PPIUpstream], ccbr.ccb_cost_implications[Cost], case when ccbr.ccbsop=1 then 'Yes' else 'No'end[SOP], case when ccbr.ccbtraining=1 then 'Yes' else 'No'end [Training Session],  case when ccbr.ccbaxentis=1 then 'Yes' else 'No'end[Axentis], case when ccbr.ccbvendorguide=1 then 'Yes' else 'No'end [Vendor Guide],  case when ccbr.ccbvendortraining=1 then 'Yes' else 'No'end [Vendor Training], ccbr.ccblistimpactsop[List Impacted],  ccbst.ccbstatus[Change Request Status],ccbcom.ccbcoordcomment  [CHANGE COORDINATOR COMMENTS],ccbcom.ccbmembername [CCB Member Names],ccbcom.ccbcomment [CCB Comments],ccbr.statuscomment[Status Reason] FROM ccb_request ccbr(nolock)join Category cate(nolock)on cate.Category_id=ccbr.ccbReq_category join ref_ccbstatus ccbst(nolock)on ccbst.ccbstatus_id=ccbr.ccb_status join ref_piority pior (nolock)on pior.piority_id=ccbr.ccbpiority outer apply ( select top 1 ccbcomment.ccbcoordcomment,ccbcomment.ccbmembername,ccbcomment.ccbcomment from ccbcomment (nolock) where ccbcomment.ccbid= ccbr.ccbid) as ccbcom WHERE ([ccb_request_number] = @ccb_request_number)";
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.Parameters.Add("@ccb_request_number", SqlDbType.NVarChar).Value = numb;
           conn.Open();
            Reader = cmd.ExecuteReader();
            DataTable trans = new DataTable();
            if (Reader.HasRows)
            {
                trans.Reset();
                trans.Load(Reader);
            }
            DataTable inputTable = trans;
            DataTable transposedTable = GenerateTransposedTable(inputTable);           
            
            ExportToSpreadsheet(transposedTable, "CCB Request Form");
           
        }

        private DataTable GenerateTransposedTable(DataTable inputTable)
        {
            DataTable outputTable = new DataTable();

            // Add columns by looping rows

            // Header row's first column is same as in inputTable
            outputTable.Columns.Add(inputTable.Columns[0].ColumnName.ToString());

            // Header row's second column onwards, 'inputTable's first column taken
            foreach (DataRow inRow in inputTable.Rows)
            {
                string newColName = inRow[0].ToString();
                outputTable.Columns.Add(newColName);
            }

            // Add rows by looping columns        
            for (int rCount = 1; rCount <= inputTable.Columns.Count - 1; rCount++)
            {
                DataRow newRow = outputTable.NewRow();

                // First column is inputTable's Header row's second column
                newRow[0] = inputTable.Columns[rCount].ColumnName.ToString();
                for (int cCount = 0; cCount <= inputTable.Rows.Count - 1; cCount++)
                {
                    string colValue = inputTable.Rows[cCount][rCount].ToString();
                    newRow[cCount + 1] = colValue;
                }
                outputTable.Rows.Add(newRow);
            }
            return outputTable;

        }

       

        public static void ExportToSpreadsheet(DataTable tblPeople, string name)
        {        

            HttpContext context = HttpContext.Current;
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ClearContent();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + name + ".xls");
            HttpContext.Current.Response.Charset = "utf-8";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
            //sets font
            HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
            HttpContext.Current.Response.Write("<BR><BR><BR>");
            //sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            HttpContext.Current.Response.Write("<Table border='1' width=750  bgColor='#ffffff' " +
              "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
              "style='text-align:right; font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");          
            context.Response.Write("CHANGE REQUEST FORM- Property Preservation and Inspection");
            HttpContext.Current.Response.Write("</TR>");
            context.Response.Write(Environment.NewLine);
            HttpContext.Current.Response.Write("<TR>");
            foreach (DataColumn column in tblPeople.Columns)
            {    
               HttpContext.Current.Response.Write("<Td>");
               context.Response.Write(column.ColumnName);
               HttpContext.Current.Response.Write("</Td>");
            }
            HttpContext.Current.Response.Write("</TR>");           
            foreach (DataRow row in tblPeople.Rows)
            {
                HttpContext.Current.Response.Write("<TR>");
                for (int i = 0; i < tblPeople.Columns.Count; i++)
                {
                    HttpContext.Current.Response.Write("<Td>");
                    context.Response.Write(row[i].ToString());
                    HttpContext.Current.Response.Write("</Td>");
                }
                HttpContext.Current.Response.Write("</TR>");
            }
            HttpContext.Current.Response.Write("</Table>");
            HttpContext.Current.Response.Write("</font>");
            HttpContext.Current.Response.Flush();
            HttpContext.Current.Response.End();
        }

     
       

    }
}