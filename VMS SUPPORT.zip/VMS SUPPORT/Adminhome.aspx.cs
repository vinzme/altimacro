﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
namespace VMS_SUPPORT
{
    public partial class Adminlogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = HttpContext.Current.User.Identity.Name;
            string username =s.Substring(s.IndexOf(@"\") + 1);         
            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand user = new SqlCommand("Select Uid from users where uname=@userName", conn);            
            user.Parameters.Add("@userName", SqlDbType.VarChar, 25);
            user.Parameters["@userName"].Value = username;
            conn.Open();
            SqlDataReader reader = user.ExecuteReader();           
            if (!reader.HasRows)
            {
                string myStringVariable = "Access denied! Authentication Failed";
                string Aut = "Default.aspx";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('" + myStringVariable + "'); window.location='" + Request.ApplicationPath + Aut + "';", true);              
            }                
      }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            Response.Redirect("Workflow.aspx");
            
        }

        protected void btnsubmit3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Domainexport.aspx");
        }

        protected void btnsubmit2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Template.aspx");
        }

        protected void ccbbutton_Click(object sender, EventArgs e)
        {
            string s = HttpContext.Current.User.Identity.Name;
            string username = s.Substring(s.IndexOf(@"\") + 1);

            SqlConnection conn = VMS_SUPPORT.Connection.GetConnection();
            SqlCommand user = new SqlCommand("Select Uid from users where uname=@userName and is_ccb=1", conn);

            user.Parameters.Add("@userName", SqlDbType.VarChar, 25);
            user.Parameters["@userName"].Value = username;
            conn.Open();
            SqlDataReader reader = user.ExecuteReader();

            if (!reader.HasRows)
            {
                string myStringVariable = "Access denied! Please contact Admin for Access";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable + "');", true);
            }
            else
                if(reader.HasRows)
            {
                string myStringVariable = "Authentication Passed";
                string Aut = "CCBReviewsearch.aspx";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('" + myStringVariable + "'); window.location='" + Request.ApplicationPath + Aut + "';", true);
            }
        }
    }
}