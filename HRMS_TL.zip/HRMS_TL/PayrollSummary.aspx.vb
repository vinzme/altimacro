﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Globalization
Imports System.Data
Imports System.Web.Services
Imports PayrollSummary
Imports Newtonsoft.Json

Public Class PayrollSummary
    Inherits System.Web.UI.Page

    Dim pubUser As String = ""

    Dim cls As New clsConnection

    Dim empID As String
    Dim empNT As String
    Dim empName As String
    Dim empMngrNT As String
    Dim empMngrName As String
    Dim empType As String
    Dim empSchedDate As String
    Dim empStartTime As String
    Dim empEndTime As String
    Dim strNDStart As String
    Dim strNDEnd As String

    Dim dtBSegment As New DataTable
    Dim dtBU As New DataTable
    Dim dtBUPerSegment As New DataTable
    Dim dtManager As New DataTable
    Dim dtManagerPerBU As New DataTable
    Dim dtTL As New DataTable

    Dim dtEmpPayroll As New DataTable
    Dim dtSched As New DataTable
    Dim dtTotalHours As New DataTable
    Dim dtStartTime As New DataTable
    Dim dtEndTime As New DataTable
    Dim dtND As New DataTable
    Dim dtPayroll As New DataTable
    Dim dtHoliday As New DataTable
    Dim dtEmplevel As New DataTable

    Dim sql As String = ""

    Dim actStart As String = ""
    Dim actEnd As String = ""

    Dim NDStartTime As String = "10:00:00 PM"
    Dim NDEndTime As String = "06:00:00 AM"

    Dim NDEnd As String = "06:00:00 AM"
    Dim NDStart As String = "10:00:00 PM"

    Dim earlyMin As String = ""
    Dim OT_Approved_HRS As String = ""

    Dim OT_Consecutive_Days As String = "5"

    Dim fDate1 As String = ""
    Dim fDate2 As String = ""
    Dim rsTable As DataTable

    Dim RH_ND As String = "0"
    Dim RH_Total As String = "0"
    Dim RH_OT As String = "0"

    Dim SNW_ND As String = "0"
    Dim SNW_Total As String = "0"
    Dim SNW_OT As String = "0"

    Dim ND_HRS As String = "0"
    Dim OT_HRS As String = "0"
    Dim Total_HRS As String = "0"

    'Connections
    Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim sqlConn As SqlConnection = New SqlConnection(connStr)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        pubUser = Session("userID")

        If pubUser Is Nothing Then
            Session("page") = "~/PayrollSummary.aspx"
            Response.Redirect("~/Home.aspx")
        End If

    End Sub

    <WebMethod>
    Public Shared Function PopulateList() As PopulateList

        Dim cls As New clsConnection

        Dim da As New DataSet

        Dim rt As New PopulateList

        Dim qry As String = ""

		qry = "select SubSubject from tbl_HRMS_SubjectList where sId = '1' order by SubSubject;"
		qry += "select SubSubject from tbl_HRMS_SubjectList where sId = '2' order by SubSubject;"
		qry += "select SubSubject from tbl_HRMS_SubjectList where sId = '3' order by SubSubject;"
        qry += "select EmpName from dbo.tbl_HRMS_EmployeeMaster where ntid in (select distinct MngrNTID from tbl_HRMS_EmployeeMaster) order by EmpName;"

        da = cls.GetDataSet(qry)

        Dim bs As New List(Of String)
        Dim bu As New List(Of String)
        Dim lvl As New List(Of String)
        Dim isup As New List(Of String)

        Dim addType As New List(Of String)
        Dim adjType As New List(Of String)


        For i = 0 To da.Tables(0).Rows.Count - 1
            bs.Add(da.Tables(0).Rows(i)(0))
        Next

        For i = 0 To da.Tables(1).Rows.Count - 1
            bu.Add(da.Tables(1).Rows(i)(0))
        Next

        For i = 0 To da.Tables(2).Rows.Count - 1
            lvl.Add(da.Tables(2).Rows(i)(0))
        Next

        For i = 0 To da.Tables(3).Rows.Count - 1
            isup.Add(da.Tables(3).Rows(i)(0))
        Next

        rt.bs = bs
        rt.bu = bu
        rt.lvl = lvl

        rt.isup = isup

        rt.additionType = addType
        rt.adjustmentType = adjType

        Return rt
    End Function

    <WebMethod>
    Public Shared Function getEmpNames(data As String) As List(Of autoEmpName)

        Dim autoEmpNameL As New List(Of autoEmpName)


        Dim cls As New clsConnection
        Dim qry As String = ""
        qry = "select top 10 * from dbo.tbl_HRMS_EmployeeMaster where empname like '%" & data & "%' and AccessLevel is not null and NTID is not null order by empname"

        Dim dt As DataTable = cls.GetData(qry)

        For i = 0 To dt.Rows.Count - 1
            Dim d As New autoEmpName
            d.ntid = dt.Rows(i)("ntid")
            d.empname = dt.Rows(i)("empname")

            autoEmpNameL.Add(d)
        Next

        Return autoEmpNameL
    End Function


    <WebMethod>
    Public Shared Function btnGenerate_Click(data As PSgetList) As String

        Try
            Dim payrollTableReturnL As New List(Of payrollTableReturn)
            Dim cls As New clsConnection
            Dim qry As String = ""
            Dim connStr = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()

            Dim sqlConn = New SqlConnection(connStr)
            Dim cmd As New SqlCommand("sp_payrollHours", sqlConn)

            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@from", data.dtFrom)
            cmd.Parameters.AddWithValue("@to", data.dtTo)
            cmd.Parameters.AddWithValue("@cmd", "SELECT")

            If Not data.bs = "0" Then cmd.Parameters.AddWithValue("@segment", data.bs)
            If Not data.bu = "0" Then cmd.Parameters.AddWithValue("@unit", data.bu)
            If Not data.lvl = "0" Then cmd.Parameters.AddWithValue("@level", data.lvl)
            If Not data.isup = "0" Then cmd.Parameters.AddWithValue("@superior", data.isup)

            Dim da As New SqlDataAdapter(cmd)

            Dim dt As New DataTable

			da.SelectCommand.CommandTimeout = 180

            da.Fill(dt)

            da.Dispose()

            Return JsonConvert.SerializeObject(New With {Key .Success = True, Key .Message = "Success", Key .data = New With {Key .columns = cls.FUNC.GetAllColumnName(dt), Key .record = cls.FUNC.convertAllColumnsToString(dt)}})

        Catch ex As Exception
            Return JsonConvert.SerializeObject(New With {Key .Success = False, Key .Message = ex.Message})
        End Try

        'For i = 0 To dt.Rows.Count - 1
        '    Dim d As New payrollTableReturn

        '    d.Cut_Off = dt.Rows(i)("Cut_Off")
        '    d.Status = dt.Rows(i)("Status")
        '    'd.emplevel = dt.Rows(i)("emplevel")
        '    d.EmpID = dt.Rows(i)("EmpID")
        '    d.EmpName = dt.Rows(i)("EmpName")
        '    d.NTID = dt.Rows(i)("NTID")
        '    d.MngrID = dt.Rows(i)("MngrID")
        '    d.MngrName = dt.Rows(i)("MngrName")
        '    d.Scheduled_Start = dt.Rows(i)("Scheduled Start")
        '    d.Scheduled_Out = dt.Rows(i)("Scheduled Out")
        '    d.Log_In_Time = dt.Rows(i)("Log In Time")
        '    d.Log_Out_Time = dt.Rows(i)("Log Out Time")
        '    d.TotalUnComputedHours = dt.Rows(i)("TotalUnComputedHours")
        '    d.TOTAL_ND_HRS = dt.Rows(i)("TOTAL_ND_HRS")
        '    d.TOTAL_REG_HRS = dt.Rows(i)("TOTAL_REG_HRS")
        '    d.TOTAL_OT_HRS = dt.Rows(i)("TOTAL_OT_HRS")
        '    d.RH_ND_HOURS = dt.Rows(i)("RH_ND_HOURS")
        '    d.RH_REG_HOURS = dt.Rows(i)("RH_REG_HOURS")
        '    d.RH_OT_HOURS = dt.Rows(i)("RH_OT_HOURS")
        '    d.SNW_ND_HOURS = dt.Rows(i)("SNW_ND_HOURS")
        '    d.SNW_REG_HOURS = dt.Rows(i)("SNW_REG_HOURS")
        '    d.SNW_OT_HOURS = dt.Rows(i)("SNW_OT_HOURS")
        '    d.PTO_Whole_Day = dt.Rows(i)("PTO Whole Day")
        '    d.PTO_Half_Day = dt.Rows(i)("PTO Half Day")
        '    d.Maternity = dt.Rows(i)("Maternity")
        '    d.Paternity = dt.Rows(i)("Paternity")
        '    d.SoloParent = dt.Rows(i)("SoloParent")
        '    d.NDRestDay = dt.Rows(i)("NDRestDay")
        '    d.RestDay = dt.Rows(i)("RestDay")
        '    d.RestDayOT = dt.Rows(i)("RestDayOT")
        '    d.RD_RH_ND_HOURS = dt.Rows(i)("RD_RH_ND_HOURS")
        '    d.RD_RH_REG_HOURS = dt.Rows(i)("RD_RH_REG_HOURS")
        '    d.RD_RH_OT_HOURS = dt.Rows(i)("RD_RH_OT_HOURS")
        '    d.RD_SNW_ND_HOURS = dt.Rows(i)("RD_SNW_ND_HOURS")
        '    d.RD_SNW_REG_HOURS = dt.Rows(i)("RD_SNW_REG_HOURS")
        '    d.RD_SNW_OT_HOURS = dt.Rows(i)("RD_SNW_OT_HOURS")

        '    payrollTableReturnL.Add(d)
        'Next


    End Function

    Public Shared Function convertDataTabletoJSON(dt As DataTable) As String

        Dim serializer As New System.Web.Script.Serialization.JavaScriptSerializer()
        Dim rows As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object)
        For Each dr As DataRow In dt.Rows
            row = New Dictionary(Of String, Object)()
            For Each col As DataColumn In dt.Columns
                row.Add(col.ColumnName, dr(col))
            Next
            rows.Add(row)
        Next
        Return serializer.Serialize(rows)
    End Function


End Class
