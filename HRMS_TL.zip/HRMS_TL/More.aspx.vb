﻿Imports System.Web.Services
Imports System.IO
Imports iTextSharp.text.pdf
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf.parser
Imports iTextSharp.text.html
Imports HRMS.CustomHtmlWorkerTag
Imports System.Data

Public Class More
	Inherits System.Web.UI.Page

	Dim pubUser As String = ""

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/More.aspx"
			Response.Redirect("~/Home.aspx")
		End If
	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub GetRequest(Request As Request)

		Dim cls As New clsConnection
		Dim query As String = ""
		Dim rt As New Integer

		query = "insert into tbl_HRMS_RequestForms (form_name, emp_level, isAllow_Print, isAllow_Send, isAllow_Share, isSign_Auto, isSign_Perm, isSign_Print, isAuto_OnLeave, isAuto_NotSigned, Auto_NotSigned_Days, firstSignatory, firstSignatory_BackUp, secSignatory, secSignatory_Backup) "
		query += "values('" & Request.formName & "', '" & Request.empLevel & "', Case when '" & Request.isPrint & "' = 1 then '1' else '0' end, Case when '" & Request.isSend & "' = 1 then '1' else '0' end, Case when '" & Request.isShare & "' = 1 then '1' else '0' end, "
		query += "Case when '" & Request.isSigned & "' = 1 then '1' else '0' end, Case when '" & Request.isSignPerm & "' = 1 then '1' else '0' end, Case when '" & Request.isSignPrint & "' = 1 then '1' else '0' end, Case when '" & Request.isAuto & "' = 1 then '1' else '0' end, "
		query += "Case when '" & Request.isAutoDays & "' = 1 then '1' else '0' end, '" & Request.days & "', '" & Request.firstSig & "', '" & Request.firstBackup & "', '" & Request.secondSig & "', '" & Request.secondBackup & "')"

		rt = cls.ExecuteQuery(query)

	End Sub

	<WebMethod()> _
	Public Shared Function GetDocument()
		Dim cls As New clsConnection
		Dim Document As New Document
		Dim qry As String = ""
		Dim dtDocument As New DataTable

		qry = "select * from dbo.tbl_HRMS_CompanyDetails a join dbo.tbl_HRMS_EmployerDetails b on a.CompanyName = b.Name"

		dtDocument = cls.GetData(qry)

		Dim DocumentLists As New List(Of DocumentList)

		Dim x As Integer = 0
		Do Until x = dtDocument.Rows.Count
			Dim DocumentList As New DocumentList

			DocumentList.companyName = dtDocument.Rows(x)("CompanyName")
			DocumentList.address = dtDocument.Rows(x)("Address")
			DocumentList.zip = dtDocument.Rows(x)("Zip")
			DocumentList.telephone = dtDocument.Rows(x)("Telephone")
			DocumentList.fax = dtDocument.Rows(x)("Fax")
			DocumentList.generalEmail = dtDocument.Rows(x)("GeneralEmail")
			DocumentList.tin = dtDocument.Rows(x)("TIN")
			DocumentList.sss = dtDocument.Rows(x)("SSS")
			DocumentList.philHealth = dtDocument.Rows(x)("PhilHealth")
			DocumentList.hdmf = dtDocument.Rows(x)("HDMF")
			DocumentList.webPage = dtDocument.Rows(x)("WebPage")
			DocumentList.companyRegistration = dtDocument.Rows(x)("CompanyRegistration")
			DocumentList.dateOfRegistration = dtDocument.Rows(x)("DateOfRegistration")

			DocumentLists.Add(DocumentList)

			x += 1
		Loop

		Document.tblDocument = DocumentLists

		Return Document
	End Function

	<WebMethod()> _
	Public Shared Function SaveDocument(user As String, file As String, type As String, form As String)
		Dim qry As String = ""
		Dim cls As New clsConnection
		Dim rt As New Integer

		Dim filename As String = String.Concat(file, ".pdf")

		Using stream As New FileStream(String.Concat(HttpContext.Current.Server.MapPath("~/PDF Template/"), filename), FileMode.Create)
			Using ms As New MemoryStream()
				Dim document As New iTextSharp.text.Document(PageSize.A4, 25, 25, 30, 30)
				Dim writer As PdfWriter = PdfWriter.GetInstance(document, stream)

				'Dim image1 As Image = Image.GetInstance(HttpContext.Current.Server.MapPath("~/images/Altisource_Logo.png"))
				document.Open()


				'Dim tags = New HTMLTagProcessors()
				'tags(HtmlTags.IMG) = New CustomImageHTMLTagProcessor()


				'Dim chunk1 As Chunk = New Chunk(form.IndexOf("[President Signature]"))
				Dim img1 As iTextSharp.text.Image
				'Dim img2 As iTextSharp.text.Image
				Dim regx As Regex = New Regex("(<img src=""([\w\/\;\:\,\+]+)=="">)", RegexOptions.IgnoreCase)

				'Dim mtch As Match = regx.Matches(regx).

				Dim str As String = regx.Matches(form).Count
				Dim x As Integer = 1
				For Each strE As Match In regx.Matches(form)
					Dim strA As String = strE.Value
					'Dim strindex1 As String = strE.Value.IndexOf("<img src=""")
					'Dim strindex2 As String = strE.Value.IndexOf(""">")
					strA = strA.Replace("<img src=""", "")
					strA = strA.Replace(""">", "")
					If strA.StartsWith("data:image/") Then
						Dim base64Data = strA.Substring(strA.IndexOf(",") + 1)
						Dim imageData As Byte() = Convert.FromBase64String(base64Data)
						Dim imageStream As MemoryStream = New MemoryStream(imageData)
						img1 = iTextSharp.text.Image.GetInstance(imageStream)
					End If
					document.Add(img1)
				Next

				Dim strindex1 As Integer = form.IndexOf("<img src=""")
				Dim strindex2 As Integer = form.IndexOf(">")

				form = form.Remove(strindex1, strindex2 + 1)

				Dim strindex3 As Integer = form.IndexOf("<img src=""")
				Dim strindex4 As Integer = form.IndexOf("=="">")

				'Dim strinx As String = form.Chars(strindex4 + 3)
				form = form.Remove(strindex3, (strindex4 + 4) - strindex3)


				'document.Add(img2)
				Dim worker As New HTMLWorker(document)
				'worker.ProcessImage(img1, )
				worker.Parse(New StringReader(form))

				document.Close()
				writer.Close()
				HttpContext.Current.Response.ContentType = "pdf/application"
				HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" & filename)
				HttpContext.Current.Response.OutputStream.Write(ms.GetBuffer(), 0, ms.GetBuffer().Length)
			End Using
		End Using

		Dim check As String = ""
		Dim dtCheck As New DataTable

		check = "select * from tbl_HRMS_Documents where FormName = '" & file & "' and Type = '" & type & "'"

		dtCheck = cls.GetData(check)

		If dtCheck.Rows.Count > 0 Then
			qry = "update tbl_HRMS_Documents set FormName = '" & file & "', CodeName = '" & file & "', '" & type & "', AddedBy = '" & user & "', DateAdded = GETDATE() where CodeName = '" & file & "' and Type = '" & type & "'"
		Else
			qry = "insert into tbl_HRMS_Documents (FormName, CodeName, Type, Category, AddedBy, DateAdded) "
			qry += "values ('" & file & "', '" & file & "', '" & type & "', 'New', '" & user & "', GETDATE())"
		End If

		rt = cls.ExecuteQuery(qry)

		Return filename
	End Function

	<WebMethod>
	Public Shared Function GetDocuments()
		Dim qry As String = ""
		Dim qry2 As String = ""
		Dim cls As New clsConnection
		Dim dtDocumentsPersonal As New DataTable
		Dim dtDocumentsCompany As New DataTable
		Dim Form As New Form

		qry = "select * from tbl_HRMS_Documents where Type = 'Personal' and DeletedBy is null"

		dtDocumentsPersonal = cls.GetData(qry)

		qry2 = "select * from tbl_HRMS_Documents where Type = 'Company' and DeletedBy is null"

		dtDocumentsCompany = cls.GetData(qry2)

		Dim FormLists1 As New List(Of FormList)
		Dim FormLists2 As New List(Of FormList)

		Dim x As Integer = 0
		Do Until x = dtDocumentsPersonal.Rows.Count
			Dim FormList As New FormList

			FormList.formName = dtDocumentsPersonal.Rows(x)("FormName")
			FormList.codeName = dtDocumentsPersonal.Rows(x)("CodeName")

			FormLists1.Add(FormList)
			x += 1
		Loop

		Dim y As Integer = 0
		Do Until y = dtDocumentsCompany.Rows.Count
			Dim FormList As New FormList

			FormList.formName = dtDocumentsCompany.Rows(y)("FormName")
			FormList.codeName = dtDocumentsCompany.Rows(y)("CodeName")

			FormLists2.Add(FormList)

			y += 1
		Loop

		Form.tblDocumentsPersonal = FormLists1
		Form.tblDocumentsCompany = FormLists2

		Return Form
	End Function

	<WebMethod>
	Public Shared Function GetSavedDocs()
		Dim qry As String = ""
		Dim cls As New clsConnection
		Dim dtSavedDocs As New DataTable
		Dim SavedDocs As New SavedDocs

		qry = "select * from tbl_HRMS_Documents where Category = 'New' and DeletedBy is null"

		dtSavedDocs = cls.GetData(qry)

		Dim SavedDocsLists As New List(Of SavedDocsList)

		Dim x As Integer = 0
		Do Until x = dtSavedDocs.Rows.Count
			Dim SavedDocsList As New SavedDocsList

			SavedDocsList.docName = dtSavedDocs.Rows(x)("FormName")
			SavedDocsList.createdBy = dtSavedDocs.Rows(x)("AddedBy")
			SavedDocsList.dateModified = dtSavedDocs.Rows(x)("DateAdded")

			SavedDocsLists.Add(SavedDocsList)
			x += 1
		Loop

		SavedDocs.tblSavedDocs = SavedDocsLists

		Return SavedDocs
	End Function

	<WebMethod>
	Public Shared Sub DeleteSavedDocs(empID As String, formName As String, createdBy As String)
		Dim qry As String = ""
		Dim cls As New clsConnection
		Dim rt As Integer

		qry = "update tbl_HRMS_Documents set DeletedBy = '" & empID & "', DateDeleted = GETDATE() where FormName = '" & formName & "' and AddedBy = '" & createdBy & "'"

		rt = cls.ExecuteQuery(qry)
	End Sub

	<WebMethod>
	Public Shared Function GetSubj(sbjID As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtSubject As New DataTable
		Dim Subject As New Subject

		qry = "select * from tbl_HRMS_SubjectList where Tag <> 'Delete' and Subject = '" & sbjID & "'"

		dtSubject = cls.GetData(qry)

		Dim SubjectLists As New List(Of SubjectList)

		Dim x As Integer = 0
		Do Until x = dtSubject.Rows.Count
			Dim SubjectList As New SubjectList

			SubjectList.Subject = dtSubject.Rows(x)("Subject")
			SubjectList.SubSubject = dtSubject.Rows(x)("SubSubject")
			SubjectList.ModifiedBy = dtSubject.Rows(x)("ModifiedBy")
			SubjectList.DateModified = dtSubject.Rows(x)("DateModified")
			SubjectList.Modified = dtSubject.Rows(x)("ModifiedBy") & " - " & dtSubject.Rows(x)("DateModified")

			SubjectLists.Add(SubjectList)
			x += 1
		Loop

		Subject.tblSubject = SubjectLists

		Return Subject
	End Function

End Class