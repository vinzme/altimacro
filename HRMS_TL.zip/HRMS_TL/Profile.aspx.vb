﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Services
Imports System.Data

Public Class Profile
	Inherits System.Web.UI.Page

	Dim cls As New clsConnection
	Dim pubUser As String

#Region "Employee Info"
	Dim empID As String
	Dim empNT As String
	Dim empAlias As String
	Dim empName As String
	Dim empSupervisor As String
	Dim empDeptName As String
	Dim empDeptCode As String
	Dim empJobDesc As String
	Dim empEmail As String
	Dim empExtNum As String
	Dim empSkill As String
	Dim empJoinDate As String
	Dim empProdDate As String
	Dim empRegDate As String
	Dim empTenure As String
	Dim empTenureInMonths As String
	Dim empBatch As String
	Dim empClass As String
	Dim empStat As String
	Dim empBU As String
	Dim empBUHead As String
	Dim empStation As String
	Dim empTimeIn As String
	Dim empTimeOut As String
#End Region

#Region "Personal Info"
	'Personal Info
	Dim personalHouseNum As String
	Dim personalStName As String
	Dim personalBrgy As String
	Dim personalTown As String
	Dim personalCity As String
	Dim personalRegion As String
	Dim personalZip As String
	Dim personalBlood As String
	Dim personalGender As String
	Dim personalDOB As String
	Dim personalCitizenship As String

	'Personal Contact
	Dim personalAreaCodeMobile As String
	Dim personalMobileNum As String
	Dim personalAreaCodeHome As String
	Dim personalHomeNum As String
	Dim personalEmail As String

	'Emergency Contact
	Dim emrgName As String
	Dim emrgNum As String
	Dim emrgRel As String
#End Region

#Region "Emgergency Contact"

#End Region

#Region "Employement History"
	'Employer1
	Dim histEmployer1 As String
	Dim histWork1 As String
	Dim histDateFrom1 As String
	Dim histDateTo1 As String
	Dim histTenure1 As String

	'Employer2
	Dim histEmployer2 As String
	Dim histWork2 As String
	Dim histDateFrom2 As String
	Dim histDateTo2 As String
	Dim histTenure2 As String

	'Employer3
	Dim histEmployer3 As String
	Dim histWork3 As String
	Dim histDateFrom3 As String
	Dim histDateTo3 As String
	Dim histTenure3 As String

	'Employer4
	Dim histEmployer4 As String
	Dim histWork4 As String
	Dim histDateFrom4 As String
	Dim histDateTo4 As String
	Dim histTenure4 As String

	'Employer5
	Dim histEmployer5 As String
	Dim histWork5 As String
	Dim histDateFrom5 As String
	Dim histDateTo5 As String
	Dim histTenure5 As String
#End Region

#Region "School"
	'School1
	Dim educSchool1 As String
	Dim educCourse1 As String
	Dim educDegree1 As String
	Dim educLocation1 As String
	Dim educDateFrom1 As String
	Dim educDateTo1 As String

	'School2
	Dim educSchool2 As String
	Dim educCourse2 As String
	Dim educDegree2 As String
	Dim educLocation2 As String
	Dim educDateFrom2 As String
	Dim educDateTo2 As String

	'School3
	Dim educSchool3 As String
	Dim educCourse3 As String
	Dim educDegree3 As String
	Dim educLocation3 As String
	Dim educDateFrom3 As String
	Dim educDateTo3 As String
#End Region

#Region "Confidential Information"
	Dim confiTax As String
	Dim confiSSS As String
	Dim confiTIN As String
	Dim confiPhilHealth As String
	Dim confiPagIbig As String
#End Region

#Region "Dependent Details"
	Dim depFathersName As String
	Dim depFathersDOB As String
	Dim depMothersName As String
	Dim depMothersDOB As String
	Dim depSpouseName As String
	Dim depSpouseDOB As String
	Dim depChild1Name As String
	Dim depChild1DOB As String
	Dim depChild2Name As String
	Dim depChild2DOB As String
	Dim depChild3Name As String
	Dim depChild3DOB As String
#End Region

#Region "Data Tables"
	'DataTables
	Dim dtLastActivity As New DataTable
	Dim dtEmp As New DataTable
	Dim dtTenure As New DataTable
	Dim dtSched As New DataTable
	Dim dtPersonal As New DataTable
	Dim dtEmergency As New DataTable
	Dim dtHistory As New DataTable
	Dim dtEduc As New DataTable
	Dim dtConfidential As New DataTable
	Dim dtDependent As New DataTable

	Dim dtCompany As New DataTable
	Dim dtSchool As New DataTable
	Dim dtCourse As New DataTable
	Dim dtEducAttainment As New DataTable
	Dim dtBrgy As New DataTable
	Dim dtTown As New DataTable
	Dim dtCity As New DataTable
	Dim dtRegion As New DataTable
	Dim dtCitizenship As New DataTable

	Dim dtChanges As New DataTable
#End Region

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Profile.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		GetEmpInfo()
		GetSched()
		CheckPersonalInfo()
		CheckHistory()
		CheckEduc()
		CheckConfidentialInfo()
		CheckDependent()
		GetTenure()

		empID = dtEmp.Rows(0)("EmpID")

		If Not IsPostBack Then

			GetLastActivity()

			'If dtLastActivity.Rows(0)("reasonid") = 14 Or
			'    dtLastActivity.Rows(0)("reasonid") = 16 Then

			'    Response.Redirect("Home.aspx")
			'Else

			'----------------------
			'Employee Information
			'----------------------
			If dtSched.Rows.Count > 0 Then
				If Not IsDBNull(dtSched.Rows(0)("SchedIN")) Then
					txtBoxEmpTimeIn.Text = dtSched.Rows(0)("SchedIN")
				Else
					txtBoxEmpTimeIn.Text = ""
				End If

				If Not IsDBNull(dtSched.Rows(0)("SchedOUT")) Then
					txtBoxEmpTimeOut.Text = dtSched.Rows(0)("SchedOUT")
				Else
					txtBoxEmpTimeOut.Text = ""
				End If
			End If

			If dtEmp.Rows.Count > 0 Then
				If Not IsDBNull(dtEmp.Rows(0)("EmpID")) Then
					txtBoxEmpNum.Text = dtEmp.Rows(0)("EmpID")
				Else
					txtBoxEmpNum.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("NTID")) Then
					txtBoxEmpNT.Text = dtEmp.Rows(0)("NTID")
				Else
					txtBoxEmpNT.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("Alias")) Then
					txtBoxEmpAlias.Text = dtEmp.Rows(0)("Alias")
				Else
					txtBoxEmpAlias.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("EmpName")) Then
					txtBoxEmpName.Text = dtEmp.Rows(0)("EmpName")
				Else
					txtBoxEmpName.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("MngrName")) Then
					txtBoxEmpSupervisor.Text = dtEmp.Rows(0)("MngrName")
				Else
					txtBoxEmpSupervisor.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("DeptName")) Then
					txtBoxEmpDeptName.Text = dtEmp.Rows(0)("DeptName")
				Else
					txtBoxEmpDeptName.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("DeptCode")) Then
					txtBoxEmpDeptCode.Text = dtEmp.Rows(0)("DeptCode")
				Else
					txtBoxEmpDeptCode.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("JobDesc")) Then
					txtBoxEmpJobDesc.Text = dtEmp.Rows(0)("JobDesc")
				Else
					txtBoxEmpJobDesc.Text = ""
				End If

				txtBoxEmpEmail.Text = pubUser + "@altisource.com"

				If Not IsDBNull(dtEmp.Rows(0)("ExtensionNumber")) Then
					txtBoxEmpExtNum.Text = dtEmp.Rows(0)("ExtensionNumber")
				Else
					txtBoxEmpExtNum.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("Skill")) Then
					If dtEmp.Rows(0)("Skill") <> "" Then
						ddlEmpSkill.ClearSelection()
						ddlEmpSkill.Items.FindByValue(dtEmp.Rows(0)("Skill")).Selected = True
					Else
						ddlEmpSkill.ClearSelection()
						ddlEmpSkill.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEmpSkill.ClearSelection()
					ddlEmpSkill.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEmp.Rows(0)("DateJoined")) Then
					txtBoxEmpJoinDate.Text = dtEmp.Rows(0)("DateJoined")
				Else
					txtBoxEmpJoinDate.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("ProdDate")) Then
					txtBoxEmpProdDate.Text = dtEmp.Rows(0)("ProdDate")
				Else
					txtBoxEmpProdDate.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("RegDate")) Then
					txtBoxEmpRegDate.Text = dtEmp.Rows(0)("RegDate")
				Else
					txtBoxEmpRegDate.Text = ""
				End If

				Dim tenure As String = dtTenure.Rows(0)("Years") & " years " & dtTenure.Rows(0)("Months") & " months " & dtTenure.Rows(0)("Days") & " days"

				If tenure <> "" Then
					txtBoxEmpTenure.Text = tenure
				Else
					txtBoxEmpTenure.Text = ""
				End If

				'If Not IsDBNull(dtEmp.Rows(0)("Tenure")) Then
				'    txtBoxEmpTenure.Text = dtEmp.Rows(0)("Tenure")
				'Else
				'    txtBoxEmpTenure.Text = ""
				'End If
				If Not IsDBNull(dtEmp.Rows(0)("TenureInMonths")) Then
					txtBoxEmpTenureInMonths.Text = dtEmp.Rows(0)("TenureInMonths")
				Else
					txtBoxEmpTenureInMonths.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("Batch")) Then
					txtBoxEmpBatch.Text = dtEmp.Rows(0)("Batch")
				Else
					txtBoxEmpBatch.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("Class")) Then
					txtBoxEmpClass.Text = dtEmp.Rows(0)("Class")
				Else
					txtBoxEmpClass.Text = ""
				End If
				If Not IsDBNull(dtEmp.Rows(0)("EmpStatus")) Then
					txtBoxEmpStat.Text = dtEmp.Rows(0)("EmpStatus")
				Else
					txtBoxEmpStat.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("BusinessUnit")) Then
					txtBoxEmpBU.Text = dtEmp.Rows(0)("BusinessUnit")
				Else
					txtBoxEmpBU.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("BusinessUnitHead")) Then
					txtBoxEmpBUHead.Text = dtEmp.Rows(0)("BusinessUnitHead")
				Else
					txtBoxEmpBUHead.Text = ""
				End If

				If Not IsDBNull(dtEmp.Rows(0)("Workstation")) Then
					txtBoxEmpStation.Text = dtEmp.Rows(0)("Workstation")
				Else
					txtBoxEmpStation.Text = ""
				End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------

			'-----------------------
			'Personal Information
			'-----------------------
			GetCitizenship()

			If dtPersonal.Rows.Count > 0 Then
				If Not IsDBNull(dtPersonal.Rows(0)("HouseNumber")) Then
					txtBoxPersonalHouseNum.Text = dtPersonal.Rows(0)("HouseNumber")
				Else
					txtBoxPersonalHouseNum.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("StreetName")) Then
					txtBoxPersonalStName.Text = dtPersonal.Rows(0)("StreetName")
				Else
					txtBoxPersonalStName.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("Barangay")) Then
					txtBoxPersonalBrgy.Text = dtPersonal.Rows(0)("Barangay")
				Else
					txtBoxPersonalBrgy.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("Town")) Then
					txtBoxPersonalTown.Text = dtPersonal.Rows(0)("Town")
				Else
					txtBoxPersonalTown.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("City")) Then
					txtBoxPersonalCity.Text = dtPersonal.Rows(0)("City")
				Else
					txtBoxPersonalCity.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("Region")) Then
					txtBoxPersonalRegion.Text = dtPersonal.Rows(0)("Region")
				Else
					txtBoxPersonalRegion.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("ZipCode")) Then
					txtBoxPersonalZip.Text = dtPersonal.Rows(0)("ZipCode")
				Else
					txtBoxPersonalZip.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("BloodType")) Then
					If dtPersonal.Rows(0)("BloodType") <> "" Then
						ddlBlood.ClearSelection()
						ddlBlood.Items.FindByValue(dtPersonal.Rows(0)("BloodType")).Selected = True
					Else
						ddlBlood.ClearSelection()
						ddlBlood.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlBlood.ClearSelection()
					ddlBlood.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("Gender")) Then
					If dtPersonal.Rows(0)("Gender") <> "" Then
						ddlGender.ClearSelection()
						ddlGender.Items.FindByValue(dtPersonal.Rows(0)("Gender")).Selected = True
					Else
						ddlGender.ClearSelection()
						ddlGender.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlGender.ClearSelection()
					ddlGender.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("DOB")) Then
					txtBoxPersonalDOB.Text = dtPersonal.Rows(0)("DOB")
				Else
					txtBoxPersonalDOB.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("Citizenship")) Then
					If dtPersonal.Rows(0)("Citizenship") <> "" Then
						ddlCitizenship.ClearSelection()
						ddlCitizenship.Items.FindByValue(dtPersonal.Rows(0)("Citizenship").ToString.Trim).Selected = True
					Else
						ddlCitizenship.ClearSelection()
						ddlCitizenship.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlCitizenship.ClearSelection()
					ddlCitizenship.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("MobileAreaCode")) Then
					If dtPersonal.Rows(0)("MobileAreaCode") <> "" Then
						ddlPersonalMobileArea.ClearSelection()
						ddlPersonalMobileArea.Items.FindByValue(dtPersonal.Rows(0)("MobileAreaCode").ToString.Trim).Selected = True
					Else
						ddlPersonalMobileArea.ClearSelection()
						ddlPersonalMobileArea.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlPersonalMobileArea.ClearSelection()
					ddlPersonalMobileArea.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("MobileNumber")) Then
					txtBoxPersonalMobileNum.Text = dtPersonal.Rows(0)("MobileNumber")
				Else
					txtBoxPersonalMobileNum.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("HomeAreaCode")) Then
					If dtPersonal.Rows(0)("HomeAreaCode") <> "" Then
						ddlPersonalHomeArea.ClearSelection()
						ddlPersonalHomeArea.Items.FindByValue(dtPersonal.Rows(0)("HomeAreaCode")).Selected = True
					Else
						ddlPersonalHomeArea.ClearSelection()
						ddlPersonalHomeArea.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlPersonalHomeArea.ClearSelection()
					ddlPersonalHomeArea.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("HomeNumber")) Then
					txtBoxPersonalHomeNum.Text = dtPersonal.Rows(0)("HomeNumber")
				Else
					txtBoxPersonalHomeNum.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("PersonalEmail")) Then
					txtBoxPersonalEmail.Text = dtPersonal.Rows(0)("PersonalEmail")
				Else
					txtBoxPersonalEmail.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("EmrgName")) Then
					txtBoxEmergencyName.Text = dtEmergency.Rows(0)("EmrgName")
				Else
					txtBoxEmergencyName.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("EmrgNumber")) Then
					txtBoxEmergencyContactNum.Text = dtPersonal.Rows(0)("EmrgNumber")
				Else
					txtBoxEmergencyContactNum.Text = ""
				End If

				If Not IsDBNull(dtPersonal.Rows(0)("EmrgRelationship")) Then
					If dtPersonal.Rows(0)("EmrgRelationship") <> "" Then
						ddlEmergencyRel.ClearSelection()
						ddlEmergencyRel.Items.FindByValue(dtPersonal.Rows(0)("EmrgRelationship")).Selected = True
					Else
						ddlEmergencyRel.ClearSelection()
						ddlEmergencyRel.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEmergencyRel.ClearSelection()
					ddlEmergencyRel.Items.FindByValue("--Select One Below--").Selected = True
				End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------

			'---------------------
			'Employment History
			'---------------------

			GetCompnay()

			If dtHistory.Rows.Count > 0 Then
				'Employer1
				If Not IsDBNull(dtHistory.Rows(0)("Employer1")) Then
					If dtHistory.Rows(0)("Employer1").Trim <> "--Select One Below--" Then
						ddlHistEmployer1.ClearSelection()
						ddlHistEmployer1.Items.FindByValue(dtHistory.Rows(0)("Employer1").Trim).Selected = True
					Else
						ddlHistEmployer1.ClearSelection()
						ddlHistEmployer1.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlHistEmployer1.ClearSelection()
					ddlHistEmployer1.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtHistory.Rows(0)("Work1")) Then
					txtBoxHistWork1.Text = dtHistory.Rows(0)("Work1")
				Else
					txtBoxHistWork1.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateFrom1")) Then
					txtBoxHistDateFrom1.Text = dtHistory.Rows(0)("DateFrom1")
				Else
					txtBoxHistDateFrom1.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateTo1")) Then
					txtBoxHistDateTo1.Text = dtHistory.Rows(0)("DateTo1")
				Else
					txtBoxHistDateTo1.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("TenureInMonths1")) Then
					txtBoxHistTenure1.Text = dtHistory.Rows(0)("TenureInMonths1")
				Else
					txtBoxHistTenure1.Text = ""
				End If

				'Employer2
				If Not IsDBNull(dtHistory.Rows(0)("Employer2")) Then
					If dtHistory.Rows(0)("Employer2") <> "" Then
						ddlHistEmployer2.ClearSelection()
						ddlHistEmployer2.Items.FindByValue(dtHistory.Rows(0)("Employer2")).Selected = True
					Else
						ddlHistEmployer2.ClearSelection()
						ddlHistEmployer2.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlHistEmployer2.ClearSelection()
					ddlHistEmployer2.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtHistory.Rows(0)("Work2")) Then
					txtBoxHistWork2.Text = dtHistory.Rows(0)("Work2")
				Else
					txtBoxHistWork2.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateFrom2")) Then
					txtBoxHistDateFrom2.Text = dtHistory.Rows(0)("DateFrom2")
				Else
					txtBoxHistDateFrom2.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateTo2")) Then
					txtBoxHistDateTo2.Text = dtHistory.Rows(0)("DateTo2")
				Else
					txtBoxHistDateTo2.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("TenureInMonths2")) Then
					txtBoxHistTenure2.Text = dtHistory.Rows(0)("TenureInMonths2")
				Else
					txtBoxHistTenure2.Text = ""
				End If

				'Employer3
				If Not IsDBNull(dtHistory.Rows(0)("Employer3")) Then
					If dtHistory.Rows(0)("Employer3") <> "" Then
						ddlHistEmployer3.ClearSelection()
						ddlHistEmployer3.Items.FindByValue(dtHistory.Rows(0)("Employer3")).Selected = True
					Else
						ddlHistEmployer3.ClearSelection()
						ddlHistEmployer3.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlHistEmployer3.ClearSelection()
					ddlHistEmployer3.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtHistory.Rows(0)("Work3")) Then
					txtBoxHistWork3.Text = dtHistory.Rows(0)("Work3")
				Else
					txtBoxHistWork3.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateFrom3")) Then
					txtBoxHistDateFrom3.Text = dtHistory.Rows(0)("DateFrom3")
				Else
					txtBoxHistDateFrom3.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateTo3")) Then
					txtBoxHistDateTo3.Text = dtHistory.Rows(0)("DateTo3")
				Else
					txtBoxHistDateTo3.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("TenureInMonths3")) Then
					txtBoxHistTenure3.Text = dtHistory.Rows(0)("TenureInMonths3")
				Else
					txtBoxHistTenure3.Text = ""
				End If

				'Employer4
				If Not IsDBNull(dtHistory.Rows(0)("Employer4")) Then
					If dtHistory.Rows(0)("Employer4") <> "" Then
						ddlHistEmployer4.ClearSelection()
						ddlHistEmployer4.Items.FindByValue(dtHistory.Rows(0)("Employer4")).Selected = True
					Else
						ddlHistEmployer4.ClearSelection()
						ddlHistEmployer4.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlHistEmployer4.ClearSelection()
					ddlHistEmployer4.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtHistory.Rows(0)("Work4")) Then
					txtBoxHistWork4.Text = dtHistory.Rows(0)("Work4")
				Else
					txtBoxHistWork4.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateFrom4")) Then
					txtBoxHistDateFrom4.Text = dtHistory.Rows(0)("DateFrom4")
				Else
					txtBoxHistDateFrom4.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateTo4")) Then
					txtBoxHistDateTo4.Text = dtHistory.Rows(0)("DateTo4")
				Else
					txtBoxHistDateTo4.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("TenureInMonths4")) Then
					txtBoxHistTenure4.Text = dtHistory.Rows(0)("TenureInMonths4")
				Else
					txtBoxHistTenure4.Text = ""
				End If

				'Employer5
				If Not IsDBNull(dtHistory.Rows(0)("Employer5")) Then
					If dtHistory.Rows(0)("Employer5") <> "" Then
						ddlHistEmployer5.ClearSelection()
						ddlHistEmployer5.Items.FindByValue(dtHistory.Rows(0)("Employer5")).Selected = True
					Else
						ddlHistEmployer5.ClearSelection()
						ddlHistEmployer5.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlHistEmployer5.ClearSelection()
					ddlHistEmployer5.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtHistory.Rows(0)("Work5")) Then
					txtBoxHistWork5.Text = dtHistory.Rows(0)("Work5")
				Else
					txtBoxHistWork5.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateFrom5")) Then
					txtBoxHistDateFrom5.Text = dtHistory.Rows(0)("DateFrom5")
				Else
					txtBoxHistDateFrom5.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("DateTo5")) Then
					txtBoxHistDateTo5.Text = dtHistory.Rows(0)("DateTo5")
				Else
					txtBoxHistDateTo5.Text = ""
				End If

				If Not IsDBNull(dtHistory.Rows(0)("TenureInMonths5")) Then
					txtBoxHistTenure5.Text = dtHistory.Rows(0)("TenureInMonths5")
				Else
					txtBoxHistTenure5.Text = ""
				End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------

			'--------------------------
			'Educational Background
			'--------------------------
			GetSchool()
			GetCourse()
			GetEducAttainment()

			If dtEduc.Rows.Count > 0 Then
				'School1
				If Not IsDBNull(dtEduc.Rows(0)("School1")) Then
					If dtEduc.Rows(0)("School1") <> "" Then
						ddlEducSchool1.ClearSelection()
						ddlEducSchool1.Items.FindByValue(dtEduc.Rows(0)("School1")).Selected = True
					Else
						ddlEducSchool1.ClearSelection()
						ddlEducSchool1.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducSchool1.ClearSelection()
					ddlEducSchool1.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Course1")) Then
					If dtEduc.Rows(0)("Course1") <> "" Then
						ddlEducCourse1.ClearSelection()
						'ddlEducCourse1.Items.FindByText(dtEduc.Rows(0)("Course1")).Selected = True
						ddlEducCourse1.Items.FindByValue(dtEduc.Rows(0)("Course1").ToString.Trim).Selected = True
					Else
						ddlEducCourse1.ClearSelection()
						ddlEducCourse1.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducCourse1.ClearSelection()
					ddlEducCourse1.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Degree1")) Then
					If dtEduc.Rows(0)("Degree1") <> "" Then
						ddlEducDegree1.ClearSelection()
						ddlEducDegree1.Items.FindByValue(dtEduc.Rows(0)("Degree1")).Selected = True
					Else
						ddlEducDegree1.ClearSelection()
						ddlEducDegree1.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducDegree1.ClearSelection()
					ddlEducDegree1.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Location1")) Then
					txtBoxEducLoc1.Text = dtEduc.Rows(0)("Location1")
				Else
					txtBoxEducLoc1.Text = ""
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateFrom1")) Then
					txtBoxEducDateFrom1.Text = dtEduc.Rows(0)("DateFrom1")
				Else
					txtBoxEducDateFrom1.Text = ""
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateTo1")) Then
					txtBoxEducDateTo1.Text = dtEduc.Rows(0)("DateTo1")
				Else
					txtBoxEducDateTo1.Text = ""
				End If

				'School2
				If Not IsDBNull(dtEduc.Rows(0)("School2")) Then
					If dtEduc.Rows(0)("School2") <> "" Then
						ddlEducSchool2.ClearSelection()
						ddlEducSchool2.Items.FindByValue(dtEduc.Rows(0)("School2")).Selected = True
					Else
						ddlEducSchool2.ClearSelection()
						ddlEducSchool2.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducSchool2.ClearSelection()
					ddlEducSchool2.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Course2")) Then
					If dtEduc.Rows(0)("Course2") <> "" Then
						ddlEducCourse2.ClearSelection()
						ddlEducCourse2.Items.FindByValue(dtEduc.Rows(0)("Course2")).Selected = True
					Else
						ddlEducCourse2.ClearSelection()
						ddlEducCourse2.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducCourse2.ClearSelection()
					ddlEducCourse2.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Degree2")) Then
					If dtEduc.Rows(0)("Degree2") <> "" Then
						ddlEducDegree2.ClearSelection()
						ddlEducDegree2.Items.FindByValue(dtEduc.Rows(0)("Degree2")).Selected = True
					Else
						ddlEducDegree2.ClearSelection()
						ddlEducDegree2.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducDegree2.ClearSelection()
					ddlEducDegree2.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateFrom2")) Then
					txtBoxEducDateFrom2.Text = dtEduc.Rows(0)("DateFrom2")
				Else
					txtBoxEducDateFrom2.Text = ""
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateTo2")) Then
					txtBoxEducDateTo2.Text = dtEduc.Rows(0)("DateTo2")
				Else
					txtBoxEducDateTo2.Text = ""
				End If

				'School3
				If Not IsDBNull(dtEduc.Rows(0)("School3")) Then
					If dtEduc.Rows(0)("School3") <> "" Then
						ddlEducSchool3.ClearSelection()
						ddlEducSchool3.Items.FindByValue(dtEduc.Rows(0)("School3")).Selected = True
					Else
						ddlEducSchool3.ClearSelection()
						ddlEducSchool3.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducSchool3.ClearSelection()
					ddlEducSchool3.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Course3")) Then
					If dtEduc.Rows(0)("Course3") <> "" Then
						ddlEducCourse3.ClearSelection()
						ddlEducCourse3.Items.FindByValue(dtEduc.Rows(0)("Course3")).Selected = True
					Else
						ddlEducCourse3.ClearSelection()
						ddlEducCourse3.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducCourse3.ClearSelection()
					ddlEducCourse3.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Degree3")) Then
					If dtEduc.Rows(0)("Degree3") <> "" Then
						ddlEducDegree3.ClearSelection()
						ddlEducDegree3.Items.FindByValue(dtEduc.Rows(0)("Degree3")).Selected = True
					Else
						ddlEducDegree3.ClearSelection()
						ddlEducDegree3.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlEducDegree3.ClearSelection()
					ddlEducDegree3.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtEduc.Rows(0)("Location3")) Then
					txtBoxEducLoc3.Text = dtEduc.Rows(0)("Location3")
				Else
					txtBoxEducLoc3.Text = ""
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateFrom3")) Then
					txtBoxEducDateFrom3.Text = dtEduc.Rows(0)("DateFrom3")
				Else
					txtBoxEducDateFrom3.Text = ""
				End If

				If Not IsDBNull(dtEduc.Rows(0)("DateTo3")) Then
					txtBoxEducDateTo3.Text = dtEduc.Rows(0)("DateTo3")
				Else
					txtBoxEducDateTo3.Text = ""
				End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------

			'---------------------------
			'Confidential Information
			'---------------------------
			If dtConfidential.Rows.Count > 0 Then
				If Not IsDBNull(dtConfidential.Rows(0)("TaxStatus")) Then
					If dtConfidential.Rows(0)("TaxStatus") <> "" Then
						ddlTaxStat.ClearSelection()
						ddlTaxStat.Items.FindByValue(dtConfidential.Rows(0)("TaxStatus")).Selected = True
					Else
						ddlTaxStat.ClearSelection()
						ddlTaxStat.Items.FindByValue("--Select One Below--").Selected = True
					End If
				Else
					ddlTaxStat.ClearSelection()
					ddlTaxStat.Items.FindByValue("--Select One Below--").Selected = True
				End If

				If Not IsDBNull(dtConfidential.Rows(0)("SSS")) Then
					txtBoxSSS1.Text = dtConfidential.Rows(0)("SSS").ToString.Substring(0, 2)
					txtBoxSSS2.Text = dtConfidential.Rows(0)("SSS").ToString.Substring(3, 7)
					txtBoxSSS3.Text = dtConfidential.Rows(0)("SSS").ToString.Substring(9, 1)
				Else
					txtBoxSSS1.Text = ""
					txtBoxSSS2.Text = ""
					txtBoxSSS3.Text = ""
				End If

				If Not IsDBNull(dtConfidential.Rows(0)("TIN")) Then
					txtBoxTIN1.Text = dtConfidential.Rows(0)("TIN").ToString.Substring(0, 3)
					txtBoxTIN2.Text = dtConfidential.Rows(0)("TIN").ToString.Substring(4, 3)
					txtBoxTIN3.Text = dtConfidential.Rows(0)("TIN").ToString.Substring(8, 3)
				Else
					txtBoxTIN1.Text = ""
					txtBoxTIN2.Text = ""
					txtBoxTIN3.Text = ""
				End If

				If Not IsDBNull(dtConfidential.Rows(0)("PhilHealth")) Then
					txtBoxPhilHealth1.Text = dtConfidential.Rows(0)("PhilHealth").ToString.Substring(0, 2)
					txtBoxPhilHealth2.Text = dtConfidential.Rows(0)("PhilHealth").ToString.Substring(3, 9)
					txtBoxPhilHealth3.Text = dtConfidential.Rows(0)("PhilHealth").ToString.Substring(11, 1)
				Else
					txtBoxPhilHealth1.Text = ""
					txtBoxPhilHealth2.Text = ""
					txtBoxPhilHealth3.Text = ""
				End If

				If Not IsDBNull(dtConfidential.Rows(0)("PagIbig")) Then
					txtBoxPagIbig1.Text = dtConfidential.Rows(0)("PagIbig").ToString.Substring(0, 4)
					txtBoxPagIbig2.Text = dtConfidential.Rows(0)("PagIbig").ToString.Substring(0, 4)
					txtBoxPagIbig3.Text = dtConfidential.Rows(0)("PagIbig").ToString.Substring(0, 4)
				Else
					txtBoxPagIbig1.Text = ""
					txtBoxPagIbig2.Text = ""
					txtBoxPagIbig3.Text = ""
				End If

				'If Not IsDBNull(dtConfidential.Rows(0)("Citizenship")) Then
				'	If dtConfidential.Rows(0)("Citizenship") <> "" Then
				'		ddlCitizenship.ClearSelection()
				'		ddlCitizenship.Items.FindByValue(dtConfidential.Rows(0)("Citizenship")).Selected = True
				'	Else
				'		ddlCitizenship.ClearSelection()
				'		ddlCitizenship.Items.FindByValue("--Select One Below--").Selected = True
				'	End If
				'Else
				'	ddlCitizenship.ClearSelection()
				'	ddlCitizenship.Items.FindByValue("--Select One Below--").Selected = True
				'End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------

			'--------------------
			'Dependent Details
			'--------------------
			If dtDependent.Rows.Count > 0 Then
				If Not IsDBNull(dtDependent.Rows(0)("FathersName")) Then
					txtBoxDepFather.Text = dtDependent.Rows(0)("FathersName")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("FathersDOB")) Then
					txtBoxDepFatherDOB.Text = dtDependent.Rows(0)("FathersDOB")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("MothersName")) Then
					txtBoxDepMother.Text = dtDependent.Rows(0)("MothersName")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("MothersDOB")) Then
					txtBoxDepMotherDOB.Text = dtDependent.Rows(0)("MothersDOB")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("SpouseName")) Then
					txtBoxDepSpouse.Text = dtDependent.Rows(0)("SpouseName")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("SpouseDOB")) Then
					txtBoxDepSpouseDOB.Text = dtDependent.Rows(0)("SpouseDOB")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child1Name")) Then
					txtBoxDepChild1.Text = dtDependent.Rows(0)("Child1Name")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child1DOB")) Then
					txtBoxDepChild1DOB.Text = dtDependent.Rows(0)("Child1DOB")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child2Name")) Then
					txtBoxDepChild2.Text = dtDependent.Rows(0)("Child2Name")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child2DOB")) Then
					txtBoxDepChild2DOB.Text = dtDependent.Rows(0)("Child2DOB")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child3Name")) Then
					txtBoxDepChild3.Text = dtDependent.Rows(0)("Child3Name")
				End If
				If Not IsDBNull(dtDependent.Rows(0)("Child3DOB")) Then
					txtBoxDepChild3DOB.Text = dtDependent.Rows(0)("Child3DOB")
				End If
			End If

			'-------------------------------------------------------------------------
			'-------------------------------------------------------------------------
		End If
		'End If
	End Sub

	<WebMethod()>
	Public Shared Function GetBarangay(prefix As String) As String()
		Dim barangay As New List(Of String)()
		Using conn As New SqlConnection()
			conn.ConnectionString = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString
			Using cmd As New SqlCommand()
				cmd.CommandText = "select Distinct barangay from dbo.tbl_DB_Brgy_And_City (nolock) where barangay like @SearchText + '%' order by barangay"
				cmd.Parameters.AddWithValue("@SearchText", prefix)
				cmd.Connection = conn
				conn.Open()
				Using sdr As SqlDataReader = cmd.ExecuteReader()
					While sdr.Read()
						barangay.Add(String.Format("{0}", sdr("barangay")))
					End While
				End Using
				conn.Close()
			End Using
		End Using
		Return barangay.ToArray()
	End Function

	<WebMethod()>
	Public Shared Function GetTown(prefix As String) As String()
		Dim town As New List(Of String)()
		Using conn As New SqlConnection()
			conn.ConnectionString = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString
			Using cmd As New SqlCommand()
				cmd.CommandText = "select Distinct town from dbo.tbl_DB_Brgy_And_City (nolock) where town like @SearchText + '%' order by town"
				cmd.Parameters.AddWithValue("@SearchText", prefix)
				cmd.Connection = conn
				conn.Open()
				Using sdr As SqlDataReader = cmd.ExecuteReader()
					While sdr.Read()
						town.Add(String.Format("{0}", sdr("town")))
					End While
				End Using
				conn.Close()
			End Using
		End Using
		Return town.ToArray()
	End Function

	<WebMethod()>
	Public Shared Function GetCity(prefix As String) As String()
		Dim city As New List(Of String)()
		Using conn As New SqlConnection()
			conn.ConnectionString = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString
			Using cmd As New SqlCommand()
				cmd.CommandText = "select Distinct city from dbo.tbl_DB_Brgy_And_City (nolock) where city like @SearchText + '%' order by city"
				cmd.Parameters.AddWithValue("@SearchText", prefix)
				cmd.Connection = conn
				conn.Open()
				Using sdr As SqlDataReader = cmd.ExecuteReader()
					While sdr.Read()
						city.Add(String.Format("{0}", sdr("city")))
					End While
				End Using
				conn.Close()
			End Using
		End Using
		Return city.ToArray()
	End Function

	<WebMethod()>
	Public Shared Function GetRegion(prefix As String) As String()
		Dim region As New List(Of String)()
		Using conn As New SqlConnection()
			conn.ConnectionString = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString
			Using cmd As New SqlCommand()
				cmd.CommandText = "select Distinct region from dbo.tbl_DB_Brgy_And_City (nolock) where region like @SearchText + '%' order by region"
				cmd.Parameters.AddWithValue("@SearchText", prefix)
				cmd.Connection = conn
				conn.Open()
				Using sdr As SqlDataReader = cmd.ExecuteReader()
					While sdr.Read()
						region.Add(String.Format("{0}", sdr("region")))
					End While
				End Using
				conn.Close()
			End Using
		End Using
		Return region.ToArray()
	End Function

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' order by seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub


	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select EmpID, NTID, Alias, EmpName, MngrName, DeptName, DeptCode, JobDesc, ExtensionNumber, Skill, Batch, Class, Workstation, DATENAME(MONTH, DateJoined) + ' ' + DATENAME(DAY, DateJoined) + ', ' + DATENAME(YEAR, DateJoined) as DateJoined, DATENAME(MONTH, ProductionStartDate) + ' ' + DATENAME(DAY, ProductionStartDate) + ', ' + DATENAME(YEAR, ProductionStartDate) as ProdDate, DATENAME(MONTH, DATEADD(MONTH, 6, DateJoined)) + ' ' + DATENAME(DAY, DateJoined) + ', ' + DATENAME(YEAR, DateJoined) as RegDate, CAST(DATEDIFF(MONTH, DateJoined, GetDate()) as VARCHAR) + ' months' as TenureInMonths , EmpStatus, BusinessUnit, BusinessUnitHead from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser & "'"
		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub GetTenure()
		GetEmpInfo()

		Dim qry As String = ""

		qry += "DECLARE @date datetime, @tmpdate datetime, @years int, @months int, @days int" & vbCrLf
		qry += "SELECT @date = '" & dtEmp.Rows(0)("DateJoined") & "';" & vbCrLf
		qry += "SELECT @tmpdate = @date;" & vbCrLf
		qry += "SELECT @years = DATEDIFF(yy, @tmpdate, GETDATE()) - CASE WHEN (MONTH(@date) > MONTH(GETDATE())) OR (MONTH(@date) = MONTH(GETDATE()) AND DAY(@date) > DAY(GETDATE())) THEN 1 ELSE 0 END" & vbCrLf
		qry += "SELECT @tmpdate = DATEADD(yy, @years, @tmpdate);" & vbCrLf
		qry += "SELECT @months = DATEDIFF(m, @tmpdate, GETDATE()) - CASE WHEN DAY(@date) > DAY(GETDATE()) THEN 1 ELSE 0 END;" & vbCrLf
		qry += "SELECT @tmpdate = DATEADD(m, @months, @tmpdate);" & vbCrLf
		qry += "SELECT @days = DATEDIFF(d, @tmpdate, GETDATE());" & vbCrLf
		qry += "SELECT @years as [Years], @months as [Months], @days as [Days]"

		dtTenure = cls.GetData(qry)
	End Sub

	Private Sub GetSched()
		Dim qry As String = ""

		qry = "select RIGHT(CONVERT(varchar(25), SchedIN, 100), 7) as SchedIN, RIGHT(CONVERT(varchar(25), SchedOUT, 100), 7) as SchedOUT from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & pubUser & "' and SchedDate = CAST(GETDATE() AS DATE)"
		dtSched = cls.GetData(qry)

	End Sub

	Private Sub GetCompnay()
		ddlHistEmployer1.Items.Clear()
		ddlHistEmployer2.Items.Clear()
		ddlHistEmployer3.Items.Clear()
		ddlHistEmployer4.Items.Clear()
		ddlHistEmployer5.Items.Clear()

		Dim query As String

		query = "select Company from dbo.tbl_DB_Company (nolock) order by Company asc"

		dtCompany = cls.GetData(query)

		'Employer1
		ddlHistEmployer1.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCompany.Rows.Count - 1
			ddlHistEmployer1.Items.Add(dtCompany.Rows(x)("Company").ToString.Trim)
		Next

		'Employer2
		ddlHistEmployer2.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCompany.Rows.Count - 1
			ddlHistEmployer2.Items.Add(dtCompany.Rows(x)("Company").ToString.Trim)
		Next

		'Employer3
		ddlHistEmployer3.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCompany.Rows.Count - 1
			ddlHistEmployer3.Items.Add(dtCompany.Rows(x)("Company").ToString.Trim)
		Next

		'Employer4
		ddlHistEmployer4.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCompany.Rows.Count - 1
			ddlHistEmployer4.Items.Add(dtCompany.Rows(x)("Company").ToString.Trim)
		Next

		'Employer5
		ddlHistEmployer5.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCompany.Rows.Count - 1
			ddlHistEmployer5.Items.Add(dtCompany.Rows(x)("Company").ToString.Trim)
		Next

	End Sub

	Private Sub GetSchool()
		Dim query As String

		query = "select Distinct School from tbl_DB_Schools (nolock)"

		dtSchool = cls.GetData(query)

		'School1
		ddlEducSchool1.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtSchool.Rows.Count - 1
			ddlEducSchool1.Items.Add(dtSchool.Rows(x)("School").ToString.Trim)
		Next

		'School2
		ddlEducSchool2.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtSchool.Rows.Count - 1
			ddlEducSchool2.Items.Add(dtSchool.Rows(x)("School").ToString.Trim)
		Next

		'School3
		ddlEducSchool3.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtSchool.Rows.Count - 1
			ddlEducSchool3.Items.Add(dtSchool.Rows(x)("School").ToString.Trim)
		Next
	End Sub

	Private Sub GetCourse()
		Dim query As String

		query = "select Course from tbl_DB_Courses (nolock)"

		dtCourse = cls.GetData(query)

		'Course1
		ddlEducCourse1.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCourse.Rows.Count - 1
			ddlEducCourse1.Items.Add(dtCourse.Rows(x)("Course").ToString.Trim)
		Next

		'Course2
		ddlEducCourse2.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCourse.Rows.Count - 1
			ddlEducCourse2.Items.Add(dtCourse.Rows(x)("Course").ToString.Trim)
		Next

		'Course3
		ddlEducCourse3.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCourse.Rows.Count - 1
			ddlEducCourse3.Items.Add(dtCourse.Rows(x)("Course").ToString.Trim)
		Next
	End Sub

	Private Sub GetEducAttainment()
		Dim query As String

		query = "select Distinct Degree from tbl_DB_Courses (nolock)"

		dtEducAttainment = cls.GetData(query)

		'Degree1
		ddlEducDegree1.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtEducAttainment.Rows.Count - 1
			ddlEducDegree1.Items.Add(dtEducAttainment.Rows(x)("Degree").ToString.Trim)
		Next

		'Degree2
		ddlEducDegree2.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtEducAttainment.Rows.Count - 1
			ddlEducDegree2.Items.Add(dtEducAttainment.Rows(x)("Degree").ToString.Trim)
		Next

		'Degree3
		ddlEducDegree3.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtEducAttainment.Rows.Count - 1
			ddlEducDegree3.Items.Add(dtEducAttainment.Rows(x)("Degree").ToString.Trim)
		Next
	End Sub

	Private Sub GetCitizenship()
		Dim query As String

		query = "select Distinct Nationality from tbl_DB_Nationality (nolock)"

		dtCitizenship = cls.GetData(query)

		ddlCitizenship.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtCitizenship.Rows.Count - 1
			ddlCitizenship.Items.Add(dtCitizenship.Rows(x)("Nationality").ToString.Trim)
		Next
	End Sub

	Private Sub GetChanges(tblName As String)
		Dim query As String

		query = "select * from dbo.tbl_HRMS_Profile_Changes where NTID = '" & pubUser.Trim & "' and Status = 'Pending' and TableName = '" & tblName & "'"

		dtChanges = cls.GetData(query)
	End Sub

	Private Sub btnSaveEmployeeInfo_Click(sender As Object, e As EventArgs) Handles btnSaveEmployeeInfo.Click

		empAlias = txtBoxEmpAlias.Text

		empExtNum = txtBoxEmpExtNum.Text

		If ddlEmpSkill.SelectedItem.Text = "--Select One Below--" Then
			empSkill = ""
		Else
			empSkill = ddlEmpSkill.SelectedItem.Text
		End If

		'Dim prodDate As DateTime = Convert.ToDateTime(txtBoxEmpProdDate.Text).ToString("yyyy-MM-dd")

		empProdDate = Convert.ToDateTime(txtBoxEmpProdDate.Text).ToString("yyyy-MM-dd")

		empBatch = txtBoxEmpBatch.Text

		empClass = txtBoxEmpClass.Text

		empStation = txtBoxEmpStation.Text

		UpdateEmployeeInfo()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdateEmployeeInfo()
		GetEmpInfo()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtEmp.Rows.Count > 0 Then

			Dim tblName = "tbl_HRMS_EmployeeMaster"

			'GetChanges(tblName)

			Dim dbProdDate As String

			If Not IsDBNull(dtEmp.Rows(0)("ProdDate")) Then
				dbProdDate = Convert.ToDateTime(dtEmp.Rows(0)("ProdDate")).ToString("yyyy-MM-dd")
			Else
				dbProdDate = ""
			End If

			'Dim find As String = "FieldName = 'Batch'"
			'Dim foundRows As DataRow() = dtChanges.[Select](find)
			'Dim strBatch As String = "batch"
			'Dim foundMatch As Boolean

			'For x As Integer = 0 To foundRows.Length
			'    If dtChanges.Rows(x)("FieldValueIs") <> empBatch.Trim Then
			'        foundMatch = True
			'    End If
			'Next

			If dtEmp.Rows(0)("Alias") <> empAlias.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'Alias', '" & empAlias.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEmp.Rows(0)("ExtensionNumber") <> empExtNum.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'ExtensionNumber', '" & empExtNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEmp.Rows(0)("Skill") <> empSkill.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'Skill', '" & empSkill.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbProdDate.Trim <> empProdDate.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'ProductionStartDate', CAST('" & empProdDate.Trim & "' as date), '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEmp.Rows(0)("Batch") <> empBatch.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'Batch', '" & empBatch.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEmp.Rows(0)("Class") <> empClass.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'Class', '" & empClass.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEmp.Rows(0)("Workstation") <> empStation.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeMaster', 'Employee Information', 'Workstation', '" & empStation.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""
			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query

		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub CheckPersonalInfo()
		Dim qry As String = ""

		qry = "select * from tbl_HRMS_Employee_PersonalInformation (nolock) where NTID = '" & pubUser & "'"
		dtPersonal = cls.GetData(qry)
	End Sub

	Private Sub btnSavePersonalInfo_Click(sender As Object, e As EventArgs) Handles btnSavePersonalInfo.Click
		personalHouseNum = txtBoxPersonalHouseNum.Text
		personalStName = txtBoxPersonalStName.Text
		personalBrgy = txtBoxPersonalBrgy.Text
		personalTown = txtBoxPersonalTown.Text
		personalCity = txtBoxPersonalCity.Text
		personalRegion = txtBoxPersonalRegion.Text
		personalZip = txtBoxPersonalZip.Text
		If ddlBlood.SelectedItem.Text = "--Select One Below--" Then
			personalBlood = ""
		Else
			personalBlood = ddlBlood.SelectedItem.Text
		End If
		If ddlGender.SelectedItem.Text = "--Select One Below--" Then
			personalGender = ""
		Else
			personalGender = ddlGender.SelectedItem.Text
		End If
		personalDOB = txtBoxPersonalDOB.Text
		If ddlCitizenship.SelectedItem.Text = "--Select One Below--" Then
			personalCitizenship = ""
		Else
			personalCitizenship = ddlCitizenship.SelectedItem.Text
		End If

		UpdatePersonalInfo()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdatePersonalInfo()
		CheckPersonalInfo()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtPersonal.Rows.Count > 0 Then
			Dim dbDOB As String

			If Not IsDBNull(dtPersonal.Rows(0)("DOB")) Then
				dbDOB = Convert.ToDateTime(dtPersonal.Rows(0)("DOB")).ToShortDateString
			Else
				dbDOB = ""
			End If

			If dtPersonal.Rows(0)("HouseNumber") <> personalHouseNum.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'HouseNumber', '" & personalHouseNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("StreetName") <> personalStName.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'StreetName', '" & personalStName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("Barangay") <> personalBrgy.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Barangay', '" & personalBrgy.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("Town") <> personalTown.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Town', '" & personalTown.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("City") <> personalCity.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'City', '" & personalCity.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("Region") <> personalRegion.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Region', '" & personalRegion.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("ZipCode") <> personalZip.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'ZipCode', '" & personalZip.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("BloodType") <> personalBlood.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'BloodType', '" & personalBlood.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("Gender") <> personalGender.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Gender', '" & personalGender.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDOB <> personalDOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'DOB', '" & personalDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("Citizenship") <> personalCitizenship.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Citizenship', '" & personalCitizenship.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query

		Else
			If personalHouseNum.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'HouseNumber', '" & personalHouseNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalStName.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'StreetName', '" & personalStName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalBrgy.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Barangay', '" & personalBrgy.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalTown.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Town', '" & personalTown.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalCity.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'City', '" & personalCity.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalRegion.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Region', '" & personalRegion.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalZip.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'ZipCode', '" & personalZip.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalBlood.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'BloodType', '" & personalBlood.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalGender.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Gender', '" & personalGender.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalDOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'DOB', '" & personalDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalCitizenship.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Citizenship', '" & personalCitizenship.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub btnSavePersonalContactInfo_Click(sender As Object, e As EventArgs) Handles btnSavePersonalContactInfo.Click

		If ddlPersonalMobileArea.SelectedItem.Text = "--Select One Below--" Then
			personalAreaCodeMobile = ""
		Else
			personalAreaCodeMobile = ddlPersonalMobileArea.SelectedItem.Text
		End If
		personalMobileNum = txtBoxPersonalMobileNum.Text
		If ddlPersonalHomeArea.SelectedItem.Text = "--Select One Below--" Then
			personalAreaCodeHome = ""
		Else
			personalAreaCodeHome = ddlPersonalHomeArea.SelectedItem.Text
		End If
		personalHomeNum = txtBoxPersonalHomeNum.Text
		personalEmail = txtBoxPersonalEmail.Text

		UpdatePersonalContactInfo()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdatePersonalContactInfo()
		CheckPersonalInfo()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtPersonal.Rows.Count > 0 Then

			If dtPersonal.Rows(0)("AreaCodeMobile") <> personalAreaCodeMobile.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'AreaCodeMobile' '" & personalAreaCodeMobile.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("MobileNumber") <> personalMobileNum.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'MobileNumber', '" & personalMobileNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("AreaCodeHome") <> personalAreaCodeHome.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'AreaCodeHome', '" & personalAreaCodeHome.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("HomeNumber") <> personalHomeNum.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'HomeNumber', '" & personalHomeNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("PersonalEmail") <> personalEmail.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'PersonalEmail', '" & personalEmail.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If personalAreaCodeMobile.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'AreaCodeMobile' '" & personalAreaCodeMobile.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalMobileNum.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'MobileNumber', '" & personalMobileNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalAreaCodeHome.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'AreaCodeHome', '" & personalAreaCodeHome.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalHomeNum.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'HomeNumber', '" & personalHomeNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If personalEmail.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'PersonalEmail', '" & personalEmail.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub btnSaveEmergencyInfo_Click(sender As Object, e As EventArgs) Handles btnSaveEmergencyInfo.Click

		emrgName = txtBoxEmergencyName.Text
		emrgNum = txtBoxEmergencyContactNum.Text
		If ddlEmergencyRel.SelectedItem.Text <> "--Select One Below" Then
			emrgRel = ddlEmergencyRel.SelectedItem.Text
		Else
			emrgRel = ""
		End If

		UpdateEmergencyInfo()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdateEmergencyInfo()


		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtPersonal.Rows.Count > 0 Then
			If dtPersonal.Rows(0)("EmrgName") <> emrgName.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'EmergencyContactname', '" & emrgName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("EmrgNumber") <> emrgNum.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'EmergenctContactNumber', '" & emrgNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtPersonal.Rows(0)("EmrgRelationship") <> emrgRel.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Relationship', '" & emrgRel.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If emrgName.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'EmergencyContactname', '" & emrgName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If emrgNum.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'EmergenctContactNumber', '" & emrgNum.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If emrgRel.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_PersonalInformation', 'Personal Information', 'Relationship', '" & emrgRel.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub CheckHistory()
		Dim sb As New StringBuilder

		sb.Append("select  ")
		sb.Append("Employer1, ")
		sb.Append("Work1, ")
		sb.Append("DATENAME(MM, DateFrom1) + ' ' + CAST(DAY(DateFrom1) as VARCHAR(2)) + ', ' + CAST(YEAR(DateFrom1) as varchar(4)) as DateFrom1, ")
		sb.Append("DATENAME(MM, DateTo1) + ' ' + CAST(DAY(DateTo1) as VARCHAR(2)) + ', ' + CAST(YEAR(DateTo1) as varchar(4)) as DateTo1, ")
		sb.Append("CAST(DATEDIFF(MONTH, DateFrom1, DateTo1) as VARCHAR) + ' months' as TenureInMonths1, ")
		sb.Append("Employer2, ")
		sb.Append("Work2, ")
		sb.Append("DATENAME(MM, DateFrom2) + ' ' + CAST(DAY(DateFrom2) as VARCHAR(2)) + ', ' + CAST(YEAR(DateFrom2) as varchar(4)) as DateFrom2, ")
		sb.Append("DATENAME(MM, DateTo2) + ' ' + CAST(DAY(DateTo2) as VARCHAR(2)) + ', ' + CAST(YEAR(DateTo2) as varchar(4)) as DateTo2, ")
		sb.Append("CAST(DATEDIFF(MONTH, DateFrom2, DateTo2) as VARCHAR) + ' months' as TenureInMonths2, ")
		sb.Append("Employer3, ")
		sb.Append("Work3, ")
		sb.Append("DATENAME(MM, DateFrom3) + ' ' + CAST(DAY(DateFrom3) as VARCHAR(2)) + ', ' + CAST(YEAR(DateFrom3) as varchar(4)) as DateFrom3, ")
		sb.Append("DATENAME(MM, DateTo3) + ' ' + CAST(DAY(DateTo3) as VARCHAR(2)) + ', ' + CAST(YEAR(DateTo3) as varchar(4)) as DateTo3, ")
		sb.Append("CAST(DATEDIFF(MONTH, DateFrom3, DateTo3) as VARCHAR) + ' months' as TenureInMonths3, ")
		sb.Append("Employer4, ")
		sb.Append("Work4, ")
		sb.Append("DATENAME(MM, DateFrom4) + ' ' + CAST(DAY(DateFrom4) as VARCHAR(2)) + ', ' + CAST(YEAR(DateFrom4) as varchar(4)) as DateFrom4, ")
		sb.Append("DATENAME(MM, DateTo4) + ' ' + CAST(DAY(DateTo4) as VARCHAR(2)) + ', ' + CAST(YEAR(DateTo4) as varchar(4)) as DateTo4, ")
		sb.Append("CAST(DATEDIFF(MONTH, DateFrom4, DateTo4) as VARCHAR) + ' months' as TenureInMonths4, ")
		sb.Append("Employer5, ")
		sb.Append("Work5, ")
		sb.Append("DATENAME(MM, DateFrom5) + ' ' + CAST(DAY(DateFrom5) as VARCHAR(2)) + ', ' + CAST(YEAR(DateFrom5) as varchar(4)) as DateFrom5, ")
		sb.Append("DATENAME(MM, DateTo5) + ' ' + CAST(DAY(DateTo5) as VARCHAR(2)) + ', ' + CAST(YEAR(DateTo5) as varchar(4)) as DateTo5, ")
		sb.Append("CAST(DATEDIFF(MONTH, DateFrom5, DateTo5) as VARCHAR) + ' months' as TenureInMonths5 ")
		sb.Append("from dbo.tbl_HRMS_EmployeeHistory (nolock) ")
		sb.Append("where  ")
		sb.Append("NTID = '" & pubUser.Trim & "' ")

		dtHistory = cls.GetData(sb.ToString())
	End Sub

	Private Sub btnSaveEmpHistory_Click(sender As Object, e As EventArgs) Handles btnSaveEmpHistory.Click

		If ddlHistEmployer1.SelectedItem.Text = "--Select One Below--" Then
			histEmployer1 = ""
		Else
			histEmployer1 = ddlHistEmployer1.SelectedItem.Text.Trim
		End If
		histWork1 = txtBoxHistWork1.Text
		histDateFrom1 = txtBoxHistDateFrom1.Text
		histDateTo1 = txtBoxHistDateTo1.Text

		If ddlHistEmployer2.SelectedItem.Text = "--Select One Below--" Then
			histEmployer2 = ""
		Else
			histEmployer2 = ddlHistEmployer2.SelectedItem.Text.Trim
		End If
		histWork2 = txtBoxHistWork2.Text
		histDateFrom2 = txtBoxHistDateFrom2.Text
		histDateTo2 = txtBoxHistDateTo2.Text

		If ddlHistEmployer3.SelectedItem.Text = "--Select One Below--" Then
			histEmployer3 = ""
		Else
			histEmployer3 = ddlHistEmployer3.SelectedItem.Text.Trim
		End If
		histWork3 = txtBoxHistWork3.Text
		histDateFrom3 = txtBoxHistDateFrom3.Text
		histDateTo3 = txtBoxHistDateTo3.Text

		If ddlHistEmployer4.SelectedItem.Text = "--Select One Below--" Then
			histEmployer4 = ""
		Else
			histEmployer4 = ddlHistEmployer4.SelectedItem.Text.Trim
		End If
		histWork4 = txtBoxHistWork4.Text
		histDateFrom4 = txtBoxHistDateFrom4.Text
		histDateTo4 = txtBoxHistDateTo4.Text

		If ddlHistEmployer5.SelectedItem.Text = "--Select One Below--" Then
			histEmployer5 = ""
		Else
			histEmployer5 = ddlHistEmployer5.SelectedItem.Text.Trim
		End If
		histWork5 = txtBoxHistWork5.Text
		histDateFrom5 = txtBoxHistDateFrom5.Text
		histDateTo5 = txtBoxHistDateTo5.Text

		UpdateEmployeeHistory()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)

	End Sub

	Private Sub UpdateEmployeeHistory()
		CheckHistory()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtHistory.Rows.Count > 0 Then
			Dim dbDateFrom1 As String
			Dim dbDateFrom2 As String
			Dim dbDateFrom3 As String
			Dim dbDateFrom4 As String
			Dim dbDateFrom5 As String
			Dim dbDateTo1 As String
			Dim dbDateTo2 As String
			Dim dbDateTo3 As String
			Dim dbDateTo4 As String
			Dim dbDateTo5 As String

			If Not IsDBNull(dtHistory.Rows(0)("DateFrom1")) Then
				dbDateFrom1 = Convert.ToDateTime(dtHistory.Rows(0)("DateFrom1")).ToShortDateString
			Else
				dbDateFrom1 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateFrom2")) Then
				dbDateFrom2 = Convert.ToDateTime(dtHistory.Rows(0)("DateFrom2")).ToShortDateString
			Else
				dbDateFrom2 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateFrom3")) Then
				dbDateFrom3 = Convert.ToDateTime(dtHistory.Rows(0)("DateFrom3")).ToShortDateString
			Else
				dbDateFrom3 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateFrom4")) Then
				dbDateFrom4 = Convert.ToDateTime(dtHistory.Rows(0)("DateFrom4")).ToShortDateString
			Else
				dbDateFrom4 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateFrom5")) Then
				dbDateFrom5 = Convert.ToDateTime(dtHistory.Rows(0)("DateFrom5")).ToShortDateString
			Else
				dbDateFrom5 = ""
			End If

			If Not IsDBNull(dtHistory.Rows(0)("DateTo1")) Then
				dbDateTo1 = Convert.ToDateTime(dtHistory.Rows(0)("DateTo1")).ToShortDateString
			Else
				dbDateTo1 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateTo2")) Then
				dbDateTo2 = Convert.ToDateTime(dtHistory.Rows(0)("DateTo2")).ToShortDateString
			Else
				dbDateTo2 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateTo3")) Then
				dbDateTo3 = Convert.ToDateTime(dtHistory.Rows(0)("DateTo3")).ToShortDateString
			Else
				dbDateTo3 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateTo4")) Then
				dbDateTo4 = Convert.ToDateTime(dtHistory.Rows(0)("DateTo4")).ToShortDateString
			Else
				dbDateTo4 = ""
			End If
			If Not IsDBNull(dtHistory.Rows(0)("DateTo5")) Then
				dbDateTo5 = Convert.ToDateTime(dtHistory.Rows(0)("DateTo5")).ToShortDateString
			Else
				dbDateTo5 = ""
			End If

			If dtHistory.Rows(0)("Employer1") <> histEmployer1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer1', '" & histEmployer1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Work1") <> histWork1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work1', '" & histWork1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom1.Trim <> histDateFrom1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom1', '" & histDateFrom1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo1.Trim <> histDateTo1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo1', '" & histDateTo1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Employer2") <> histEmployer2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer2', '" & histEmployer2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Work2") <> histWork2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work2', '" & histWork2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom2.Trim <> histDateFrom2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom2', '" & histDateFrom2.Trim & "' as date) as varchar), '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo2.Trim <> histDateTo2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo2', '" & histDateTo2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Employer3") <> histEmployer3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer3', '" & histEmployer3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Work3") <> histWork3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work3', '" & histWork3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom3.Trim <> histDateFrom3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom3', '" & histDateFrom3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo3.Trim <> histDateTo3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo3', '" & histDateTo3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Employer4") <> histEmployer4.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer4', '" & histEmployer4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Work4") <> histWork4.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work4', '" & histWork4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom4.Trim <> histDateFrom4.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom4', '" & histDateFrom4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo4.Trim <> histDateTo4.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo4', '" & histDateTo4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Employer5") <> histEmployer5.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer5', '" & histEmployer5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtHistory.Rows(0)("Work5") <> histWork5.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work5', '" & histWork5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom5.Trim <> histDateFrom5.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom5', '" & histDateFrom5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo5.Trim <> histDateTo5.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo5', '" & histDateTo5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If histEmployer1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer1', '" & histEmployer1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histWork1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work1', '" & histWork1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateFrom1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom1', '" & histDateFrom1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateTo1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo1', '" & histDateTo1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histEmployer2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer2', '" & histEmployer2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histWork2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work2', '" & histWork2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateFrom2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom2', '" & histDateFrom2.Trim & "' as date) as varchar), '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateTo2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo2', '" & histDateTo2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histEmployer3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer3', '" & histEmployer3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histWork3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work3', '" & histWork3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateFrom3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom3', '" & histDateFrom3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateTo3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo3', '" & histDateTo3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histEmployer4.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer4', '" & histEmployer4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histWork4.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work4', '" & histWork4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateFrom4.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom4', '" & histDateFrom4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateTo4.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo4', '" & histDateTo4.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histEmployer5.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Employer5', '" & histEmployer5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histWork5.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'Work5', '" & histWork5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateFrom5.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateFrom5', '" & histDateFrom5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If histDateTo5.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_EmployeeHistory', 'Employee History', 'DateTo5', '" & histDateTo5.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub CheckEduc()
		Dim qry As String = ""

		qry = "select * from tbl_HRMS_Employee_EducationalBackground (nolock) where NTID = '" & pubUser & "'"
		dtEduc = cls.GetData(qry)
	End Sub

	Private Sub btnSaveEduc_Click(sender As Object, e As EventArgs) Handles btnSaveEduc.Click

		'School1
		If ddlEducSchool1.SelectedItem.Text = "--Select One Below--" Then
			educSchool1 = ""
		Else
			educSchool1 = ddlEducSchool1.SelectedItem.Text.Trim
			If InStr(educSchool1, "'") > 0 Then
				educSchool1 = educSchool1.Replace("'", "'")
			End If
		End If
		If ddlEducCourse1.SelectedItem.Text = "--Select One Below--" Then
			educCourse1 = ""
		Else
			educCourse1 = ddlEducCourse1.SelectedItem.Text.Trim
		End If
		educLocation1 = txtBoxEducLoc1.Text
		If ddlEducDegree1.SelectedItem.Text = "--Select One Below--" Then
			educDegree1 = ""
		Else
			educDegree1 = ddlEducDegree1.SelectedItem.Text.Trim
			If InStr(educDegree1, "'") > 0 Then
				educDegree1 = educDegree1.Replace("'", "''")
			End If
		End If
		educDateFrom1 = txtBoxEducDateFrom1.Text
		educDateTo1 = txtBoxEducDateTo1.Text

		'School2
		If ddlEducSchool2.SelectedItem.Text = "--Select One Below--" Then
			educSchool2 = ""
		Else
			educSchool2 = ddlEducSchool2.SelectedItem.Text.Trim
			If InStr(educSchool2, "'") > 0 Then
				educSchool2 = educSchool2.Replace("'", "'")
			End If
		End If
		If ddlEducCourse2.SelectedItem.Text = "--Select One Below--" Then
			educCourse2 = ""
		Else
			educCourse2 = ddlEducCourse2.SelectedItem.Text.Trim
		End If
		educLocation2 = txtBoxEducLoc2.Text
		If ddlEducDegree2.SelectedItem.Text = "--Select One Below--" Then
			educDegree2 = ""
		Else
			educDegree2 = ddlEducDegree2.SelectedItem.Text.Trim
			If InStr(educDegree2, "'") > 0 Then
				educDegree2 = educDegree2.Replace("'", "''")
			End If
		End If
		educDateFrom2 = txtBoxEducDateFrom2.Text
		educDateTo2 = txtBoxEducDateTo2.Text

		'School3
		If ddlEducSchool3.SelectedItem.Text = "--Select One Below--" Then
			educSchool3 = ""
		Else
			educSchool3 = ddlEducSchool3.SelectedItem.Text.Trim
			If InStr(educSchool3, "'") > 0 Then
				educSchool3 = educSchool3.Replace("'", "'")
			End If
		End If
		If ddlEducCourse3.SelectedItem.Text = "--Select One Below--" Then
			educCourse3 = ""
		Else
			educCourse3 = ddlEducCourse3.SelectedItem.Text.Trim
		End If
		educLocation3 = txtBoxEducLoc3.Text
		If ddlEducDegree3.SelectedItem.Text = "--Select One Below--" Then
			educDegree3 = ""
		Else
			educDegree3 = ddlEducDegree3.SelectedItem.Text.Trim
			If InStr(educDegree3, "'") > 0 Then
				educDegree3 = educDegree3.Replace("'", "''")
			End If
		End If
		educDateFrom3 = txtBoxEducDateFrom3.Text
		educDateTo3 = txtBoxEducDateTo3.Text

		UpdateEducationalBackground()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdateEducationalBackground()
		CheckEduc()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtEduc.Rows.Count > 0 Then

			Dim dbDateFrom1 As String
			Dim dbDateFrom2 As String
			Dim dbDateFrom3 As String
			Dim dbDateTo1 As String
			Dim dbDateTo2 As String
			Dim dbDateTo3 As String
			If Not IsDBNull(dtEduc.Rows(0)("DateFrom1")) Then
				dbDateFrom1 = Convert.ToDateTime(dtEduc.Rows(0)("DateFrom1")).ToShortDateString()
			Else
				dbDateFrom1 = ""
			End If
			If Not IsDBNull(dtEduc.Rows(0)("DateFrom2")) Then
				dbDateFrom2 = Convert.ToDateTime(dtEduc.Rows(0)("DateFrom2")).ToShortDateString()
			Else
				dbDateFrom2 = ""
			End If
			If Not IsDBNull(dtEduc.Rows(0)("DateFrom3")) Then
				dbDateFrom3 = Convert.ToDateTime(dtEduc.Rows(0)("DateFrom3")).ToShortDateString()
			Else
				dbDateFrom3 = ""
			End If
			If Not IsDBNull(dtEduc.Rows(0)("DateTo1")) Then
				dbDateTo1 = Convert.ToDateTime(dtEduc.Rows(0)("DateTo1")).ToShortDateString()
			Else
				dbDateTo1 = ""
			End If
			If Not IsDBNull(dtEduc.Rows(0)("DateTo2")) Then
				dbDateTo2 = Convert.ToDateTime(dtEduc.Rows(0)("DateTo2")).ToShortDateString()
			Else
				dbDateTo2 = ""
			End If
			If Not IsDBNull(dtEduc.Rows(0)("DateTo3")) Then
				dbDateTo3 = Convert.ToDateTime(dtEduc.Rows(0)("DateTo3")).ToShortDateString()
			Else
				dbDateTo3 = ""
			End If


			If dtEduc.Rows(0)("School1") <> educSchool1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School1', '" & educSchool1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Course1") <> educCourse1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course1', '" & educCourse1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Degree1") <> educDegree1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree1', '" & educDegree1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Location1") <> educLocation1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location1', '" & educLocation1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom1.Trim <> educDateFrom1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom1', '" & educDateFrom1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo1.Trim <> educDateTo1.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo1', '" & educDateTo1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("School2") <> educSchool2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School2', '" & educSchool2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Course2") <> educCourse2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course2', '" & educCourse2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Degree2") <> educDegree2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree2', '" & educDegree2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Location2") <> educLocation2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location2', '" & educLocation2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom2.Trim <> educDateFrom2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom2', '" & educDateFrom2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo2.Trim <> educDateTo2.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo2', '" & educDateTo2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("School3") <> educSchool3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School3', '" & educSchool3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Course3") <> educCourse3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course3', '" & educCourse3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Degree3") <> educDegree3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree3', '" & educDegree3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtEduc.Rows(0)("Location3") <> educLocation3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location3', '" & educLocation3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateFrom3.Trim <> educDateFrom3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom3', '" & educDateFrom3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbDateTo3.Trim <> educDateTo3.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo3', '" & educDateTo3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If educSchool1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School1', '" & educSchool1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educCourse1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course1', '" & educCourse1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDegree1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree1', '" & educDegree1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educLocation1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location1', '" & educLocation1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDateFrom1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom1', '" & educDateFrom1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDateTo1.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo1', '" & educDateTo1.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educSchool2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School2', '" & educSchool2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educCourse2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course2', '" & educCourse2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDegree2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree2', '" & educDegree2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educLocation2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location2', '" & educLocation2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDateFrom2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom2', '" & educDateFrom2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educDateTo2.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo2', '" & educDateTo2.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If educSchool3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'School3', '" & educSchool3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If educCourse3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Course3', '" & educCourse3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If educDegree3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Degree3', '" & educDegree3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If educLocation3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'Location3', '" & educLocation3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If educDateFrom3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateFrom3', '" & educDateFrom3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If educDateTo3.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_EducationalBackground', 'Educational Background', 'DateTo3', '" & educDateTo3.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub CheckConfidentialInfo()
		Dim qry As String = ""

		qry = "select * from tbl_HRMS_Employee_ConfidentialInfo (nolock) where NTID = '" & pubUser & "'"
		dtConfidential = cls.GetData(qry)
	End Sub

	Private Sub btnSaveConfidentialInfo_Click(sender As Object, e As EventArgs) Handles btnSaveConfidentialInfo.Click

		If ddlTaxStat.SelectedItem.Text <> "--Select One Below--" Then
			confiTax = ddlTaxStat.SelectedItem.Text
		Else
			confiTax = ""
		End If
		confiSSS = txtBoxSSS1.Text + txtBoxSSS2.Text + txtBoxSSS3.Text
		confiTIN = txtBoxTIN1.Text + txtBoxTIN2.Text + txtBoxTIN3.Text
		confiPhilHealth = txtBoxPhilHealth1.Text + txtBoxPhilHealth2.Text + txtBoxPhilHealth3.Text
		confiPagIbig = txtBoxPagIbig1.Text + txtBoxPagIbig2.Text + txtBoxPagIbig3.Text

		UpdateConfidentailInfo()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdateConfidentailInfo()
		CheckConfidentialInfo()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtConfidential.Rows.Count > 0 Then

			If dtConfidential.Rows(0)("TaxStatus") <> confiTax.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'TaxStatus', '" & confiTax.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtConfidential.Rows(0)("SSS") <> confiSSS.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'SSS', '" & confiSSS.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtConfidential.Rows(0)("TIN") <> confiTIN.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'TIN', '" & confiTIN.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtConfidential.Rows(0)("PhilHealth") <> confiPhilHealth.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'PhilHealth', '" & confiPhilHealth.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtConfidential.Rows(0)("PagIbig") <> confiPagIbig.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'PagIbig', '" & confiPagIbig.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If confiTax.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'TaxStatus', '" & confiTax.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If confiSSS.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'SSS', '" & confiSSS.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If confiTIN.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'TIN', '" & confiTIN.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If confiPhilHealth.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'PhilHealth', '" & confiPhilHealth.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If confiPagIbig.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_ConfidentialInfo', 'Confidential Information', 'PagIbig', '" & confiPagIbig.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If
	End Sub

	Private Sub CheckDependent()
		Dim qry As String = ""

		qry = "select * from tbl_HRMS_Employee_DependentDetails (nolock) where NTID = '" & pubUser & "'"
		dtDependent = cls.GetData(qry)
	End Sub

	Private Sub btnSaveDependent_Click(sender As Object, e As EventArgs) Handles btnSaveDependent.Click

		depFathersName = txtBoxDepFather.Text
		depFathersDOB = txtBoxDepFatherDOB.Text
		depMothersName = txtBoxDepMother.Text
		depMothersDOB = txtBoxDepMotherDOB.Text
		depSpouseName = txtBoxDepSpouse.Text
		depSpouseDOB = txtBoxDepSpouseDOB.Text
		depChild1Name = txtBoxDepChild1.Text
		depChild1DOB = txtBoxDepChild1DOB.Text
		depChild2Name = txtBoxDepChild2.Text
		depChild2DOB = txtBoxDepChild2DOB.Text
		depChild3Name = txtBoxDepChild3.Text
		depChild3DOB = txtBoxDepChild3DOB.Text

		UpdateDependentDetails()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
	End Sub

	Private Sub UpdateDependentDetails()
		CheckDependent()

		Dim cmdUpdate As New SqlCommand

		Dim sb As New StringBuilder

		If dtDependent.Rows.Count > 0 Then

			Dim dbFathersDOB As String
			Dim dbMothersDOB As String
			Dim dbSpouseDOB As String
			Dim dbChild1DOB As String
			Dim dbChild2DOB As String
			Dim dbChild3DOB As String
			If Not IsDBNull(dtDependent.Rows(0)("FathersDOB")) Then
				dbFathersDOB = Convert.ToDateTime(dtDependent.Rows(0)("FathersDOB")).ToShortDateString()
			Else
				dbFathersDOB = ""
			End If
			If Not IsDBNull(dtDependent.Rows(0)("MothersDOB")) Then
				dbMothersDOB = Convert.ToDateTime(dtDependent.Rows(0)("MothersDOB")).ToShortDateString()
			Else
				dbMothersDOB = ""
			End If
			If Not IsDBNull(dtDependent.Rows(0)("SpouseDOB")) Then
				dbSpouseDOB = Convert.ToDateTime(dtDependent.Rows(0)("SpouseDOB")).ToShortDateString()
			Else
				dbSpouseDOB = ""
			End If
			If Not IsDBNull(dtDependent.Rows(0)("Child1DOB")) Then
				dbChild1DOB = Convert.ToDateTime(dtDependent.Rows(0)("Child1DOB")).ToShortDateString()
			Else
				dbChild1DOB = ""
			End If
			If Not IsDBNull(dtDependent.Rows(0)("Child2DOB")) Then
				dbChild2DOB = Convert.ToDateTime(dtDependent.Rows(0)("Child2DOB")).ToShortDateString()
			Else
				dbChild2DOB = ""
			End If
			If Not IsDBNull(dtDependent.Rows(0)("Child3DOB")) Then
				dbChild3DOB = Convert.ToDateTime(dtDependent.Rows(0)("Child3DOB")).ToShortDateString()
			Else
				dbChild3DOB = ""
			End If

			If dtDependent.Rows(0)("FathersName") <> depFathersName.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'FathersName', '" & depFathersName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbFathersDOB.Trim <> depFathersDOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'FathersDOB', '" & depFathersDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtDependent.Rows(0)("MothersName") <> depMothersName.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'MothersName', '" & depMothersName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbMothersDOB.Trim <> depMothersDOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'MothersDOB', '" & depMothersDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtDependent.Rows(0)("SpouseName") <> depSpouseName.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'SpouseName', '" & depSpouseName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbSpouseDOB.Trim <> depSpouseDOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'SpouseDOB', '" & depSpouseDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtDependent.Rows(0)("Child1Name") <> depChild1Name.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child1Name', '" & depChild1Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbChild1DOB.Trim <> depChild1DOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child1DOB', '" & depChild1DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtDependent.Rows(0)("Child2Name") <> depChild2Name.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child2Name', '" & depChild2Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbChild2DOB.Trim <> depChild2DOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child2DOB', '" & depChild2DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dtDependent.Rows(0)("Child3Name") <> depChild3Name.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child3Name', '" & depChild3Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If
			If dbChild3DOB.Trim <> depChild3DOB.Trim Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child3DOB', '" & depChild3DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Edited Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		Else
			If depFathersName.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'FathersName', '" & depFathersName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depFathersDOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'FathersDOB', '" & depFathersDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depMothersName.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'MothersName', '" & depMothersName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depMothersDOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'MothersDOB', '" & depMothersDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depSpouseName.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'SpouseName', '" & depSpouseName.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depSpouseDOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'SpouseDOB', '" & depSpouseDOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild1Name.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child1Name', '" & depChild1Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild1DOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child1DOB', '" & depChild1DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild2Name.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child2Name', '" & depChild2Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild2DOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child2DOB', '" & depChild2DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild3Name.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child3Name', '" & depChild3Name.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If
			If depChild3DOB.Trim <> "" Then
				sb.Append("('" & pubUser.Trim & "', 'tbl_HRMS_Employee_DependentDetails', 'Dependent Details', 'Child3DOB', '" & depChild3DOB.Trim & "', '" & dtEmp.Rows(0)("MngrName") & "', 'Added Details', 'Pending'),")
			End If

			Dim query As String = ""

			If sb.Length > 0 Then
				query = sb.ToString().Remove(sb.Length - 1, 1)
				sb.Clear()
			Else
				Exit Sub
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_Profile_Changes(NTID, TableName, PageName, FieldName, FieldValueIs, ImmediateSuperior, Action, Status) values " & query
		End If

		Try
			sqlConn.Open()
			cmdUpdate.Connection = sqlConn
			cmdUpdate.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Protected Sub btnUploadClick(sender As Object, e As EventArgs)
		Dim file As HttpPostedFile = Request.Files("myFile")

		'check file was submitted
		If file IsNot Nothing AndAlso file.ContentLength > 0 Then
			Dim fname As String = Path.GetFileName(file.FileName)
			file.SaveAs(Server.MapPath(Path.Combine("~/Attachments/", fname)))
		End If
	End Sub

	Private Sub btnSendForms_Click(sender As Object, e As EventArgs) Handles btnSendForms.Click
		Dim strError As String = ""
		If fileResume.HasFiles Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_Resume_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/Resume/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_Resume_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/Resume/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'Resume', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileResume.SaveAs(strPath)
			Else
				strError += "\n- Resume"
			End If
		End If

		If fileSSS.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_SSS_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/SSS/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_SSS_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/SSS/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
				"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'SSS', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileSSS.SaveAs(strPath)
			Else
				strError += "\n- SSS"
			End If

		End If

		If fileTIN.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_TIN_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/TIN/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_TIN_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/TIN/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'TIN', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileTIN.SaveAs(strPath)
			Else
				strError += "\n- TIN"
			End If

		End If

		If filePagibig.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_PagIbig_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/PagIbig/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_PagIbig_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/PagIbig/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'Pag-Ibig', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				filePagibig.SaveAs(strPath)
			Else
				strError += "\n- Pag-Ibig"
			End If

		End If

		If filePhilHealth.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_PhilHealth_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/PhilHealth/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_PhilHealth_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/PhilHealth/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'PhilHealth', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				filePhilHealth.SaveAs(strPath)
			Else
				strError += "\n- Phil Health"
			End If

		End If

		If filePoliceClearance.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_PoliceClearance_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/PoliceClearance/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_PoliceClearance_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/PoliceClearance/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'Police Clearance', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				filePoliceClearance.SaveAs(strPath)
			Else
				strError += "\n- Police Clearnace"
			End If

		End If

		If fileBrgyClearance.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_BrgyClearance_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/BrgyClearance/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_BrgyClearance_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/BrgyClearance/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'Brgy. Clearance', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileBrgyClearance.SaveAs(strPath)
			Else
				strError += "\n- Brgy. Clearance"
			End If

		End If

		If fileCedula.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_Cedula_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/Cedula/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_Cedula_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/Cedula/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'Cedula', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileCedula.SaveAs(strPath)
			Else
				strError += "\n- Cedula"
			End If

		End If

		If fileNBI.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_NBI_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/NBI/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_NBI_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/NBI/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'NBI', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileNBI.SaveAs(strPath)
			Else
				strError += "\n- NBI"
			End If

		End If

		If fileCOE.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_COE_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/COE/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_COE_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/COE/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'COE', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileCOE.SaveAs(strPath)
			Else
				strError += "\n- COE"
			End If

		End If

		If fileTOR.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_Diploma_TOR_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/DiplomaTOR/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_Diploma_TOR_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/TOR/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'TOR', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileTOR.SaveAs(strPath)
			Else
				strError += "\n- Diploma/TOR"
			End If

		End If

		If fileNSO.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_NSO_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/NSO/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_NSO_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/NSO/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'NSO', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileNSO.SaveAs(strPath)
			Else
				strError += "\n- NSO"
			End If

		End If

		If fileDepNSO.HasFile Then
			Dim extension = Path.GetExtension(fileResume.PostedFile.FileName).ToString()
			If extension = ".pdf" Then
				Dim x As Integer = 1
				Dim filename1 As String = fileResume.FileName.ToString.Replace(extension, "")
				Dim filename2 As String = pubUser & "_DepNSO_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
				Dim strPath As String = HttpContext.Current.Server.MapPath("~/Attachments/DepNSO/") & filename2

				While File.Exists(strPath) = True
					x = x + 1
					filename2 = pubUser & "_DepNSO_" & x & "_" & Date.Now.Month.ToString() & Date.Now.Day.ToString() & Date.Now.Year.ToString() & ".pdf"
					strPath = HttpContext.Current.Server.MapPath("~/Attachments/DepNSO/") & filename2
				End While

				Dim cmdInsert As New SqlCommand

				cmdInsert.CommandText = "insert into tbl_HRMS_Employee_Forms(NTID, Filename, Path, Form, OriginalFilename, Extension, UploadedBy, UploadDate) " & _
										"values('" & pubUser.Trim & "', '" & filename2.Trim & "', '" & strPath.Trim & "', 'DepNSO', '" & filename1.Trim & "', '" & extension.Trim & "', '" & pubUser.Trim & "', GETDATE())"

				Try
					sqlConn.Open()
					cmdInsert.Connection = sqlConn
					cmdInsert.ExecuteNonQuery()
				Catch ex As Exception
				Finally
					sqlConn.Close()
				End Try

				fileDepNSO.SaveAs(strPath)
			Else
				strError += "\n- Dependent NSO"
			End If
		End If

		'If strError <> "" Then
		'    ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblError').html('The format of the following files is incorrect: \n " & strError & "'); clickModal5();", True)
		'Else
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal3();", True)
		'End If
	End Sub
End Class