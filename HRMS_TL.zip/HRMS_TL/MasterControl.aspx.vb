﻿Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Data

Public Class MasterControl1
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

	End Sub



	<WebMethod()>
	Public Shared Function OnChangeModifier(SchedRulesDesc As SchedRulesDesc) As SchedRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtModifer As New DataTable

		qry = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = '" & SchedRulesDesc.strModifier & "' and AccessLevel is not null order by EmpName"
		dtModifer = cls.GetData(qry)

		Dim ListModifierNames As New List(Of SchedRulesModifierList)

		Dim ModifierList As New SchedRulesModifierList
		Dim ModifierNames As New List(Of SchedRulesModifierName)

		Dim x As Integer = 0
		Do Until x = dtModifer.Rows.Count

			Dim Name As New SchedRulesModifierName
			Name.modifierName = dtModifer.Rows(x)("EmpName")
			Name.modifierNTID = dtModifer.Rows(x)("NTID")

			ModifierNames.Add(Name)
			x += 1
		Loop

		ModifierList.ListOfModifier = ModifierNames

		ListModifierNames.Add(ModifierList)

		SchedRulesDesc.tblModifier = ListModifierNames

		Return SchedRulesDesc
	End Function

	<WebMethod()>
	Public Shared Function OnChangePersonToModify(SchedRulesDesc As SchedRulesDesc) As SchedRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtModifer As New DataTable

		qry = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = '" & SchedRulesDesc.strPersonToModify & "' and AccessLevel is not null order by EmpName"
		dtModifer = cls.GetData(qry)

		Dim ListPersonToModify As New List(Of SchedRulesPersonToModifyList)

		Dim PersonToModifyList As New SchedRulesPersonToModifyList
		Dim PersonToModify As New List(Of SchedRulesPersonToModify)

		Dim x As Integer = 0
		Do Until x = dtModifer.Rows.Count

			Dim Name As New SchedRulesPersonToModify
			Name.personToModify = dtModifer.Rows(x)("EmpName")
			Name.personToModifyNTID = dtModifer.Rows(x)("NTID")

			PersonToModify.Add(Name)
			x += 1
		Loop

		PersonToModifyList.ListOfPersonToModify = PersonToModify

		ListPersonToModify.Add(PersonToModifyList)

		SchedRulesDesc.tblPersonToModifyList = ListPersonToModify

		Return SchedRulesDesc
	End Function

	<WebMethod()>
	Public Shared Function GetSchedRuleDesc(SchedRulesDesc As SchedRulesDesc) As SchedRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim qry2 As String = ""
		Dim qry3 As String = ""
		Dim qry4 As String = ""
		Dim dtSchedRulesDesc As New DataTable
		Dim dtModifer As New DataTable
		Dim dtPersonToModify As New DataTable
		Dim dtEscalateTo As New DataTable

		qry = "select * from tbl_HRMS_SchedUpload_Settings where BusinessUnit = '" & SchedRulesDesc.strBU & "' and DeletedBy is null"



		dtSchedRulesDesc = cls.GetData(qry)

		Dim SchedRulesDescTables As New List(Of SchedRulesTable)
		Dim ListModifierNames As New List(Of SchedRulesModifierList)
		Dim ListPersonToModify As New List(Of SchedRulesPersonToModifyList)

		qry4 = "select * from tbl_HRMS_EmployeeMaster where Emplevel <> 'EE' and AccessLevel is not null and BusinessUnit = '" & SchedRulesDesc.strBU & "' order by EmpName"

		dtEscalateTo = cls.GetData(qry4)


		Dim ListEscalateTo As New List(Of EscalateToList)

		Dim EscalateToList As New EscalateToList
		Dim EscalateNames As New List(Of EscalateToName)

		Dim count As Integer = 0
		Do Until count = dtEscalateTo.Rows.Count
			Dim EscalateName As New EscalateToName

			EscalateName.EmpName = dtEscalateTo.Rows(count)("EmpName")
			EscalateName.NTID = dtEscalateTo.Rows(count)("NTID")

			EscalateNames.Add(EscalateName)
			count += 1
		Loop

		EscalateToList.ListOfEscalation = EscalateNames
		ListEscalateTo.Add(EscalateToList)

		Dim x As Integer = 0
		If dtSchedRulesDesc.Rows.Count > 0 Then
			Do Until x = dtSchedRulesDesc.Rows.Count
				Dim SchedRulesTable As New SchedRulesTable

				SchedRulesTable.id = dtSchedRulesDesc.Rows(x)("id")
				If Not IsDBNull(dtSchedRulesDesc.Rows(x)("BusinessUnit")) Then
					SchedRulesTable.businessUnit = dtSchedRulesDesc.Rows(x)("BusinessUnit")
				Else
					SchedRulesTable.businessUnit = SchedRulesDesc.strBU
				End If
				If Not IsDBNull(dtSchedRulesDesc.Rows(x)("ModifierLevel")) Then
					If dtSchedRulesDesc.Rows(x)("ModifierLevel") = "Director" Then
						SchedRulesTable.modifierLevel = "DIR"
					Else
						SchedRulesTable.modifierLevel = dtSchedRulesDesc.Rows(x)("ModifierLevel")
					End If
				Else
					SchedRulesTable.modifierLevel = ""
				End If
				If Not IsDBNull(dtSchedRulesDesc.Rows(x)("Modifier")) Then
					SchedRulesTable.modifier = dtSchedRulesDesc.Rows(x)("Modifier")
				Else
					SchedRulesTable.modifier = ""
				End If
				If Not IsDBNull(dtSchedRulesDesc.Rows(x)("PersonToModifyLevel")) Then
					If dtSchedRulesDesc.Rows(x)("PersonToModifyLevel") = "Director" Then
						SchedRulesTable.personToModifyLevel = "DIR"
					Else
						SchedRulesTable.personToModifyLevel = dtSchedRulesDesc.Rows(x)("PersonToModifyLevel")
					End If
				Else
					SchedRulesTable.personToModifyLevel = ""
				End If
				If Not IsDBNull(dtSchedRulesDesc.Rows(x)("PersonToModify")) Then
					SchedRulesTable.personToModify = dtSchedRulesDesc.Rows(x)("PersonToModify")
				Else
					SchedRulesTable.personToModify = ""
				End If

				SchedRulesDescTables.Add(SchedRulesTable)

				Dim y As Integer = 0
				Dim z As Integer = 0

				Dim ModifierList As New SchedRulesModifierList
				Dim ModifierNames As New List(Of SchedRulesModifierName)

				Dim PersonToModifyList As New SchedRulesPersonToModifyList
				Dim PersonToModify As New List(Of SchedRulesPersonToModify)

				If SchedRulesDesc.strTag = 1 Then
					qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
				Else
					qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = '" & dtSchedRulesDesc.Rows(x)("ModifierLevel") & "' and AccessLevel is not null order by EmpName"
				End If

				dtModifer = cls.GetData(qry2)
				Do Until y = dtModifer.Rows.Count

					Dim Name As New SchedRulesModifierName
					Name.modifierName = dtModifer.Rows(y)("EmpName")
					Name.modifierNTID = dtModifer.Rows(y)("NTID")

					ModifierNames.Add(Name)
					y += 1
				Loop

				ModifierList.ListOfModifier = ModifierNames

				ListModifierNames.Add(ModifierList)

				If SchedRulesDesc.strTag = 1 Then
					qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
				Else
					qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = '" & dtSchedRulesDesc.Rows(x)("PersonToModifyLevel") & "' and AccessLevel is not null order by EmpName"
				End If
				dtPersonToModify = cls.GetData(qry3)
				Do Until z = dtPersonToModify.Rows.Count

					Dim Name As New SchedRulesPersonToModify
					Name.personToModify = dtPersonToModify.Rows(z)("EmpName")
					Name.personToModifyNTID = dtPersonToModify.Rows(z)("NTID")

					PersonToModify.Add(Name)
					z += 1
				Loop

				PersonToModifyList.ListOfPersonToModify = PersonToModify

				ListPersonToModify.Add(PersonToModifyList)

				x = x + 1
			Loop
		Else
			Dim SchedRulesTable As New SchedRulesTable

			SchedRulesTable.businessUnit = SchedRulesDesc.strBU

			SchedRulesTable.modifierLevel = "EE"
			SchedRulesTable.personToModifyLevel = "EE"

			SchedRulesDescTables.Add(SchedRulesTable)

			Dim y As Integer = 0
			Dim z As Integer = 0

			Dim ModifierList As New SchedRulesModifierList
			Dim ModifierNames As New List(Of SchedRulesModifierName)

			Dim PersonToModifyList As New SchedRulesPersonToModifyList
			Dim PersonToModify As New List(Of SchedRulesPersonToModify)


			qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
			dtModifer = cls.GetData(qry2)
			Do Until y = dtModifer.Rows.Count

				Dim Name As New SchedRulesModifierName
				Name.modifierName = dtModifer.Rows(y)("EmpName")
				Name.modifierNTID = dtModifer.Rows(y)("NTID")

				ModifierNames.Add(Name)
				y += 1
			Loop

			ModifierList.ListOfModifier = ModifierNames

			ListModifierNames.Add(ModifierList)

			qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & SchedRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
			dtPersonToModify = cls.GetData(qry3)
			Do Until z = dtPersonToModify.Rows.Count

				Dim Name As New SchedRulesPersonToModify
				Name.personToModify = dtPersonToModify.Rows(z)("EmpName")
				Name.personToModifyNTID = dtPersonToModify.Rows(z)("NTID")

				PersonToModify.Add(Name)
				z += 1
			Loop

			PersonToModifyList.ListOfPersonToModify = PersonToModify

			ListPersonToModify.Add(PersonToModifyList)
			'Loop

		End If

		SchedRulesDesc.tblEscalateTo = ListEscalateTo
		SchedRulesDesc.tblSchedRulesDesc = SchedRulesDescTables
		SchedRulesDesc.tblModifier = ListModifierNames
		SchedRulesDesc.tblPersonToModifyList = ListPersonToModify

		Return SchedRulesDesc
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub AddSchedRulesDesc(strUser As String, strBU As String, modifierLevel As String, modifier As String, personToModifyLevel As String, personToModify As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "insert into tbl_HRMS_SchedUpload_Settings(BusinessUnit, ModifierLevel, Modifier, PersonToModifyLevel, PersonToModify, ModifiedBy, DateModified) "
		qry += "values('" & strBU & "', '" & modifierLevel & "', '" & modifier & "', '" & personToModifyLevel & "', '" & personToModify & "', '" & strUser & "', GETDATE())"
		rt = cls.ExecuteQuery(qry)

	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub EditSchedRulesDesc(strUser As String, strBU As String, modifierLevel As String, modifier As String, personToModifyLevel As String, personToModify As String, lblID As String, pendingDays As String, escalateTo As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "update tbl_HRMS_SchedUpload_Settings set "
		qry += "BusinessUnit = '" & strBU & "', "
		qry += "ModifierLevel = '" & modifierLevel & "', "
		qry += "Modifier = '" & modifier & "', "
		qry += "PersonToModifyLevel = '" & personToModifyLevel & "', "
		qry += "PersonToModify = '" & personToModify & "', "
		qry += "PendingDays = '" & pendingDays & "', "
		qry += "EscalateTo = '" & escalateTo & "', "
		qry += "ModifiedBy = '" & strUser & "', "
		qry += "DateModified = GETDATE() "
		qry += "where id = '" & lblID & "'"

		rt = cls.ExecuteQuery(qry)

	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub DeleteSchedRulesDesc(strUser As String, strBU As String, modifier As String, personToModify As String, lblID As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "update tbl_HRMS_SchedUpload_Settings set "
		qry += "DeletedBy = '" & strUser & "', "
		qry += "DateDeleted = GETDATE(), "
		qry += "ModifiedBy = '" & strUser & "', "
		qry += "DateModified = GETDATE() "
		qry += "where id = '" & lblID & "'"

		rt = cls.ExecuteQuery(qry)
	End Sub

	'------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	<WebMethod()>
	Public Shared Function OnChangeLogsModifier(LogsRulesDesc As LogsRulesDesc) As LogsRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtModifer As New DataTable

		qry = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = '" & LogsRulesDesc.strModifier & "' and AccessLevel is not null order by EmpName"
		dtModifer = cls.GetData(qry)

		Dim ListLogsModifierNames As New List(Of LogsRulesModifierList)

		Dim LogsModifierList As New LogsRulesModifierList
		Dim LogsModifierNames As New List(Of LogsRulesModifierName)

		Dim x As Integer = 0
		Do Until x = dtModifer.Rows.Count

			Dim Name As New LogsRulesModifierName
			Name.modifierName = dtModifer.Rows(x)("EmpName")
			Name.modifierNTID = dtModifer.Rows(x)("NTID")

			LogsModifierNames.Add(Name)
			x += 1
		Loop

		LogsModifierList.ListOfLogsModifier = LogsModifierNames

		ListLogsModifierNames.Add(LogsModifierList)

		LogsRulesDesc.tblLogsModifier = ListLogsModifierNames

		Return LogsRulesDesc
	End Function

	<WebMethod()>
	Public Shared Function OnChangeLogsPersonToModify(LogsRulesDesc As LogsRulesDesc) As LogsRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtModifer As New DataTable

		qry = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = '" & LogsRulesDesc.strPersonToModify & "' and AccessLevel is not null order by EmpName"
		dtModifer = cls.GetData(qry)

		Dim ListLogsPersonToModify As New List(Of LogsRulesPersonToModifyList)

		Dim LogsPersonToModifyList As New LogsRulesPersonToModifyList
		Dim LogsPersonToModify As New List(Of LogsRulesPersonToModify)

		Dim x As Integer = 0
		Do Until x = dtModifer.Rows.Count

			Dim Name As New LogsRulesPersonToModify
			Name.personToModify = dtModifer.Rows(x)("EmpName")
			Name.personToModifyNTID = dtModifer.Rows(x)("NTID")

			LogsPersonToModify.Add(Name)
			x += 1
		Loop

		LogsPersonToModifyList.ListOfLogsPersonToModify = LogsPersonToModify

		ListLogsPersonToModify.Add(LogsPersonToModifyList)

		LogsRulesDesc.tblLogsPersonToModifyList = ListLogsPersonToModify

		Return LogsRulesDesc
	End Function

	<WebMethod()>
	Public Shared Function GetLogsRuleDesc(LogsRulesDesc As LogsRulesDesc) As LogsRulesDesc

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim qry2 As String = ""
		Dim qry3 As String = ""
		Dim dtLogsRulesDesc As New DataTable
		Dim dtModifer As New DataTable
		Dim dtPersonToModify As New DataTable

		qry = "select * from tbl_HRMS_LogsValidation_Settings where BusinessUnit = '" & LogsRulesDesc.strBU & "' and DeletedBy is null"

		dtLogsRulesDesc = cls.GetData(qry)

		Dim LogsRulesDescTables As New List(Of LogsRulesTable)
		Dim ListLogsModifierNames As New List(Of LogsRulesModifierList)
		Dim ListLogsPersonToModify As New List(Of LogsRulesPersonToModifyList)

		Dim x As Integer = 0
		If dtLogsRulesDesc.Rows.Count > 0 Then
			Do Until x = dtLogsRulesDesc.Rows.Count
				Dim LogsRulesTable As New LogsRulesTable

				LogsRulesTable.id = dtLogsRulesDesc.Rows(x)("id")
				If Not IsDBNull(dtLogsRulesDesc.Rows(x)("BusinessUnit")) Then
					LogsRulesTable.businessUnit = dtLogsRulesDesc.Rows(x)("BusinessUnit")
				Else
					LogsRulesTable.businessUnit = LogsRulesDesc.strBU
				End If
				If Not IsDBNull(dtLogsRulesDesc.Rows(x)("ModifierLevel")) Then
					If dtLogsRulesDesc.Rows(x)("ModifierLevel") = "Director" Then
						LogsRulesTable.modifierLevel = "DIR"
					Else
						LogsRulesTable.modifierLevel = dtLogsRulesDesc.Rows(x)("ModifierLevel")
					End If
				Else
					LogsRulesTable.modifierLevel = ""
				End If
				If Not IsDBNull(dtLogsRulesDesc.Rows(x)("Modifier")) Then
					LogsRulesTable.modifier = dtLogsRulesDesc.Rows(x)("Modifier")
				Else
					LogsRulesTable.modifier = ""
				End If
				If Not IsDBNull(dtLogsRulesDesc.Rows(x)("PersonToModifyLevel")) Then
					If dtLogsRulesDesc.Rows(x)("PersonToModifyLevel") = "Director" Then
						LogsRulesTable.personToModifyLevel = "DIR"
					Else
						LogsRulesTable.personToModifyLevel = dtLogsRulesDesc.Rows(x)("PersonToModifyLevel")
					End If
				Else
					LogsRulesTable.personToModifyLevel = ""
				End If
				If Not IsDBNull(dtLogsRulesDesc.Rows(x)("PersonToModify")) Then
					LogsRulesTable.personToModify = dtLogsRulesDesc.Rows(x)("PersonToModify")
				Else
					LogsRulesTable.personToModify = ""
				End If

				LogsRulesDescTables.Add(LogsRulesTable)

				Dim y As Integer = 0
				Dim z As Integer = 0

				Dim LogsModifierList As New LogsRulesModifierList
				Dim LogsModifierNames As New List(Of LogsRulesModifierName)

				Dim LogsPersonToModifyList As New LogsRulesPersonToModifyList
				Dim LogsPersonToModify As New List(Of LogsRulesPersonToModify)

				If LogsRulesDesc.strTag = 1 Then
					qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
				Else
					qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = '" & dtLogsRulesDesc.Rows(x)("ModifierLevel") & "' and AccessLevel is not null order by EmpName"
				End If

				dtModifer = cls.GetData(qry2)
				Do Until y = dtModifer.Rows.Count

					Dim Name As New LogsRulesModifierName
					Name.modifierName = dtModifer.Rows(y)("EmpName")
					Name.modifierNTID = dtModifer.Rows(y)("NTID")

					LogsModifierNames.Add(Name)
					y += 1
				Loop

				LogsModifierList.ListOfLogsModifier = LogsModifierNames

				ListLogsModifierNames.Add(LogsModifierList)

				If LogsRulesDesc.strTag = 1 Then
					qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
				Else
					qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = '" & dtLogsRulesDesc.Rows(x)("PersonToModifyLevel") & "' and AccessLevel is not null order by EmpName"
				End If
				dtPersonToModify = cls.GetData(qry3)
				Do Until z = dtPersonToModify.Rows.Count

					Dim Name As New LogsRulesPersonToModify
					Name.personToModify = dtPersonToModify.Rows(z)("EmpName")
					Name.personToModifyNTID = dtPersonToModify.Rows(z)("NTID")

					LogsPersonToModify.Add(Name)
					z += 1
				Loop

				LogsPersonToModifyList.ListOfLogsPersonToModify = LogsPersonToModify

				ListLogsPersonToModify.Add(LogsPersonToModifyList)

				x = x + 1
			Loop
		Else
			Dim LogsRulesTable As New LogsRulesTable

			LogsRulesTable.businessUnit = LogsRulesDesc.strBU

			LogsRulesTable.modifierLevel = "EE"
			LogsRulesTable.personToModifyLevel = "EE"

			LogsRulesDescTables.Add(LogsRulesTable)

			Dim y As Integer = 0
			Dim z As Integer = 0

			Dim LogsModifierList As New LogsRulesModifierList
			Dim LogsModifierNames As New List(Of LogsRulesModifierName)

			Dim LogsPersonToModifyList As New LogsRulesPersonToModifyList
			Dim LogsPersonToModify As New List(Of LogsRulesPersonToModify)

			qry2 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
			dtModifer = cls.GetData(qry2)
			Do Until y = dtModifer.Rows.Count

				Dim Name As New LogsRulesModifierName
				Name.modifierName = dtModifer.Rows(y)("EmpName")
				Name.modifierNTID = dtModifer.Rows(y)("NTID")

				LogsModifierNames.Add(Name)
				y += 1
			Loop

			LogsModifierList.ListOfLogsModifier = LogsModifierNames

			ListLogsModifierNames.Add(LogsModifierList)

			qry3 = "select * from tbl_HRMS_EmployeeMaster where BusinessUnit = '" & LogsRulesDesc.strBU & "' and EmpLevel = 'EE' and AccessLevel is not null order by EmpName"
			dtPersonToModify = cls.GetData(qry3)
			Do Until z = dtPersonToModify.Rows.Count

				Dim Name As New LogsRulesPersonToModify
				Name.personToModify = dtPersonToModify.Rows(z)("EmpName")
				Name.personToModifyNTID = dtPersonToModify.Rows(z)("NTID")

				LogsPersonToModify.Add(Name)
				z += 1
			Loop

			LogsPersonToModifyList.ListOfLogsPersonToModify = LogsPersonToModify

			ListLogsPersonToModify.Add(LogsPersonToModifyList)
			'Loop

		End If

		LogsRulesDesc.tblLogsRulesDesc = LogsRulesDescTables
		LogsRulesDesc.tblLogsModifier = ListLogsModifierNames
		LogsRulesDesc.tblLogsPersonToModifyList = ListLogsPersonToModify

		Return LogsRulesDesc
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub AddLogsRulesDesc(strUser As String, strBU As String, modifierLevel As String, modifier As String, personToModifyLevel As String, personToModify As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "insert into tbl_HRMS_LogsValidation_Settings(BusinessUnit, ModifierLevel, Modifier, PersonToModifyLevel, PersonToModify, ModifiedBy, DateModified) "
		qry += "values('" & strBU & "', '" & modifierLevel & "', '" & modifier & "', '" & personToModifyLevel & "', '" & personToModify & "', '" & strUser & "', GETDATE())"
		rt = cls.ExecuteQuery(qry)

	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub EditLogsRulesDesc(strUser As String, strBU As String, modifierLevel As String, modifier As String, personToModifyLevel As String, personToModify As String, lblID As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "update tbl_HRMS_LogsValidation_Settings set "
		qry += "BusinessUnit = '" & strBU & "', "
		qry += "ModifierLevel = '" & modifierLevel & "', "
		qry += "Modifier = '" & modifier & "', "
		qry += "PersonToModifyLevel = '" & personToModifyLevel & "', "
		qry += "PersonToModify = '" & personToModify & "', "
		qry += "ModifiedBy = '" & strUser & "', "
		qry += "DateModified = GETDATE() "
		qry += "where id = '" & lblID & "'"

		rt = cls.ExecuteQuery(qry)

	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Sub DeleteLogsRulesDesc(strUser As String, strBU As String, modifier As String, personToModify As String, lblID As String)
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As New Integer

		qry += "update tbl_HRMS_LogsValidation_Settings set "
		qry += "DeletedBy = '" & strUser & "', "
		qry += "DateDeleted = GETDATE(), "
		qry += "ModifiedBy = '" & strUser & "', "
		qry += "DateModified = GETDATE() "
		qry += "where id = '" & lblID & "'"

		rt = cls.ExecuteQuery(qry)
	End Sub

End Class