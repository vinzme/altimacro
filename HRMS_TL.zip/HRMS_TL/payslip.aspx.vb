﻿Imports System.Data
Imports System.Web.Services
Imports iTextSharp.text.pdf
Imports System.IO
Imports System.Diagnostics

Public Class payslip
    Inherits System.Web.UI.Page

    <WebMethod> _
    Public Shared Function getPayday(data As payslipclass) As payslipclass
        Dim x As Integer = 0

        Dim cls As New clsConnection

        Dim qry = "select * from dbo.tbl_HRMS_PayslipMaster a join dbo.tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where a.NTID = '" & data.usr & "' order by cast(payday as date)"

        Dim dt As DataTable = cls.GetData(qry)

        data.payct = dt.Rows.Count

        Dim paydays As New List(Of paydayList)

        For x = 1 To 12

            Dim payday As New paydayList
            payday.paydayMonth = MonthName(x).ToString()

            Dim paydaylst As New List(Of String)

            For i = 0 To data.payct - 1

                If MonthName(x) = MonthName(Month(dt.Rows(i)("payday"))) Then
                    paydaylst.Add(dt.Rows(i)("payday"))

                    payday.cutoff_date = dt.Rows(i)("cutoff_date")

                    payday.eId = dt.Rows(i)("EmpId")
                End If

            Next

            payday.paydays = paydaylst
            paydays.Add(payday)

        Next


        data.payday = paydays

        Return data

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function viewPSPDF(data As viewPSPDF) As String
      
        Try
            Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")
            Dim pdfReader As New PdfReader(HttpContext.Current.Server.MapPath("~/PDF Template/PaySlip.pdf"))

            Using stream As New FileStream(String.Concat(HttpContext.Current.Server.MapPath("~/PDF Export/"), filename), FileMode.Create)
                Dim pdfStamper As New PdfStamper(pdfReader, stream)

                Dim cls As New clsConnection
                Dim da As New DataSet
                Dim emp As New DataTable, pay As New DataTable, slip As New DataTable, adj As New DataTable, tax As New DataTable, tSalary As New DataTable

                Dim qry = "Select * from dbo.tbl_HRMS_EmployeeMaster where empid = '" & data.eid & "';"
                qry &= "select * from dbo.tbl_HRMS_PayslipMaster where cutoff_date = '" & data.cutoff_date & "' and ntid ='" & data.ntid & "';"
                qry &= "select * from dbo.tbl_HRMS_Employee_Pay where ntid = '" & data.ntid & "';"
                qry &= "select * from dbo.tbl_hrms_Adjustments where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.ntid & "';"
                qry &= "select * from dbo.tbl_hrms_payroll_tax where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.ntid & "';"

                qry &= "select reg [txttbs], 0.00 [txttnta],nd_reg [txttrnd],reg_hld [txttrh],nd_rest+nd_hrd [txttrhnd],0.00 [txttpto],reg_ot+rest_ot+rest[txttro],restday_reghld[txttrhot],spchld[txttsh],rest_spday[txttshot],nd_spc[txttshnd],reg+rest+spchld+rest_spday+reg_hld+restday_reghld+reg_ot+rest_ot+nd_reg+nd_rest+nd_hrd+nd_spc [txtttotalsal]"
                qry &= "from("
                qry &= "select ntid, SUM(CAST(reg as float))[reg], "
                qry &= "SUM(CAST(rest as float))[rest],"
                qry &= "SUM(CAST(spchld as float))[spchld],"
                qry &= "SUM(CAST(rest_spday as float))[rest_spday],"
                qry &= "SUM(CAST(reg_hld as float))[reg_hld],"
                qry &= "SUM(CAST(restday_reghld as float))[restday_reghld],"
                qry &= "SUM(CAST(reg_ot as float))[reg_ot],"
                qry &= "SUM(CAST(rest_ot as float))[rest_ot],"
                qry &= "SUM(CAST(nd_reg as float))[nd_reg],"
                qry &= "SUM(CAST(nd_rest as float))[nd_rest],"
                qry &= "SUM(CAST(nd_hrd as float))[nd_hrd],"
                qry &= "SUM(CAST(nd_spc as float))[nd_spc]"
                qry &= "from tbl_HRMS_PayslipMaster where ntid = '" & data.ntid & "' group by ntid) tot;"

                qry &= "select payid,deduct_desc, SUM(CAST(deduct_cost as float))[TotalContrib] from dbo.tbl_hrms_Adjustments where payid='" & data.ntid & "' group by payid,deduct_desc order by payid;"

                qry &= "select payid,txttwtax,case when txttenetpay <0 then 0 else txttenetpay end [txttenetpay] from("
                qry &= "select payid, SUM(CAST(deduction as float)) [txttwtax], "
                qry &= "SUM(CAST(taxable_amount as float)-CAST(deduction as float))[txttenetpay] "
                qry &= "from tbl_hrms_payroll_tax where payid='" & data.ntid & "' group by payid) tax;"


                da = cls.GetDataSet(qry)
                emp = da.Tables(0) : slip = da.Tables(1) : pay = da.Tables(2) : adj = da.Tables(3) : tax = da.Tables(4) : tSalary = da.Tables(5)

                Dim total_salary As String = CDbl(slip.Rows(0)("reg")) + CDbl(slip.Rows(0)("rest")) + CDbl(slip.Rows(0)("spchld")) + CDbl(slip.Rows(0)("rest_spday")) + CDbl(slip.Rows(0)("reg_hld")) + CDbl(slip.Rows(0)("restday_reghld")) + CDbl(slip.Rows(0)("reg_ot")) + CDbl(slip.Rows(0)("rest_ot")) + CDbl(slip.Rows(0)("nd_reg")) + CDbl(slip.Rows(0)("nd_rest")) + CDbl(slip.Rows(0)("nd_hrd")) + CDbl(slip.Rows(0)("nd_spc"))

                Dim formFields As AcroFields = pdfStamper.AcroFields

                formFields.SetField("untitled32", emp.Rows(0)("JobDesc").ToString.Trim())
                formFields.SetField("untitled33", emp.Rows(0)("EmpName").ToString.Trim())
                formFields.SetField("txtempid", data.eid)

                formFields.SetField("txtjoined", DateValue(emp.Rows(0)("DateJoined")).ToString("MM/dd/yyyy"))
                formFields.SetField("txtresigned", "--")

                formFields.SetField("txtpagibig", "--")
                formFields.SetField("txtph", "--")
                formFields.SetField("txtsss", "--")
                formFields.SetField("txttax", "--")

                formFields.SetField("txtPayPeriod", data.cutoff_date)

                formFields.SetField("txtpayday", "--")

                formFields.SetField("txthourly", FormatNumber(pay.Rows(0)("hourly").ToString.Trim(), 2))
                formFields.SetField("txtcat", pay.Rows(0)("tax_status").ToString.Trim())


                formFields.SetField("txtbasic", FormatNumber(slip.Rows(0)("reg"), 2))
                formFields.SetField("txtnontax", "0.00")

                formFields.SetField("txtrdnd", FormatNumber(slip.Rows(0)("nd_reg"), 2))
                formFields.SetField("txtrh", FormatNumber(slip.Rows(0)("reg_hld"), 2))
                formFields.SetField("txtrhnd", FormatNumber(CDbl(slip.Rows(0)("nd_rest")) + CDbl(slip.Rows(0)("nd_hrd")), 2))

                formFields.SetField("txtpto", "0.00")


                formFields.SetField("txtreghld", FormatNumber(CDbl(slip.Rows(0)("reg_ot")) + CDbl(slip.Rows(0)("rest_ot")) + CDbl(slip.Rows(0)("rest")), 2))
                formFields.SetField("txtreghldOT", FormatNumber(slip.Rows(0)("restday_reghld"), 2))
                formFields.SetField("txtspcl", FormatNumber(slip.Rows(0)("spchld"), 2))
                formFields.SetField("txtspclOT", FormatNumber(slip.Rows(0)("rest_spday"), 2))
                formFields.SetField("txtspclnd", FormatNumber(slip.Rows(0)("nd_spc"), 2))

                If slip.Rows(0)("reg_hrs") > 0 Then formFields.SetField("txtbasichr", "(" & FormatNumber(slip.Rows(0)("reg_hrs"), 2) & ")") Else formFields.SetField("txtbasichr", "")
                'formFields.SetField("txtnontaxhrs", "(" & FormatNumber(0, 2) & ")")

                If slip.Rows(0)("nd_reg_hrs") > 0 Then formFields.SetField("txtregNDhrs", "(" & FormatNumber(slip.Rows(0)("nd_reg_hrs"), 2) & ")") Else formFields.SetField("txtregNDhrs", "")
                If slip.Rows(0)("reg_hld_hrs") > 0 Then formFields.SetField("txtregHhrs", "(" & FormatNumber(slip.Rows(0)("reg_hld_hrs"), 2) & ")") Else formFields.SetField("txtregHhrs", "")
                If CDbl(slip.Rows(0)("nd_rest_hrs")) + CDbl(slip.Rows(0)("nd_hrd_hrs")) > 0 Then formFields.SetField("txtregHNdHrs", "(" & FormatNumber(CDbl(slip.Rows(0)("nd_rest_hrs")) + CDbl(slip.Rows(0)("nd_hrd_hrs")), 2) & ")") Else formFields.SetField("txtregHNdHrs", "")

                If CDbl(slip.Rows(0)("reg_ot_hrs")) + CDbl(slip.Rows(0)("rest_ot_hrs")) + CDbl(slip.Rows(0)("rest_hrs")) > 0 Then formFields.SetField("txtRegOverT", "(" & FormatNumber(CDbl(slip.Rows(0)("reg_ot_hrs")) + CDbl(slip.Rows(0)("rest_ot_hrs")) + CDbl(slip.Rows(0)("rest_hrs")), 2) & ")") Else formFields.SetField("txtRegOverT", "")
                If slip.Rows(0)("restday_reghld_hrs") Then formFields.SetField("txtregHOtHrs", "(" & FormatNumber(slip.Rows(0)("restday_reghld_hrs"), 2) & ")") Else formFields.SetField("txtregHOtHrs", "")
                If slip.Rows(0)("spchld_hrs") > 0 Then formFields.SetField("txtspclHolHrs", "(" & FormatNumber(slip.Rows(0)("spchld_hrs"), 2) & ")") Else formFields.SetField("txtspclHolHrs", "")
                If slip.Rows(0)("rest_spday_hrs") > 0 Then formFields.SetField("txtspclHolOOTHrs", "(" & FormatNumber(slip.Rows(0)("rest_spday_hrs"), 2) & ")") Else formFields.SetField("txtspclHolOOTHrs", "")
                If slip.Rows(0)("nd_spc_hrs") > 0 Then formFields.SetField("txtspclHolNDHrs", "(" & FormatNumber(slip.Rows(0)("nd_spc_hrs"), 2) & ")") Else formFields.SetField("txtspclHolNDHrs", "")


                formFields.SetField("txtTotalSalary", FormatNumber(total_salary, 2))

                For i = 0 To adj.Rows.Count - 1
                    If adj.Rows(i)(3) = "Employee HDMF" Then formFields.SetField("txthdmf", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
                    If adj.Rows(i)(3) = "Employee PhilHealth" Then formFields.SetField("txteph", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
                    If adj.Rows(i)(3) = "Employee Social Security" Then formFields.SetField("txtesss", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
                Next

                formFields.SetField("txtwighTax", "(" & FormatNumber(tax.Rows(0)("deduction"), 2) & ")")
                formFields.SetField("txtnetpay", FormatNumber(CDbl(tax.Rows(0)("taxable_amount")) - CDbl(tax.Rows(0)("deduction")), 2))

                formFields.SetField("txttbs", FormatNumber(tSalary.Rows(0)("txttbs"), 2))
                formFields.SetField("txttnta", FormatNumber(tSalary.Rows(0)("txttnta"), 2))
                formFields.SetField("txttrnd", FormatNumber(tSalary.Rows(0)("txttrnd"), 2))
                formFields.SetField("txttrh", FormatNumber(tSalary.Rows(0)("txttrh"), 2))
                formFields.SetField("txttrhnd", FormatNumber(tSalary.Rows(0)("txttrhnd"), 2))
                formFields.SetField("txttpto", FormatNumber(tSalary.Rows(0)("txttpto"), 2))
                formFields.SetField("txttro", FormatNumber(tSalary.Rows(0)("txttro"), 2))
                formFields.SetField("txttrhot", FormatNumber(tSalary.Rows(0)("txttrhot"), 2))
                formFields.SetField("txttsh", FormatNumber(tSalary.Rows(0)("txttsh"), 2))
                formFields.SetField("txttshot", FormatNumber(tSalary.Rows(0)("txttshot"), 2))
                formFields.SetField("txttshnd", FormatNumber(tSalary.Rows(0)("txttshnd"), 2))
                formFields.SetField("txtttotalsal", FormatNumber(tSalary.Rows(0)("txtttotalsal"), 2))

                tSalary.Dispose() : tSalary = da.Tables(6)

                For i = 0 To tSalary.Rows.Count - 1
                    If tSalary.Rows(i)(1) = "Employee HDMF" Then formFields.SetField("txttehdmf", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
                    If tSalary.Rows(i)(1) = "Employee PhilHealth" Then formFields.SetField("txtteph", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
                    If tSalary.Rows(i)(1) = "Employee Social Security" Then formFields.SetField("txttsss", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
                Next

                tSalary.Dispose() : tSalary = da.Tables(7)

                formFields.SetField("txttwtax", "(" & FormatNumber(tSalary.Rows(0)("txttwtax"), 2) & ")")
                formFields.SetField("txttenetpay", FormatNumber(tSalary.Rows(0)("txttenetpay"), 2))

                'formFields.SetField("txtcat", "")
                pdfStamper.FormFlattening = True
                pdfStamper.Close()

                emp.Dispose() : pay.Dispose() : slip.Dispose() : adj.Dispose() : tax.Dispose() : tSalary.Dispose() : da.Dispose()

                'Dim script As String = String.Format("window.open('{0}');", String.Concat("/export/", filename))
                'ClientScript.RegisterClientScriptBlock(Me.[GetType](), "newPDF", script, True)

                Return String.Concat("PDF Export/", filename)
            End Using
        Catch ex As Exception
            Debug.WriteLine(ex.HResult)
            Return ex.ToString
        End Try

    End Function

    <WebMethod> _
    Public Shared Function getYear(data As payslipclass) As List(Of String)

        Dim qry As String = "select DISTINCT Year(payday) [year] from tbl_HRMS_PayslipMaster where NTID = 'lamzonde'"
        Dim cls As New clsConnection
        Dim years As New List(Of String)

        Dim dt As DataTable = cls.GetData(qry)

        Dim i As Integer = 0

        For i = 0 To dt.Rows.Count - 1
            years.Add(dt.Rows(i)("year"))
        Next

        Return years
    End Function

End Class