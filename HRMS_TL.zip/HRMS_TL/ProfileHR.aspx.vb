﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Services
Imports System.Data

Public Class ProfileHR
	Inherits System.Web.UI.Page

	Dim pubUser As String

	Dim cls As New clsConnection

	Dim ntid As String

	Dim dtBSegment As New DataTable
	Dim dtBU As New DataTable
	Dim dtBUPerSegment As New DataTable
	Dim dtEmpLevel As New DataTable
	Dim dtManager As New DataTable
	Dim dtManagerPerBU As New DataTable
	Dim dtEmp As New DataTable
	Dim dtTenure As New DataTable

	Dim dtResume As New DataTable
	Dim dtSSS As New DataTable
	Dim dtTin As New DataTable
	Dim dtPagIbig As New DataTable
	Dim dtPhilHealth As New DataTable
	Dim dtPoliceClearance As New DataTable
	Dim dtBrgyClearance As New DataTable
	Dim dtCedula As New DataTable
	Dim dtNBI As New DataTable
	Dim dtCOE As New DataTable
	Dim dtTOR As New DataTable
	Dim dtNSO As New DataTable
	Dim dtDepNSO As New DataTable

	Dim infoDatasource As New SqlDataSource

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/ProfileHR.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		If Not IsPostBack Then
			txtEmployeeName.Attributes.Add("placeholder", "Search Employee Name")
			PopulateBSegment()
			'ddlBusinessUnit.Items.Add("--Select One Below--")
			PopulateBU()
			PopulateLevel()
			'ddlImmediateSuperior.Items.Add("--Select One Below--")
			PopulateManager()
		End If
	End Sub

	Private Sub PopulateBSegment()
		Dim query As String

		query = "select Distinct BusinessSegment from tbl_HRMS_EmployeeMaster (nolock) order by BusinessSegment"

		dtBSegment = cls.GetData(query)

		ddlBusinessSegment.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtBSegment.Rows.Count - 1
			ddlBusinessSegment.Items.Add(dtBSegment.Rows(x)("BusinessSegment"))
		Next
	End Sub

	Private Sub PopulateBU()
		Dim query As String

		query = "select Distinct BusinessUnit from tbl_HRMS_EmployeeMaster (nolock) where BusinessUnit is not null order by BusinessUnit"

		dtBU = cls.GetData(query)

		ddlBusinessUnit.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtBU.Rows.Count - 1
			ddlBusinessUnit.Items.Add(dtBU.Rows(x)("BusinessUnit"))
		Next
	End Sub

	Private Sub PopulateBUPerSegment()
		Dim query As String

		query = "select Distinct BusinessUnit from tbl_HRMS_EmployeeMaster (nolock) where BusinessUnit is not null and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' order by BusinessUnit"

		dtBUPerSegment = cls.GetData(query)

		ddlBusinessUnit.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtBUPerSegment.Rows.Count - 1
			ddlBusinessUnit.Items.Add(dtBUPerSegment.Rows(x)("BusinessUnit"))
		Next
	End Sub

	Private Sub PopulateLevel()

		ddlEmpLevel.Items.Add("--Select One Below--")
		ddlEmpLevel.Items.Add("VP")
		ddlEmpLevel.Items.Add("DIR")
		ddlEmpLevel.Items.Add("MGR")
		ddlEmpLevel.Items.Add("SR. MGR")
		ddlEmpLevel.Items.Add("AM")
		ddlEmpLevel.Items.Add("TL")
		ddlEmpLevel.Items.Add("EE")

	End Sub

	Private Sub PopulateManager()
		Dim empLevel As String
		Dim levels As String = ""

		Dim sb1 As New StringBuilder

		sb1.Append("select Distinct  ")
		sb1.Append("MngrNTID  ")
		sb1.Append("from tbl_HRMS_EmployeeMaster (nolock)  ")
		sb1.Append("where  ")

		If ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below" Then
			sb1.Append("EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' and ")
		End If

		sb1.Append("MngrNTID is not null ")
		sb1.Append("order by  ")
		sb1.Append("MngrNTID ")

		empLevel = sb1.ToString()

		dtEmpLevel = cls.GetData(empLevel)

		For x As Integer = 0 To dtEmpLevel.Rows.Count - 1
			If x = dtEmpLevel.Rows.Count - 1 Then
				levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "'"
			Else
				levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "',"
			End If
		Next

		Dim query As String

		Dim sb2 As New StringBuilder

		sb2.Append("select ")
		sb2.Append("EmpName, ")
		sb2.Append("EmpLevel ")
		sb2.Append("from tbl_HRMS_EmployeeMaster (nolock) ")
		sb2.Append("where ")
		sb2.Append("NTID in (" & levels.Trim & ")")
		sb2.Append("order by ")
		sb2.Append("EmpName ")

		query = sb2.ToString()

		dtManager = cls.GetData(query)

		ddlImmediateSuperior.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtManager.Rows.Count - 1
			ddlImmediateSuperior.Items.Add(dtManager.Rows(x)("EmpName"))
		Next
	End Sub

	Private Sub PopulateManagerPerBU()
		Dim empLevel As String
		Dim levels As String = ""

		Dim sb1 As New StringBuilder

		sb1.Append("select Distinct  ")
		sb1.Append("MngrNTID  ")
		sb1.Append("from tbl_HRMS_EmployeeMaster (nolock)  ")
		sb1.Append("where  ")

		If ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below" Then
			sb1.Append("EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' and ")
		End If

		sb1.Append("BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' and ")
		sb1.Append("MngrNTID is not null ")
		sb1.Append("order by  ")
		sb1.Append("MngrNTID ")

		empLevel = sb1.ToString()

		dtEmpLevel = cls.GetData(empLevel)

		For x As Integer = 0 To dtEmpLevel.Rows.Count - 1
			If x = dtEmpLevel.Rows.Count - 1 Then
				levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "'"
			Else
				levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "',"
			End If
		Next

		Dim query As String

		Dim sb2 As New StringBuilder

		sb2.Append("select ")
		sb2.Append("EmpName, ")
		sb2.Append("EmpLevel ")
		sb2.Append("from tbl_HRMS_EmployeeMaster (nolock) ")
		sb2.Append("where ")
		sb2.Append("NTID in (" & levels.Trim & ")")
		sb2.Append("order by ")
		sb2.Append("EmpName ")

		query = sb2.ToString()

		dtManagerPerBU = cls.GetData(query)

		ddlImmediateSuperior.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtManagerPerBU.Rows.Count - 1
			ddlImmediateSuperior.Items.Add(dtManagerPerBU.Rows(x)("EmpName"))
		Next
	End Sub

	Private Sub ddlBusinessSegment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessSegment.SelectedIndexChanged
		ddlBusinessUnit.Items.Clear()
		PopulateBUPerSegment()
	End Sub

	Private Sub ddlBusinessUnit_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessUnit.SelectedIndexChanged
		ddlImmediateSuperior.Items.Clear()
		PopulateManagerPerBU()
	End Sub

	Private Sub ddlEmpLevel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlEmpLevel.SelectedIndexChanged
		ddlImmediateSuperior.Items.Clear()
		If ddlBusinessUnit.SelectedItem.Text.Trim <> "--Select One Below--" Then
			PopulateManagerPerBU()
		Else
			PopulateManager()
		End If
	End Sub

	Private Sub GetSchedDate()
		Dim query As String


	End Sub

	Private Sub QueryConditions()
		Dim query As String

		If ddlPages.SelectedValue = 1 Then

			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("a.EmpID as [Employee #],  ")
			sb.Append("a.NTID as [NT Log in],  ")
			sb.Append("CONVERT(varchar(10), CAST((select Schedin from tbl_HRMS_Employee_Schedule where SchedDate = lastAct.SchedDate and LoginID = a.NTID) as TIME), 100) [TimeIN], ")
			sb.Append("CONVERT(varchar(10), CAST((select SchedOUT from tbl_HRMS_Employee_Schedule where SchedDate = lastAct.SchedDate and LoginID = a.NTID) as TIME), 100) [TimeOUT],  ")
			sb.Append("a.Alias as [Alias],  ")
			sb.Append("a.EmpName as [Name],  ")
			sb.Append("a.MngrName as [Immediate Superior],  ")
			sb.Append("a.DeptName as [Department Name],  ")
			sb.Append("a.DeptCode as [Department Code]  ")
			sb.Append("from tbl_HRMS_EmployeeMaster a  ")
			sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_Employee_Activity where LoginID = a.NTID order by SeriesID desc) lastAct ")
			sb.Append("where  ")
			sb.Append("a.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and a.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and a.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and a.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and a.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and a.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("a.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 2 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("EmpID as [Employee #], ")
			sb.Append("NTID as [NT Log in], ")
			sb.Append("NTID + '@altisource.com' as [Work Email], ")
			sb.Append("ExtensionNumber as [Extension], ")
			sb.Append("Skill as [Skill], ")
			sb.Append("Convert(varchar(15), DateJoined, 107) as [Joining Date], ")
			sb.Append("Convert(varchar(15), ProductionStartDate, 107) as [Production Start Date], ")
			sb.Append("'' as [Tenure], ")
			sb.Append("'' as [Tenure In Months] ")
			sb.Append("from tbl_HRMS_EmployeeMaster ")
			sb.Append("where ")
			sb.Append("NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 3 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("EmpID as [Employee #], ")
			sb.Append("NTID as [NT Log in], ")
			sb.Append("Batch as [Batch], ")
			sb.Append("Class as [Class], ")
			sb.Append("EmpStatus as [Employee Status], ")
			sb.Append("BusinessUnit as [Business Unit], ")
			sb.Append("BusinessUnitHead as [Business Unit Head], ")
			sb.Append("Workstation as [Work Station] ")
			sb.Append("from tbl_HRMS_EmployeeMaster ")
			sb.Append("where ")
			sb.Append("NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 4 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.HouseNumber as [House Number], ")
			sb.Append("a.StreetName as [Street Name], ")
			sb.Append("a.Barangay as [Barangay], ")
			sb.Append("a.Town as [Town], ")
			sb.Append("a.City as [City], ")
			sb.Append("a.Region as [Region], ")
			sb.Append("a.ZipCode as [Zip Code] ")
			sb.Append("from tbl_HRMS_Employee_PersonalInformation a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 5 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.BloodType as [Blood Type], ")
			sb.Append("a.Gender as [Gender], ")
			sb.Append("a.DOB as [Date of Birth], ")
			sb.Append("a.Citizenship as [Citizenship] ")
			sb.Append("from tbl_HRMS_Employee_PersonalInformation a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 6 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.MobileAreaCode + a.MobileNumber as [Mobile Number], ")
			sb.Append("a.HomeAreaCode + a.HomeNumber as [Home Number], ")
			sb.Append("a.PersonalEmail as [Personal Email] ")
			sb.Append("from tbl_HRMS_Employee_PersonalInformation a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 7 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.EmrgNumber as [Mobile Number], ")
			sb.Append("a.EmrgName as [Name], ")
			sb.Append("a.EmrgRelationship as [Relationship] ")
			sb.Append("from tbl_HRMS_Employee_PersonalInformation a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 8 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.Employer1, ")
			sb.Append("a.Work1, ")
			sb.Append("Convert(varchar(20),a.DateFrom1,107) as DateFrom1, ")
			sb.Append("Convert(varchar(20),a.DateTo1,107) as DateTo1 ")
			sb.Append("from tbl_HRMS_EmployeeHistory a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 9 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.Employer2, ")
			sb.Append("a.Work2, ")
			sb.Append("Convert(varchar(20),a.DateFrom2,107) as DateFrom2, ")
			sb.Append("Convert(varchar(20),a.DateTo2,107) as DateTo2 ")
			sb.Append("from tbl_HRMS_EmployeeHistory a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 10 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.Employer3, ")
			sb.Append("a.Work3, ")
			sb.Append("Convert(varchar(20),a.DateFrom3,107) as DateFrom3, ")
			sb.Append("Convert(varchar(20),a.DateTo3,107) as DateTo3 ")
			sb.Append("from tbl_HRMS_EmployeeHistory a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 11 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.Employer4, ")
			sb.Append("a.Work4, ")
			sb.Append("Convert(varchar(20),a.DateFrom4,107) as DateFrom4, ")
			sb.Append("Convert(varchar(20),a.DateTo4,107) as DateTo4 ")
			sb.Append("from tbl_HRMS_EmployeeHistory a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 12 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.Employer5, ")
			sb.Append("a.Work5, ")
			sb.Append("Convert(varchar(20),a.DateFrom5,107) as DateFrom5, ")
			sb.Append("Convert(varchar(20),a.DateTo5,107) as DateTo5 ")
			sb.Append("from tbl_HRMS_EmployeeHistory a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 13 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.School1, ")
			sb.Append("a.Course1, ")
			sb.Append("a.Degree1, ")
			sb.Append("a.Location1, ")
			sb.Append("Convert(varchar(20),a.DateFrom1,107) as DateFrom1, ")
			sb.Append("Convert(varchar(20),a.DateTo1,107) as DateTo1 ")
			sb.Append("from tbl_HRMS_Employee_EducationalBackground a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID  ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 14 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.School2, ")
			sb.Append("a.Course2, ")
			sb.Append("a.Degree2, ")
			sb.Append("a.Location2, ")
			sb.Append("Convert(varchar(20),a.DateFrom2,107) as DateFrom2, ")
			sb.Append("Convert(varchar(20),a.DateTo2,107) as DateTo2 ")
			sb.Append("from tbl_HRMS_Employee_EducationalBackground a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 15 Then
			Dim sb As New StringBuilder

			sb.Append("select  ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("a.School3, ")
			sb.Append("a.Course3, ")
			sb.Append("a.Degree3, ")
			sb.Append("a.Location3, ")
			sb.Append("Convert(varchar(20),a.DateFrom3,107) as DateFrom3, ")
			sb.Append("Convert(varchar(20),a.DateTo3,107) as DateTo3 ")
			sb.Append("from tbl_HRMS_Employee_EducationalBackground a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 16 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.FathersName as [Father's Name], ")
			sb.Append("Convert(varchar(20),a.FathersDOB,107) as [Date of Birth], ")
			sb.Append("a.MothersName as [Mother's Name], ")
			sb.Append("Convert(varchar(20),a.MothersDOB,107) as [Date of Birth], ")
			sb.Append("a.SpouseName as [Spouse's Name], ")
			sb.Append("Convert(varchar(20),a.SpouseDOB,107) as [Date of Birth] ")
			sb.Append("from tbl_HRMS_Employee_DependentDetails a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 17 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID as [Employee #], ")
			sb.Append("b.NTID as [NT Log in], ")
			sb.Append("a.Child1Name as [1st Child's Name], ")
			sb.Append("Convert(varchar(20),a.Child1DOB,107) as [Date of Birth], ")
			sb.Append("a.Child2Name as [2nd Child's Name], ")
			sb.Append("Convert(varchar(20),a.Child2DOB,107) as [Date of Birth], ")
			sb.Append("a.Child3Name as [3rd Child's Name], ")
			sb.Append("Convert(varchar(20),a.Child3DOB,107) as [Date of Birth] ")
			sb.Append("from tbl_HRMS_Employee_DependentDetails a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where ")
			sb.Append("b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid.DataSource = infoDatasource
			infoGrid.EmptyDataText = "No Data!"
			infoGrid.DataBind()
			infoGrid.Visible = True
			infoGrid2.Visible = False
		ElseIf ddlPages.SelectedValue = 18 Then
			Dim sb As New StringBuilder

			sb.Append("select ")
			sb.Append("b.EmpID, ")
			sb.Append("b.NTID, ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'Resume' and NTID = b.NTID) as [ResumeFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'Resume' and NTID = b.NTID) as [ResumePath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'SSS' and NTID = b.NTID) as [SSSFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'SSS' and NTID = b.NTID) as [SSSPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'TIN' and NTID = b.NTID) as [TINFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'TIN' and NTID = b.NTID) as [TINPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'Pag-Ibig' and NTID = b.NTID) as [PagIbigFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'Pag-Ibig' and NTID = b.NTID) as [PagIbigPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'PhilHealth' and NTID = b.NTID) as [PhilHealthFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'PhilHealth' and NTID = b.NTID) as [PhilHealthPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'Police Clearance' and NTID = b.NTID) as [PoliceClearanceFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'Police Clearance' and NTID = b.NTID) as [PoliceClearancePath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'Brgy. Clearance' and NTID = b.NTID) as [BrgyClearanceFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'Brgy. Clearance' and NTID = b.NTID) as [BrgyClearancePath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'Cedula' and NTID = b.NTID) as [CedulaFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'Cedula' and NTID = b.NTID) as [CedulaPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'NBI' and NTID = b.NTID) as [NBIFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'NBI' and NTID = b.NTID) as [NBIPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'COE' and NTID = b.NTID) as [COEFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'COE' and NTID = b.NTID) as [COEPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'TOR' and NTID = b.NTID) as [TORFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'TOR' and NTID = b.NTID) as [TORPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'NSO' and NTID = b.NTID) as [NSOFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'NSO' and NTID = b.NTID) as [NSOPath], ")
			sb.Append("(select top 1 Filename from tbl_HRMS_Employee_Forms where Form = 'DepNSO' and NTID = b.NTID) as [DepNSOFile], ")
			sb.Append("(select top 1 Path from tbl_HRMS_Employee_Forms where Form = 'DepNSO' and NTID = b.NTID) as [DepNSOPath] ")
			sb.Append("from tbl_HRMS_Employee_Forms a ")
			sb.Append("join tbl_HRMS_EmployeeMaster b ")
			sb.Append("on a.NTID = b.NTID ")
			sb.Append("where b.NTID is not null ")
			If txtEmployeeName.Text <> "" Then
				sb.Append(" and b.EmpName like '%" & txtEmployeeName.Text & "%' ")
			End If
			If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
			End If
			If ddlBusinessUnit.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
			End If
			If ddlEmpLevel.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
			End If
			If ddlImmediateSuperior.SelectedItem.Text <> "--Select One Below--" Then
				sb.Append(" and b.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
			End If
			sb.Append("order by ")
			sb.Append("b.NTID ")

			query = sb.ToString()
			sb.Clear()
			infoDatasource.ConnectionString = connStr
			infoDatasource.SelectCommand = query

			infoDatasource.DataBind()
			infoGrid2.DataSource = infoDatasource
			infoGrid2.EmptyDataText = "No Data!"
			infoGrid2.DataBind()
			infoGrid.Visible = False
			infoGrid2.Visible = True
		End If
	End Sub

	Private Sub ddlPages_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlPages.SelectedIndexChanged
		If txtEmployeeName.Text <> "" Or
			ddlBusinessSegment.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlBusinessUnit.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlImmediateSuperior.SelectedItem.Text.Trim <> "--Select One Below--" Then
			QueryConditions()
		End If
	End Sub

	Private Sub infoGrid_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles infoGrid.RowDataBound
		If e.Row.RowType = DataControlRowType.DataRow Then
			If ddlPages.SelectedValue = 2 Then
				ntid = e.Row.Cells(1).Text

				GetEmpInfo()
				GetTenure()

				If dtTenure.Rows.Count > 0 Then
					If Not IsDBNull(dtTenure.Rows(0)("Years")) And
					Not IsDBNull(dtTenure.Rows(0)("Months")) And
					Not IsDBNull(dtTenure.Rows(0)("Days")) Then
						e.Row.Cells(7).Text = dtTenure.Rows(0)("Years") & " years " & dtTenure.Rows(0)("Months") & " months " & dtTenure.Rows(0)("Days") & " days"
					Else
						e.Row.Cells(7).Text = ""
					End If
				End If

				If dtEmp.Rows.Count > 0 Then
					If Not IsDBNull(dtEmp.Rows(0)("TenureInMonths")) Then
						e.Row.Cells(8).Text = dtEmp.Rows(0)("TenureInMonths")
					Else
						e.Row.Cells(8).Text = ""
					End If
				End If
			End If
		End If
	End Sub

	Protected Sub DownloadFile(ByVal sender As Object, ByVal e As EventArgs)
		Dim filePath As String = CType(sender, LinkButton).CommandArgument
		Response.ContentType = ContentType
		Response.AppendHeader("Content-Disposition", ("attachment; filename=" & Path.GetFileName(filePath)))
		Response.WriteFile(filePath)
		Response.End()
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select EmpID, NTID, Alias, EmpName, MngrName, DeptName, DeptCode, JobDesc, ExtensionNumber, Skill, Batch, Class, Workstation, DATENAME(MONTH, DateJoined) + ' ' + DATENAME(DAY, DateJoined) + ', ' + DATENAME(YEAR, DateJoined) as DateJoined, DATENAME(MONTH, ProductionStartDate) + ' ' + DATENAME(DAY, ProductionStartDate) + ', ' + DATENAME(YEAR, ProductionStartDate) as ProdDate, DATENAME(MONTH, DATEADD(MONTH, 6, DateJoined)) + ' ' + DATENAME(DAY, DateJoined) + ', ' + DATENAME(YEAR, DateJoined) as RegDate, CAST(DATEDIFF(MONTH, DateJoined, GetDate()) as VARCHAR) + ' months' as TenureInMonths , EmpStatus, BusinessUnit, BusinessUnitHead from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & ntid.Trim & "'"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub GetTenure()

		Dim qry As String = ""

		qry += "DECLARE @date datetime, @tmpdate datetime, @years int, @months int, @days int" & vbCrLf
		qry += "SELECT @date = '" & dtEmp.Rows(0)("DateJoined") & "';" & vbCrLf
		qry += "SELECT @tmpdate = @date;" & vbCrLf
		qry += "SELECT @years = DATEDIFF(yy, @tmpdate, GETDATE()) - CASE WHEN (MONTH(@date) > MONTH(GETDATE())) OR (MONTH(@date) = MONTH(GETDATE()) AND DAY(@date) > DAY(GETDATE())) THEN 1 ELSE 0 END" & vbCrLf
		qry += "SELECT @tmpdate = DATEADD(yy, @years, @tmpdate);" & vbCrLf
		qry += "SELECT @months = DATEDIFF(m, @tmpdate, GETDATE()) - CASE WHEN DAY(@date) > DAY(GETDATE()) THEN 1 ELSE 0 END;" & vbCrLf
		qry += "SELECT @tmpdate = DATEADD(m, @months, @tmpdate);" & vbCrLf
		qry += "SELECT @days = DATEDIFF(d, @tmpdate, GETDATE());" & vbCrLf
		qry += "SELECT @years as [Years], @months as [Months], @days as [Days]"

		dtTenure = cls.GetData(qry)
	End Sub

	Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
		UpdatePanel1.Update()
		QueryConditions()
	End Sub

	Private Sub GetResume()
		Dim query As String

		query = "select Filename, Path from tbl_HRMS_Employee_Forms where Form = 'Resume' and NTID = '" & ntid.Trim & "'"

		dtResume = cls.GetData(query)
	End Sub

	Public Class changesMade
		Public id As String
		Public ChangesMadeTo As String
		Public oldDetails As String
		Public newDetails As String
		Public fieldname As String
		Public fieldvalue As String
	End Class

	<WebMethod(EnableSession:=True)> _
	Public Shared Function GetPreviewChanges(ByVal str As changesMade) As changesMade

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtChanges As New DataTable

		qry = "Select * from dbo.tbl_HRMS_Profile_Changes where id = " & str.id
		dtChanges = cls.GetData(qry)

		str.ChangesMadeTo = dtChanges.Rows(0)("PageName")
		str.fieldvalue = dtChanges.Rows(0)("FieldValueIs")
		str.fieldname = dtChanges.Rows(0)("FieldName")

		Dim strDate As Date

		If InStr(str.fieldname, "Date") > 0 Then
			If dtChanges.Rows.Count > 0 Then
				If dtChanges(0)("FieldValueIs").ToString <> "" Then
					strDate = Convert.ToDateTime(dtChanges(0)("FieldValueIs")).ToShortDateString
					str.newDetails = strDate.ToString("MMM dd, yyyy")
				Else
					str.newDetails = "--"
				End If

				qry = "Select " & str.fieldname & " from " & dtChanges.Rows(0)("TableName") & " where NTID = '" & dtChanges.Rows(0)("NTID") & "'"
				dtChanges = cls.GetData(qry)
				If dtChanges.Rows.Count > 0 Then
					If dtChanges(0)(str.fieldname).ToString <> "" Then
						strDate = Convert.ToDateTime(dtChanges(0)(str.fieldname)).ToShortDateString()
						str.oldDetails = strDate.ToString("MMM dd, yyyy")
					Else
						str.oldDetails = "--"
					End If
				Else
					str.oldDetails = "--"
					str.newDetails = "--"
				End If
			End If
		Else
			If dtChanges.Rows.Count > 0 Then
				If dtChanges(0)("FieldValueIs").ToString <> "" Then
					str.newDetails = dtChanges(0)("FieldValueIs")
				Else
					str.newDetails = "--"
				End If

				qry = "Select " & str.fieldname & " from " & dtChanges.Rows(0)("TableName") & " where NTID = '" & dtChanges.Rows(0)("NTID") & "'"
				dtChanges = cls.GetData(qry)
				If dtChanges.Rows.Count > 0 Then
					If dtChanges(0)(str.fieldname).ToString <> "" Then
						str.oldDetails = dtChanges(0)(str.fieldname)
					Else
						str.oldDetails = "--"
					End If
				Else
					str.oldDetails = "--"
					str.newDetails = "--"
				End If
			End If
		End If

		Return str

	End Function

	Private Sub btnApprove_Click(sender As Object, e As EventArgs) Handles btnApprove.Click
		Dim qry As String = ""
		Dim str As String = ""
		Dim updte As String = ""
		Dim dtChanges As New DataTable
		Dim hasCheck As Boolean = False

		Dim MySqlConn As New SqlConnection(connStr)

		Dim cmdUpdate As New SqlCommand

		For Each row As GridViewRow In requestGrid.Rows
			'For Each row As TableRow In dtDateApplied.Rows
			If row.RowType = DataControlRowType.DataRow Then
				Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("chkBox"), CheckBox)

				If chkRow.Checked Then
					qry = "Select * from dbo.tbl_HRMS_Profile_Changes where id = " & chkRow.ToolTip
					dtChanges = cls.GetData(qry)
					If dtChanges.Rows.Count Then
						updte = "UPDATE " & dtChanges.Rows(0)("TableName") & " SET " & dtChanges(0)("FieldName") & " = '" & dtChanges.Rows(0)("FieldValueIs") & "' WHERE NTID = '" & dtChanges.Rows(0)("NTID") & "'"

						cmdUpdate = New SqlCommand

						cmdUpdate.CommandText = updte

						cmdUpdate.Connection = MySqlConn
						cmdUpdate.Connection.Open()
						cmdUpdate.ExecuteNonQuery()
						MySqlConn.Close()

					End If
					hasCheck = True
					str += chkRow.ToolTip & ","
				End If
			End If

		Next
		If hasCheck = True Then
			str = Mid(str, 1, Len(str) - 1)
			qry = "UPDATE tbl_HRMS_Profile_Changes SET [2ndApproval] = '" & pubUser.Trim & "', [2ndApprovalDate] = GETDATE(), Status = 'Approved' where id in (" & str & ")"

			cmdUpdate = New SqlCommand

			cmdUpdate.CommandText = qry

			cmdUpdate.Connection = MySqlConn
			cmdUpdate.Connection.Open()
			cmdUpdate.ExecuteNonQuery()
			MySqlConn.Close()

			requestGrid.DataBind()

			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
					   "javascript:alert('Changes has been made..');", True)
		Else
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
					   "javascript:alert('Please Select..');", True)
		End If
	End Sub

	Private Sub btnDeny_Click(sender As Object, e As EventArgs) Handles btnDeny.Click
		Dim qry As String = ""
		Dim hasCheck As Boolean = False
		Dim str As String = ""

		Dim MySqlConn As New SqlConnection(connStr)
		Dim cmdUpdate As New SqlCommand

		For Each row As GridViewRow In requestGrid.Rows
			'For Each row As TableRow In dtDateApplied.Rows
			If row.RowType = DataControlRowType.DataRow Then
				Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("chkBox"), CheckBox)

				If chkRow.Checked Then
					hasCheck = True
					str += chkRow.ToolTip & ","
				End If
			End If
		Next

		If hasCheck = True Then
			str = Mid(str, 1, Len(str) - 1)
			qry = "UPDATE tbl_HRMS_Profile_Changes SET Status = 'Denied', [2ndApproval] = '" & pubUser.Trim & "', [2ndApprovalDate] = GETDATE() where id in (" & str & ")"

			cmdUpdate.CommandText = qry

			cmdUpdate.Connection = MySqlConn
			cmdUpdate.Connection.Open()
			cmdUpdate.ExecuteNonQuery()
			requestGrid.DataBind()

			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
						 "javascript:alert('Changes has been made..');", True)
		Else
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
					   "javascript:alert('Please Select..');", True)
		End If
	End Sub

	Private Sub btnNext_ServerClick(sender As Object, e As EventArgs) Handles btnNext.ServerClick
		If txtEmployeeName.Text.Trim <> "" Or
			ddlBusinessSegment.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlBusinessUnit.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlImmediateSuperior.SelectedItem.Text.Trim <> "--Select One Below--" Then

			If ddlPages.SelectedValue <> ddlPages.Items.Count Then
				ddlPages.SelectedValue = Convert.ToInt32(ddlPages.SelectedValue) + 1
				QueryConditions()
			End If
		Else
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblError').text('Please select a filter on the settings panel.'); clickModal5()", True)
		End If

	End Sub

	Private Sub btnPrev_ServerClick(sender As Object, e As EventArgs) Handles btnPrev.ServerClick
		If txtEmployeeName.Text.Trim <> "" Or
			ddlBusinessSegment.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlBusinessUnit.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below--" Or
			ddlImmediateSuperior.SelectedItem.Text.Trim <> "--Select One Below--" Then

			If ddlPages.SelectedValue <> 0 Then
				ddlPages.SelectedValue = Convert.ToInt32(ddlPages.SelectedValue) - 1
				QueryConditions()
			End If

		Else
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblError').text('Please select a filter on the settings panel.'); $('#lblError').text('Please select a filter on the settings panel.');clickModal5()", True)
		End If
	End Sub
End Class