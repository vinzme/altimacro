﻿#Region "Imports"

Imports System.Data.SqlClient
Imports System.Data.DataSet
Imports System.Security.Principal
Imports System.Web.UI.Page
Imports System.IO
Imports System.Data
Imports System.Net
Imports System
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Threading

#End Region

Public Class HoursWorked
	Inherits System.Web.UI.Page

	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String
	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String
	Dim employeeEmpLevel As String

	Dim pubUserMode As String
	Dim ExpiredMinutes As Integer

	Dim pubUserStatus As String
	Dim pubUserStatusTag As String
	Dim pubServerDateTime As String
	Dim pubActivityID As Integer

	Dim pubLoginTimeSummary As String
	Dim pubLogoutTimeSummary As String
	Dim pubTotalHoursSummary As String
	Dim pubLoginTime As String
	Dim pubLogoutTime As String
	Dim pubTotalHours As String

	Dim dtChkHoliday As DataTable
	Dim dtChkLeave As DataTable
	Dim dtChkLeaveExisting As DataTable
	Dim dtHoliday_spcW As New DataTable
	Dim dtHoliday_reg As New DataTable
	Dim dtHolidays As New DataTable
	Dim dtLastActivity As New DataTable
	Dim dtEmpLevel As New DataTable
	Dim dtPaidHours As New DataTable
	Dim dtExcessHours As New DataTable
	Dim dtUnpaidHours As New DataTable
	Dim dtLoginTimeSummary As New DataTable
	Dim dtLogoutTimeSummary As New DataTable
	Dim dtTotalHoursSummary As New DataTable
	Dim dtLoginTime As New DataTable
	Dim dtLogoutTime As New DataTable
	Dim dtTotalHours As New DataTable
	Dim dtPaidHoursSummary As New DataTable
	Dim dtEndTime As New DataTable
	Dim dtActLate As New DataTable
	Dim dtSchedLate As New DataTable
	Dim dtSchedAbsent As New DataTable
	Dim dtActAbsent As New DataTable

	Dim pubTotalSegmentMinutes As Integer = 0
	Dim pubIfTotalSegmentMinutes As Boolean = False
	Dim pubIfStartTimeSegment As Boolean = False
	Dim pubIfEndTimeSegment As Boolean = False

	Dim fullName As String = ""

	Dim dtLogin As DateTime
	Dim schedDate As String

	'Add Segment

	Dim pubTransSchedDate As String
	Dim pubTransStartTime As String
	Dim pubTransEndTime As String
	Dim pubTransReason As String
	Dim pubTransReasonID As Integer
	Dim pubSeries As String
	Dim pubSeriesAdjusted As String
	Dim pubOrigSeries As String
	Dim pubSchedDate As String
	Dim pubNewStartDate As String
	Dim pubNewEndDate As String

	'Leave Controls
	Dim pubLeaveDate As String
	Dim pubHalfDay As String
	Dim pubLeaveType As String
	Dim pubLeavePayment As String
	Dim pubLeaveStatus As String

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/HoursWorked.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		GetEmpInfo()
		employeeEmpLevel = dtEmp.Rows(0)("EmpLevel")
		If Not Page.IsPostBack Then

			GetLastActivity()

			'If dtLastActivity.Rows(0)("reasonid") = 14 Or
			'    dtLastActivity.Rows(0)("reasonid") = 16 Then

			'    Response.Redirect("Home.aspx")
			'Else

			PopulateTreeView()

			GetLastLeaveDate()

			Dim year As String = Convert.ToInt32(DateTime.Now.Year).ToString

			Dim yearRes As String = ""

			yearRes = year.Substring(2)

			Dim items As New List(Of ListItem)()
			For i As Integer = -16 To 0
				'Populating the Year Values in dropdown
				items.Add(New ListItem(DateTime.Now.AddYears(i).Year, DateTime.Now.AddYears(i).Year))
			Next

			For j As Integer = 1 To 4
				'Populating the Year Values in dropdown
				items.Add(New ListItem(DateTime.Now.AddYears(j).Year, DateTime.Now.AddYears(j).Year))
			Next

			DropDownList2.DataSource = items
			DropDownList2.DataBind()
			DropDownList2.Items(Convert.ToInt32(yearRes) - 1).Selected = True
		End If
		'End If
	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' order by seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub PopulateTreeView()

		GetEmpInfo()
		Dim MngrNTID As String = ""
		Dim AccessLevel As String = ""
		If dtEmp.Rows.Count > 0 Then
			MngrNTID = dtEmp.Rows(0)("MngrNTID")
			AccessLevel = dtEmp.Rows(0)("AccessLevel")
		End If

		If AccessLevel = "24" Then
			Dim parentAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster where BusinessSegment = 'Financial Services' and AccessLevel is not null and NTID = '" & pubUser & "' order by EmpName", sqlConn)

			Dim dtParent As DataTable = New DataTable()

			parentAdapter.Fill(dtParent)
			Dim index As Integer = -1
			Dim drParent As DataRow
			For Each drParent In dtParent.Rows
				Dim childAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster where BusinessSegment = 'Financial Services' and AccessLevel is not null and NTID <> '" & pubUser & "' order by EmpName", sqlConn)
				Dim dtChild As DataTable = New DataTable()
				childAdapter.Fill(dtChild)
				index = index + 1
				Dim parent As TreeNode = New TreeNode()
				parent.Value = drParent("NTID").ToString()
				parent.Text = drParent("EmpName").ToString()
				TreeView1.Nodes.Add(parent)
				Dim drChild As DataRow
				For Each drChild In dtChild.Rows
					If dtChild.Rows.Count > 0 Then
						Dim child As TreeNode = New TreeNode()
						child.Value = drChild("NTID").ToString()
						child.Text = drChild("EmpName").ToString()
						TreeView1.Nodes(index).ChildNodes.Add(child)
					End If
				Next
			Next
		Else
			Dim query As String = "select Empname, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & MngrNTID & "' and AccessLevel is not null order by EmpName"
			Dim parentAdapter As New SqlDataAdapter(query, sqlConn)

			Dim dtParent As DataTable = New DataTable()

			parentAdapter.Fill(dtParent)
			Dim index As Integer = -1
			Dim drParent As DataRow
			For Each drParent In dtParent.Rows
				Dim childAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drParent("NTID").ToString & "' and AccessLevel is not null order by EmpName", sqlConn)
				Dim dtChild As DataTable = New DataTable()
				childAdapter.Fill(dtChild)
				index = index + 1
				Dim parent As TreeNode = New TreeNode()
				parent.Value = drParent("NTID").ToString()
				parent.Text = drParent("EmpName").ToString()
				TreeView1.Nodes.Add(parent)
				Dim drChild As DataRow
				For Each drChild In dtChild.Rows
					If dtChild.Rows.Count > 0 Then
						Dim child As TreeNode = New TreeNode()
						child.Value = drChild("NTID").ToString()
						child.Text = drChild("EmpName").ToString()
						TreeView1.Nodes(index).ChildNodes.Add(child)
					End If
				Next
			Next
		End If

	End Sub

	Protected Sub TreeView1_SelectedNodeChanged(sender As Object, e As EventArgs) Handles TreeView1.SelectedNodeChanged

		agentName.Text = TreeView1.SelectedNode.Text.Trim + "'s Schedule:"
		Label35.Text = TreeView1.SelectedValue.Trim.ToString
		GetEmpLvl()
		lblEmpLvl.Text = dtEmpLevel.Rows(0)("EmpLevel")
		lblAccessLvl.Text = dtEmpLevel.Rows(0)("AccessLevel")
		GridView4.Visible = False
		GridView5.Visible = False
		GridView6.Visible = False
		UpdatePanel1.Update()

	End Sub

	Private Sub GetHrsWorkedCutOff()
		Dim hrsWorked As Double = 0
		For x As Integer = 0 To GridView5.Rows.Count - 1
			hrsWorked += Format(Val(Convert.ToDouble(GridView5.Rows(x).Cells(9).Text)), "0.00")
		Next

		totalHoursCutoff.Text = hrsWorked
	End Sub

	Private Sub GetPaidWorkedCutOff()
		Dim paidWorked As Double = 0.0

		For x As Integer = 0 To GridView5.Rows.Count - 1
			schedDate = GridView5.Rows(x).Cells(1).Text

			GetPaidSummary()

			If Not IsDBNull(dtPaidHours.Rows(0)("PaidHours")) Then
				paidWorked += Format(Val(Convert.ToDouble(dtPaidHours.Rows(0)("PaidHours"))), "0.00")
			Else
				paidWorked += "0.00"
			End If
		Next

		totalPaidCutoff.Text = paidWorked
	End Sub

	Private Sub GetEmpLvl()
		Dim query As String

		query = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & Label35.Text.Trim & "'"

		dtEmpLevel = cls.GetData(query)
	End Sub

	Private Sub UpdateScheduleHrsWorked()
		Try
			Dim query As String

			query = "select CONVERT(varchar, SchedDate, 107) as SchedDate, LEFT(DATENAME(DW,SchedDate), 3) as dow, SchedIN, Break1, Lunch, Break2, SchedOUT, SchedType, HoursWorked from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & Label35.Text & "' and SchedDate BETWEEN '" & LblSchedule.Text & "' AND '" & LblSchedule2.Text & "' order by SchedDate"
			'query = "Select loginid, CONVERT(varchar, sched.SchedDate, 107) as SchedDate, "
			'query += "LEFT(DATENAME(DW,sched.SchedDate), 3) as dow, "
			'query += "SchedIN, Break1, Lunch, Break2, SchedOUT, SchedType, HoursWorked, img.imgUrl "
			'query += ",outrCheck.nP, outrCheck.Activity_Status, outrCheck.EEApproval "

			'query += "from tbl_HRMS_Employee_Schedule sched "
			'query += "outer apply(Select SUM(CASE WHEN EEApproval IS null then 1 else CASE WHEN Activity_Status = 'Pending' then 1 else 0 end end ) nP, Activity_Status, EEApproval "

			'query += "from dbo.tbl_HRMS_Employee_Activity where LoginID=sched.LoginID and SchedDate = sched.SchedDate and EEApproval is null group by Activity_Status, EEApproval) outrCheck "

			'query += "outer apply(select Case when Emp.EmpLevel = 'EE' then (CASE WHEN outrCheck.nP > 0 then '~/Images/select1.png' else '~/Images/select2.png' end) else '~/Images/select2.png' end [imgUrl] from tbl_HRMS_EmployeeMaster Emp where Emp.NTID = sched.LoginID) img "

			'query += "where sched.LoginID = '" & Label35.Text & "' and sched.SchedDate BETWEEN '" & LblSchedule.Text & "' AND '" & LblSchedule2.Text & "' order by loginid,SchedDate "

			Dim ad As SqlDataAdapter = New SqlDataAdapter(query, sqlConn)

			sqlConn.Open()

			GridView5.Visible = True
			Dim ds As Data.DataSet = New Data.DataSet

			ad.Fill(ds)

			GridView5.DataSource = ds
			'Dim str As String = GridView5.Rows.Count.ToString()
			GridView5.SelectedIndex = -1
			GridView5.DataBind()
			GridView5.Visible = True

			lblPaid.Visible = False
			totalHoursPaid.Visible = False
			lblExcess.Visible = False
			totalHoursExcesspaid.Visible = False
			lblUnpaid.Visible = False
			totalHoursUnpaid.Visible = False

			sqlConn.Close()
		Catch ex As Exception
			GridView5.Visible = False
			GridView5.DataSource = Nothing
		Finally
			sqlConn.Close()
		End Try
	End Sub

	Private Sub GetLastLeaveDate()

		Dim lblLastLeave As Label = TryCast(Me.Master.FindControl("Label100"), Label)
		Dim query As String

		Try
			sqlConn.Open()
			query = "Select MAX(LeaveDate) as LastLeave from dbo.tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser.Trim & "'"

			Dim MySqlCmd As New SqlCommand(query, sqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then

				While mReader.Read()

					lblLastLeave.Text = mReader("LastLeave")

				End While

			End If

		Catch ex As Exception
			sqlConn.Close()
		Finally
			sqlConn.Close()
		End Try

	End Sub

	Private Sub GetSched()

		If DropDownList4.SelectedItem.Text.Trim = "1 - 15" Then
			LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 1 " + DropDownList2.SelectedItem.Text.Trim
			LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 15 " + DropDownList2.SelectedItem.Text.Trim
		Else
			Select Case DropDownList3.SelectedItem.Text.Trim
				Case "January"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "February"
					If Val(DropDownList2.SelectedItem.Text) Mod 4 = 0 Then
						LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
						LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 29 " + DropDownList2.SelectedItem.Text.Trim
					Else
						LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
						LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 28 " + DropDownList2.SelectedItem.Text.Trim
					End If
				Case "March"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "April"
					LblSchedule.Text = "16 " + DropDownList3.SelectedItem.Text.Trim + " " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = "30 " + DropDownList3.SelectedItem.Text.Trim + " " + DropDownList2.SelectedItem.Text.Trim
				Case "May"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "June"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 30 " + DropDownList2.SelectedItem.Text.Trim
				Case "July"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "August"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "September"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 30 " + DropDownList2.SelectedItem.Text.Trim
				Case "October"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim
				Case "November"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 30 " + DropDownList2.SelectedItem.Text.Trim
				Case "December"
					LblSchedule.Text = DropDownList3.SelectedItem.Text.Trim + " 16 " + DropDownList2.SelectedItem.Text.Trim
					LblSchedule2.Text = DropDownList3.SelectedItem.Text.Trim + " 31 " + DropDownList2.SelectedItem.Text.Trim

			End Select
		End If
		GridView5.SelectedIndex = -1
		GridView5.DataBind()
		GridView5.Visible = True
		lblPaid.Visible = False
		totalHoursPaid.Visible = False
		lblExcess.Visible = False
		totalHoursExcesspaid.Visible = False
		lblUnpaid.Visible = False
		totalHoursUnpaid.Visible = False

	End Sub

	Protected Sub GridView5_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView5.RowCommand

		Select Case e.CommandName

			Case "Select"
				Dim rowindex As Integer = CInt(e.CommandArgument)
				Dim row As GridViewRow = GridView5.Rows(rowindex)

				If row IsNot Nothing Then
					LblActivityDate.Text = row.Cells(1).Text
					lblStart.Text = row.Cells(3).Text
					lblEnd.Text = row.Cells(7).Text
					Dim str As String = Label35.Text
				End If

				lblPaid.Visible = True
				totalHoursPaid.Visible = True
				If lblAccessLvl.Text <> "1" Then
					lblExcess.Visible = True
					totalHoursExcesspaid.Visible = True
					lblUnpaid.Visible = False
					totalHoursUnpaid.Visible = False
				Else
					lblExcess.Visible = False
					totalHoursExcesspaid.Visible = False
					lblUnpaid.Visible = True
					totalHoursUnpaid.Visible = True
				End If

				'If lblEmpLvl.Text = "EE" Then
				'	btnApproveHrs.Visible = True
				'End If
		End Select

		GridView4.SelectedIndex = -1
		GridView4.EmptyDataText = "No Activity!"
		GridView4.Visible = True
		GridView4.DataBind()

		GetLogInTime()
		GetLogOutTime()

		If dtLoginTime.Rows.Count > 0 Then
			pubLoginTime = dtLoginTime.Rows(0)("Start_Time")

			If dtLogoutTime.Rows.Count > 0 Then
				If Not IsDBNull(dtLogoutTime.Rows(0)("End_Time")) Then
					pubLogoutTime = dtLogoutTime.Rows(0)("End_Time")

					GetTotalHours()

					pubTotalHours = dtTotalHours.Rows(0)("TotalHours")

					GetPaidHoursActivity()

					If Not IsDBNull(dtPaidHours.Rows(0)("PaidHours")) Then
						totalHoursPaid.Text = dtPaidHours.Rows(0)("PaidHours")
					Else
						totalHoursPaid.Text = "0.0"
					End If

					If lblAccessLvl.Text <> "1" Then
						GetExcessHoursActivity()

						If Not IsDBNull(dtExcessHours.Rows(0)("ExcessHours")) Then
							totalHoursExcesspaid.Text = dtExcessHours.Rows(0)("ExcessHours")
						Else
							totalHoursExcesspaid.Text = "0.0"
						End If
					Else
						GetUnpaidHoursActivity()

						If Not IsDBNull(dtUnpaidHours.Rows(0)("UnpaidHours")) Then
							totalHoursUnpaid.Text = dtUnpaidHours.Rows(0)("UnpaidHours")
						Else
							totalHoursUnpaid.Text = "0.0"
						End If
					End If
				End If
			Else
				totalHoursPaid.Text = "0.0"
			End If
		Else
			totalHoursPaid.Text = "0.0"
		End If
		'If GridView4.Rows.Count = 0 Then
		BtnSaveSegment.Visible = True
		btnAddSlot.Enabled = True
		activityTrackerPanel.Update()
		addSegmentPanel.Update()
		'GridView4.Visible = True
		'Else
		'BtnSaveSegment.Visible = False
		'ImageButtonAddSlot.Enabled = False
		'End If

	End Sub

	Private Sub GetAbsent()
		Dim query As String

		query = "select * from tbl_HRMS_Employee_Activity where LoginID = '" & Label35.Text & "' and SchedDate = '" & lblSchedDate.Text & "' order by Start_Time"

		dtActAbsent = cls.GetData(query)

		Dim query2 As String

		query2 = "select * from tbl_HRMS_Employee_Schedule where LoginID = '" & Label35.Text & "' and SchedDate = '" & lblSchedDate.Text & "' and SchedType not in ('RD', 'PTO', 'CTO') order by SchedDate"

		dtSchedAbsent = cls.GetData(query2)
	End Sub

	Protected Sub GridView5_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView5.RowDataBound

		If e.Row.RowType = DataControlRowType.DataRow Then
			For Each ctrl As Control In e.Row.Cells(4).Controls
				If ctrl.[GetType]().BaseType = GetType(ImageButton) Then
					DirectCast(ctrl, ImageButton).ToolTip = DirectCast(ctrl, ImageButton).AlternateText
				End If
			Next

			lblSchedDate.Text = e.Row.Cells(1).Text

			GetPaidHoursSummary()

			If Not IsDBNull(dtPaidHours.Rows(0)("PaidHours")) Then
				e.Row.Cells(9).Text = dtPaidHours.Rows(0)("PaidHours")
			Else
				e.Row.Cells(9).Text = "0.0"
			End If

			Dim result As Integer = DateTime.Compare(Convert.ToDateTime(lblSchedDate.Text).ToShortDateString, DateTime.Now.ToShortDateString)

			If result <= 0 Then
				GetAbsent()

				If dtActAbsent.Rows.Count = 0 And
					dtSchedAbsent.Rows.Count > 0 Then
					e.Row.ForeColor = Drawing.Color.Red
					e.Row.Style.Add("font-weight", "bold")
				End If
			End If
		End If
	End Sub

	Protected Sub GridView4_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView4.RowCommand

		Select Case e.CommandName

			Case "Select"
				Dim rowindex As Integer = CInt(e.CommandArgument)
				Dim row As GridViewRow = GridView4.Rows(rowindex)

				If row IsNot Nothing Then
					If row.Cells(5).Text.Trim <> "" And _
						 row.Cells(5).Text.Trim <> 0 Then

						'Add Segment
						pubTransSchedDate = row.Cells(1).Text.Trim
						pubTransReason = row.Cells(4).Text.Trim

						'start
						Dim lbl3 As Label = DirectCast(row.FindControl("Label3"), Label)
						pubTransStartTime = lbl3.Text.Trim

						'series 
						Dim lbl2 As Label = DirectCast(row.FindControl("Label2"), Label)
						pubSeries = lbl2.Text.Trim

						DeleteActivityTrans()

						InsertIntoActivityTrans()

						'set label
						LblSeriesID.Text = pubSeries.Trim

						'unhide/activate
						BtnSaveSegment.Visible = True
						btnAddSlot.Enabled = True

						GridView6.Visible = True
						GridView6.DataBind()
						addSegmentPanel.Update()

					End If

				End If

		End Select

	End Sub

	Private Sub GetActivityNumber()

		Dim query As String
		Dim i As Integer

		Try
			sqlConn.Open()
			i = 0

			query = "Select top 1 a.SeriesID from dbo.tbl_HRMS_Employee_Activity a (nolock) inner join dbo.tbl_HRMS_PAY_Reason b (nolock) on a.ReasonID = b.ReasonID where a.LoginID = '" & Label35.Text.Trim & _
							"' and a.SchedDate = '" & pubTransSchedDate.Trim & "' and b.ReasonDesc = '" & pubTransReason.Trim & "' and a.Start_Time >= '" & pubTransStartTime.Trim & "' order by a.SeriesID"

			Dim MySqlCmd As New SqlCommand(query, sqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then
				While mReader.Read()

					pubActivityID = mReader("SeriesID")

				End While

			End If

		Catch ex As Exception

		Finally
			sqlConn.Close()
		End Try

	End Sub

	Private Sub GetReasonNumber()
		Dim query As String
		Dim i As Integer

		Try
			sqlConn.Open()
			i = 0

			query = "Select ReasonID from dbo.tbl_HRMS_PAY_Reason (nolock) where ReasonDesc = '" & pubTransReason.Trim & "'"

			Dim MySqlCmd As New SqlCommand(query, sqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then
				While mReader.Read()

					pubTransReasonID = mReader("Reasonid")

				End While

			End If

		Catch ex As Exception

		Finally
			sqlConn.Close()
		End Try

	End Sub

	Private Sub InsertIntoActivityTrans()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "insert into tbl_HRMS_Employee_Activity_Trans(LoginID,SchedDate,Start_Time,End_Time,ReasonDesc,Series_Adjusted) " & _
											 "Select a.LoginID, a.SchedDate, a.Start_Time, a.End_Time, b.ReasonDesc, '" & pubSeries.Trim & "' from dbo.tbl_HRMS_Employee_Activity a inner join dbo.tbl_HRMS_PAY_Reason b " & _
											 "on a.ReasonID = b.ReasonID where SeriesID = '" & pubSeries.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub InsertIntoActivityMaster()

		Dim cmdUpdate As New SqlCommand

		If lblEmpLvl.Text.Trim = employeeEmpLevel Then
			cmdUpdate.CommandText = "insert into dbo.tbl_HRMS_Employee_Activity(LoginID,Start_Time,End_Time,ReasonID,SchedDate,TotalTimeMin,TotalTimeHour,Series_Adjusted,Activity_Status,Activity_Tag,AddedBy,DateAdded) " & _
											"Select LoginID,Start_Time,End_Time,ReasonID,SchedDate,TotalTimeMin,DATEDIFF(MI, Start_Time, End_Time)/60,Series_Adjusted, 'Pending' as Activity_Status, 'OK' as Activity_Tag, '" & pubUser.Trim & "' as AddedBy, GETDATE() as DateAdded from dbo.tbl_HRMS_Employee_Activity_Trans (nolock) where SeriesID = '" & pubSeries.Trim & "'"
		Else
			cmdUpdate.CommandText = "insert into dbo.tbl_HRMS_Employee_Activity(LoginID,Start_Time,End_Time,ReasonID,SchedDate,IsPaid,TotalTimeMin,TotalTimeHour,Approved_Time,Series_Adjusted,Activity_Status,Activity_Tag,AddedBy,DateAdded) " & _
											"Select LoginID,Start_Time,End_Time,ReasonID,SchedDate,'YES' as IsPaid,TotalTimeMin,DATEDIFF(MI, Start_Time, End_Time)/60 as TotalTimeHour,GETDATE() as Approved_Time,Series_Adjusted, 'Approved' as Activity_Status, 'OK' as Activity_Tag, '" & pubUser.Trim & "' as AddedBy, GETDATE() as DateAdded from dbo.tbl_HRMS_Employee_Activity_Trans (nolock) where SeriesID = '" & pubSeries.Trim & "'"
		End If

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub InsertIntoActivityMaster2()

		Dim cmdUpdate As New SqlCommand

		If Label35.Text = pubUser Then
			cmdUpdate.CommandText = "insert into dbo.tbl_HRMS_Employee_Activity(LoginID,Start_Time,End_Time,ReasonID,SchedDate,TotalTimeMin,Series_Adjusted,Activity_Status,Activity_Tag,AddedBy,DateAdded) " & _
											"Select LoginID,Start_Time,End_Time,ReasonID,SchedDate,TotalTimeMin,Series_Adjusted, 'Pending' as Activity_Status, 'OK' as Activity_Tag, '" & pubUser.Trim & "' as AddedBy, GETDATE() as DateAdded from dbo.tbl_HRMS_Employee_Activity_Trans (nolock) where SeriesID = '" & pubSeries.Trim & "'"
		Else
			cmdUpdate.CommandText = "insert into dbo.tbl_HRMS_Employee_Activity(LoginID,Start_Time,End_Time,ReasonID,SchedDate,TotalTimeMin,Approved_Time,Series_Adjusted,Activity_Status,Activity_Tag,AddedBy,DateAdded)) " & _
											"Select LoginID,Start_Time,End_Time,ReasonID,SchedDate,DATEDIFF(MI, Start_Time, End_Time)/60,GETDATE(),Series_Adjusted, 'Approved' as Activity_Status, 'OK' as Activity_Tag, '" & pubUser.Trim & "' as AddedBy, GETDATE() as DateAdded from dbo.tbl_HRMS_Employee_Activity_Trans (nolock) where SeriesID = '" & pubSeries.Trim & "'"
		End If

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub InsertIntoActivityTransSegment()
		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "insert into tbl_HRMS_Employee_Activity_Trans(LoginID,Start_Time,End_Time,ReasonID,SchedDate,Series_Adjusted) " & _
									"Select top 1 LoginID, End_Time, End_Time, ReasonID, SchedDate, Series_Adjusted from dbo.tbl_HRMS_Employee_Activity_Trans where LoginID = '" & Label35.Text.Trim & "' order by SeriesID desc"

		cmdUpdate.Connection = sqlConn
		cmdUpdate.Connection.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub SaveCurrentActivityTrans()
		Dim sql As String = ""
		Dim dr As GridViewRow
		Dim gIndex As Integer = -1
		For Each dr In GridView6.Rows

			If gIndex = -1 Then
				gIndex = 0
			End If

			'series 
			Dim lbl2 As Label = DirectCast(GridView6.Rows(gIndex).FindControl("lblHrsWorkedSeriesID"), Label)
			pubSeries = lbl2.Text.Trim

			'Start Time
			Dim lbl3 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox3"), TextBox)
			pubTransStartTime = lbl3.Text.Trim

			'End Time
			Dim lbl4 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox4"), TextBox)
			pubTransEndTime = lbl4.Text.Trim

			'Reason
			Dim lbl5 As DropDownList = DirectCast(GridView6.Rows(gIndex).FindControl("DropDownList2"), DropDownList)
			pubTransReason = lbl5.Text.Trim

			GetReasonNumber()

			Try
				sql = "UPDATE dbo.tbl_HRMS_Employee_Activity_Trans SET Start_Time = '" & pubTransStartTime.Trim & "'," & _
				"End_Time = '" & pubTransEndTime.Trim & "', ReasonID = " & pubTransReasonID.ToString.Trim & " where SeriesID = " & pubSeries

				cls.ExecuteQuery(sql)
			Catch ex As Exception
				System.Diagnostics.Debug.WriteLine(ex.InnerException)
			End Try

			gIndex += 1
		Next
	End Sub

	Private Sub InsertIntoActivityTransSegment2()
		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "insert into tbl_HRMS_Employee_Activity_Trans(LoginID, Start_Time, End_Time, SchedDate) " & _
										"Select TOP 1 LoginID, SchedIN, SchedOUT, SchedDate from tbl_HRMS_Employee_Schedule (nolock) " & _
										"where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & LblActivityDate.Text.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()
	End Sub

	Private Sub DeleteActivityTransSeries()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "delete from tbl_HRMS_Employee_Activity_Trans where SeriesID = '" & pubSeries.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub DeleteActivityTrans()
		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "delete from tbl_HRMS_Employee_Activity_Trans where LoginID = '" & Label35.Text.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Public Function PopulateReason() As Data.DataSet
		If lblAccessLvl.Text.Trim <> "1" Then
			Dim ad As SqlDataAdapter = New SqlDataAdapter("Select ReasonDesc as prompt from dbo.tbl_HRMS_PAY_Reason (nolock) where ReasonID in ('2') order by ReasonDesc", sqlConn)
			Dim ds As Data.DataSet = New Data.DataSet()
			ad.Fill(ds, "tblLeaveType")
			Return ds
		Else
			Dim ad As SqlDataAdapter = New SqlDataAdapter("Select ReasonDesc as prompt from dbo.tbl_HRMS_PAY_Reason (nolock) where ReasonID not in ('1','14','16') and Active = '1' order by ReasonDesc", sqlConn)
			Dim ds As Data.DataSet = New Data.DataSet()
			ad.Fill(ds, "tblLeaveType")
			Return ds
		End If


	End Function

	Private Sub GridView6_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView6.RowCommand
		Select Case e.CommandName

			Case "Delete"
				Dim rowindex As Integer = CInt(e.CommandArgument)
				Dim row As GridViewRow = GridView6.Rows(rowindex)

				If row IsNot Nothing Then
					Dim lbl2 As Label = DirectCast(row.FindControl("lblHrsWorkedSeriesID"), Label)
					pubSeries = lbl2.Text.Trim
				End If

				DeleteActivityTransSeries()
				If GridView6.Rows.Count = 0 Then
					GridView4.SelectedIndex = -1
				End If
				activityTrackerPanel.Update()
		End Select

		GridView6.Visible = True
		GridView6.DataBind()
		addSegmentPanel.Update()
	End Sub

	Protected Sub GridView6_RowUpdated(sender As Object, e As GridViewUpdatedEventArgs) Handles GridView6.RowUpdated
		UpdateReasonDesc()
	End Sub

	Private Sub UpdateReasonDesc()

		Dim cmdUpdate As New SqlCommand


		cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity_Trans set ReasonDesc = '" & pubTransReason.Trim & "' where SeriesID = '" & pubSeries.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub UpdateActivityAdjusted()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity set Activity_Status = 'Adjusted' where SeriesID = '" & LblSeriesID.Text.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub LoopLogGrid()

		Dim dr As GridViewRow
		Dim gIndex As Integer = -1
		Dim skip As Integer = 0
		Dim err As String = ""

		For Each dr In GridView6.Rows

			If gIndex = -1 Then
				gIndex = 0
			End If

			'series 
			Dim lblHrsWorkedSeriesID As Label = DirectCast(GridView6.Rows(gIndex).FindControl("lblHrsWorkedSeriesID"), Label)
			pubSeries = lblHrsWorkedSeriesID.Text.Trim

			Dim lblDate As Label = DirectCast(GridView6.Rows(gIndex).FindControl("lblSchedDate"), Label)
			pubSchedDate = lblDate.Text.Trim

			'Start Time
			Dim lbl3 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox3"), TextBox)
			pubTransStartTime = lbl3.Text.Trim

			Dim startAmPm As String = pubTransStartTime.Substring(pubTransStartTime.Length - 2)

			'End Time
			Dim lbl4 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox4"), TextBox)
			pubTransEndTime = lbl4.Text

			'Reason
			Dim lbl5 As DropDownList = DirectCast(GridView6.Rows(gIndex).FindControl("DropDownList2"), DropDownList)
			pubTransReason = lbl5.Text.Trim

			If pubTransEndTime = "" Then
				ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Cannot save segment without end time!');", True)
				Exit Sub
			End If

			Dim pubStartDate As DateTime = pubTransStartTime
			Dim pubEndDate As DateTime = pubTransEndTime
			Dim lblStartDate As DateTime = LblActivityDate.Text & " " & lblStart.Text

			If pubEndDate < pubStartDate Then
				skip = 1
				ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "alert", "javascript: alert('Invalid end time!')", True)
				Exit Sub
			End If

			If GridView4.SelectedIndex = -1 Then
				Dim checkOverlap As String
				Dim dtOverlap As New DataSet

				Dim empName As String = agentName.Text.Substring(0, agentName.Text.IndexOf("'s Schedule"))

				checkOverlap = "select a.* from dbo.tbl_HRMS_Employee_Activity a join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID where b.EmpName = '" & empName.Trim & "' and Convert(varchar(20),Start_Time, 100) between Convert(varchar(20),'" & pubTransStartTime & "', 100) and Convert(varchar(20), '" & pubTransEndTime & "', 100);"
				checkOverlap += "select a.* from dbo.tbl_HRMS_Employee_Activity a join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID where b.EmpName = '" & empName.Trim & "' and Convert(varchar(20),End_Time, 100) between Convert(varchar(20),'" & pubTransStartTime & "', 100) and Convert(varchar(20), '" & pubTransEndTime & "', 100);"
				dtOverlap = cls.GetDataSet(checkOverlap)

				If dtOverlap.Tables(0).Rows.Count > 0 Or dtOverlap.Tables(1).Rows.Count > 0 Then
					ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "alert", "javascript: alert('Overlap with existing activity, please check the time you input.')", True)
					Exit Sub
				End If
			End If

			GetReasonNumber()

			UpdateActivityTrans()

			UpdateTimeMinHour()

			InsertIntoActivityMaster()

			GetSeriesAdjustedFromTrans()

			If pubSeriesAdjusted <> "" Then
				UpdateActivityTagADJ()
			End If

			gIndex += 1

		Next

		DeleteActivityTrans()

		GridView6.Visible = True
		GridView6.DataBind()
		GridView4.Visible = True
		GridView4.SelectedIndex = -1
		GridView4.DataBind()

		GetPaidHoursActivity()

		If Not IsDBNull(dtPaidHours.Rows(0)("PaidHours")) Then
			totalHoursPaid.Text = dtPaidHours.Rows(0)("PaidHours")
		Else
			totalHoursPaid.Text = "0.0"
		End If

		If lblAccessLvl.Text <> "1" Then
			GetExcessHoursActivity()

			If Not IsDBNull(dtExcessHours.Rows(0)("ExcessHours")) Then
				totalHoursExcesspaid.Text = dtExcessHours.Rows(0)("ExcessHours")
			Else
				totalHoursExcesspaid.Text = "0.0"
			End If
		Else
			GetUnpaidHoursActivity()

			If Not IsDBNull(dtUnpaidHours.Rows(0)("UnpaidHours")) Then
				totalHoursUnpaid.Text = dtUnpaidHours.Rows(0)("UnpaidHours")
			Else
				totalHoursUnpaid.Text = "0.0"
			End If
		End If
		activityTrackerPanel.Update()
		addSegmentPanel.Update()

	End Sub

	Private Sub LoopLogGrid2()

		Dim dr As GridViewRow
		Dim gIndex As Integer = -1
		Dim skip As Integer = 0
		Dim err As String = ""

		For Each dr In GridView6.Rows

			If gIndex = -1 Then
				gIndex = 0
			End If

			'series 
			Dim lblHrsWorkedSeriesID As Label = DirectCast(GridView6.Rows(gIndex).FindControl("lblHrsWorkedSeriesID"), Label)
			pubSeries = lblHrsWorkedSeriesID.Text.Trim

			Dim lblDate As Label = DirectCast(GridView6.Rows(gIndex).FindControl("lblSchedDate"), Label)
			pubSchedDate = lblDate.Text.Trim

			'Start Time
			Dim lbl3 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox3"), TextBox)
			pubTransStartTime = lbl3.Text.Trim

			'End Time
			Dim lbl4 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox4"), TextBox)
			pubTransEndTime = lbl4.Text

			Dim startAmPm As String = pubTransStartTime.Substring(pubTransStartTime.Length - 2)

			'If lbl4.Text.Trim <> "" Then
			'	pubTransEndTime = pubSchedDate & " " & lbl4.Text.Trim

			'	Dim startAmPm As String = pubTransStartTime.Substring(pubTransStartTime.Length - 2)
			'	Dim endAmPm As String = pubTransEndTime.Substring(pubTransEndTime.Length - 2)

			'	If startAmPm = "PM" And endAmPm = "AM" Then
			'		Dim addDate As Date = Convert.ToDateTime(pubTransEndTime)
			'		addDate = addDate.AddDays(1)
			'		pubNewEndDate = addDate.ToString()

			'		pubTransEndTime = pubNewEndDate
			'	End If
			'Else
			'	pubTransEndTime = ""
			'End If

			'Reason
			Dim lbl5 As DropDownList = DirectCast(GridView6.Rows(gIndex).FindControl("DropDownList2"), DropDownList)
			pubTransReason = lbl5.Text.Trim

			If pubTransEndTime = "" Then
				ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Cannot save segment without end time!');", True)
				Exit Sub
			End If

			Dim pubStartDate As DateTime = pubTransStartTime
			Dim pubEndDate As DateTime = pubTransEndTime
			Dim lblStartDate As DateTime = LblActivityDate.Text & " " & lblStart.Text

			If pubEndDate < pubStartDate Then
				skip = 1
				ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "alert", "javascript: alert('Invalid end time!')", True)
				Exit Sub
			End If

			GetReasonNumber()

			UpdateActivityTrans()

			UpdateTimeMinHour()

			InsertIntoActivityMaster()
			'InsertIntoActivityMaster2()

			GetSeriesAdjustedFromTrans()

			'If pubSeriesAdjusted <> "" Then
			'	UpdateActivityTagADJ()
			'End If

			gIndex += 1

		Next

		DeleteActivityTrans()

		GridView6.Visible = True
		GridView6.DataBind()
		GridView4.Visible = True
		GridView4.SelectedIndex = -1
		GridView4.DataBind()

		GetPaidHoursActivity()

		If Not IsDBNull(dtPaidHours.Rows(0)("PaidHours")) Then
			totalHoursPaid.Text = dtPaidHours.Rows(0)("PaidHours")
		Else
			totalHoursPaid.Text = "0.0"
		End If

		If lblAccessLvl.Text <> "1" Then
			GetExcessHoursActivity()

			If Not IsDBNull(dtExcessHours.Rows(0)("ExcessHours")) Then
				totalHoursExcesspaid.Text = dtExcessHours.Rows(0)("ExcessHours")
			Else
				totalHoursExcesspaid.Text = "0.0"
			End If
		Else
			GetUnpaidHoursActivity()

			If Not IsDBNull(dtUnpaidHours.Rows(0)("UnpaidHours")) Then
				totalHoursUnpaid.Text = dtUnpaidHours.Rows(0)("UnpaidHours")
			Else
				totalHoursUnpaid.Text = "0.0"
			End If
		End If
		activityTrackerPanel.Update()
		addSegmentPanel.Update()
	End Sub

	Private Sub GetEndTime()
		Dim query As String

		query = "select * from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & Label35.Text & "' and SchedDate = '" & LblActivityDate.Text & "'"

		dtEndTime = cls.GetData(query)
	End Sub

	Private Sub UpdateTimeMinHour()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "update tbl_HRMS_Employee_Activity_Trans set TotalTimeMin = cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) where SeriesID = '" & pubSeries.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub UpdateActivityTagADJ()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity Set Activity_Tag = 'ADJ' where SeriesID = '" & pubSeriesAdjusted.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()


	End Sub

	Private Sub UpdateActivityTrans()

		Dim cmdUpdate As New SqlCommand

		If pubTransEndTime <> "" Then
			cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity_Trans set Start_Time = '" & pubTransStartTime.Trim & "', End_Time = '" & _
											pubTransEndTime.Trim & "', ReasonID = '" & pubTransReasonID.ToString.Trim & "', ReasonDesc = '" & pubTransReason.Trim & "' where SeriesID = '" & pubSeries.Trim & "'"
		Else
			cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity_Trans set Start_Time = '" & pubTransStartTime.Trim & "', End_Time = null , ReasonID = '" & pubTransReasonID.ToString.Trim & "', ReasonDesc = '" & pubTransReason.Trim & "' where SeriesID = '" & pubSeries.Trim & "'"
		End If


		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub GetSeriesAdjustedFromTrans()
		Dim query As String

		Dim dtPubSeriesAdj As New DataTable

		query = "select Series_Adjusted from dbo.tbl_HRMS_Employee_Activity_Trans (nolock) where SeriesID = '" & pubSeries.Trim & "'"

		dtPubSeriesAdj = cls.GetData(query)

		If IsDBNull(dtPubSeriesAdj.Rows(0)("Series_Adjusted")) Then
			pubSeriesAdjusted = ""
		Else
			pubSeriesAdjusted = dtPubSeriesAdj.Rows(0)("Series_Adjusted")
		End If

	End Sub

	Private Sub DropDownList3_Load(sender As Object, e As EventArgs) Handles DropDownList3.Load
		If Not IsPostBack Then
			DropDownList3.SelectedIndex = Convert.ToInt32(Date.Now.Month) - 1
		End If
	End Sub

	'Private Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList2.SelectedIndexChanged
	'    If Label35.Text <> "" Then
	'        GetSched()
	'        UpdateScheduleHrsWorked()
	'        GetHrsWorkedCutOff()
	'        GetPaidWorkedCutOff()
	'        GridView4.Visible = False
	'    End If
	'End Sub

	'Private Sub DropDownList3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList3.SelectedIndexChanged
	'    If Label35.Text <> "" Then
	'        GetSched()
	'        UpdateScheduleHrsWorked()
	'        GetHrsWorkedCutOff()
	'        GetPaidWorkedCutOff()
	'        GridView4.Visible = False
	'    End If
	'End Sub

	Private Sub DropDownList4_Load(sender As Object, e As EventArgs) Handles DropDownList4.Load
		If Not IsPostBack Then
			If Date.Now.Day <= 15 Then
				DropDownList4.SelectedIndex = 0
			ElseIf Date.Now.Day > 15 And Date.Now.Day < 30 Then
				DropDownList4.SelectedIndex = 1
			End If
		End If
	End Sub

	'Private Sub DropDownList4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList4.SelectedIndexChanged
	'    If Label35.Text <> "" Then
	'        GetSched()
	'        UpdateScheduleHrsWorked()
	'        GetHrsWorkedCutOff()
	'        GetPaidWorkedCutOff()
	'        GridView4.Visible = False
	'    End If
	'End Sub

	Private Sub BtnSaveSegment_Click(sender As Object, e As EventArgs) Handles BtnSaveSegment.Click

		'LoopSegmentChkTotalMinute()
		'LoopChkStartTime()
		'LoopChkEndTime()

		'If pubIfTotalSegmentMinutes = False And pubIfStartTimeSegment = False And pubIfEndTimeSegment = False Then
		If GridView4.Rows.Count > 0 Then
			LoopLogGrid()
		Else
			LoopLogGrid2()
		End If

		'End If


	End Sub

	Private Sub GetSegmentTimeDifference()

		'Dim ConnStr As String
		Dim sSql As String
		Dim i As Integer

		'ConnStr = ConfigurationManager.ConnectionStrings("MIS_ALTIConnectionString").ConnectionString.ToString()


		sqlConn.Open()
		Try
			i = 0

			sSql = "Select datediff(minute,'" & pubTransStartTime.Trim & "','" & pubTransEndTime.Trim & "') as timedifference"

			Dim MySqlCmd As New SqlCommand(sSql, sqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then
				While mReader.Read()

					pubTotalSegmentMinutes += Val(mReader("timedifference"))

				End While

			End If

		Catch ex As Exception

		Finally
			sqlConn.Close()
		End Try

	End Sub

	Private Sub LoopSegmentChkTotalMinute()

		Dim dr As GridViewRow
		Dim gIndex As Integer = -1

		pubTotalSegmentMinutes = 0
		For Each dr In GridView6.Rows

			If gIndex = -1 Then
				gIndex = 0
			End If

			'Start Time
			Dim lbl3 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox3"), TextBox)
			pubTransStartTime = Convert.ToDateTime(lbl3.Text.Trim)

			'End Time
			Dim lbl4 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox4"), TextBox)
			pubTransEndTime = Convert.ToDateTime(lbl4.Text.Trim)

			Session("SessionEndDate") = pubTransEndTime

			GetSegmentTimeDifference()

			gIndex += 1

		Next

		Try

			If Session("SessionEndDate").ToString.Trim <> "" Then
				If pubTotalSegmentMinutes > 0 Then


					If Val(Session("SessionMinute")) <> pubTotalSegmentMinutes Then
						pubIfTotalSegmentMinutes = True
						ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
						"javascript:alertify.alert('Total Minute(s) should be equal to - " & Session("SessionMinute").ToString & "...!');", True)
						Exit Sub
					Else
						pubIfTotalSegmentMinutes = False
					End If

				Else
					pubIfTotalSegmentMinutes = True
					ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
					"javascript:alertify.alert('Invalid Minute(s) should not be less than 0...!');", True)
					Exit Sub
				End If
			End If

		Catch ex As Exception

		End Try

	End Sub

	Private Sub LoopChkStartTime()

		Dim gIndex As Integer = -1

		If gIndex = -1 Then
			gIndex = 0
		End If

		'Start Time
		Dim lbl3 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox3"), TextBox)
		pubTransStartTime = lbl3.Text.Trim

		Try

			If DateTime.Compare(pubTransStartTime.Trim, Session("SessionStartDate").ToString) <> 0 Then
				'If pubTransStartTime.Trim <> Session("SessionStartDate").ToString Then
				pubIfStartTimeSegment = True
				ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
				"javascript:alertify.alert('Start Time should be equal to - " & Session("SessionStartDate").ToString & "...!');", True)
				Exit Sub
			Else
				pubIfStartTimeSegment = False
			End If
		Catch ex As Exception

		End Try

	End Sub

	Private Sub LoopChkEndTime()

		Dim dr As GridViewRow
		Dim gIndex As Integer = -1
		For Each dr In GridView6.Rows

			If gIndex = -1 Then
				gIndex = 0
			End If

			'End Time
			Dim lbl4 As TextBox = DirectCast(GridView6.Rows(gIndex).FindControl("TextBox4"), TextBox)
			pubTransEndTime = lbl4.Text.Trim

			gIndex += 1

		Next

		Try

			If Session("SessionEndDate").ToString.Trim <> "" Then
				If DateTime.Compare(pubTransEndTime.Trim, Session("SessionEndDate").ToString) <> 0 Then
					'If pubTransEndTime.Trim <> Session("SessionEndDate").ToString Then
					pubIfEndTimeSegment = True
					ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
					"javascript:alertify.alert('End Time should be equal to - " & Session("SessionEndDate").ToString & "...!');", True)
					Exit Sub
				Else
					pubIfEndTimeSegment = False
				End If
			End If
		Catch ex As Exception

		End Try

	End Sub

	Private Sub GetPaidHoursSummary()

		Dim query As String

		query = "select SUM(convert(decimal(10,2),TotalTimeHour,10)) as PaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & _
							 "' and SchedDate = '" & lblSchedDate.Text.Trim & "' and Activity_Tag not in ('ADJ')"

		dtPaidHours = cls.GetData(query)

	End Sub

	Private Sub GetLogInTimeSummary()
		Dim query As String

		query = "select top 1 a.SchedDate, a.Start_Time, a.ReasonID from tbl_HRMS_Employee_Activity a (nolock) " & _
				  "left join tbl_HRMS_Employee_Schedule b (nolock) on b.SchedDate = a.SchedDate " & _
				  "where a.LoginID = '" & Label35.Text.Trim & "' and a.SchedDate = '" & lblSchedDate.Text.Trim & "' and " & _
				  "a.ReasonID = '1' order by a.Start_Time asc"

		dtLoginTimeSummary = cls.GetData(query)
		pubLoginTimeSummary = dtLoginTimeSummary.Rows(0)("Start_Time")
	End Sub

	Private Sub GetLogOutTimeSummary()
		Dim query As String

		query = "select top 1 a.SchedDate, a.End_Time, a.ReasonID from tbl_HRMS_Employee_Activity a (nolock) " & _
				  "left join tbl_HRMS_Employee_Schedule b (nolock) on b.SchedDate = a.SchedDate " & _
				  "where a.LoginID = '" & Label35.Text.Trim & "' and a.SchedDate = '" & lblSchedDate.Text.Trim & "' and " & _
				  "a.ReasonID in ('14', '16') order by a.End_Time desc"

		dtLogoutTimeSummary = cls.GetData(query)
		If Not IsDBNull(dtLogoutTimeSummary.Rows(0)("End_Time")) Then
			pubLogoutTimeSummary = dtLogoutTimeSummary.Rows(0)("End_Time")
		Else
			pubLogoutTimeSummary = "Null"
		End If
	End Sub

	Private Sub GetTotalHoursSummary()
		Dim query As String

		query = "select CAST(DATEDIFF(MINUTE,'" & pubLoginTimeSummary.Trim & "','" & pubLogoutTimeSummary.Trim & "') as decimal) / 60 as TotalHours"

		dtTotalHoursSummary = cls.GetData(query)
		pubTotalHoursSummary = dtTotalHoursSummary.Rows(0)("TotalHours")
	End Sub

	Private Sub GetPaidHoursActivity()

		Dim query As String

		If lblAccessLvl.Text <> "1" Then
			query = "select case when SUM(convert(decimal(10,2),TotalTimeHour,10)) >= 9 then 8 else SUM(convert(decimal(10,2),TotalTimeHour,10)) - 1 end as PaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & LblActivityDate.Text.Trim & "' and IsPaid = 'YES'"
		Else
			query = "select SUM(convert(decimal(10,2),TotalTimeHour,10)) as PaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & _
							"' and SchedDate = '" & LblActivityDate.Text.Trim & "' and IsPaid = 'YES' and EEApproval is not null"
		End If

		dtPaidHours = cls.GetData(query)

	End Sub

	Private Sub GetPaidSummary()

		Dim query As String

		If lblAccessLvl.Text <> "1" Then
			query = "select case when SUM(convert(decimal(10,2),TotalTimeHour,10)) >= 9 then 8 else SUM(convert(decimal(10,2),TotalTimeHour,10)) - 1 end as PaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & schedDate.Trim & "' and IsPaid = 'YES'"
		Else
			query = "select SUM(convert(decimal(10,2),TotalTimeHour,10)) as PaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & _
							"' and SchedDate = '" & schedDate.Trim & "' and IsPaid = 'YES' and EEApproval is not null"
		End If

		dtPaidHours = cls.GetData(query)

	End Sub

	Private Sub GetLogInTime()
		Dim query As String

		query = "select top 1 a.SchedDate, a.Start_Time, a.ReasonID from tbl_HRMS_Employee_Activity a (nolock) " & _
				  "left join tbl_HRMS_Employee_Schedule b (nolock) on b.SchedDate = a.SchedDate " & _
				  "where a.LoginID = '" & Label35.Text.Trim & "' and a.SchedDate = '" & LblActivityDate.Text.Trim & "' and " & _
				  "a.ReasonID = '1' order by a.Start_Time asc"

		dtLoginTime = cls.GetData(query)

	End Sub

	Private Sub GetLogOutTime()
		Dim query As String

		query = "select top 1 a.SchedDate, a.End_Time, a.ReasonID from tbl_HRMS_Employee_Activity a (nolock) " & _
				  "left join tbl_HRMS_Employee_Schedule b (nolock) on b.SchedDate = a.SchedDate " & _
				  "where a.LoginID = '" & Label35.Text.Trim & "' and a.SchedDate = '" & LblActivityDate.Text.Trim & "' and " & _
				  "a.ReasonID in ('14', '16') order by a.End_Time desc"

		dtLogoutTime = cls.GetData(query)

	End Sub

	Private Sub GetTotalHours()
		Dim query As String

		query = "select CAST(DATEDIFF(MINUTE,'" & pubLoginTime.Trim & "','" & pubLogoutTime.Trim & "') as decimal) / 60 as TotalHours"

		dtTotalHours = cls.GetData(query)
	End Sub

	Private Sub GetExcessHoursActivity()

		Dim query As String

		query = "select Case when SUM(convert(decimal(10,2),TotalTimeHour,10)) >= 9 then SUM(convert(decimal(10,2),TotalTimeHour,10)) - 9 else 0.0 end as ExcessHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & LblActivityDate.Text.Trim & "' and IsPaid = 'YES'"

		dtExcessHours = cls.GetData(query)

	End Sub

	Private Sub GetUnpaidHoursActivity()
		Dim query As String

		query = "select SUM(convert(decimal(10,2),TotalTimeHour,10)) as UnpaidHours from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & Label35.Text.Trim & _
							 "' and SchedDate = '" & LblActivityDate.Text.Trim & "' and IsPaid = 'No'"

		dtUnpaidHours = cls.GetData(query)
	End Sub

	Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
		If Label35.Text <> "" Then
			GetSched()

			UpdateScheduleHrsWorked()
			GetHrsWorkedCutOff()
			GetPaidWorkedCutOff()
			DeleteActivityTrans()
			GridView4.Visible = False
			schedulePanel.Update()
			activityTrackerPanel.Update()
		End If

	End Sub

	Private Sub btnAddSlot_Click(sender As Object, e As EventArgs) Handles btnAddSlot.Click
		If GridView4.SelectedValue IsNot Nothing Then
			SaveCurrentActivityTrans()
			InsertIntoActivityTransSegment()
			GridView6.DataBind()
			GridView6.Visible = True
		Else
			InsertIntoActivityTransSegment2()
			GridView6.DataBind()
			GridView6.Visible = True
		End If
	End Sub

	Private Sub GetLate()
		Dim query As String

		query = "select * from tbl_HRMS_Employee_Activity where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & LblActivityDate.Text.Trim & "' and ReasonID in ('1', '2') order by Start_Time"

		dtActLate = cls.GetData(query)

		Dim query2 As String

		query2 = "select * from tbl_HRMS_Employee_Schedule where LoginID = '" & Label35.Text.Trim & "' and SchedDate = '" & LblActivityDate.Text.Trim & "' order by SchedDate"

		dtSchedLate = cls.GetData(query2)
	End Sub

	Private Sub GridView4_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView4.RowDataBound
		If e.Row.RowType = DataControlRowType.DataRow Then
			If e.Row.RowIndex = 0 Then
				GetLate()

				Dim schedin As Date = Convert.ToDateTime(dtSchedLate.Rows(0)("SchedIN"))
				schedin = schedin.AddSeconds(-1 * schedin.Second)
				Dim todayin As Date = Convert.ToDateTime(dtActLate.Rows(0)("Start_Time"))
				todayin = todayin.AddSeconds(-1 * todayin.Second)

				If todayin > schedin Then
					e.Row.ForeColor = Drawing.Color.Red
					e.Row.Style.Add("font-weight", "bold")
				End If
			End If

		End If
	End Sub
End Class