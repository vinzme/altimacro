﻿Imports System.Web.Services

Public Class ICP
	Inherits System.Web.UI.Page
	Dim pubUser As String
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		'If Session("userID") = "" Then
		'	Response.Redirect("LoginTL.aspx")
		'Else

		'End If
		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/ICP.aspx"
			Response.Redirect("~/Home.aspx")
		End If
		'pubUser = "devtest"
	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Function ICP_TL() As String
		Dim pubUser As String = HttpContext.Current.Session("userID")

		Dim strLink = "http://172.21.5.174/Alti-ICP/TL.php?user=" & pubUser

		Dim encodedBytes As Byte() = Encoding.UTF8.GetBytes(strLink)

		Dim base64EncodedText = Convert.ToBase64String(encodedBytes)

		Return strLink

	End Function

End Class