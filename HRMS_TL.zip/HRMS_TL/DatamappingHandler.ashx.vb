﻿Imports System.Web
Imports System.Web.Services
Imports System.Data.OleDb
Imports System.IO

Public Class DatamappingHandler
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "text/plain"

        Dim dirFullPath As String = HttpContext.Current.Server.MapPath("~/flatfiles/")
        Dim files As String()
        Dim numFiles As Integer
        files = System.IO.Directory.GetFiles(dirFullPath)
        numFiles = files.Length
        numFiles = numFiles + 1
        Dim str_image As String = ""
        Dim fileName As String
        Dim fileExtension As String
        Dim file_name As String = Trim(Now.Date.Year & Now.Date.Day & Now.Date.Hour.ToString & Now.Date.Minute.ToString & Now.Date.Millisecond.ToString)
        Dim pathToSave_100 As String
        For Each s As String In context.Request.Files
            Dim file As HttpPostedFile = context.Request.Files(s)
            '  int fileSizeInBytes = file.ContentLength;
            fileName = file.FileName
            fileExtension = file.ContentType

            If Not String.IsNullOrEmpty(fileName) Then
                fileExtension = Path.GetExtension(fileName)
                str_image = Convert.ToString(file_name) & fileExtension
                pathToSave_100 = HttpContext.Current.Server.MapPath("~/flatfiles/") & str_image
                file.SaveAs(pathToSave_100)
            End If
        Next



        context.Response.Write(file_name & fileExtension)


        'context.Response.ContentType = "text/plain"

        'Dim dirFullPath As String = HttpContext.Current.Server.MapPath("~/flatfiles/")
        'Dim files As String()
        'Dim numFiles As Integer
        'files = System.IO.Directory.GetFiles(dirFullPath)
        'numFiles = files.Length
        'numFiles = numFiles + 1

        'Dim str_image As String = ""
        'Dim fileName As String
        'Dim fileExtension As String
        'Dim file_name As String = Trim(Now.Date.Year & Now.Date.Day & Now.Date.Hour.ToString & Now.Date.Minute.ToString & Now.Date.Millisecond.ToString)
        'Dim pathToSave_100 As String
        'For Each s As String In context.Request.Files
        '    Dim file As HttpPostedFile = context.Request.Files(s)
        '    '  int fileSizeInBytes = file.ContentLength;
        '    fileName = file.FileName
        '    fileExtension = file.ContentType

        '    If Not String.IsNullOrEmpty(fileName) Then
        '        fileExtension = Path.GetExtension(fileName)
        '        str_image = Convert.ToString(file_name) & fileExtension
        '        pathToSave_100 = HttpContext.Current.Server.MapPath("~/flatfiles/") & str_image
        '        file.SaveAs(pathToSave_100)
        '    End If
        'Next
        'Dim ds As New DataSet
        'Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;" & "Data Source=" & pathToSave_100 & ";" & "Extended Properties=Excel 12.0;"
        'Dim excelData As New OleDbDataAdapter("SELECT * FROM [Sheet1$]", connectionString)
        'excelData.TableMappings.Add("Table", "ExcelSheet")
        'excelData.Fill(ds)
        'Dim x As Integer
        'x = 0
        'Dim dt As New DataTable
        'dt = ds.Tables(0)
        'Dim myitems As String
        'Do Until x = dt.Columns.Count
        '    myitems = myitems & dt.Columns(x).ColumnName & "~"
        '    x = x + 1
        'Loop


        'context.Response.Write(file_name & fileExtension & " * " & myitems)


    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class