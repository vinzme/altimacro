﻿Imports System.Data.SqlClient
Imports System.Web.Services
Imports HRFormsClass
Imports iTextSharp.text.pdf
Imports System.IO
Imports System.Net
Imports iTextSharp.text.pdf.parser
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports System.Data
Imports System.Web
Imports System.Diagnostics
'Imports PDF_Play.LocTextExtraction

'Imports System.Net

Public Class RequestForms
	Inherits System.Web.UI.Page

	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String
	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String
	Dim employeeAccess As String

	Dim pubUserMode As String
	Dim ExpiredMinutes As Integer

	Dim pubUserStatus As String
	Dim pubUserStatusTag As String
	Dim pubServerDateTime As String
	Dim pubActivityID As Integer
	Dim pubIdleTimeInserted As Boolean = False
	Dim pubIdleMinutes As Integer = 0
	Dim pubClickOKIdle As Boolean = False
	Dim pubAspectNRStatus As String

	Dim dtChkHoliday As DataTable
	Dim dtChkLeave As DataTable
	Dim dtChkLeaveExisting As DataTable
	Dim dtHoliday_spcW As New DataTable
	Dim dtHoliday_reg As New DataTable
	Dim dtHolidays As New DataTable
	Dim dtLastActivity As New DataTable
	Dim dtNews As New DataTable

	Dim fullName As String = ""

	Dim dtLogin As DateTime
	Dim gSelectedDate As String

	Dim totaltime As Integer = 0

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/RequestForms.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		GetEmpInfo()

		If Not Page.IsPostBack Then
			CreateNewsPanel()
			GetLastActivity()

			'If dtLastActivity.Rows(0)("reasonid") = 14 Or
			'    dtLastActivity.Rows(0)("reasonid") = 16 Then

			'    Response.Redirect("Home.aspx")
			'Else

			If dtEmp.Rows.Count > 0 Then
				'lblUser.Text = pubUser

				employeeID = dtEmp.Rows(0)("EmpID")
				employeeName = dtEmp.Rows(0)("EmpName")
				employeeSupervisor = dtEmp.Rows(0)("MngrName")
				employeeDepartment = dtEmp.Rows(0)("DeptName")
				'employeeLocation = dtEmp.Rows(0)("Location")
				employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
				employeeApprover = dtEmp.Rows(0)("MngrName")
				employeeAccess = dtEmp.Rows(0)("AccessLevel")

				empID.Text = employeeID
				empName.Text = employeeName
				supervisor.Text = employeeSupervisor
				dept.Text = employeeDepartment
				'Loc.Text = employeeLocation
				doj.Text = employeeDoj

				If employeeAccess <> "4" And employeeAccess <> "22" Then
					liCompany.Visible = False
				Else
					liCompany.Visible = True
				End If
			End If
		End If
		'End If
	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity where loginid = '" & pubUser.Trim & "' order by seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "'"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub ProcessNews()
		Dim sql As String = ""
		sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"
		dtNews = cls.GetData(sql)
	End Sub
	Private Sub CreateNewsPanel()
		Dim str As String = ""

		ProcessNews()
		If dtNews.Rows.Count > 0 Then
			For x As Integer = 0 To dtNews.Rows.Count - 1
				str &= "<li class='news-item'>"
				str &= "<table cellpadding='4'>"
				str &= "<tr>"
				str &= "<td>"
				str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
				str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a onclick = ""window.open('" & dtNews.Rows(x)("imgNews") & "', '_Parent', 'toolbar=0,scrollbars=0,resizable=0,top=0,left=20%,width=800,height=700');"" href='#'>Read more...</a></td>"
				str &= "<tr>"
				str &= "</table>"
				str &= "</li>"
			Next

			lt1.Text = str

		End If

	End Sub

	<WebMethod>
	Public Shared Function ViewForm(strForm As String, strEmpID As String) As Forms
		Dim cls As New clsConnection
		Dim dtEmpInfo As New DataTable
		Dim dtEmployerInfo As New DataTable
		Dim dtCompanyInfo As New DataTable
		Dim dtSignature As New DataTable
		Dim dtPersonalInfo As New DataTable
		Dim dtConfiInfo As New DataTable
		Dim dtDepInfo As New DataTable
		Dim dtPayInfo As New DataTable
		Dim dtPayDeducInfo As New DataTable

		Dim Forms As New Forms

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & strEmpID.Trim & "' and AccessLevel is not null"

		dtEmpInfo = cls.GetData(qry)

		Dim slctCompany As String = ""

		slctCompany = "select * from dbo.tbl_HRMS_CompanyDetails"

		dtCompanyInfo = cls.GetData(slctCompany)

		Dim slctEmployer As String = ""

		slctEmployer = "select * from tbl_HRMS_EmployerDetails"

		dtEmployerInfo = cls.GetData(slctEmployer)

		Dim qry2 As String = ""

		qry2 = "select a.* from tbl_HRMS_Employee_PersonalInformation a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.NTID = '" & strEmpID & "'"

		dtPersonalInfo = cls.GetData(qry2)

		Dim qry3 As String = ""

		qry3 = "select a.* from tbl_HRMS_Employee_ConfidentialInfo a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.NTID = '" & strEmpID & "'"

		dtConfiInfo = cls.GetData(qry3)

		Dim qry4 As String = ""

		qry4 = "select a.* from tbl_HRMS_Employee_DependentDetails a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.NTID = '" & strEmpID & "'"

		dtDepInfo = cls.GetData(qry4)

		Dim qry5 As String = ""

		qry5 = "select top 1 a.* from tbl_HRMS_PayslipMaster a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.NTID = '" & strEmpID & "'"

		dtPayInfo = cls.GetData(qry5)

		Dim qry6 As String = ""

		qry6 = "select top 1 a.* from tbl_hrms_Adjustments a join tbl_HRMS_EmployeeMaster b on a.payid = b.NTID where b.NTID = '" & strEmpID & "'"

		dtPayDeducInfo = cls.GetData(qry6)

		Dim qry7 As String

		qry7 = "select * from dbo.tbl_HRMS_SignatureMaster a join tbl_HRMS_EmployeeMaster b on a.payid = b.NTID where b.NTID = '" & strEmpID & "' and Status = 'Active'"

		dtSignature = cls.GetData(qry7)

		If dtEmpInfo.Rows.Count > 0 Then
			Try
				Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")

				IsValidPdf(HttpContext.Current.Server.MapPath("~/PDF Template/" & strForm & ".pdf"))

				Dim pdfReader As New PdfReader(HttpContext.Current.Server.MapPath("~/PDF Template/" & strForm & ".pdf"))

				Dim testFile = HttpContext.Current.Server.MapPath("~/PDF Template/" & strForm & ".pdf")
				Dim imageFileName As String = "http://hrms4103.cloudapp.net/Image/Base64?id=sainibha"

				Using stream As New FileStream(String.Concat(HttpContext.Current.Server.MapPath("~/PDF Export/"), filename), FileMode.Create)
					Dim pdfStamper As New PdfStamper(pdfReader, stream)

					Dim formFields As AcroFields = pdfStamper.AcroFields
					Dim item As New AcroFields.Item

					If strForm = "2316" Then
						'Name
						formFields.SetField("untitled8", UCase(dtEmpInfo.Rows(0)("EmpName")))

						'Employee Signature
						formFields.SetField("untitled100", UCase(dtEmpInfo.Rows(0)("EmpName")))
						formFields.SetField("untitled104", UCase(dtEmpInfo.Rows(0)("EmpName")))

						'Employer Signature
						formFields.SetField("untitled99", UCase("Saini, Bhartendu"))
						item = formFields.GetFieldItem("untitled99")
						item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

						Try
							Dim client = New Http.HttpClient()
							Dim response = client.GetAsync(imageFileName).Result

							Dim NewsJson = response.Content.ReadAsStringAsync()
							NewsJson.Wait()

							Dim data As Byte()
							data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
							Dim ImageStream As MemoryStream = New MemoryStream(data)

							Dim sig1img As iTextSharp.text.Image

							Try
								sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
								Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("untitled99")
								Dim test As AcroFields.FieldPosition = sig1position(0)
								Dim left, right, top, bottom As Single
								left = test.position.Left
								right = test.position.Right
								top = test.position.Top
								bottom = test.position.Bottom - 10
								sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
								sig1img.ScalePercent(15.0F)
							Catch ex As Exception

							End Try

							Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
							contentByte.AddImage(sig1img)
						Catch ex As Exception

						End Try

						'Employer's Name
						formFields.SetField("untitled47", "ALTISOURCE BUSINESS SOLUTIONS CORP.")

						'Employer's Address
						formFields.SetField("untitled48", "TWO E-COM CENTER, MALL OF ASIA COMPLEX, PASAY CITY")
						formFields.SetFieldProperty("untitled48", "textsize", 6.0F, Nothing)

						'Employer's Zip
						formFields.SetField("untitled49", "1300")

						'Main Employer Checked
						formFields.SetField("untitled115", "X")

						If dtPersonalInfo.Rows.Count > 0 Then
							'Address
							formFields.SetField("untitled9", UCase(dtPersonalInfo.Rows(0)("HouseNumber") & " " & dtPersonalInfo.Rows(0)("StreetName") & " " & dtPersonalInfo.Rows(0)("Barangay") & " " & dtPersonalInfo.Rows(0)("Town") & " " & dtPersonalInfo.Rows(0)("City")))

							'Zip
							formFields.SetField("untitled13", UCase(dtPersonalInfo.Rows(0)("ZipCode")))

							'DOB
							Dim dob As Date = dtPersonalInfo.Rows(0)("DOB")
							Dim intMonth As Integer = Month(dob)
							Dim intDay As Integer = Day(dob)
							Dim intYear As Integer = Year(dob)
							formFields.SetField("untitled21", intMonth)
							formFields.SetField("untitled22", intDay)
							formFields.SetField("untitled23", intYear)

							'Telphone Number
							formFields.SetField("untitled16", UCase("+" & dtPersonalInfo.Rows(0)("MobileAreaCode") & " " & dtPersonalInfo.Rows(0)("MobileNumber")))
						End If

						If dtEmployerInfo.Rows.Count > 0 Then
							Dim strTIN As String = dtEmployerInfo.Rows(0)("TIN")

							formFields.SetField("untitled43", strTIN.Substring(0, 3))
							formFields.SetField("untitled44", strTIN.Substring(4, 3))
							formFields.SetField("untitled45", strTIN.Substring(8, 3))
							formFields.SetField("untitled46", "000")

						End If

						If dtPayInfo.Rows.Count > 0 Then
							'Non-Tax
							Dim intspchld As Double = dtPayInfo.Rows(0)("spchld")
							Dim intrest_spday As Double = dtPayInfo.Rows(0)("rest_spday")
							Dim intreg_hld As Double = dtPayInfo.Rows(0)("reg_hld")
							Dim intrestday_reghld As Double = dtPayInfo.Rows(0)("restday_reghld")

							Dim intreg_ot As Double = dtPayInfo.Rows(0)("reg_ot")
							Dim intrest_ot As Double = dtPayInfo.Rows(0)("rest_ot")

							Dim intnd_reg As Double = dtPayInfo.Rows(0)("nd_reg")
							Dim intnd_rest As Double = dtPayInfo.Rows(0)("nd_rest")
							Dim intnd_hrd As Double = dtPayInfo.Rows(0)("nd_hrd")
							Dim intnd_spc As Double = dtPayInfo.Rows(0)("nd_spc")

							'Dim intHolidayPay As Double = intspchld + intrest_spday + intreg_hld + intrestday_reghld
							'Dim intOTPay As Double = intreg_ot + intrest_ot
							'Dim intNDPay As Double = intnd_reg + intnd_rest + intnd_hrd + intnd_spc

							Dim strHolidayPay As String = Format(intspchld + intrest_spday + intreg_hld + intrestday_reghld, "0.00").ToString()
							Dim strOTPay As String = Format(intreg_ot + intrest_ot, "0.00").ToString()
							Dim strNDPay As String = Format(intnd_reg + intnd_rest + intnd_hrd + intnd_spc, "0.00").ToString()

							formFields.SetField("untitled69", "Php " & dtPayInfo.Rows(0)("monthly"))
							formFields.SetField("untitled70", "Php " & strHolidayPay)
							formFields.SetField("untitled71", "Php " & strOTPay)
							formFields.SetField("untitled72", "Php " & strNDPay)



							Dim strTotalNonTax As String = Format(Convert.ToDouble(dtPayInfo.Rows(0)("monthly")) + Convert.ToDouble(strHolidayPay) + Convert.ToDouble(strOTPay) + Convert.ToDouble(strNDPay), "0.00").ToString()

							formFields.SetField("untitled78", "Php " & strTotalNonTax)

							'------------------------------------------------------------------------------------------------------------------------------

							Dim strStatus As String = dtPayInfo.Rows(0)("tax_status")

							If InStr(strStatus, "S") > 0 Then
								formFields.SetField("untitled24", "X")
							ElseIf InStr(strStatus, "ME") > 0 Then
								formFields.SetField("untitled26", "X")
							End If
						End If

						If dtPayDeducInfo.Rows.Count > 0 Then
							Dim intHDMF As Double = 0.0
							Dim intPH As Double = 0.0
							Dim intSSS As Double = 0.0

							For deduct As Integer = 0 To dtPayDeducInfo.Rows.Count - 1
								If InStr(dtPayDeducInfo.Rows(deduct)("deduct_desc"), "HDMF") > 0 Then
									intHDMF = dtPayDeducInfo.Rows(deduct)("deduct_cost")
								End If
								If InStr(dtPayDeducInfo.Rows(deduct)("deduct_desc"), "PhilHealth") > 0 Then
									intPH = dtPayDeducInfo.Rows(deduct)("deduct_cost")
								End If
								If InStr(dtPayDeducInfo.Rows(deduct)("deduct_desc"), "Social Security") > 0 Then
									intSSS = dtPayDeducInfo.Rows(deduct)("deduct_cost")
								End If
							Next deduct

							Dim strDeductPay As String = (intHDMF + intPH + intSSS).ToString()

							formFields.SetField("untitled76", "Php " & strDeductPay)

						End If

						If dtConfiInfo.Rows.Count > 0 Then
							'Tax ID No.
							Dim strTIN As String = dtConfiInfo.Rows(0)("TIN")
							Dim strTIN1 As String = strTIN.Substring(0, 3)
							Dim strTIN2 As String = strTIN.Substring(4, 3)
							Dim strTIN3 As String = strTIN.Substring(8, 3)
							formFields.SetField("untitled4", strTIN1)
							formFields.SetField("untitled5", strTIN2)
							formFields.SetField("untitled6", strTIN3)
							formFields.SetField("untitled7", "000")

						End If
						If dtDepInfo.Rows.Count > 0 Then
							'Dependent (Child)
							Dim dateDOB1 As Date = Nothing
							Dim monthDOB1 As String = ""
							Dim dayDOB1 As String = ""
							Dim yearDOB1 As String = ""
							If Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")) Then
								dateDOB1 = dtDepInfo.Rows(0)("Child1DOB")
								monthDOB1 = Convert.ToInt32(Month(dateDOB1)).ToString()
								dayDOB1 = Convert.ToInt32(Day(dateDOB1)).ToString()
								yearDOB1 = Convert.ToInt32(Year(dateDOB1)).ToString()
							End If

							Dim dateDOB2 As Date = Nothing
							Dim monthDOB2 As String = ""
							Dim dayDOB2 As String = ""
							Dim yearDOB2 As String = ""
							If Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")) Then
								dateDOB2 = dtDepInfo.Rows(0)("Child2DOB")
								monthDOB2 = Convert.ToInt32(Month(dateDOB2)).ToString()
								dayDOB2 = Convert.ToInt32(Day(dateDOB2)).ToString()
								yearDOB2 = Convert.ToInt32(Year(dateDOB2)).ToString()
							End If

							Dim dateDOB3 As Date = Nothing
							Dim monthDOB3 As String = ""
							Dim dayDOB3 As String = ""
							Dim yearDOB3 As String = ""
							If Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")) Then
								dateDOB3 = dtDepInfo.Rows(0)("Child3DOB")
								monthDOB3 = Convert.ToInt32(Month(dateDOB3)).ToString()
								dayDOB3 = Convert.ToInt32(Day(dateDOB3)).ToString()
								yearDOB3 = Convert.ToInt32(Year(dateDOB3)).ToString()
							End If
							'Name
							formFields.SetField("untitled17", UCase(dtDepInfo.Rows(0)("Child1Name")))
							formFields.SetField("untitled18", UCase(dtDepInfo.Rows(0)("Child2Name")))
							formFields.SetField("untitled19", UCase(dtDepInfo.Rows(0)("Child3Name")))
							'Month
							formFields.SetField("untitled29", monthDOB1)
							formFields.SetField("untitled30", monthDOB2)
							formFields.SetField("untitled31", monthDOB3)
							'Day
							formFields.SetField("untitled33", dayDOB1)
							formFields.SetField("untitled34", dayDOB2)
							formFields.SetField("untitled35", dayDOB3)
							'Year
							formFields.SetField("untitled37", yearDOB1)
							formFields.SetField("untitled38", yearDOB2)
							formFields.SetField("untitled39", yearDOB3)

						End If

						'Date Signed & Date Issued
						Dim dateToday As Date = Date.Now
						Dim monthToday As Integer = Month(dateToday)
						Dim dayToday As Integer = Day(dateToday)
						Dim yearToday As Integer = Year(dateToday)

						formFields.SetField("untitled112", monthToday)
						formFields.SetField("untitled113", monthToday)
						formFields.SetField("untitled114", monthToday)

						formFields.SetField("untitled107", dayToday)
						formFields.SetField("untitled110", dayToday)
						formFields.SetField("untitled111", dayToday)

						formFields.SetField("untitled106", yearToday)
						formFields.SetField("untitled109", yearToday)
						formFields.SetField("untitled108", yearToday)

					ElseIf strForm = "1902" Then

						If dtConfiInfo.Rows.Count > 0 Then
							Dim strTin As String = dtConfiInfo.Rows(0)("TIN")

							formFields.SetField("paytin1", strTin.Substring(0, 3))
							formFields.SetField("paytin2", strTin.Substring(4, 3))
							formFields.SetField("paytin3", strTin.Substring(8, 3))
						End If

						formFields.SetField("lastname", dtEmpInfo.Rows(0)("EmpName"))
						formFields.SetField("untitled7", IIf(IsDBNull(dtEmpInfo.Rows(0)("Alias")), dtEmpInfo.Rows(0)("Alias"), ""))

						If dtEmpInfo.Rows(0)("Gender") = "M" Or dtEmpInfo.Rows(0)("Gender") = "Male" Then
							formFields.SetField("untitled3", "X")
						Else
							formFields.SetField("untitled4", "X")
						End If

						If dtPersonalInfo.Rows.Count > 0 Then
							Dim dob As Date = dtPersonalInfo.Rows(0)("DOB")
							Dim intMonth As Integer = Month(dob)
							Dim intDay As Integer = Day(dob)
							Dim intYear As Integer = Year(dob)

							formFields.SetField("untitled8", intMonth)
							formFields.SetField("untitled10", intDay)
							formFields.SetField("untitled9", intYear)

							formFields.SetField("untitled30", dtPersonalInfo.Rows(0)("HouseNumber"))
							formFields.SetField("untitled31", dtPersonalInfo.Rows(0)("StreetName"))
							formFields.SetField("untitled32", dtPersonalInfo.Rows(0)("City"))
							formFields.SetField("untitled33", dtPersonalInfo.Rows(0)("Town"))
							formFields.SetField("untitled34", dtPersonalInfo.Rows(0)("Barangay"))
							formFields.SetField("untitled35", dtPersonalInfo.Rows(0)("ZipCode"))
						End If

						If dtDepInfo.Rows.Count > 0 Then
							formFields.SetField("untitled12", dtDepInfo.Rows(0)("MothersName"))
							formFields.SetField("untitled14", dtDepInfo.Rows(0)("FathersName"))

							formFields.SetField("deplastname01", dtDepInfo.Rows(0)("Child1Name"))
							If Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")) Then
								Dim dobChild1 As Date = dtDepInfo.Rows(0)("Child1DOB")

								formFields.SetField("dobmonth01", Month(dobChild1))
								formFields.SetField("dobday01", Day(dobChild1))
								formFields.SetField("dobyear01", Year(dobChild1))
							End If

							formFields.SetField("deplastname02", dtDepInfo.Rows(0)("Child2Name"))
							If Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")) Then
								Dim dobChild2 As Date = dtDepInfo.Rows(0)("Child2DOB")

								formFields.SetField("dobmonth02", Month(dobChild2))
								formFields.SetField("dobday02", Day(dobChild2))
								formFields.SetField("dobyear02", Year(dobChild2))
							End If

							formFields.SetField("deplastname03", dtDepInfo.Rows(0)("Child3Name"))
							If Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")) Then
								Dim dobChild3 As Date = dtDepInfo.Rows(0)("Child3DOB")

								formFields.SetField("dobmonth03", Month(dobChild3))
								formFields.SetField("dobday03", Day(dobChild3))
								formFields.SetField("dobyear03", Year(dobChild3))
							End If
						End If

						formFields.SetField("untitled87", dtEmpInfo.Rows(0)("EmpName"))

						If dtEmployerInfo.Rows.Count > 0 Then
							Dim strTIN As String = dtEmployerInfo.Rows(0)("TIN")

							formFields.SetField("untitled88", strTIN.Substring(0, 3))
							formFields.SetField("untitled89", strTIN.Substring(4, 3))
							formFields.SetField("untitled90", strTIN.Substring(8, 3))
							formFields.SetField("untitled91", "000")

							formFields.SetField("untitled97", dtEmployerInfo.Rows(0)("Name"))
						End If

						If dtCompanyInfo.Rows.Count > 0 Then
							formFields.SetField("untitled99", dtCompanyInfo.Rows(0)("Address"))
							formFields.SetField("untitled103", dtCompanyInfo.Rows(0)("Zip"))
							formFields.SetField("untitled104", dtCompanyInfo.Rows(0)("Telephone"))
						End If

						formFields.SetField("untitled111", "SAINI, BHARTENDU")
					ElseIf strForm = "1905" Then

						If dtConfiInfo.Rows.Count > 0 Then
							Dim strTIN As String = dtConfiInfo.Rows(0)("TIN")

							formFields.SetField("tin1", strTIN.Substring(0, 3))
							formFields.SetField("tin2", strTIN.Substring(4, 3))
							formFields.SetField("tin3", strTIN.Substring(8, 3))
							formFields.SetField("tin4", "000")
						End If

						formFields.SetField("name", dtEmpInfo.Rows(0)("EmpName"))

						formFields.SetField("untitled148", "SAINI, BHARTENDU")
					ElseIf strForm = "E1" Then

						If dtConfiInfo.Rows.Count > 0 Then
							formFields.SetField("ss_number01", dtConfiInfo.Rows(0)("SSS"))
						End If

						formFields.SetField("surname", dtEmpInfo.Rows(0)("EmpName"))

						If dtPersonalInfo.Rows.Count > 0 Then
							formFields.SetField("address 1", dtPersonalInfo.Rows(0)("HouseNumber") & " " & dtPersonalInfo.Rows(0)("StreetName") & " " & _
												dtPersonalInfo.Rows(0)("Barangay") & " " & dtPersonalInfo.Rows(0)("Town") & " " & dtPersonalInfo.Rows(0)("City"))

							Dim strZip As String = dtPersonalInfo.Rows(0)("ZipCode")

							formFields.SetField("postalcode01", strZip.Substring(0, 1))
							formFields.SetField("postalcode02", strZip.Substring(1, 1))
							formFields.SetField("postalcode03", strZip.Substring(2, 1))
							formFields.SetField("postalcode04", strZip.Substring(3, 1))

							If dtPersonalInfo.Rows(0)("Gender") = "Male" Or dtPersonalInfo.Rows(0)("Gender") = "M" Then
								formFields.SetField("untitled6", "Yes")
							Else
								formFields.SetField("untitled7", "Yes")
							End If

							Dim dob As Date = dtPersonalInfo.Rows(0)("DOB")

							formFields.SetField("dobmonth01", dob.ToString("MM").Substring(0, 1))
							formFields.SetField("dobmonth02", dob.ToString("MM").Substring(1, 1))
							formFields.SetField("dobday01", dob.ToString("dd").Substring(0, 1))
							formFields.SetField("dobday02", dob.ToString("dd").Substring(1, 1))
							formFields.SetField("dobyear01", dob.ToString("yy").Substring(0, 1))
							formFields.SetField("dobyear02", dob.ToString("yy").Substring(1, 1))
						End If

						If dtDepInfo.Rows.Count > 0 Then

							formFields.SetField("spousename", IIf(dtDepInfo.Rows(0)("SpouseName") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("SpouseName")),
																  dtDepInfo.Rows(0)("SpouseName"), ""))

							formFields.SetField("fathername", IIf(dtDepInfo.Rows(0)("FathersName") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("FathersName")),
																  dtDepInfo.Rows(0)("FathersName"), ""))

							formFields.SetField("mothername", IIf(dtDepInfo.Rows(0)("MothersName") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("MothersName")),
																  dtDepInfo.Rows(0)("MothersName"), ""))

							formFields.SetField("child01", IIf(dtDepInfo.Rows(0)("Child1Name") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1Name")),
																  dtDepInfo.Rows(0)("Child1Name"), ""))

							formFields.SetField("dobmonth0101", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("MM").ToString().Substring(0, 1), ""))

							formFields.SetField("dobmonth0102", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("MM").ToString().Substring(1, 1), ""))

							formFields.SetField("dobday0101", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("dd").ToString().Substring(0, 1), ""))

							formFields.SetField("dobday0102", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("dd").ToString().Substring(1, 1), ""))

							formFields.SetField("dobyear0101", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("yy").ToString().Substring(0, 1), ""))

							formFields.SetField("dobyear0102", IIf(dtDepInfo.Rows(0)("Child1DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child1DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("yy").ToString().Substring(1, 1), ""))

							formFields.SetField("child02", IIf(dtDepInfo.Rows(0)("Child2Name") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2Name")),
																  dtDepInfo.Rows(0)("Child2Name"), ""))

							formFields.SetField("dobmonth0201", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("MM").ToString().Substring(0, 1), ""))

							formFields.SetField("dobmonth0202", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child2DOB").ToString("MM").ToString().Substring(1, 1), ""))

							formFields.SetField("dobday0201", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child2DOB").ToString("dd").ToString().Substring(0, 1), ""))

							formFields.SetField("dobday0202", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child2DOB").ToString("dd").ToString().Substring(1, 1), ""))

							formFields.SetField("dobyear0201", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child2DOB").ToString("yy").ToString().Substring(0, 1), ""))

							formFields.SetField("dobyear0202", IIf(dtDepInfo.Rows(0)("Child2DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child2DOB")),
																  dtDepInfo.Rows(0)("Child2DOB").ToString("yy").ToString().Substring(1, 1), ""))

							formFields.SetField("child03", IIf(dtDepInfo.Rows(0)("Child3Name") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3Name")),
																  dtDepInfo.Rows(0)("Child3Name"), ""))

							formFields.SetField("dobmonth0301", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child1DOB").ToString("MM").ToString().Substring(0, 1), ""))

							formFields.SetField("dobmonth0302", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child3DOB").ToString("MM").ToString().Substring(1, 1), ""))

							formFields.SetField("dobday0301", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child3DOB").ToString("dd").ToString().Substring(0, 1), ""))

							formFields.SetField("dobday0302", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child3DOB").ToString("dd").ToString().Substring(1, 1), ""))

							formFields.SetField("dobyear0301", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child3DOB").ToString("yy").ToString().Substring(0, 1), ""))

							formFields.SetField("dobyear0302", IIf(dtDepInfo.Rows(0)("Child3DOB") <> "" Or Not IsDBNull(dtDepInfo.Rows(0)("Child3DOB")),
																  dtDepInfo.Rows(0)("Child3DOB").ToString("yy").ToString().Substring(1, 1), ""))
						End If
					Else
						Dim empID As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("EmpID")), dtEmpInfo.Rows(0)("EmpID"), "[Employee ID]")
						Dim empName As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("EmpName")), dtEmpInfo.Rows(0)("EmpName"), "[Employee Name]")
						Dim doj As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("DateJoined")), dtEmpInfo.Rows(0)("DateJoined"), "[Date Joined]")
						Dim ced As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("ContractEndDate")), dtEmpInfo.Rows(0)("ContractEndDate"), "[Contract End Date]")
						Dim jobDesc As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("JobDesc")), dtEmpInfo.Rows(0)("JobDesc"), "[Job Description]")
						Dim deptCode As String = IIf(dtEmpInfo.Rows.Count > 0 Or Not IsDBNull(dtEmpInfo.Rows(0)("DeptCode")), dtEmpInfo.Rows(0)("DeptCode"), "[Department Code]")

						Dim hourlyRate, dailyRate, monthlyRate, taxStatus As String
						If dtPayInfo.Rows.Count > 0 Then
							If Not IsDBNull(dtPayInfo.Rows(0)("hourly")) Then
								hourlyRate = dtPayInfo.Rows(0)("hourly")
							Else
								hourlyRate = "[Hourly Rate]"
							End If

							If Not IsDBNull(dtPayInfo.Rows(0)("daily")) Then
								dailyRate = dtPayInfo.Rows(0)("daily")
							Else
								dailyRate = "[Daily Rate]"
							End If
							If Not IsDBNull(dtPayInfo.Rows(0)("monthly")) Then
								monthlyRate = dtPayInfo.Rows(0)("monthly")
							Else
								monthlyRate = "[Monthly Rate]"
							End If
							If Not IsDBNull(dtPayInfo.Rows(0)("tax_status")) Then
								taxStatus = dtPayInfo.Rows(0)("tax_status")
							Else
								taxStatus = "[Tax Status]"
							End If
						Else
							hourlyRate = "[Hourly Rate]"
							dailyRate = "[Daily Rate]"
							monthlyRate = "[Monthly Rate]"
							taxStatus = "[Tax Status]"
						End If

						For i = 1 To pdfReader.NumberOfPages

							Dim lteStrategy As LocationTextExtractionStrategy = New LocationTextExtractionStrategy

							Dim strExtract = PdfTextExtractor.GetTextFromPage(pdfReader, i, lteStrategy)

							Dim sb As New StringBuilder

							sb.Append(PdfTextExtractor.GetTextFromPage(pdfReader, i))

							sb.Replace("[Employee ID]", empID)
							sb.Replace("[Employee Name]", empName)
							sb.Replace("[Date Joined]", doj)
							sb.Replace("[Contract End Date]", ced)
							sb.Replace("[Job Description]", jobDesc)
							sb.Replace("[Department Code]", deptCode)
							sb.Replace("[Hourly Rate]", hourlyRate)
							sb.Replace("[Daily Rate]", dailyRate)
							sb.Replace("[Monthly Rate]", monthlyRate)
							sb.Replace("[Tax Status]", taxStatus)

							Dim imageFileName2 As String = ""
							Dim strSignature As New ArrayList()
							Dim sigBool1 As Boolean = False
							Dim sigBool2 As Boolean = False
							Dim sigBool3 As Boolean = False

							Dim filepath = HttpContext.Current.Server.MapPath("~/PDF Template/" & strForm & ".pdf")

							'Create an instance of our strategy
							Dim t = New MyLocationTextExtractionStrategy()

							Dim extr = PdfTextExtractor.GetTextFromPage(pdfReader, 1, t)
							'End Using
							Dim sig1img As Image
							Dim sig2img As Image
							Dim sig3img As Image
							'Loop through each chunk found
							'Try

							If sb.ToString.Contains("[President Signature]") Then
								strSignature.Add("[President Signature]")
								imageFileName2 = "http://hrms4103.cloudapp.net/Image/Base64?id=sainibha"

								Try
									Dim client = New Http.HttpClient()
									Dim response = client.GetAsync(imageFileName2).Result

									Dim NewsJson = response.Content.ReadAsStringAsync()
									NewsJson.Wait()

									Dim data As Byte()
									data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
									Dim ImageStream As MemoryStream = New MemoryStream(data)

									sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
									sigBool1 = True
								Catch ex As Exception
									imageFileName2 = HttpContext.Current.Server.MapPath("~/images/Altisource_Logo.png")
									sig1img = iTextSharp.text.Image.GetInstance(imageFileName2)
									sigBool1 = True
								End Try

							End If

							If sb.ToString.Contains("[HR Signature]") Then
								strSignature.Add("[HR Signature]")
								imageFileName2 = "http://hrms4103.cloudapp.net/Image/Base64?id=hrmanager"

								Try
									Dim client = New Http.HttpClient()
									Dim response = client.GetAsync(imageFileName2).Result

									Dim NewsJson = response.Content.ReadAsStringAsync()
									NewsJson.Wait()

									Dim data As Byte()
									data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
									Dim ImageStream As MemoryStream = New MemoryStream(data)

									sig2img = iTextSharp.text.Image.GetInstance(ImageStream)
									sigBool2 = True
								Catch ex As Exception
									imageFileName2 = HttpContext.Current.Server.MapPath("~/images/Altisource_Logo.png")
									sig2img = iTextSharp.text.Image.GetInstance(imageFileName2)
									sigBool2 = True
								End Try
							End If

							If sb.ToString.Contains("[Employee Signature]") Then
								strSignature.Add("[Employee Signature]")
								imageFileName2 = "http://hrms4103.cloudapp.net/Image/Base64?id=" & strEmpID

								Try
									Dim client = New Http.HttpClient()
									Dim response = client.GetAsync(imageFileName2).Result

									Dim NewsJson = response.Content.ReadAsStringAsync()
									NewsJson.Wait()

									Dim data As Byte()
									data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
									Dim ImageStream As MemoryStream = New MemoryStream(data)

									sig3img = iTextSharp.text.Image.GetInstance(ImageStream)
									sigBool3 = True
								Catch ex As Exception
									imageFileName2 = HttpContext.Current.Server.MapPath("~/images/Altisource_Logo.png")
									sig3img = iTextSharp.text.Image.GetInstance(imageFileName2)
									sigBool3 = True
								End Try
							End If

							For Each p As RectAndText In t.myPoints
								Debug.WriteLine(String.Format("Found text {0} at {1}x{2}", p.Text.Trim, p.Rect.Left, p.Rect.Bottom))
								If p.Text = "[President Signature]" Then
									sig1img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
									sig1img.ScalePercent(15.0F)
									sb.Replace("[President Signature]", "Saini, Bhartendu")
								End If

								If p.Text = "[HR Signature]" Then
									sig2img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
									sig2img.ScalePercent(15.0F)
									Dim sb1 As New StringBuilder
									sb1.AppendFormat("James Smith{0}HR Manager{0}" & Date.Now.ToShortDateString, Environment.NewLine)
									sb.Replace("[HR Signature]", sb1.ToString())
								End If

								If p.Text = "[Employee Signature]" Then
									sig3img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
									sig3img.ScalePercent(15.0F)
									sb.Replace("[Employee Signature]", "")
								End If
							Next

							'For x As Integer = 0 To strSignature.Count - 1
							'	sb.Replace(strSignature(x), "")
							'Next

							'Catch ex As Exception
							'ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: console.log('" & ex.Message & "');", True)
							'Forms.path = ex.ToString()

							'Return Forms
							'End Try

							'Catch ex As Exception

							'If sb.ToString.Contains("[President Signature]") Then
							'	strSignature.Add("[President Signature]")
							'	imageFileName2 = HttpContext.Current.Server.MapPath("~/images/Altisource_Logo.png")
							'	sig1img = iTextSharp.text.Image.GetInstance(imageFileName2)
							'	sigBool1 = True
							'End If

							'If sb.ToString.Contains("[HR Signature]") Then
							'	strSignature.Add("[HR Signature]")
							'	imageFileName2 = HttpContext.Current.Server.MapPath("~/images/7thAnniv.png")
							'	sig2img = iTextSharp.text.Image.GetInstance(imageFileName2)
							'	sigBool2 = True
							'End If

							'If sb.ToString.Contains("[Employee Signature]") Then
							'	strSignature.Add("[Employee Signature]")
							'	imageFileName2 = HttpContext.Current.Server.MapPath("~/images/comingSoon.png")
							'	sig3img = iTextSharp.text.Image.GetInstance(imageFileName2)
							'	sigBool3 = True
							'End If


							''sig1img = Image.GetInstance(imageFileName2)

							'For Each p As RectAndText In t.myPoints
							'	Debug.WriteLine(String.Format("Found text {0} at {1}x{2}", p.Text.Trim, p.Rect.Left, p.Rect.Bottom))
							'	If p.Text = "[President Signature]" Then
							'		sig1img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
							'		sig1img.ScalePercent(15.0F)
							'	End If

							'	If p.Text = "[HR Signature]" Then
							'		sig2img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
							'		sig2img.ScalePercent(15.0F)
							'	End If

							'	If p.Text = "[Employee Signature]" Then
							'		sig3img.SetAbsolutePosition(p.Rect.Left, p.Rect.Bottom)
							'		sig3img.ScalePercent(15.0F)
							'	End If
							'Next

							'For x As Integer = 0 To strSignature.Count - 1
							'	sb.Replace(strSignature(x), "")
							'Next
							'End Try

							Using ms As New MemoryStream()
								Dim document As New iTextSharp.text.Document(PageSize.A4, 25, 25, 30, 30)
								Dim writer As PdfWriter = PdfWriter.GetInstance(document, stream)

								document.Open()
								document.Add(New Paragraph(sb.ToString()))
								If sigBool1 = True Then
									document.Add(sig1img)
								End If
								If sigBool2 = True Then
									document.Add(sig2img)
								End If
								If sigBool3 = True Then
									document.Add(sig3img)
								End If
								document.Close()

								HttpContext.Current.Response.ContentType = "pdf/application"
								HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" & filename)
								HttpContext.Current.Response.OutputStream.Write(ms.GetBuffer(), 0, ms.GetBuffer().Length)
							End Using

						Next i

						GoTo close
					End If

					pdfStamper.FormFlattening = False
					pdfStamper.Close()
close:
					Forms.path = "/PDF Export/" & filename

				End Using
			Catch ex As Exception
				Forms.path = ex.ToString()

				Return Forms
			End Try
		End If

		Return Forms
	End Function

	<WebMethod>
	Public Shared Function ViewForm2(strForm As String, strEmpID As String, strFormGroup As String) As Forms
		Dim cls As New clsConnection
		Dim dtEmpInfo As New DataTable
		Dim dtEmployerInfo As New DataTable
		Dim dtCompanyInfo As New DataTable
		Dim dtSignature As New DataTable
		Dim dtPersonalInfo As New DataTable
		Dim dtConfiInfo As New DataTable
		Dim dtDepInfo As New DataTable
		Dim dtPayInfo As New DataTable
		Dim dtPayDeducInfo As New DataTable

		Dim Forms As New Forms

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where AccessLevel is not null order by EmpName"

		dtEmpInfo = cls.GetData(qry)

		Dim slctCompany As String = ""

		slctCompany = "select * from dbo.tbl_HRMS_CompanyDetails"

		dtCompanyInfo = cls.GetData(slctCompany)

		Dim slctEmployer As String = ""

		slctEmployer = "select * from tbl_HRMS_EmployerDetails"

		dtEmployerInfo = cls.GetData(slctEmployer)

		If dtEmpInfo.Rows.Count > 0 Then
			Try
				Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")
				Dim pdfReader As New PdfReader(HttpContext.Current.Server.MapPath("~/PDF Template/" & strForm & ".pdf"))
				Dim imageFileName As String = "http://hrms4103.cloudapp.net/Image/Base64?id=sainibha"

				Using stream As New FileStream(String.Concat(HttpContext.Current.Server.MapPath("~/PDF Export/"), filename), FileMode.Create)
					Dim pdfStamper As New PdfStamper(pdfReader, stream)

					Dim formFields As AcroFields = pdfStamper.AcroFields
					Dim item As New AcroFields.Item

					Dim num1 As Integer = 30
					Dim phNum As Integer = 1
					Dim num3 As Integer = 46
					Dim num4 As Integer = 4
					Dim num5 As Integer = 67
					Dim num6 As Integer = 268
					Dim num7 As Integer = 434
					Dim num8 As Integer = 1

					For count As Integer = 0 To dtEmpInfo.Rows.Count - 1

						Dim qry2 As String = ""

						qry2 = "select a.* from tbl_HRMS_Employee_PersonalInformation a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.EmpID = '" & dtEmpInfo.Rows(count)("EmpID") & "'"

						dtPersonalInfo = cls.GetData(qry2)

						Dim qry3 As String = ""

						qry3 = "select a.* from tbl_HRMS_Employee_ConfidentialInfo a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.EmpID = '" & dtEmpInfo.Rows(count)("EmpID") & "'"

						dtConfiInfo = cls.GetData(qry3)

						Dim qry4 As String = ""

						qry4 = "select a.* from tbl_HRMS_Employee_DependentDetails a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.EmpID = '" & dtEmpInfo.Rows(count)("EmpID") & "'"

						dtDepInfo = cls.GetData(qry4)

						Dim qry5 As String = ""

						qry5 = "select a.* from tbl_HRMS_PayslipMaster a join tbl_HRMS_EmployeeMaster b on a.NTID = b.NTID where b.EmpID = '" & dtEmpInfo.Rows(count)("EmpID") & "' and a.cutoff_date = '2016-09-01-2016-09-30'"

						dtPayInfo = cls.GetData(qry5)

						Dim qry6 As String = ""

						qry6 = "select a.* from tbl_hrms_Adjustments a join tbl_HRMS_EmployeeMaster b on a.payid = b.NTID where b.EmpID = '" & dtEmpInfo.Rows(count)("EmpID") & "' and a.cutoff_date = '2016-09-01-2016-09-30'"

						dtPayDeducInfo = cls.GetData(qry6)

						If strFormGroup = "BIR" Then
							If strForm = "1604-CF" Then
								If count <= 35 Then
									If dtCompanyInfo.Rows.Count > 0 Then
										'Name
										formFields.SetField("untitled19", UCase(dtCompanyInfo.Rows(0)("CompanyName")))

										'Address
										formFields.SetField("untitled20", UCase(dtCompanyInfo.Rows(0)("Address")))

										'Zip
										formFields.SetField("untitled23", dtCompanyInfo.Rows(0)("Zip"))

										'Telphone Number
										formFields.SetField("untitled15", dtCompanyInfo.Rows(0)("Telephone"))
									End If

									If dtEmployerInfo.Rows.Count > 0 Then
										'TIN
										Dim strTIN As String = dtEmployerInfo.Rows(0)("TIN")
										formFields.SetField("untitled9", strTIN.Substring(0, 3))
										formFields.SetField("untitled10", strTIN.Substring(4, 3))
										formFields.SetField("untitled11", strTIN.Substring(8, 3))
										formFields.SetField("untitled12", "000")
									End If

									'Employer Signature
									formFields.SetField("untitled249", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("untitled249")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									Try
										Dim client = New Http.HttpClient()
										Dim response = client.GetAsync(imageFileName).Result

										Dim NewsJson = response.Content.ReadAsStringAsync()
										NewsJson.Wait()

										Dim data As Byte()
										data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
										Dim ImageStream As MemoryStream = New MemoryStream(data)

										Dim sig1img As iTextSharp.text.Image

										Try
											sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
											Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("untitled249")
											Dim test As AcroFields.FieldPosition = sig1position(0)
											Dim left, right, top, bottom As Single
											left = test.position.Left
											right = test.position.Right
											top = test.position.Top
											bottom = test.position.Bottom - 10
											sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
											sig1img.ScalePercent(15.0F)
										Catch ex As Exception

										End Try

										Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
										contentByte.AddImage(sig1img)
									Catch ex As Exception

									End Try

									If dtConfiInfo.Rows.Count > 0 Then

									End If
								Else
									GoTo endFor
								End If
							End If
						ElseIf strFormGroup = "PHIC" Then
							If strForm = "RF-1" Then
								If count <= 9 Then
									'Employer Signature
									formFields.SetField("untitled315", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("untitled315")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									Try
										Dim client = New Http.HttpClient()
										Dim response = client.GetAsync(imageFileName).Result

										Dim NewsJson = response.Content.ReadAsStringAsync()
										NewsJson.Wait()

										Dim data As Byte()
										data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
										Dim ImageStream As MemoryStream = New MemoryStream(data)

										Dim sig1img As iTextSharp.text.Image

										Try
											sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
											Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("untitled315")
											Dim test As AcroFields.FieldPosition = sig1position(0)
											Dim left, right, top, bottom As Single
											left = test.position.Left
											right = test.position.Right
											top = test.position.Top
											bottom = test.position.Bottom
											sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
											sig1img.ScalePercent(15.0F)
										Catch ex As Exception

										End Try

										Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
										contentByte.AddImage(sig1img)
									Catch ex As Exception

									End Try

									If dtEmployerInfo.Rows.Count > 0 Then
										Dim strEmpPH As String = dtEmployerInfo.Rows(0)("PhilHealth")
										Dim strEmpTIN As String = dtEmployerInfo.Rows(0)("TIN")

										formFields.SetField("untitled1", strEmpPH.Substring(0, 1))
										formFields.SetField("untitled2", strEmpPH.Substring(1, 1))
										formFields.SetField("untitled3", strEmpPH.Substring(3, 1))
										formFields.SetField("untitled4", strEmpPH.Substring(4, 1))
										formFields.SetField("untitled5", strEmpPH.Substring(5, 1))
										formFields.SetField("untitled6", strEmpPH.Substring(6, 1))
										formFields.SetField("untitled7", strEmpPH.Substring(7, 1))
										formFields.SetField("untitled8", strEmpPH.Substring(8, 1))
										formFields.SetField("untitled9", strEmpPH.Substring(9, 1))
										formFields.SetField("untitled10", strEmpPH.Substring(10, 1))
										formFields.SetField("untitled11", strEmpPH.Substring(11, 1))
										formFields.SetField("untitled12", strEmpPH.Substring(13, 1))

										formFields.SetField("untitled13", strEmpTIN.Substring(0, 1))
										formFields.SetField("untitled14", strEmpTIN.Substring(1, 1))
										formFields.SetField("untitled15", strEmpTIN.Substring(2, 1))
										formFields.SetField("untitled16", strEmpTIN.Substring(4, 1))
										formFields.SetField("untitled17", strEmpTIN.Substring(5, 1))
										formFields.SetField("untitled18", strEmpTIN.Substring(6, 1))
										formFields.SetField("untitled19", strEmpTIN.Substring(8, 1))
										formFields.SetField("untitled20", strEmpTIN.Substring(9, 1))
										formFields.SetField("untitled21", strEmpTIN.Substring(10, 1))

										formFields.SetField("untitled22", UCase(dtEmployerInfo.Rows(0)("Name")))
										formFields.SetField("untitled51", dtCompanyInfo.Rows(0)("Address"))
										formFields.SetField("untitled53", dtCompanyInfo.Rows(0)("Telephone"))
										formFields.SetField("untitled54", dtEmployerInfo.Rows(0)("EmailAdd"))
									End If

									If count <= 9 Then
										formFields.SetField("lastName" & phNum, UCase(dtEmpInfo.Rows(count)("EmpName")))

										item = formFields.GetFieldItem("lastName" & phNum)
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_LEFT))

										If dtPersonalInfo.Rows.Count > 0 Then
											Dim dateDOB As Date = Convert.ToDateTime(dtPersonalInfo.Rows(0)("DOB")).ToShortDateString()
											Dim monthDOB As String = Convert.ToInt32(Month(dateDOB)).ToString("00")
											Dim dayDOB As String = Convert.ToInt32(Day(dateDOB)).ToString("00")
											Dim yearDOB As String = Convert.ToInt32(Year(dateDOB)).ToString("0000")

											formFields.SetField("monthDOB" & phNum, monthDOB)
											formFields.SetField("dayDOB" & phNum, dayDOB)
											formFields.SetField("yearDOB" & phNum, yearDOB)

											Dim strSex As String = ""
											If dtEmpInfo.Rows(count)("Gender") = "Male" Then
												strSex = "M"
											Else
												strSex = "F"
											End If

											formFields.SetField("sex" & phNum, strSex)

										End If

										If dtConfiInfo.Rows.Count > 0 Then

											Dim strPH As String = dtConfiInfo.Rows(0)("PhilHealth")

											formFields.SetField("ph" & phNum & "_1", strPH.Substring(0, 1))
											formFields.SetField("ph" & phNum & "_2", strPH.Substring(1, 1))
											formFields.SetField("ph" & phNum & "_3", strPH.Substring(3, 1))
											formFields.SetField("ph" & phNum & "_4", strPH.Substring(4, 1))
											formFields.SetField("ph" & phNum & "_5", strPH.Substring(5, 1))
											formFields.SetField("ph" & phNum & "_6", strPH.Substring(6, 1))
											formFields.SetField("ph" & phNum & "_7", strPH.Substring(7, 1))
											formFields.SetField("ph" & phNum & "_8", strPH.Substring(8, 1))
											formFields.SetField("ph" & phNum & "_9", strPH.Substring(9, 1))
											formFields.SetField("ph" & phNum & "_10", strPH.Substring(10, 1))
											formFields.SetField("ph" & phNum & "_11", strPH.Substring(11, 1))
											formFields.SetField("ph" & phNum & "_12", strPH.Substring(13, 1))

											item = formFields.GetFieldItem("ph" & phNum & "_1")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_2")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_3")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_4")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_5")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_6")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_7")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_8")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_9")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_10")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_11")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
											item = formFields.GetFieldItem("ph" & phNum & "_12")
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
										End If
										phNum = phNum + 1

									End If
								Else
									formFields.SetField("untitled304", count)
									formFields.SetFieldProperty("untitled304", "textsize", 20.0F, Nothing)
									formFields.SetFieldProperty("untitled304", "textfont", iTextSharp.text.Font.BOLD, Nothing)
									GoTo endFor
								End If
							ElseIf strForm = "ER-2" Then
								If count <= 14 Then
									'Employer Signature
									formFields.SetField("signature", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("signature")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									If dtCompanyInfo.Rows.Count > 0 Then
										formFields.SetField("employerName", dtCompanyInfo.Rows(0)("CompanyName"))
										formFields.SetField("employerAddress", dtCompanyInfo.Rows(0)("Address"))
										formFields.SetField("employerEmailAdd", dtCompanyInfo.Rows(0)("GeneralEmail"))
									End If

									Try
										Dim client = New Http.HttpClient()
										Dim response = client.GetAsync(imageFileName).Result

										Dim NewsJson = response.Content.ReadAsStringAsync()
										NewsJson.Wait()

										Dim data As Byte()
										data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
										Dim ImageStream As MemoryStream = New MemoryStream(data)

										Dim sig1img As iTextSharp.text.Image

										Try
											sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
											Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("signature")
											Dim test As AcroFields.FieldPosition = sig1position(0)
											Dim left, right, top, bottom As Single
											left = test.position.Left
											right = test.position.Right
											top = test.position.Top
											bottom = test.position.Bottom
											sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
											sig1img.ScalePercent(15.0F)
										Catch ex As Exception

										End Try

										Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
										contentByte.AddImage(sig1img)
									Catch ex As Exception

									End Try

									If count <= 14 Then

										formFields.SetField("empName" & num8, UCase(dtEmpInfo.Rows(count)("EmpName")))
										formFields.SetField("empPosition" & num8, dtEmpInfo.Rows(count)("JobDesc"))
										formFields.SetField("empDOJ" & num8, Convert.ToDateTime(dtEmpInfo.Rows(count)("DateJoined")).ToString("MM-dd-yyyy"))

										item = formFields.GetFieldItem("empName" & num8)
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_LEFT))
										item = formFields.GetFieldItem("empDOJ" & num8)
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))


										formFields.SetField("page", "1")
										formFields.SetField("sheets", "1")
										formFields.SetFieldProperty("page", "textsize", 15.0F, Nothing)
										formFields.SetFieldProperty("sheets", "textsize", 15.0F, Nothing)
										formFields.SetFieldProperty("page", "textfont", iTextSharp.text.Font.BOLD, Nothing)
										formFields.SetFieldProperty("sheets", "textfont", iTextSharp.text.Font.BOLD, Nothing)
										item = formFields.GetFieldItem("page")
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
										item = formFields.GetFieldItem("sheets")
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))

										If dtConfiInfo.Rows.Count > 0 Then
											formFields.SetField("num" & num8, dtConfiInfo.Rows(0)("PhilHealth"))
											item = formFields.GetFieldItem("num" & num8)
											item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))
										End If

										If dtPayInfo.Rows.Count > 0 Then
											If dtPayInfo.Rows.Count <= 15 Then
												formFields.SetField("empSal" & num8, dtPayInfo.Rows(0)("monthly"))
											End If
										End If

										num8 = num8 + 1
									End If
								Else
									formFields.SetField("totalList", count)
									formFields.SetFieldProperty("totalList", "textsize", 20.0F, Nothing)
									formFields.SetFieldProperty("totalList", "textfont", iTextSharp.text.Font.BOLD, Nothing)
									item = formFields.GetFieldItem("totalList")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_LEFT))
									GoTo endFor
								End If
							End If
						ElseIf strFormGroup = "SSS" Then
							If strForm = "R-3" Then
								If count <= 14 Then

									'Employer Signature
									formFields.SetField("untitled43", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("untitled43")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									formFields.SetField("untitled45", DateTime.Now.ToShortDateString)

									formFields.SetField("page1", "0")
									formFields.SetField("page2", "0")
									formFields.SetField("page3", "1")

									formFields.SetField("pages1", "0")
									formFields.SetField("pages2", "0")
									formFields.SetField("pages3", "1")

									If dtEmployerInfo.Rows.Count > 0 Then
										For num As Integer = 1 To dtEmployerInfo.Rows(0)("IDNum").ToString.Length
											formFields.SetField("empNum" & num, dtEmployerInfo.Rows(0)("IDNum").ToString.Substring((num - 1), 1))
										Next num

										formFields.SetField("employerName", UCase(dtEmployerInfo.Rows(0)("Name")))
									End If

									If dtCompanyInfo.Rows.Count > 0 Then
										formFields.SetField("telNo", dtCompanyInfo.Rows(0)("Telephone"))
										formFields.SetField("address", UCase(dtCompanyInfo.Rows(0)("Address")))
									End If

									Try
										Dim client = New Http.HttpClient()
										Dim response = client.GetAsync(imageFileName).Result

										Dim NewsJson = response.Content.ReadAsStringAsync()
										NewsJson.Wait()

										Dim data As Byte()
										data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
										Dim ImageStream As MemoryStream = New MemoryStream(data)

										Dim sig1img As iTextSharp.text.Image

										Try
											sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
											Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("untitled43")
											Dim test As AcroFields.FieldPosition = sig1position(0)
											Dim left, right, top, bottom As Single
											left = test.position.Left
											right = test.position.Right
											top = test.position.Top
											bottom = test.position.Bottom
											sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
											sig1img.ScalePercent(15.0F)
										Catch ex As Exception

										End Try

										Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
										contentByte.AddImage(sig1img)
									Catch ex As Exception

									End Try

									If dtConfiInfo.Rows.Count > 0 Then
										Dim num As Integer = 1
										formFields.SetField("sssNum" & num8 & "_" & num, dtConfiInfo.Rows(0)("SSS").ToString.Substring(0, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 1, dtConfiInfo.Rows(0)("SSS").ToString.Substring(1, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 2, dtConfiInfo.Rows(0)("SSS").ToString.Substring(3, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 3, dtConfiInfo.Rows(0)("SSS").ToString.Substring(4, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 4, dtConfiInfo.Rows(0)("SSS").ToString.Substring(5, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 5, dtConfiInfo.Rows(0)("SSS").ToString.Substring(6, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 6, dtConfiInfo.Rows(0)("SSS").ToString.Substring(7, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 7, dtConfiInfo.Rows(0)("SSS").ToString.Substring(8, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 8, dtConfiInfo.Rows(0)("SSS").ToString.Substring(9, 1))
										formFields.SetField("sssNum" & num8 & "_" & num + 9, dtConfiInfo.Rows(0)("SSS").ToString.Substring(11, 1))
									End If

									formFields.SetField("name" & num8, UCase(dtEmpInfo.Rows(count)("EmpName")))

									'End If

									num8 = num8 + 1
								Else
									GoTo endFor
								End If
							ElseIf strForm = "R-1A" Then
								If count <= 19 Then
									'Employer Signature
									formFields.SetField("Text45", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("Text45")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									formFields.SetField("Text267", DateTime.Now.ToShortDateString)
									formFields.SetField("Text48", "1")
									formFields.SetField("Text49", "1")

									Try
										Dim client = New Http.HttpClient()
										Dim response = client.GetAsync(imageFileName).Result

										Dim NewsJson = response.Content.ReadAsStringAsync()
										NewsJson.Wait()

										Dim data As Byte()
										data = System.Convert.FromBase64String(NewsJson.Result.Replace("""", ""))
										Dim ImageStream As MemoryStream = New MemoryStream(data)

										Dim sig1img As iTextSharp.text.Image

										Try
											sig1img = iTextSharp.text.Image.GetInstance(ImageStream)
											Dim sig1position As System.Collections.Generic.IList(Of AcroFields.FieldPosition) = formFields.GetFieldPositions("Text45")
											Dim test As AcroFields.FieldPosition = sig1position(0)
											Dim left, right, top, bottom As Single
											left = test.position.Left
											right = test.position.Right
											top = test.position.Top
											bottom = test.position.Bottom
											sig1img.SetAbsolutePosition(absoluteX:=left, absoluteY:=bottom)
											sig1img.ScalePercent(15.0F)
										Catch ex As Exception

										End Try

										Dim contentByte As PdfContentByte = pdfStamper.GetOverContent(1)
										contentByte.AddImage(sig1img)
									Catch ex As Exception

									End Try

									If count <= 19 Then

										If dtEmployerInfo.Rows.Count > 0 Then
											Dim strEmpNum As String = dtEmployerInfo.Rows(0)("IDNum")
											For empNum As Integer = 1 To strEmpNum.Length
												formFields.SetField("employerNum" & empNum, strEmpNum.Substring(empNum - 1, 1))
											Next empNum

											formFields.SetField("employerName", dtEmployerInfo.Rows(0)("Name"))
										End If

										If dtCompanyInfo.Rows.Count > 0 Then
											formFields.SetField("employerTIN", dtCompanyInfo.Rows(0)("TIN"))
											formFields.SetField("employerAddress", dtCompanyInfo.Rows(0)("Address"))
											Dim strZip As String = dtCompanyInfo.Rows(0)("Zip")
											For empZip As Integer = 1 To strZip.Length
												formFields.SetField("postal" & empZip, strZip.Substring(empZip - 1, 1))
											Next empZip
										End If

										formFields.SetField("name" & num8, dtEmpInfo.Rows(count)("EmpName"))
										formFields.SetField("position" & num8, dtEmpInfo.Rows(count)("JobDesc"))

										item = formFields.GetFieldItem("position" & num8)
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

										Dim empCount As Integer = 1
										formFields.SetField("Text47", empCount)
										empCount += 1

										Dim dateDOJ As Date = Convert.ToDateTime(dtEmpInfo.Rows(count)("DateJoined")).ToShortDateString()
										Dim monthDOJ As String = Convert.ToInt32(Month(dateDOJ)).ToString("00")
										Dim dayDOJ As String = Convert.ToInt32(Day(dateDOJ)).ToString("00")
										Dim yearDOJ As String = Convert.ToInt32(Year(dateDOJ)).ToString("0000")

										formFields.SetField("doemonth" & num8 & "1", monthDOJ.Substring(0, 1))
										formFields.SetField("doemonth" & num8 & "2", monthDOJ.Substring(1, 1))
										formFields.SetField("doeday" & num8 & "1", dayDOJ.Substring(0, 1))
										formFields.SetField("doeday" & num8 & "2", dayDOJ.Substring(1, 1))
										formFields.SetField("deoyear" & num8 & "1", yearDOJ.Substring(0, 1))
										formFields.SetField("deoyear" & num8 & "2", yearDOJ.Substring(1, 1))
										formFields.SetField("deoyear" & num8 & "3", yearDOJ.Substring(2, 1))
										formFields.SetField("deoyear" & num8 & "4", yearDOJ.Substring(3, 1))

										If dtConfiInfo.Rows.Count > 0 Then
											Dim strSSS As String = dtConfiInfo.Rows(0)("SSS")

											formFields.SetField("sssNum" & num8 & "_1", strSSS.Substring(0, 1))
											formFields.SetField("sssNum" & num8 & "_2", strSSS.Substring(1, 1))
											formFields.SetField("sssNum" & num8 & "_3", strSSS.Substring(3, 1))
											formFields.SetField("sssNum" & num8 & "_4", strSSS.Substring(4, 1))
											formFields.SetField("sssNum" & num8 & "_5", strSSS.Substring(5, 1))
											formFields.SetField("sssNum" & num8 & "_6", strSSS.Substring(6, 1))
											formFields.SetField("sssNum" & num8 & "_7", strSSS.Substring(7, 1))
											formFields.SetField("sssNum" & num8 & "_8", strSSS.Substring(8, 1))
											formFields.SetField("sssNum" & num8 & "_9", strSSS.Substring(9, 1))
											formFields.SetField("sssNum" & num8 & "_10", strSSS.Substring(11, 1))
										End If

										If dtPersonalInfo.Rows.Count > 0 Then
											Dim dateDOB As Date = Convert.ToDateTime(dtPersonalInfo.Rows(0)("DOB")).ToShortDateString()
											Dim monthDOB As String = Convert.ToInt32(Month(dateDOB)).ToString("00")
											Dim dayDOB As String = Convert.ToInt32(Day(dateDOB)).ToString("00")
											Dim yearDOB As String = Convert.ToInt32(Year(dateDOB)).ToString("0000")

											formFields.SetField("dobmonth" & num8 & "1", monthDOB.Substring(0, 1))
											formFields.SetField("dobmonth" & num8 & "2", monthDOB.Substring(1, 1))
											formFields.SetField("dobday" & num8 & "1", dayDOB.Substring(0, 1))
											formFields.SetField("dobday" & num8 & "2", dayDOB.Substring(1, 1))
											formFields.SetField("dobyear" & num8 & "1", yearDOB.Substring(0, 1))
											formFields.SetField("dobyear" & num8 & "2", yearDOB.Substring(1, 1))
											formFields.SetField("dobyear" & num8 & "3", yearDOB.Substring(2, 1))
											formFields.SetField("dobyear" & num8 & "4", yearDOB.Substring(3, 1))

										End If

										If dtPayInfo.Rows.Count > 0 Then
											Dim strSalary As String = dtPayInfo.Rows(0)("monthly")
											strSalary = strSalary.Remove(5, 3)
											'For length As Integer = 6 To strSalary.Length
											Dim length As Integer = 6
											Dim length2 As Integer = strSalary.Length
											Do Until length = 1
												formFields.SetField("salary" & num8 & length, strSalary.Substring(length2 - 1, 1))
												length = length - 1
												length2 = length2 - 1
											Loop
											'length = 
											'Next
										End If

										num8 = num8 + 1
									End If
								Else
									GoTo endFor
								End If
							End If
						ElseIf strFormGroup = "HDMF" Then
							If strForm = "M1-1" Then
								If count <= 39 Then
									'Employer Signature
									formFields.SetField("signature", UCase("Saini, Bhartendu"))
									item = formFields.GetFieldItem("signature")
									item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))

									formFields.SetField("date", Date.Now.ToShortDateString)

									If count <= 39 Then
										formFields.SetField("page", "1")
										formFields.SetField("pages", "1")

										item = formFields.GetFieldItem("page")
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))
										item = formFields.GetFieldItem("pages")
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_CENTER))
									End If

									If dtCompanyInfo.Rows.Count > 0 Then
										'Name
										formFields.SetField("untitled1", dtCompanyInfo.Rows(0)("CompanyName"))

										'Address
										formFields.SetField("untitled2", dtCompanyInfo.Rows(0)("Address"))

										'Zip
										formFields.SetField("untitled15", dtCompanyInfo.Rows(0)("Zip"))

										'Telephone
										formFields.SetField("untitled14", dtCompanyInfo.Rows(0)("Telephone"))
									End If

									If dtEmployerInfo.Rows.Count > 0 Then
										'TIN
										formFields.SetField("untitled11", dtEmployerInfo.Rows(0)("TIN"))

										'SSS
										formFields.SetField("untitled16", dtEmployerInfo.Rows(0)("SSS"))
									End If

									If dtConfiInfo.Rows.Count > 0 Then
										'TIN
										formFields.SetField("tin" & num8, dtConfiInfo.Rows(0)("TIN"))
									End If

									formFields.SetField("name" & num8, dtEmpInfo.Rows(count)("EmpName"))

									If dtPersonalInfo.Rows.Count > 0 Then
										Dim dateDOB As Date = Convert.ToDateTime(dtPersonalInfo.Rows(0)("DOB")).ToShortDateString()
										Dim monthDOB As String = Convert.ToInt32(Month(dateDOB)).ToString("00")
										Dim dayDOB As String = Convert.ToInt32(Day(dateDOB)).ToString("00")
										Dim yearDOB As String = Convert.ToInt32(Year(dateDOB)).ToString("0000")

										formFields.SetField("dob" & num8, monthDOB & "-" & dayDOB & "-" & yearDOB)
									End If

									num8 = num8 + 1
								Else
									formFields.SetField("totalEmp1", count)
									GoTo endFor
								End If
							ElseIf strForm = "STLRF" Then
								If count <= 29 Then
									If dtEmployerInfo.Rows.Count > 0 Then
										formFields.SetField("untitled1", dtEmployerInfo.Rows(0)("HDMF"))
									End If

									If dtCompanyInfo.Rows.Count > 0 Then
										formFields.SetField("untitled2", dtCompanyInfo.Rows(0)("CompanyName"))
										formFields.SetField("untitled3", dtCompanyInfo.Rows(0)("Address"))
										formFields.SetField("untitled4", dtCompanyInfo.Rows(0)("ZIP"))
										formFields.SetField("untitled6", dtCompanyInfo.Rows(0)("Telephone"))

										item = formFields.GetFieldItem("untitled4")
										item.GetMerged(0).Put(PdfName.Q, New PdfNumber(PdfFormField.Q_RIGHT))
									End If

									If dtConfiInfo.Rows.Count > 0 Then
										formFields.SetField("midno" & num8, dtConfiInfo.Rows(0)("PagIbig"))
									End If

									formFields.SetField("lastname" & num8, dtEmpInfo.Rows(count)("EmpName"))

									formFields.SetField("untitled7", "SAINI, BHARTENDU")

									formFields.SetField("untitled9", Date.Now.ToShortDateString())

									num8 = num8 + 1
								Else
									GoTo endFor
								End If
							End If
						End If

					Next count

endFor:
					pdfStamper.FormFlattening = False
					pdfStamper.Close()

					Forms.path = "/PDF Export/" & filename

				End Using
			Catch ex As Exception
				Forms.path = ex.Message
			End Try
		End If

		Return Forms

	End Function

	<WebMethod>
	Public Shared Function GetDocuments()
		Dim qry As String = ""
		Dim qry2 As String = ""
		Dim cls As New clsConnection
		Dim dtDocumentsPersonal As New DataTable
		Dim dtDocumentsCompany As New DataTable
		Dim Form As New Form

		qry = "select * from tbl_HRMS_Documents where Type = 'Personal' and DeletedBy is null"

		dtDocumentsPersonal = cls.GetData(qry)

		qry2 = "select * from tbl_HRMS_Documents where Type = 'Company' and DeletedBy is null"

		dtDocumentsCompany = cls.GetData(qry2)

		Dim FormLists1 As New List(Of FormList)
		Dim FormLists2 As New List(Of FormList)

		Dim x As Integer = 0
		Do Until x = dtDocumentsPersonal.Rows.Count
			Dim FormList As New FormList

			FormList.formName = dtDocumentsPersonal.Rows(x)("FormName")
			FormList.codeName = dtDocumentsPersonal.Rows(x)("CodeName")

			FormLists1.Add(FormList)
			x += 1
		Loop

		Dim y As Integer = 0
		Do Until y = dtDocumentsCompany.Rows.Count
			Dim FormList As New FormList

			FormList.formName = dtDocumentsCompany.Rows(y)("FormName")
			FormList.codeName = dtDocumentsCompany.Rows(y)("CodeName")

			FormLists2.Add(FormList)

			y += 1
		Loop

		Form.tblDocumentsPersonal = FormLists1
		Form.tblDocumentsCompany = FormLists2

		Return Form
	End Function

	Public Shared Function IsValidPdf(filepath As String) As Boolean
		Dim Ret As Boolean = True

		Dim reader As PdfReader = Nothing

		Try
			reader = New PdfReader(filepath)
		Catch
			Ret = False
		End Try

		Return Ret
	End Function
End Class