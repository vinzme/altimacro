﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Data
Imports System.Drawing
Imports System.Configuration
Imports System.Data.OleDb
Imports System.Globalization
Imports System.Web.Services
Imports System.Diagnostics

Public Class DirectReports
    Inherits System.Web.UI.Page

    Dim logsCount As Integer = 0
    Dim leaveCount As Integer = 0
    Dim totalCount As Integer = 0

    Dim dtLogsPending As DataTable
    Dim dtLeavesPending As DataTable

    Dim dtEmp As New DataTable
    Dim cls As New clsConnection
    'Dim temp As New GridTemplate
    Dim pubUser As String
    Dim employeeID As String
    Dim employeeName As String
    Dim employeeSupervisor As String
    Dim employeeDepartment As String
    Dim employeeLocation As String
    Dim employeeDoj As String
    Dim employeeApprover As String
    Dim employeeLevel As String

    Dim pubUserMode As String
    Dim ExpiredMinutes As Integer

    'Dim cls As New clsConnection
    'Dim pubUser As String
    Dim pubUserStatus As String
    Dim pubUserStatusTag As String
    Dim pubServerDateTime As String
    Dim pubActivityID As Integer
    Dim pubIdleTimeInserted As Boolean = False
    Dim pubIdleMinutes As Integer = 0
    Dim pubClickOKIdle As Boolean = False
    Dim pubAspectNRStatus As String
    Dim pubLogsYesNo As String
    Dim pubLeaveYesNo As String
    Dim pubSeries As String
    Dim pubIsPaid As String
    Dim pubReasonDesc As String
    Dim pubLeaveDate As String
    Dim pubEmpID As String
    Dim pubLeaveName As String
    Dim pubReason As String
    Dim pubLogIsPaid As String
    Dim leaveDate As String
    Dim leaveUser As String
    Dim pubIsHalfDay As String
    Dim pubLeaveType As String
    Dim pubPayment As String
    Dim pubLeaveNTID As String

    'Dim dtEmp As New DataTable

    Dim dtChkHoliday As DataTable
    Dim dtChkLeave As DataTable
    Dim dtChkLeaveExisting As DataTable
    Dim dtHoliday_spcW As New DataTable
    Dim dtHoliday_reg As New DataTable
    Dim dtHolidays As New DataTable
    Dim dtSchedule As New DataTable
    Dim dtLastActivity As New DataTable
    Dim dtLastDateApplied As New DataTable
    Dim dtSelectedLeaveDates As New DataTable
    Dim dtLastSched As New DataTable
    Dim dtCountLogs As New DataTable
    Dim dtCountLeaves As New DataTable
    Dim dtScheduleBackup As New DataTable
    Dim dtNTID As New DataTable

    Dim dtLeave As New DataTable
    Dim dtSchedTemp As New DataTable

    Dim errTag As Integer = 0
    Dim overrideTag As Integer = 0
    Dim arrayStr As String = ""
    Dim errTagStr As String = ""

    Dim fullName As String = ""

    Dim dtLogin As DateTime
    Dim gSelectedDate As String

    Dim totaltime As Integer = 0

    'Connections
    Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim sqlConn As SqlConnection = New SqlConnection(connStr)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        pubUser = Session("userID")

        If pubUser Is Nothing Then
            Session("page") = "~/DirectReports.aspx"
            Response.Redirect("~/Home.aspx")
        End If

        'Try
        '	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
        '	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

        '	Dim sUser() As String = Split(DomainUser, "/")

        '	'Dim sDomain As String = suser(0)
        '	Dim sUserId As String = LCase(sUser(1))

        '	pubUser = sUserId
        '	pubUser = "sainibha"
        'Catch ex As Exception
        '	pubUser = "sainibha"
        'End Try

        GetEmpInfo()

        If Not Page.IsPostBack Then

            GetLastActivity()

            If dtEmp.Rows.Count > 0 Then

                PopulateTreeView()

                employeeID = dtEmp.Rows(0)("EmpID")

                empID.Text = pubUser

                employeeLevel = dtEmp.Rows(0)("EmpLevel")

                Dim year As String = Convert.ToInt32(DateTime.Now.Year).ToString

                Dim yearRes As String = ""

                yearRes = year.Substring(2)

                Dim items As New List(Of ListItem)()
                For i As Integer = -16 To 0
                    'Populating the Year Values in dropdown
                    items.Add(New ListItem(DateTime.Now.AddYears(i).Year, DateTime.Now.AddYears(i).Year))
                Next

                For j As Integer = 1 To 4
                    'Populating the Year Values in dropdown
                    items.Add(New ListItem(DateTime.Now.AddYears(j).Year, DateTime.Now.AddYears(j).Year))
                Next

                ddlYear.DataSource = items
                ddlYear.DataBind()
                ddlYear.Items(Convert.ToInt32(yearRes) - 1).Selected = True

                BindLogsValidation()
                BindLeaveValidation()
                BindLogsReport()
                BindLeaveReport()
                'getDPNotifs()
            End If

            CountLogs()
            CountLeaves()

            If dtCountLogs.Rows.Count > 0 Then
                If dtCountLogs.Rows(0)("PendingLogs") <> 0 Then
                    badgeLogs.Style.Add("background-color", "red")
                    lblLogsPending.ForeColor = Color.White
                End If
                lblLogsPending.Text = dtCountLogs.Rows(0)("PendingLogs")
                badgeLogs.Visible = True
            Else
                badgeLogs.Visible = False
            End If

            If dtCountLeaves.Rows.Count > 0 Then
                If dtCountLeaves.Rows(0)("PendingLeave") <> 0 Then
                    badgeLeave.Style.Add("background-color", "red")
                    lblLeavePending.ForeColor = Color.White
                End If
                lblLeavePending.Text = dtCountLeaves.Rows(0)("PendingLeave")
                badgeLeave.Visible = True
            Else
                badgeLeave.Visible = False
            End If

        End If
        'End If

    End Sub

    Private Sub GetLastActivity()
        Dim query As String

        query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' order by seriesid desc"

        dtLastActivity = cls.GetData(query)
    End Sub

    Private Sub GetEmpInfo()

        Dim qry As String = ""

        qry = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

        dtEmp = cls.GetData(qry)

    End Sub

    Public Function PopulateReasonDesc() As Data.DataSet
        Dim da As SqlDataAdapter = New SqlDataAdapter("select ReasonDesc from tbl_HRMS_PAY_Reason (nolock)", sqlConn)
        Dim ds As Data.DataSet = New Data.DataSet()
        da.Fill(ds, "tblReasonDesc")
        Return ds
    End Function

    Private Sub PopulateTreeView()

        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Dim parentAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster where BusinessSegment = 'Financial Services' and AccessLevel is not null and NTID = '" & pubUser & "' order by EmpName", sqlConn)

            Dim dtParent As DataTable = New DataTable()

            parentAdapter.Fill(dtParent)
            Dim index As Integer = -1
            Dim drParent As DataRow
            For Each drParent In dtParent.Rows
                Dim childAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster where BusinessSegment = 'Financial Services' and AccessLevel is not null and NTID <> '" & pubUser & "' order by EmpName", sqlConn)
                Dim dtChild As DataTable = New DataTable()
                childAdapter.Fill(dtChild)
                index = index + 1
                Dim parent As TreeNode = New TreeNode()
                parent.Value = drParent("NTID").ToString()
                parent.Text = drParent("EmpName").ToString()
                TreeView1.Nodes.Add(parent)
                Dim drChild As DataRow
                For Each drChild In dtChild.Rows
                    If dtChild.Rows.Count > 0 Then
                        Dim child As TreeNode = New TreeNode()
                        child.Value = drChild("NTID").ToString()
                        child.Text = drChild("EmpName").ToString()
                        TreeView1.Nodes(index).ChildNodes.Add(child)
                    End If
                Next
            Next
        Else
            Dim parentAdapter As New SqlDataAdapter("select Empname, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & MngrNTID & "' " & _
                                                    "and AccessLevel is not null order by EmpName", sqlConn)

            Dim dtParent As DataTable = New DataTable()

            parentAdapter.Fill(dtParent)
            Dim index As Integer = -1
            Dim drParent As DataRow
            For Each drParent In dtParent.Rows
                Dim childAdapter As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drParent("NTID").ToString & "' " & _
                                                       "and AccessLevel is not null order by EmpName", sqlConn)
                Dim dtChild As DataTable = New DataTable()
                childAdapter.Fill(dtChild)
                index = index + 1
                Dim parent As TreeNode = New TreeNode()
                parent.Value = drParent("NTID").ToString()
                parent.Text = drParent("EmpName").ToString()
                TreeView1.Nodes.Add(parent)
                Dim drChild As DataRow
                If dtChild.Rows.Count > 0 Then

                    Dim index2 As Integer = -1
                    For Each drChild In dtChild.Rows

                        'Dim child As TreeNode = New TreeNode()
                        'child.Value = drChild("NTID").ToString()
                        'child.Text = drChild("EmpName").ToString()
                        'TreeView1.Nodes(index).ChildNodes.Add(child)

                        Dim childAdapter2 As New SqlDataAdapter("select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drChild("NTID").ToString & "' " & _
                                                       "and AccessLevel is not null order by EmpName", sqlConn)
                        Dim dtChild2 As DataTable = New DataTable()
                        childAdapter2.Fill(dtChild2)
                        index2 = index2 + 1

                        Dim child As TreeNode = New TreeNode()
                        child.Value = drChild("NTID").ToString()
                        child.Text = drChild("EmpName").ToString()
                        TreeView1.Nodes(index).ChildNodes.Add(child)

                        If dtChild2.Rows.Count > 0 Then
                            Dim drChild2 As DataRow
                            For Each drChild2 In dtChild2.Rows

                                Dim child2 As TreeNode = New TreeNode()
                                child2.Value = drChild2("NTID").ToString()
                                child2.Text = drChild2("EmpName").ToString()
                                TreeView1.Nodes(index).ChildNodes(index2).ChildNodes.Add(child2)

                            Next
                        End If
                    Next
                End If
            Next
        End If



    End Sub

    Private Sub UpdateActivityStatus()

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Activity set TotalTimeHour = cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal)/60 as nvarchar(18)), Activity_Status = '" & pubLogsYesNo.Trim & "', Approved_Time = '" & pubServerDateTime.Trim & "', Reason = '" & pubReason.Trim & "', IsPaid = '" & pubLogIsPaid.Trim & "', ApprovedBy = '" & pubUser.Trim & "' where SeriesID = '" & pubSeries.Trim & "'"

        cmdUpdate.Connection = sqlConn
        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()

    End Sub

    Private Sub UpdateTimeMinHour()

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)), " & _
                                    "TotalTimeHour = cast(cast(DATEDIFF(MINUTE,Start_Time,End_Time) as decimal)/60 as nvarchar(18)) where SeriesID = '" & pubSeries.Trim & "'"

        cmdUpdate.Connection = sqlConn
        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()

    End Sub

    Private Sub UpdateActivityIsPaid()

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update tbl_HRMS_Employee_Activity set IsPaid = '" & pubIsPaid.Trim & "' where SeriesID = '" & pubSeries.Trim & "'"

        cmdUpdate.Connection = sqlConn
        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()

    End Sub

    Private Sub GetReasonIfPaid()
        Dim query As String
        Dim i As Integer

        Try
            sqlConn.Open()
            i = 0

            query = "Select Category from dbo.tbl_HRMS_PAY_Reason (nolock) where ReasonDesc = '" & pubReasonDesc.Trim & "'"

            Dim MySqlCmd As New SqlCommand(query, sqlConn)
            Dim mReader As SqlDataReader

            mReader = MySqlCmd.ExecuteReader()
            If mReader.HasRows Then
                While mReader.Read()

                    If mReader("Category".Trim) = "Ready" Or mReader("Category".Trim) = "Park" Then
                        pubIsPaid = "YES"
                    Else
                        pubIsPaid = "NO"
                    End If

                End While

            End If

        Catch ex As Exception

        Finally
            sqlConn.Close()
        End Try

    End Sub

    Private Sub leaveValidationGrid_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles leaveValidationGrid.RowCommand

        Select Case e.CommandName
            Case "Update"
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = leaveValidationGrid.Rows(rowindex)

                If row IsNot Nothing Then
                    pubLeaveDate = row.Cells(1).Text.Trim
                End If

                'emp id
                Dim lbl3 As TextBox = DirectCast(row.FindControl("TextBox22"), TextBox)
                pubEmpID = lbl3.Text.Trim

                'yes/no
                Dim lbl2 As DropDownList = DirectCast(row.FindControl("ddlLeave"), DropDownList)
                If lbl2.Text.Trim = "YES" Then
                    pubLogsYesNo = "Approved"
                Else
                    pubLogsYesNo = "Denied"
                End If

                GetServerDateTime()

                UpdateLeaveMaster()

        End Select

        leaveValidationGrid.DataBind()

    End Sub

    Private Sub GetServerDateTime()

        Dim query As String

        Dim mserverdatetime As DateTime

        Try
            sqlConn.Open()
            query = "select getdate() as logdate"

            Dim MySqlCmd As New SqlCommand(query, sqlConn)
            Dim mReader As SqlDataReader

            mReader = MySqlCmd.ExecuteReader()
            If mReader.HasRows Then

                While mReader.Read()

                    mserverdatetime = mReader("logdate")

                    pubServerDateTime = mserverdatetime

                End While

            End If

        Catch ex As Exception

        Finally
            sqlConn.Close()
        End Try

    End Sub

    Private Sub UpdateLeaveMaster()

        Dim mLeaveDate As String = Session("SessionLeaveDate")

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update dbo.tbl_HRMS_LeaveMaster set ApprovedBy = '" & pubUser.Trim & "', DateApproved = '" & pubServerDateTime.Trim & _
                                    "', LeaveStatus = '" & pubLogsYesNo.Trim & "', LastDateModified = '" & _
                                    pubServerDateTime.Trim & "' where EmpID = '" & pubEmpID.Trim & "' and LeaveDate = '" & pubLeaveDate.Trim & "'"

        cmdUpdate.Connection = sqlConn
        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()

    End Sub

    Protected Sub TreeView1_SelectedNodeChanged(sender As Object, e As EventArgs) Handles TreeView1.SelectedNodeChanged
        treeviewLabel.Text = TreeView1.SelectedNode.Text & "'s Schedule: "
        lblUserSched.Text = TreeView1.SelectedValue.Trim.ToString
        GetSched()
        PopulateSchedule()
    End Sub

    Private Sub UpdateTimeMinToZero()

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = '0' where SeriesID = '" & pubSeries.Trim & "'"

        cmdUpdate.Connection = sqlConn
        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()

    End Sub

    Private Sub GetNTID(name As String)
        Dim qry As String = ""

        qry = "select * from tbl_HRMS_EmployeeMaster where EmpName = '" & name & "' and AccessLevel is not null"

        dtNTID = cls.GetData(qry)
    End Sub

    Private Sub LoopLeaveGrid()

        Dim dr As GridViewRow
        Dim gIndex As Integer = 0
        For Each dr In leaveValidationGrid.Rows

            Dim lbl3 As DropDownList = DirectCast(leaveValidationGrid.Rows(gIndex).FindControl("ddlLeave"), DropDownList)
            If lbl3.Text.Trim = "Approved" Or
                lbl3.Text.Trim = "Deny" Then
                If gIndex = -1 Then
                    gIndex = 0
                End If

                pubLeaveName = leaveValidationGrid.Rows(gIndex).Cells(0).Text
                pubLeaveDate = leaveValidationGrid.Rows(gIndex).Cells(1).Text
                pubIsHalfDay = leaveValidationGrid.Rows(gIndex).Cells(3).Text
                pubLeaveType = leaveValidationGrid.Rows(gIndex).Cells(4).Text
                pubPayment = leaveValidationGrid.Rows(gIndex).Cells(5).Text

                GetNTID(pubLeaveName)

                pubLeaveNTID = dtNTID.Rows(0)("NTID")

                If lbl3.Text.Trim = "Approved" Then
                    pubLeaveYesNo = "Approved"
                    'Update Schedule
                    CheckSchedule(pubLeaveNTID, pubLeaveDate)
                    Dim cmdUpdateSched As New SqlCommand
                    Dim cmdInsertBackup As New SqlCommand
                    If dtSchedule.Rows.Count > 0 Then
                        'Transfer current schedule to back up table
                        cmdInsertBackup.CommandText = "insert into tbl_HRMS_Employee_Schedule_Backup(LoginID, SchedDate, SchedIN, SchedOUT, Break1, Lunch, Break2, Logout_Tag, SchedType, Timestamp) " & _
                                                "Select LoginID, SchedDate, SchedIN, SchedOUT, Break1, Lunch, Break2, Logout_Tag, SchedType, GETDATE() from tbl_HRMS_Employee_Schedule (nolock) " & _
                                                "where LoginID = '" & pubLeaveNTID & "' and SchedDate = '" & pubLeaveDate & "'"

                        Try
                            sqlConn.Open()
                            cmdInsertBackup.Connection = sqlConn
                            cmdInsertBackup.ExecuteNonQuery()
                        Catch ex As Exception
                        Finally
                            sqlConn.Close()
                        End Try

                        'Update schedule table

                        cmdUpdateSched.CommandText = "update a " & _
                                                     "set " & _
                                                     "a.SchedIN =  CASE when b.isHalfDay = 0 then null  else case when b.halfDayPart = 1 then a.SchedIN when b.halfDayPart = 2 then Cast(Dateadd(hh,-4,Cast(a.SchedOUT as datetime)) as varchar) when b.halfDayPart = 0 then a.SchedIN end end, " & _
                                                     "a.SchedOut = CASE when b.isHalfDay = 0 then null else case when b.halfDayPart = 1 then CAST(DATEADD(hh, +4, Cast(a.SchedIN as datetime)) as varchar) when b.halfDayPart = 2 then a.SchedOUT when b.halfDayPart = 0 then a.SchedOUT end end, " & _
                                                     "a.Break1 = CASE when b.isHalfDay = 0 then null else case when b.halfDayPart = 1 then a.Break1 when b.halfDayPart = 2 then null when b.halfDayPart = 0 then a.Break1 end end, " & _
                                                     "a.Lunch = null, " & _
                                                     "a.Break2 = CASE when b.isHalfDay = 0 then null else case when b.halfDayPart = 1 then null when b.halfDayPart = 2 then a.Break2 when b.halfDayPart = 0 then a.Break2 end end, " & _
                                                     "a.Logout_Tag = 'YES', a.SchedType = '" & pubLeaveType & "', a.EditedBy = '" & pubUser & "', a.DateEdited = GETDATE() " & _
                                                     "from tbl_HRMS_Employee_Schedule a " & _
                                                     "join tbl_HRMS_LeaveMaster b " & _
                                                     "on a.LoginID = b.EmpID and a.SchedDate = b.LeaveDate " & _
                                                     "outer apply (select cast(cast(DATEDIFF(MINUTE,a.SchedIN,a.SchedOUT) as decimal)/60 as decimal)/2 [datediff]) c " & _
                                                     "outer apply (select dateadd(hh,+c.[datediff],a.SchedIN) [dateadd]) d " & _
                                                     "where a.LoginID = '" & pubLeaveNTID & "' and a.SchedDate = '" & pubLeaveDate & "' "

                        Try
                            sqlConn.Open()
                            cmdUpdateSched.Connection = sqlConn
                            cmdUpdateSched.ExecuteNonQuery()
                        Catch ex As Exception
                        Finally
                            sqlConn.Close()
                        End Try
                    Else
                        'Insert
                        cmdUpdateSched.CommandText = "insert into tbl_HRMS_Employee_Schedule (LoginID, SchedDate, SchedIN, SchedOUT, Break1, Lunch, Break2, Logout_Tag, SchedType, UploadedBy, DateUploaded) " & _
                                                     "values ('" & pubLeaveNTID & "', '" & pubLeaveDate & "', Null, Null, Null, Null, Null, 'YES', '" & Trim(pubLeaveType) & "', '" & pubUser & "', GETDATE())"

                        Try
                            sqlConn.Open()
                            cmdUpdateSched.Connection = sqlConn
                            cmdUpdateSched.ExecuteNonQuery()
                        Catch ex As Exception
                        Finally
                            sqlConn.Close()
                        End Try
                    End If
                Else
                    pubLeaveYesNo = "Denied"
                End If

                UpdateLeaveSubmitted()

                If pubLeaveYesNo = "Denied" And
                    pubPayment = "Paid" Then
                    If pubLeaveType <> "RHD" And pubLeaveType <> "SHD" Then
                        If pubLeaveType = "CTO" Then
                            UpdateLeaveBalanceCTO()
                        Else
                            UpdateLeaveBalancePTO()
                        End If
                    End If
                End If
            Else

            End If

            gIndex += 1
        Next

        leaveValidationGrid.DataBind()

    End Sub

    Private Sub LoopLogGrid()

        Dim dr As GridViewRow
        Dim gIndex As Integer = 0
        For Each dr In logsValidationGrid.Rows

            Dim lbl3 As DropDownList = DirectCast(logsValidationGrid.Rows(gIndex).FindControl("ddlLogs"), DropDownList)
            If lbl3.Text.Trim = "Approved" Or
                lbl3.Text.Trim = "Deny" Then
                If gIndex = -1 Then
                    gIndex = 0
                End If

                'series 
                Dim lbl2 As Label = DirectCast(logsValidationGrid.Rows(gIndex).FindControl("Label2"), Label)
                pubSeries = lbl2.Text.Trim

                'yes/no

                If lbl3.Text.Trim = "Approved" Then
                    pubLogsYesNo = "Approved"
                    pubLogIsPaid = "YES"
                Else
                    pubLogsYesNo = "Denied"
                    pubLogIsPaid = "NO"
                    UpdateTimeMinToZero()
                End If

                Dim txtBoxDenyReason As TextBox = DirectCast(logsValidationGrid.Rows(gIndex).FindControl("txtBoxDenyReason"), TextBox)
                pubReason = txtBoxDenyReason.Text.Trim

                GetServerDateTime()
                UpdateActivityStatus()

                totalCount -= 1
            Else

            End If

            gIndex += 1
        Next

        logsValidationGrid.DataBind()

    End Sub

    Private Sub CountLogs()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Dim query As String

            query = "select Count(a.Activity_Status) as PendingLogs from tbl_HRMS_Employee_Activity a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.BusinessSegment = 'Financial Services' and a.Activity_Status = 'Pending' and a.ReasonID not in (1,14)"

            dtCountLogs = cls.GetData(query)
        Else
            Dim query As String

            query = "select Count(a.Activity_Status) as PendingLogs from tbl_HRMS_Employee_Activity a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.MngrNTID = '" & pubUser.Trim & "' and a.Activity_Status = 'Pending' and a.ReasonID not in (1,14)"

            dtCountLogs = cls.GetData(query)
        End If

    End Sub

    Private Sub CountLeaves()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Dim query As String

            query = "select Count(a.LeaveStatus) as PendingLeave from tbl_HRMS_LeaveMaster a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.EmpID = b.NTID where b.BusinessSegment = 'Financial Services' and a.LeaveStatus = 'Pending'"
            dtCountLeaves = cls.GetData(query)
        Else
            Dim query As String

            query = "select Count(a.LeaveStatus) as PendingLeave from tbl_HRMS_LeaveMaster a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.EmpID = b.NTID where b.NTID in ( select NTID from tbl_HRMS_EmployeeMaster where MngrNTID = '" & pubUser.Trim & "') and a.LeaveStatus = 'Pending'"

            dtCountLeaves = cls.GetData(query)
        End If
    End Sub

    Private Sub leaveSubmit_Click(sender As Object, e As EventArgs) Handles leaveSubmit.Click
        LoopLeaveGrid()

        CountLogs()
        CountLeaves()

        Dim logs As Integer = 0
        Dim leaves As Integer = 0

        If dtCountLogs.Rows.Count > 0 Then
            logs = Convert.ToInt32(dtCountLogs.Rows(0)("PendingLogs"))
        End If

        If dtCountLeaves.Rows.Count > 0 Then
            leaves = Convert.ToInt32(dtCountLeaves.Rows(0)("PendingLeave"))
        End If

        'directReportsNotifs.Text = logs + leaves

        Dim site As MasterPage = TryCast(Me.Master, MasterPage)
        If site IsNot Nothing Then
            Dim directReportsNotifs As Label = TryCast(site.FindControl("directReportsNotifs"), Label)
            directReportsNotifs.Text = logs + leaves
        End If

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Submit Successful!'); clickModal4('lnkLeaves'); ", True)

    End Sub

    Private Sub GetLeaveLoginID()

        Dim query As String

        Try
            sqlConn.Open()
            query = "Select top 1 a.EmpID from dbo.tbl_HRMS_LeaveMaster a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) " & _
                        "on a.EmpID = b.NTID where b.EmpName = '" & pubLeaveName.Trim & "'"

            Dim MySqlCmd As New SqlCommand(query, sqlConn)
            Dim mReader As SqlDataReader

            mReader = MySqlCmd.ExecuteReader()
            If mReader.HasRows Then

                While mReader.Read()

                    pubEmpID = mReader("EmpID")

                End While

            End If

        Catch ex As Exception

        Finally
            sqlConn.Close()
        End Try

    End Sub

    Private Sub UpdateLeaveSubmitted()

        Dim cmdUpdate As New SqlCommand
        Try
            cmdUpdate.CommandText = "update dbo.tbl_HRMS_LeaveMaster set LeaveStatus = '" & pubLeaveYesNo.Trim & "', ApprovedBy = '" & pubUser.Trim & "', DateApproved = '" & DateTime.Now.ToString() & "', LastDateModified = '" & DateTime.Now.ToString() & "', Submitted = 'YES' where EmpID = '" & pubLeaveNTID.Trim & _
                    "' and LeaveDate = '" & pubLeaveDate & "'"

            cmdUpdate.Connection = sqlConn
            sqlConn.Open()
            cmdUpdate.ExecuteNonQuery()
            sqlConn.Close()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub UpdateLeaveBalancePTO()
        Dim cmdUpdate As New SqlCommand

        If pubIsHalfDay = "NO" Then
            cmdUpdate.CommandText = "update tbl_HRMS_EmployeeMaster set LeaveBal = LeaveBal + 1 where EmpName = '" & pubLeaveName.Trim & "'"
        Else
            cmdUpdate.CommandText = "update tbl_HRMS_EmployeeMaster set LeaveBal = LeaveBal + 0.5 where EmpName = '" & pubLeaveName.Trim & "'"
        End If

        Try
            sqlConn.Open()
            cmdUpdate.Connection = sqlConn
            cmdUpdate.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub UpdateLeaveBalanceCTO()
        Dim cmdUpdate As New SqlCommand

        If pubIsHalfDay = "NO" Then
            cmdUpdate.CommandText = "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO + 1 where NTID = '" & pubLeaveName.Trim & "'"
        Else
            cmdUpdate.CommandText = "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO + 0.5 where NTID = '" & pubLeaveName.Trim & "'"
        End If

        Try
            sqlConn.Open()
            cmdUpdate.Connection = sqlConn
            cmdUpdate.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetSched()

        Dim dtSched = New DataTable
        Dim schedQuery As String = ""

        If ddlCutoff.SelectedItem.Text.Trim = "1 - 15" Then
            sched1.Text = ddlMonth.SelectedValue.Trim + "/01/" + ddlYear.SelectedItem.Text.Trim
            sched2.Text = ddlMonth.SelectedValue.Trim + "/15/" + ddlYear.SelectedItem.Text.Trim
        Else
            Select Case ddlMonth.SelectedItem.Text.Trim
                Case "January"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "February"
                    If Val(ddlYear.SelectedItem.Text) Mod 4 = 0 Then
                        sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                        sched2.Text = ddlMonth.SelectedValue.Trim + "/29/" + ddlYear.SelectedItem.Text.Trim
                    Else
                        sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                        sched2.Text = ddlMonth.SelectedValue.Trim + "/28/" + ddlYear.SelectedItem.Text.Trim
                    End If
                Case "March"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "April"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/30/" + ddlYear.SelectedItem.Text.Trim
                Case "May"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "June"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/30/" + ddlYear.SelectedItem.Text.Trim
                Case "July"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "August"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "September"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/30/" + ddlYear.SelectedItem.Text.Trim
                Case "October"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
                Case "November"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/30/" + ddlYear.SelectedItem.Text.Trim
                Case "December"
                    sched1.Text = ddlMonth.SelectedValue.Trim + "/16/" + ddlYear.SelectedItem.Text.Trim
                    sched2.Text = ddlMonth.SelectedValue.Trim + "/31/" + ddlYear.SelectedItem.Text.Trim
            End Select
        End If
    End Sub

    Private Sub PopulateSchedule()
        Try
            Dim sb As New StringBuilder

            sb.Append("select SeriesID as SeriesID, CONVERT(varchar(15), SchedDate, 107) as Date, ")
            sb.Append("SUBSTRING(DATENAME(dw, SchedDate), 1,3) as Day,  ")
            sb.Append("CASE  ")
            sb.Append("WHEN SchedType = 'RD' THEN 'RD' ")
            sb.Append("WHEN SchedType = 'PTO' THEN 'PTO' ")
            sb.Append("WHEN SchedType = 'CTO' THEN 'CTO' ")
            sb.Append("WHEN SchedType = 'RTWO' THEN 'RTWO' ")
            sb.Append("WHEN SchedType = 'LOA' THEN 'LOA' ")
            sb.Append("WHEN SchedType = 'LWOP' THEN 'LWOP' ")
            sb.Append("WHEN SchedType = 'PAT' THEN 'PAT' ")
            sb.Append("WHEN SchedType = 'MAT' THEN 'MAT' ")
            sb.Append("ELSE RIGHT(CONVERT(varchar, SchedIN, 100), 7)  ")
            sb.Append("END as Login,  ")
            sb.Append("CASE  ")
            sb.Append("WHEN SchedType = 'RD' THEN 'RD' ")
            sb.Append("WHEN SchedType = 'PTO' THEN 'PTO' ")
            sb.Append("WHEN SchedType = 'CTO' THEN 'CTO' ")
            sb.Append("WHEN SchedType = 'RTWO' THEN 'RTWO' ")
            sb.Append("WHEN SchedType = 'LOA' THEN 'LOA' ")
            sb.Append("WHEN SchedType = 'LWOP' THEN 'LWOP' ")
            sb.Append("WHEN SchedType = 'PAT' THEN 'PAT' ")
            sb.Append("WHEN SchedType = 'MAT' THEN 'MAT' ")
            sb.Append("ELSE RIGHT(CONVERT(varchar, Break1, 100), 7)  ")
            sb.Append("END as Break1,  ")
            sb.Append("CASE  ")
            sb.Append("WHEN SchedType = 'RD' THEN 'RD' ")
            sb.Append("WHEN SchedType = 'PTO' THEN 'PTO' ")
            sb.Append("WHEN SchedType = 'CTO' THEN 'CTO' ")
            sb.Append("WHEN SchedType = 'RTWO' THEN 'RTWO' ")
            sb.Append("WHEN SchedType = 'LOA' THEN 'LOA' ")
            sb.Append("WHEN SchedType = 'LWOP' THEN 'LWOP' ")
            sb.Append("WHEN SchedType = 'PAT' THEN 'PAT' ")
            sb.Append("WHEN SchedType = 'MAT' THEN 'MAT' ")
            sb.Append("ELSE RIGHT(CONVERT(varchar, Lunch, 100), 7)  ")
            sb.Append("END as Lunch,  ")
            sb.Append("CASE  ")
            sb.Append("WHEN SchedType = 'RD' THEN 'RD' ")
            sb.Append("WHEN SchedType = 'PTO' THEN 'PTO' ")
            sb.Append("WHEN SchedType = 'CTO' THEN 'CTO' ")
            sb.Append("WHEN SchedType = 'RTWO' THEN 'RTWO' ")
            sb.Append("WHEN SchedType = 'LOA' THEN 'LOA' ")
            sb.Append("WHEN SchedType = 'LWOP' THEN 'LWOP' ")
            sb.Append("WHEN SchedType = 'PAT' THEN 'PAT' ")
            sb.Append("WHEN SchedType = 'MAT' THEN 'MAT' ")
            sb.Append("ELSE RIGHT(CONVERT(varchar, Break2, 100), 7) ")
            sb.Append("END as Break2,  ")
            sb.Append("CASE  ")
            sb.Append("WHEN SchedType = 'RD' THEN 'RD' ")
            sb.Append("WHEN SchedType = 'PTO' THEN 'PTO' ")
            sb.Append("WHEN SchedType = 'CTO' THEN 'CTO' ")
            sb.Append("WHEN SchedType = 'RTWO' THEN 'RTWO' ")
            sb.Append("WHEN SchedType = 'LOA' THEN 'LOA' ")
            sb.Append("WHEN SchedType = 'LWOP' THEN 'LWOP' ")
            sb.Append("WHEN SchedType = 'PAT' THEN 'PAT' ")
            sb.Append("WHEN SchedType = 'MAT' THEN 'MAT' ")
            sb.Append("ELSE RIGHT(CONVERT(varchar, SchedOUT, 100), 7) ")
            sb.Append("END as Logout  ")
            sb.Append("from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate BETWEEN '" & sched1.Text.Trim & "'  ")
            sb.Append("and '" & sched2.Text.Trim & "' order by SchedDate ")


            Dim query As String = sb.ToString
            sb.Clear()

            Dim myAdapter As New SqlDataAdapter(query, sqlConn)

            sqlConn.Open()

            scheduleGrid.Visible = True

            Dim dt As Data.DataTable = New Data.DataTable

            myAdapter.Fill(dt)

            scheduleGrid.DataSource = dt

            scheduleGrid.EmptyDataText = "No Schedule!"
            scheduleGrid.DataBind()

            sqlConn.Close()
        Catch ex As Exception
            scheduleGrid.Visible = False
            scheduleGrid.DataSource = Nothing
        End Try
    End Sub

    Private Sub logSubmit_Click(sender As Object, e As EventArgs) Handles logSubmit.Click
        LoopLogGrid()

        Dim dtLogsPending As DataTable
        Dim qry As String = ""

        qry = "select a.SeriesID, b.EmpName, CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc from tbl_HRMS_Employee_Activity a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c (nolock) on a.ReasonID = c.ReasonID where b.MngrNTID = '" & pubUser & "' and a.Activity_Status = 'Pending' and a.Activity_Tag = 'OK'"

        dtLogsPending = cls.GetData(qry)

        CountLogs()
        CountLeaves()

        Dim logs As Integer = 0
        Dim leaves As Integer = 0

        If dtCountLogs.Rows.Count > 0 Then
            logs = Convert.ToInt32(dtCountLogs.Rows(0)("PendingLogs"))
        End If

        If dtCountLeaves.Rows.Count > 0 Then
            leaves = Convert.ToInt32(dtCountLeaves.Rows(0)("PendingLeave"))
        End If

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Submit Successful!'); clickModal4('lnkLogs');", True)

    End Sub

    Private Sub UpdateSchedule()

        GetServerDateTime()

        Dim loginTime As String = ""
        Dim break1Time As String = ""
        Dim lunchTime As String = ""
        Dim break2Time As String = ""
        Dim logoutTime As String = ""
        Dim schedDate As String = ""
        Dim schedDate2 As String = ""
        Dim loginID As String = ""
        Dim seriesID As String = ""

        Dim cmdUpdateSchedule As New SqlCommand
        'Dim nxtRow As GridViewRow

        If scheduleGrid.Rows.Count <> 0 Then

            For x As Integer = 0 To scheduleGrid.Rows.Count - 1
                Dim row As GridViewRow = scheduleGrid.Rows(x)
                'If x < scheduleGrid.Rows.Count - 1 Then
                '    nxtRow = scheduleGrid.Rows(x + 1)
                '    schedDate2 = nxtRow.Cells(1).Text.Trim
                'End If

                schedDate = row.Cells(0).Text.Trim

                Dim lblSeriesID As Label = DirectCast(row.FindControl("lblSeriesID"), Label)

                seriesID = lblSeriesID.Text.Trim

                Dim txtbxLogin As TextBox = DirectCast(row.FindControl("txtBoxLogin"), TextBox)
                Dim txtbxBreak1 As TextBox = DirectCast(row.FindControl("txtBoxBreak1"), TextBox)
                Dim txtbxLunch As TextBox = DirectCast(row.FindControl("txtBoxLunch"), TextBox)
                Dim txtbxBreak2 As TextBox = DirectCast(row.FindControl("txtBoxBreak2"), TextBox)
                Dim txtbxLogout As TextBox = DirectCast(row.FindControl("txtBoxLogout"), TextBox)

                loginTime = txtbxLogin.Text.Trim
                break1Time = txtbxBreak1.Text.Trim
                lunchTime = txtbxLunch.Text.Trim
                break2Time = txtbxBreak2.Text.Trim
                logoutTime = txtbxLogout.Text.Trim


                Try
                    If loginTime <> "PTO" Or
                        loginTime <> "CTO" Then

                        If loginTime = "RD" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_Tag = 'YES', SchedType = 'RD' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        ElseIf loginTime = "RTWO" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_tag = 'YES', SchedType = 'RTWO' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        ElseIf loginTime = "LWOP" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_tag = 'YES', SchedType = 'LWOP' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        ElseIf loginTime = "LOA" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_tag = 'YES', SchedType = 'LOA' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        ElseIf loginTime = "PAT" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_tag = 'YES', SchedType = 'PAT' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        ElseIf loginTime = "MAT" Then
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = NULL, " & _
                                                            "SchedOUT = NULL, " & _
                                                            "Break1 = NULL, " & _
                                                            "Lunch = NULL, " & _
                                                            "Break2 = NULL, " & _
                                                            "Logout_tag = 'YES', SchedType = 'MAT' " & _
                                                            "where LoginID = '" & lblUserSched.Text.Trim & "' and SchedDate = '" & schedDate & "'"
                        Else
                            cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set " & _
                                                            "SchedIN = CASE WHEN '" & loginTime & "' = '' THEN NULL ELSE " & _
                                                            "CONVERT(datetime, '" & schedDate & "' + ' ' + '" & loginTime & "') end, " & _
                                                            "Break1 = CASE WHEN '" & break1Time & "' = '' THEN NULL ELSE " & _
                                                            "CASE WHEN DATEDIFF(HOUR, CONVERT(varchar(15), CAST('" & loginTime & "' AS TIME), 100), " & _
                                                            "CONVERT(varchar(15), CAST('" & break1Time & "' AS TIME), 100)) < 0 THEN " & _
                                                            "CONVERT(datetime, DATEADD(DAY, 1, '" & schedDate & "') + ' ' + '" & break1Time & "') else " & _
                                                            "CONVERT(datetime, '" & schedDate & "' + ' ' + '" & break1Time & "') end end , " & _
                                                            "Lunch = CASE WHEN '" & lunchTime & "' = '' THEN NULL ELSE " & _
                                                            "CASE WHEN DATEDIFF(HOUR, CONVERT(varchar(15), CAST('" & loginTime & "' AS TIME), 100), " & _
                                                            "CONVERT(varchar(15), CAST('" & lunchTime & "' AS TIME), 100)) < 0 THEN " & _
                                                            "CONVERT(datetime, DATEADD(DAY, 1, '" & schedDate & "') + ' ' + '" & lunchTime & "') else " & _
                                                            "CONVERT(datetime, '" & schedDate & "' + ' ' + '" & lunchTime & "') end end , " & _
                                                            "Break2 = CASE WHEN '" & break2Time & "' = '' THEN NULL ELSE " & _
                                                            "CASE WHEN DATEDIFF(HOUR, CONVERT(varchar(15), CAST('" & loginTime & "' AS TIME), 100), " & _
                                                            "CONVERT(varchar(15), CAST('" & break2Time & "' AS TIME), 100)) < 0 THEN " & _
                                                            "CONVERT(datetime, DATEADD(DAY, 1, '" & schedDate & "') + ' ' + '" & break2Time & "') else " & _
                                                            "CONVERT(datetime, '" & schedDate & "' + ' ' + '" & break2Time & "') end end , " & _
                                                            "SchedOUT = CASE WHEN '" & logoutTime & "' = '' THEN NULL ELSE " & _
                                                            "CASE WHEN DATEDIFF(HOUR, CONVERT(varchar(15), CAST('" & loginTime & "' AS TIME), 100), " & _
                                                            "CONVERT(varchar(15), CAST('" & logoutTime & "' AS TIME), 100)) < 0 THEN " & _
                                                            "CONVERT(datetime, DATEADD(DAY, 1, '" & schedDate & "') + ' ' + '" & logoutTime & "') else " & _
                                                            "CONVERT(datetime, '" & schedDate & "' + ' ' + '" & logoutTime & "') end end , " & _
                                                            "EditedBy = '" & pubUser.Trim & "', DateEdited = '" & pubServerDateTime.Trim & "', " & _
                                                            "SchedType = 'IN' where " & _
                                                            "LoginID = '" & lblUserSched.Text.Trim & "' and SeriesID = '" & seriesID & "'"
                        End If

                    End If

                    cmdUpdateSchedule.Connection = sqlConn
                    sqlConn.Open()
                    cmdUpdateSchedule.ExecuteNonQuery()

                Catch ex As Exception

                Finally
                    sqlConn.Close()
                End Try

                txtbxLogin.Visible = False
                txtbxBreak1.Visible = False
                txtbxLunch.Visible = False
                txtbxBreak2.Visible = False
                txtbxLogout.Visible = False

                Dim lblLogin As Label = DirectCast(row.FindControl("lblLogin"), Label)
                Dim lblBreak1 As Label = DirectCast(row.FindControl("lblBreak1"), Label)
                Dim lblLunch As Label = DirectCast(row.FindControl("lblLunch"), Label)
                Dim lblBreak2 As Label = DirectCast(row.FindControl("lblBreak2"), Label)
                Dim lblLogout As Label = DirectCast(row.FindControl("lblLogout"), Label)

                lblLogin.Visible = True
                lblBreak1.Visible = True
                lblLunch.Visible = True
                lblBreak2.Visible = True
                lblLogout.Visible = True

            Next
        End If
    End Sub

    Protected Sub PopulateRDPTO(sender As Object, e As EventArgs)
        If scheduleGrid.Rows.Count <> 0 Then

            Dim err As Boolean = False
            Dim errStr As String = ""

            For x = 0 To scheduleGrid.Rows.Count - 1
                Dim row As GridViewRow = scheduleGrid.Rows(x)
                Dim txtBoxLogin As TextBox = DirectCast(row.FindControl("txtBoxLogin"), TextBox)
                Dim txtBoxBreak1 As TextBox = DirectCast(row.FindControl("txtBoxBreak1"), TextBox)
                Dim txtBoxLunch As TextBox = DirectCast(row.FindControl("txtBoxLunch"), TextBox)
                Dim txtBoxBreak2 As TextBox = DirectCast(row.FindControl("txtBoxBreak2"), TextBox)
                Dim txtBoxLogout As TextBox = DirectCast(row.FindControl("txtBoxLogout"), TextBox)
                Dim loginText As String = txtBoxLogin.Text

                If txtBoxLogin.Text = "RD" Or
                    txtBoxLogin.Text = "LWOP" Or
                    txtBoxLogin.Text = "LOA" Or
                    txtBoxLogin.Text = "PAT" Or
                    txtBoxLogin.Text = "MAT" Then
                    txtBoxBreak1.Text = loginText
                    txtBoxLunch.Text = loginText
                    txtBoxBreak2.Text = loginText
                    txtBoxLogout.Text = loginText
                ElseIf txtBoxLogin.Text = "PTO" Or
                    txtBoxLogin.Text = "CTO" Then

                    ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Unable to change schedule, leaves should be filed directly at the HRMS website.')", True)

                    'txtBoxBreak1.Text = loginText
                    'txtBoxLunch.Text = loginText
                    'txtBoxBreak2.Text = loginText
                    'txtBoxLogout.Text = loginText
                Else

                    Dim datetimeLogin As DateTime = Convert.ToDateTime(txtBoxLogin.Text).ToShortTimeString

                    Dim login As String = datetimeLogin.ToShortTimeString()

                    Dim datetimeLogout As DateTime = DateAdd(DateInterval.Hour, +9, datetimeLogin)

                    Dim logout As String = datetimeLogout.ToShortTimeString()

                    txtBoxLogin.Text = login
                    txtBoxLogout.Text = logout

                End If

            Next
        End If
    End Sub

    Protected Sub ddlYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlYear.SelectedIndexChanged
        If lblUserSched.Text <> "" Then
            GetSched()
            PopulateSchedule()
        End If
    End Sub

    Private Sub ddlMonth_Load(sender As Object, e As EventArgs) Handles ddlMonth.Load
        If Not IsPostBack Then
            ddlMonth.SelectedIndex = Convert.ToInt32(DateTime.Now.Month) - 1
        End If
    End Sub

    Private Sub ddlMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlMonth.SelectedIndexChanged
        If lblUserSched.Text <> "" Then
            GetSched()
            PopulateSchedule()
        End If
    End Sub

    Private Sub ddlCutoff_Load(sender As Object, e As EventArgs) Handles ddlCutoff.Load
        If Not IsPostBack Then
            If Date.Now.Day <= 15 Then
                ddlCutoff.SelectedIndex = 0
            ElseIf Date.Now.Day > 15 And Date.Now.Day < 30 Then
                ddlCutoff.SelectedIndex = 1
            End If
        End If
    End Sub

    Private Sub ddlCutoff_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlCutoff.SelectedIndexChanged
        If lblUserSched.Text <> "" Then
            GetSched()
            PopulateSchedule()
        End If
    End Sub

    Private Sub saveSchedBtn_Click(sender As Object, e As EventArgs) Handles saveSchedBtn.Click

        'If lblUserSched.Text <> pubUser Then
        UpdateSchedule()
        PopulateSchedule()

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Save Successful!'); clickModal4('lnkViewSched');", True)
        'Else
        '	ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Cannot update your own schedule!'); clickModal4('lnkViewSched');", True)
        'End If

    End Sub

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        If FileUpload1.HasFile Then
            Dim FileName As String = pubUser.Trim & Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim Extension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim FolderPath As String = ConfigurationManager.AppSettings("FolderPath")
            Dim FilePath As String = Server.MapPath("~/Excel/" & FileName)
            FileUpload1.SaveAs(FilePath)
            UploadSchedule(FilePath, Extension, "Yes")

            Dim cmdInsertSched As New SqlCommand
            Dim cmdDeleteSched As New SqlCommand
            cmdInsertSched.Connection = sqlConn
            cmdDeleteSched.Connection = sqlConn
            Try

                If dtSchedTemp.Rows.Count > 0 Then
                    If errTag = 1 Then
                        'PROMPT < 12 HRS.
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Schedules with less than 12 hours between shifts are not allowed, Please check and Re upload again.')", True)
                    ElseIf errTag = 2 Then
                        'PROMPT PTO/CTO INVALID
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Please Re upload schedule, leaves should be filed directly at the HRMS website.')", True)
                    ElseIf errTag = 5 Then
                        'PROMPT PTO/CTO INVALID
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Please Re upload schedule, you can only upload schedules of the ff ntids: " & arrayStr.ToString() & ".')", True)
                    ElseIf errTag = 6 Then
                        'INVALID TAG
                        errTagStr = errTagStr.Remove(errTagStr.Length - 1, 1)
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Please Re upload schedule, Schedule contains Invalid Tag (" & errTagStr & ")!", True)
                    Else
                        'If overrideTag > 0 Then
                        'PROMPT OVERRIDE
                        'IF YES:
                        '- DELETE RECORDS
                        sqlConn.Close()
                        sqlConn.Open()
                        Try
                            For x As Integer = 0 To dtSchedTemp.Rows.Count - 1
                                cmdDeleteSched.CommandText = "delete from tbl_HRMS_Employee_Schedule where LoginID = LTRIM(RTRIM('" & dtSchedTemp.Rows(x)("LoginID") & "')) and SchedDate = CAST('" & dtSchedTemp.Rows(x)("SchedDate") & "' as date);"
                                cmdDeleteSched.ExecuteNonQuery()
                            Next
                        Catch ex As Exception
                        Finally
                            sqlConn.Close()
                        End Try
                        sqlConn.Open()
                        Try
                            '- INSERT NEW RECORDS
                            cls.SQLBulkCopy("tbl_HRMS_Employee_Schedule", dtSchedTemp)

                        Catch ex As Exception
                            Debug.WriteLine(ex)
                        Finally
                            sqlConn.Close()
                        End Try
                    End If
                Else
                    If errTag = 3 Then
                        'PROMPT SAME USER INVALID
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Please check your file. You cannot upload your own schedule')", True)
                    Else
                        'PROMPT PTO/CTO INVALID
                        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Please Re upload schedule, leaves should be filed directly at the HRMS website.')", True)
                    End If
                End If
            Catch ex As Exception
                ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('" & ex.Message & "'); console.log('" & ex.ToString & "');", True)

                Debug.WriteLine(ex)

            Finally
                'sqlConn.Close()
            End Try

            Dim cmdUpdateFiles As New SqlCommand

            cmdUpdateFiles.Connection = sqlConn
            Try
                sqlConn.Open()
                cmdUpdateFiles.CommandText = "insert into tbl_HRMS_UploadedFiles(UploadedBy, Filename, Timestamp) " & _
                                            "values('" & pubUser.Trim & "', '" & FileName.Trim & "', '" & DateTime.Now.ToString() & "')"
                cmdUpdateFiles.ExecuteNonQuery()
            Catch ex As Exception
            Finally
                sqlConn.Close()
            End Try

            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Upload Successful!'); clickModal4('lnkUploadSched');", True)
        End If
    End Sub

    Private Sub UploadSchedule(ByVal FilePath As String, ByVal Extension As String, ByVal isHDR As String)

        GetServerDateTime()

        Dim excelConnStr As String = ""
        Select Case Extension
            Case ".xls"
                'Excel 97-03
                excelConnStr = ConfigurationManager.ConnectionStrings("Excel03ConString") _
                    .ConnectionString
                Exit Select
            Case ".xlsx"
                'Excel 07
                excelConnStr = ConfigurationManager.ConnectionStrings("Excel07ConString") _
                    .ConnectionString
                Exit Select
        End Select

        'Get the Sheets in Excel WorkBook
        excelConnStr = String.Format(excelConnStr, FilePath, isHDR)
        Dim oleDbConn As New OleDbConnection(excelConnStr)
        oleDbConn.Open()

        Dim dt As DataTable = oleDbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
        Dim sheetname As String = dt.Rows(0)("Table_Name").ToString()
        Dim query As String = "SELECT * FROM [" + sheetname + "]"
        Dim cmdExcel As New OleDbCommand(query, oleDbConn)
        Dim rdr As OleDbDataReader = cmdExcel.ExecuteReader()

        Dim cmd As New SqlCommand

        Dim qry As String = ""
        Dim dtSchedSettings As New DataTable
        Dim sb As New StringBuilder
        Dim arr As New ArrayList()

        qry = "select * from tbl_HRMS_SchedUpload_Settings where DeletedBy is null"

        dtSchedSettings = cls.GetData(qry)

        If dtSchedSettings.Rows.Count > 0 Then
            For x As Integer = 0 To dtSchedSettings.Rows.Count - 1
                Dim personToModify As String = dtSchedSettings.Rows(x)("PersonToModify")

                Dim elements() As String = personToModify.Split(New Char() {","c}, StringSplitOptions.RemoveEmptyEntries)

                For Each element As String In elements
                    If Not (arr.Contains(element)) Then
                        arr.Add(element)
                        Debug.WriteLine(element)
                    End If
                    'sb.Append("'" & element & "',")
                Next
            Next
        End If

        cmd.Connection = sqlConn
        sqlConn.Open()
        Dim count As Integer = 0
        Dim var As String = ""
        Dim ctBlanks As Integer = 0

        'dtSchedTemp.Columns.AddRange(New DataColumn(13) {New DataColumn("LoginID", GetType(String)), New DataColumn("SchedDate", GetType(Date)), New DataColumn("SchedIN", GetType(DateTime)), New DataColumn("SchedOUT", GetType(DateTime)), New DataColumn("HoursWorked", GetType(String)), New DataColumn("Logout_Tag", GetType(String)), New DataColumn("SchedType", GetType(String)), New DataColumn("Break1", GetType(DateTime)), New DataColumn("Lunch", GetType(DateTime)), New DataColumn("Break2", GetType(DateTime)), New DataColumn("UploadedBy", GetType(String)), New DataColumn("DateUploaded", GetType(DateTime)), New DataColumn("EditedBy", GetType(String)), New DataColumn("DateEdited", GetType(DateTime))})

        Dim colid As DataColumn = dtSchedTemp.Columns.Add("SeriesID", GetType(Integer))
        colid.AllowDBNull = True
        Dim colLoginID As DataColumn = dtSchedTemp.Columns.Add("LoginID", GetType(String))
        colLoginID.MaxLength = 20
        Dim colSchedDate As DataColumn = dtSchedTemp.Columns.Add("SchedDate", GetType(String))
        Dim colSchedIN As DataColumn = dtSchedTemp.Columns.Add("SchedIN", GetType(DateTime))
        colSchedIN.AllowDBNull = True
        Dim colSchedOUT As DataColumn = dtSchedTemp.Columns.Add("SchedOUT", GetType(DateTime))
        colSchedOUT.AllowDBNull = True
        Dim colHoursWorked As DataColumn = dtSchedTemp.Columns.Add("HoursWorked", GetType(String))
        colHoursWorked.MaxLength = 50
        colHoursWorked.AllowDBNull = True
        Dim colLogout_Tag As DataColumn = dtSchedTemp.Columns.Add("Logout_Tag", GetType(String))
        colLogout_Tag.MaxLength = 3
        colLogout_Tag.AllowDBNull = True
        Dim colSchedType As DataColumn = dtSchedTemp.Columns.Add("SchedType", GetType(String))
        colSchedType.MaxLength = 20
        Dim colBreak1 As DataColumn = dtSchedTemp.Columns.Add("Break1", GetType(DateTime))
        colBreak1.AllowDBNull = True
        Dim colLunch As DataColumn = dtSchedTemp.Columns.Add("Lunch", GetType(DateTime))
        colLunch.AllowDBNull = True
        Dim colBreak2 As DataColumn = dtSchedTemp.Columns.Add("Break2", GetType(DateTime))
        colBreak2.AllowDBNull = True
        Dim colUploadedBy As DataColumn = dtSchedTemp.Columns.Add("UploadedBy", GetType(String))
        colUploadedBy.MaxLength = 20
        Dim colDateUploaded As DataColumn = dtSchedTemp.Columns.Add("DateUploaded", GetType(DateTime))
        Dim colEditedBy As DataColumn = dtSchedTemp.Columns.Add("EditedBy", GetType(String))
        colEditedBy.MaxLength = 20
        colEditedBy.AllowDBNull = True
        Dim colDateEdited As DataColumn = dtSchedTemp.Columns.Add("DateEdited", GetType(DateTime))
        colDateEdited.AllowDBNull = True

        Dim id As Integer? = CType(Nothing, Integer?)
        Dim LogoutTag As String = "NO"
        Dim HoursWorked As String = Nothing
        Dim UploadedBy As String = pubUser
        Dim DateUploaded As DateTime = DateTime.Now.ToString()
        Dim EditedBy As String = Nothing
        Dim DateEdited As DateTime? = CType(Nothing, DateTime?)
        Dim Status As String = "NULL"

        While rdr.Read()
            Debug.WriteLine("Reading..... " & count.ToString())
            'ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "console.log('Reading.... '" & count.ToString() & ");", True)
            Try
                Dim LoginID As String = rdr(0).ToString().Trim

                If LoginID <> "" Then
                    ctBlanks = 0

                    Dim SchedDate As Date = Convert.ToDateTime(rdr(1).ToString().Trim).ToShortDateString()

                    Dim SchedIN As DateTime?
                    Try
                        SchedIN = Convert.ToDateTime(rdr(2).ToString().Trim)
                    Catch ex As Exception
                        SchedIN = CType(Nothing, DateTime?)
                    End Try

                    Dim Break1 As DateTime?
                    Try
                        Break1 = Convert.ToDateTime(rdr(3).ToString().Trim)
                    Catch ex As Exception
                        Break1 = CType(Nothing, DateTime?)
                    End Try

                    Dim Lunch As DateTime?
                    Try
                        Lunch = Convert.ToDateTime(rdr(4).ToString().Trim)
                    Catch ex As Exception
                        Lunch = CType(Nothing, DateTime?)
                    End Try

                    Dim Break2 As DateTime?
                    Try
                        Break2 = Convert.ToDateTime(rdr(5).ToString().Trim)
                    Catch ex As Exception
                        Break2 = CType(Nothing, DateTime?)
                    End Try
                    
                    Dim SchedOUT As DateTime?
                    Try
                        SchedOUT = Convert.ToDateTime(rdr(6).ToString().Trim)
                    Catch ex As Exception
                        SchedOUT = CType(Nothing, DateTime?)
                    End Try
                    
                    Dim SchedType As String = rdr(7).ToString().Trim

                    Dim arrSchedTag() As String = {"pto-halfday", "pto-wholeday", "loa", "lop", "rd", "rdot", "in", "pto", "cto", "cto-wholeday", "cto-halfday"}

                    If arrSchedTag.Contains(SchedType.ToLower().Replace(" ", "")) Then
                        If dtSchedSettings.Rows.Count > 0 Then
                            If arr.Contains(LoginID) Then
                                GoTo check
                            Else
                                arrayStr = String.Join(", ", arr.ToArray)
                                errTag = 5
                                sqlConn.Close()

                                oleDbConn.Close()

                                Exit Sub
                            End If
                        Else
check:
                            'YES
                            CheckSchedule(LoginID, SchedDate)

                            'DATA HAS MATCHING SCHED DATE?

                            If dtSchedule.Rows.Count > 0 Then

                                Dim sinDate As Date = Nothing
                                Dim soutDate As Date = Nothing
                                Dim strInDate As String = ""
                                Dim strOutDate As String = ""

                                If IsDBNull(dtSchedule.Rows(0)("SchedIN")) Then
                                    strInDate = Convert.ToString(dtSchedule.Rows(0)("SchedIN"))
                                Else
                                    sinDate = dtSchedule.Rows(0)("SchedIN")
                                End If

                                If IsDBNull(dtSchedule.Rows(0)("SchedOUT")) Then
                                    strOutDate = Convert.ToString(dtSchedule.Rows(0)("SchedOUT"))
                                Else
                                    soutDate = dtSchedule.Rows(0)("SchedOUT")
                                End If

                                If SchedIN.ToString() <> strInDate And
                                    SchedIN <> sinDate.ToString And
                                    SchedOUT <> soutDate.ToShortDateString And
                                    SchedOUT.ToString() <> strOutDate Then

                                    'NO

                                    'CHECK IF SCHEDDATE HAS MATCH ON LEAVE DATE
                                    CheckLeave(LoginID, SchedDate)
                                    If dtLeave.Rows.Count > 0 Then
                                        'IF YES:	(CHANGE THE DATE THAT HAS MATCH TO LEAVE DATE AND UPDATE SCHEDULE)
                                        '- MOVE CHANGES TO TEMP DATA TABLE
                                        dtSchedTemp.Rows.Add(id, LoginID, dtLeave.Rows(0)("LeaveDate"), "NULL", "NULL", HoursWorked, "YES", dtLeave.Rows(0)("LeaveType"), "NULL", "NULL", "NULL", UploadedBy, EditedBy, DateEdited)
                                    Else
                                        'IF NO:
                                        '- MOVE CHANGES TO TEMP DATA TABLE
                                        dtSchedTemp.Rows.Add(id, LoginID, SchedDate, SchedIN, SchedOUT, HoursWorked, LogoutTag, SchedType, Break1, Lunch, Break2, UploadedBy, DateUploaded, EditedBy, DateEdited)
                                    End If
                                Else
                                    'YES
                                    overrideTag = overrideTag + 1

                                    'NO
                                    'CHECK IF SCHEDDATE HAS MATCH ON LEAVE DATE
                                    CheckLeave(LoginID, SchedDate)
                                    If dtLeave.Rows.Count > 0 Then
                                        'IF YES:	(CHANGE THE DATE THAT HAS MATCH TO LEAVE DATE AND UPDATE SCHEDULE)
                                        '- MOVE CHANGES TO TEMP DATA TABLE
                                        dtSchedTemp.Rows.Add(id, LoginID, SchedDate, "NULL", "NULL", HoursWorked, "YES", dtLeave.Rows(0)("LeaveType"), "NULL", "NULL", "NULL", UploadedBy, DateUploaded, EditedBy, DateEdited)
                                    Else
                                        'IF NO:
                                        'CHECK IF SCHEDDATE IS EXISTING IN TEMP TABLE
                                        Dim expression As String = "LoginID = '" & LoginID.ToString() & "' AND SchedDate = '" & Convert.ToDateTime(SchedDate).ToShortDateString & "'"
                                        Dim result() As DataRow = dtSchedTemp.Select(expression)

                                        If result.Length > 0 Then
                                            'IF YES:
                                            'DOES END TIME (1ST) & START TIME (2ND) IS < 12 HRS.?
                                            If (Convert.ToDateTime(SchedIN) - Convert.ToDateTime(result(0)(3))).TotalHours < 12 Then
                                                'YES
                                                errTag = 1
                                                sqlConn.Close()

                                                oleDbConn.Close()
                                                'PROMPT ERROR
                                                Exit Sub
                                            Else
                                                'NO
                                                '- MOVE CHANGES TO TEMP DATA TABLE
                                                dtSchedTemp.Rows.Add(id, LoginID, SchedDate, SchedIN, SchedOUT, HoursWorked, LogoutTag, SchedType, Break1, Lunch, Break2, UploadedBy, DateUploaded, EditedBy, DateEdited)
                                            End If
                                        Else
                                            'NO
                                            '- MOVE CHANGES TO TEMP DATA TABLE
                                            dtSchedTemp.Rows.Add(id, LoginID, SchedDate, SchedIN, SchedOUT, HoursWorked, LogoutTag, SchedType, Break1, Lunch, Break2, UploadedBy, DateUploaded, EditedBy, DateEdited)
                                        End If
                                    End If
                                    'End If
                                End If
                            Else
                                'CHECK IF SCHEDDATE HAS MATCH ON LEAVE DATE
                                CheckLeave(LoginID, SchedDate)
                                If dtLeave.Rows.Count > 0 Then
                                    'IF YES:	(CHANGE THE DATE THAT HAS MATCH TO LEAVE DATE AND UPDATE SCHEDULE)
                                    '- MOVE CHANGES TO TEMP DATA TABLE
                                    dtSchedTemp.Rows.Add(id, LoginID, dtLeave.Rows(0)("LeaveDate"), "NULL", "NULL", HoursWorked, "YES", dtLeave.Rows(0)("LeaveType"), "NULL", "NULL", "NULL", UploadedBy, EditedBy, DateEdited)
                                Else
                                    'IF NO:
                                    '- MOVE CHANGES TO TEMP DATA TABLE
                                    dtSchedTemp.Rows.Add(id, LoginID, SchedDate, SchedIN, SchedOUT, HoursWorked, LogoutTag, SchedType, Break1, Lunch, Break2, UploadedBy, DateUploaded, EditedBy, DateEdited)
                                End If
                            End If
                        End If
                    Else
                        errTag = 6
                        errTagStr += SchedType & ","
                        sqlConn.Close()

                        oleDbConn.Close()
                    End If
                Else
                    ctBlanks = ctBlanks + 1
                End If

                If ctBlanks = 4 Then
                    sqlConn.Close()

                    oleDbConn.Close()

                    'PROMPT ERROR
                    Exit Sub
                End If

                count += 1
            Catch ex As Exception
                Debug.WriteLine(ex)
            End Try
        End While
        sqlConn.Close()

        lblMessage.ForeColor = System.Drawing.Color.Green
        lblMessage.Text = count.ToString() + " records inserted."

        oleDbConn.Close()
    End Sub

    Public Sub GetLastSched(loginid As String, scheddate As String)
        Dim qry = ""

        qry = "select LoginID, SchedDate, CONVERT(varchar(50), SchedIN, 101) + ' ' +  CONVERT(varchar(50), CAST(SchedIN as TIME), 100) as SchedIN, CONVERT(varchar(50), SchedOUT, 101) + ' ' +  CONVERT(varchar(50), CONVERT(time, SchedOUT)) as SchedOUT from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & loginid & "' and SchedDate = '" & scheddate & "' order by SchedDate"

        dtLastSched = cls.GetData(qry)
    End Sub

    Public Sub CheckSchedule(loginid As String, scheddate As String)
        Dim qry = ""

        qry = "select LoginID, SchedDate, CONVERT(varchar(50), SchedIN, 101) + ' ' +  CONVERT(varchar(50), CAST(SchedIN as TIME), 100) as SchedIN, CONVERT(varchar(50), SchedOUT, 101) + ' ' +  CONVERT(varchar(50), CONVERT(time, SchedOUT)) as SchedOUT from tbl_HRMS_Employee_Schedule (nolock) where LoginID = '" & loginid & "' and SchedDate = '" & scheddate & "' order by SchedDate"

        dtSchedule = cls.GetData(qry)

    End Sub

    Public Sub CheckLeave(empid As String, leavedate As String)
        Dim qry = ""

        qry = "select EmpID, LeaveDate, LeaveType, LeaveStatus from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & empid & "' and LeaveDate = '" & leavedate & "' and LeaveStatus = 'Approved' order by LeaveDate"

        dtLeave = cls.GetData(qry)

    End Sub

    Public Sub DeleteSchedule(loginid As String, scheddate As String)
        Dim cmdDelete As New SqlCommand

        cmdDelete.CommandText = "update tbl_HRMS_Employee_Schedule"
    End Sub

    'Private Sub leaveReportGrid_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles leaveReportGrid.RowCommand
    '	Select Case e.CommandName
    '		Case "Select"
    '			Dim rowindex As Integer = CInt(e.CommandArgument)
    '			Dim row As GridViewRow = leaveReportGrid.Rows(rowindex)

    '			If row IsNot Nothing Then
    '				Dim iRow As Integer = rowindex

    '				Dim iID As String = CType(leaveReportGrid.DataKeys(iRow).Value, String)

    '				Session("SessionEmpID") = iID.ToString.Trim
    '				Session("SessionLeaveDate") = row.Cells(3).Text.Trim
    '				Session("SessionLeaveStatus") = row.Cells(8).Text.Trim

    '			End If

    '	End Select
    'End Sub

    'Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
    '	GetServerDateTime()
    '	UpdateLeaveMasterCancel()
    '	leaveReportGrid.DataBind()

    '	ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "$('#lblValidations').text('Leave has been cancelled!'); clickModal4('lnkLeave');", True)
    'End Sub

    Private Sub SelectedLeaveDates()

        Dim query As String

        query = "select * from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser.Trim & "' and ApprovedBy IS NULL and DateApproved IS NULL order by LastDateModified desc"

        dtLastDateApplied = cls.GetData(query)

    End Sub

    'Private Sub GetSelectedDates()
    '	SelectedLeaveDates()

    '	'Dim dt As New DataTable()
    '	dtSelectedLeaveDates.Columns.AddRange(New DataColumn(3) {New DataColumn("EmpID"), New DataColumn("LeaveDate"), New DataColumn("DateApplied"), New DataColumn("Status")})
    '	For Each row As GridViewRow In leaveReportGrid.Rows
    '		'For Each row As TableRow In dtDateApplied.Rows
    '		If row.RowType = DataControlRowType.DataRow Then
    '			Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("chkRow"), CheckBox)
    '			If chkRow.Checked Then
    '				Dim lblUser As Label = DirectCast(row.FindControl("Label1"), Label)
    '				leaveUser = lblUser.Text
    '				leaveDate = row.Cells(3).Text
    '				Dim lblDateApplied As Label = DirectCast(row.FindControl("hdnDateApplied"), Label)
    '				Dim lastDateApplied As String = lblDateApplied.Text
    '				'Dim lastDateApplied As String = row.Cells(4).Text
    '				'Dim key As Integer = chkRow.TabIndex
    '				'Dim lastDateApplied As String = CType(leaveReportGrid.DataKeys(row.RowIndex).Value, String)
    '				'lastDateApplied = dtLastDateApplied.Rows(row.RowIndex)("LastDateModified")
    '				Dim status As String = row.Cells(8).Text
    '				dtSelectedLeaveDates.Rows.Add(leaveUser, leaveDate, lastDateApplied, status)
    '			End If
    '		End If
    '	Next
    'End Sub

    'Private Sub UpdateLeaveMasterCancel()

    '	GetSelectedDates()

    '	'Dim mLeaveDate As String = Session("SessionLeaveDate")
    '	For x As Integer = 0 To dtSelectedLeaveDates.Rows.Count - 1
    '		Dim selectedUser As String = dtSelectedLeaveDates.Rows(x)("EmpID")
    '		Dim selectedLeaveDate As String = dtSelectedLeaveDates.Rows(x)("LeaveDate")
    '		Dim selectedLastDateApplied As String = dtSelectedLeaveDates.Rows(x)("DateApplied").ToString()
    '		Dim selectedStatus As String = dtSelectedLeaveDates.Rows(x)("Status")

    '		If selectedStatus <> "Self-cancelled" And
    '			selectedStatus <> "Denied" Then
    '			Dim cmdUpdate As New SqlCommand
    '			Dim cmdDelete As New SqlCommand
    '			cmdUpdate.CommandText = "update dbo.tbl_HRMS_LeaveMaster set ApprovedBy = '" & pubUser.Trim & "', DateApproved = '" & pubServerDateTime.Trim & _
    '										"', LeaveStatus = 'Cancelled', LastDateModified = '" & pubServerDateTime.Trim & "' where EmpID = '" & selectedUser.Trim & "' " & _
    '										"and LeaveDate = '" & selectedLeaveDate.Trim & "' and DateApplied = '" & selectedLastDateApplied.Trim & "'"

    '			cmdUpdate.Connection = sqlConn
    '			sqlConn.Open()
    '			cmdUpdate.ExecuteNonQuery()
    '			sqlConn.Close()

    '			CheckBackUpSched(selectedUser, selectedLeaveDate)
    '			If dtScheduleBackup.Rows.Count > 0 Then
    '				'Update Current Sched
    '				cmdUpdate.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = '" & dtScheduleBackup.Rows(0)("SchedIN") & "', SchedOUT = '" & dtScheduleBackup.Rows(0)("SchedOUT") & "', Break1 = '" & dtScheduleBackup.Rows(0)("Break1") & "', " & _
    '										"Lunch = '" & dtScheduleBackup.Rows(0)("Lunch") & "', Break2 = '" & dtScheduleBackup.Rows(0)("Break2") & "', Logout_Tag = '" & dtScheduleBackup.Rows(0)("Logout_Tag") & "', SchedType = '" & dtScheduleBackup.Rows(0)("SchedType") & "', " & _
    '										"EditedBy = '" & pubUser & "', DateEdited = GETDATE() where LoginID = '" & selectedUser & "' and SchedDate = '" & selectedLeaveDate & "'"
    '				Try
    '					sqlConn.Open()
    '					cmdUpdate.Connection = sqlConn
    '					cmdUpdate.ExecuteNonQuery()
    '				Catch ex As Exception
    '				Finally
    '					sqlConn.Close()
    '				End Try
    '				'Delete backup record
    '				cmdDelete.CommandText = "delete from tbl_HRMS_Employee_Schedule_Backup where LoginID = '" & selectedUser & "' and SchedDate = '" & selectedLeaveDate & "'"
    '			End If
    '		End If
    '	Next

    'End Sub

    Private Sub CheckBackUpSched(loginid As String, scheddate As String)
        Dim qry = ""

        qry = "select LoginID, SchedDate, CONVERT(varchar(50), SchedIN, 101) + ' ' +  CONVERT(varchar(50), CAST(SchedIN as TIME), 100) as SchedIN, CONVERT(varchar(50), SchedOUT, 101) + ' ' +  CONVERT(varchar(50), CONVERT(time, SchedOUT)) as SchedOUT from tbl_HRMS_Employee_Schedule_Backup (nolock) where LoginID = '" & loginid & "' and SchedDate = '" & scheddate & "' order by SchedDate"

        dtScheduleBackup = cls.GetData(qry)
    End Sub

    Private Sub BindLogsValidation()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select a.SeriesID, b.EmpName as EmpName,CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc from tbl_HRMS_Employee_Activity a  inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.BusinessSegment = 'Financial Services' and a.Activity_Status = 'Pending'")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            logsValidationGrid.DataSource = dt
                            logsValidationGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        Else
            Dim qry As String = ""
            Dim dtLogsSettings As New DataTable
            Dim sb As New StringBuilder
            qry = "select * from tbl_HRMS_LogsValidation_Settings where DeletedBy is null and ModifierLevel = '" & employeeLevel & "' and Modifier like '%" & pubUser & "%'"

            dtLogsSettings = cls.GetData(qry)

            If dtLogsSettings.Rows.Count > 0 Then
                For x As Integer = 0 To dtLogsSettings.Rows.Count - 1
                    Dim personToModify As String = dtLogsSettings.Rows(x)("PersonToModify")

                    Dim elements() As String = personToModify.Split(New Char() {","c}, StringSplitOptions.RemoveEmptyEntries)

                    For Each element As String In elements
                        sb.Append("'" & element & "',")
                    Next
                Next

                Using con As New SqlConnection(connStr)
                    Using cmd As New SqlCommand("select distinct(a.SeriesID), b.EmpName as EmpName,CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc from tbl_HRMS_Employee_Activity a  inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID outer apply(select a.LoginID from tbl_HRMS_Employee_Activity a join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID where b.MngrNTID = '" & pubUser.Trim & "' and a.Activity_Status = 'Pending') d  where b.NTID in (" & sb.ToString() & "d.LoginID) and a.Activity_Status = 'Pending' order by b.EmpName")
                        Using sda As New SqlDataAdapter()
                            cmd.Connection = con
                            sda.SelectCommand = cmd
                            Using dt As New DataTable()
                                sda.Fill(dt)
                                logsValidationGrid.DataSource = dt
                                logsValidationGrid.DataBind()
                            End Using
                        End Using
                    End Using
                End Using
            Else
                Using con As New SqlConnection(connStr)
                    Using cmd As New SqlCommand("select a.SeriesID, b.EmpName as EmpName,CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc from tbl_HRMS_Employee_Activity a  inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.MngrNTID = '" & pubUser.Trim & "' and a.Activity_Status = 'Pending'")
                        Using sda As New SqlDataAdapter()
                            cmd.Connection = con
                            sda.SelectCommand = cmd
                            Using dt As New DataTable()
                                sda.Fill(dt)
                                logsValidationGrid.DataSource = dt
                                logsValidationGrid.DataBind()
                            End Using
                        End Using
                    End Using
                End Using
            End If
        End If

    End Sub

    Private Sub BindLeaveValidation()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select b.EmpName as Name, CONVERT(varchar(15), a.LeaveDate, 107) as LeaveDate, CONVERT(varchar(15), a.DateApplied, 107) as AppliedDate, case a.isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, a.LeaveType, case a.isPaid when 0 then 'Unpaid' else 'Paid' end as Type, a.LeaveStatus as Status, case a.LeaveStatus when 'Pending' then 'NO' when 'Approved' then 'YES' Else 'NO' end as Yesno, a.EmpID from tbl_HRMS_LeaveMaster a inner join tbl_HRMS_EmployeeMaster b on a.EmpID = b.NTID where b.BusinessSegment = 'Financial Services' and a.LeaveStatus = 'Pending'")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            leaveValidationGrid.DataSource = dt
                            leaveValidationGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        Else
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select b.EmpName as Name, CONVERT(varchar(15), a.LeaveDate, 107) as LeaveDate, CONVERT(varchar(15), a.DateApplied, 107) as AppliedDate, case a.isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, a.LeaveType, case a.isPaid when 0 then 'Unpaid' else 'Paid' end as Type, a.LeaveStatus as Status, case a.LeaveStatus when 'Pending' then 'NO' when 'Approved' then 'YES' Else 'NO' end as Yesno, a.EmpID from tbl_HRMS_LeaveMaster a inner join tbl_HRMS_EmployeeMaster b on a.EmpID = b.NTID where b.NTID in ( select NTID from tbl_HRMS_EmployeeMaster where MngrNTID = '" & pubUser.Trim & "') and a.LeaveStatus = 'Pending'")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            leaveValidationGrid.DataSource = dt
                            leaveValidationGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        End If
    End Sub

    Public Sub BindLeaveReport()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select a.EmpID, b.EmpName as Name, CONVERT(varchar(15), a.LeaveDate, 107) as LeaveDate, CONVERT(varchar(15), a.DateApplied, 107) as AppliedDate, case a.isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, a.LeaveType, case a.isPaid when 0 then 'Unpaid' else 'Paid' end as Type, a.LeaveStatus as Status, CONVERT(varchar(15), a.DateApproved, 107) as ApprovedDate, ApprovedBy as ApprovedBy, a.DateApplied as DateApplied from tbl_HRMS_LeaveMaster a inner join tbl_HRMS_EmployeeMaster b on a.EmpID = b.NTID where b.BusinessSegment = 'Financial Services'")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            'leaveReportGrid.DataSource = dt
                            'leaveReportGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        Else
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select a.EmpID, b.EmpName as Name, CONVERT(varchar(15), a.LeaveDate, 107) as LeaveDate, CONVERT(varchar(15), a.DateApplied, 107) as AppliedDate, case a.isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, a.LeaveType, case a.isPaid when 0 then 'Unpaid' else 'Paid' end as Type, a.LeaveStatus as Status, CONVERT(varchar(15), a.DateApproved, 107) as ApprovedDate, ApprovedBy as ApprovedBy, a.DateApplied as DateApplied from tbl_HRMS_LeaveMaster a inner join tbl_HRMS_EmployeeMaster b on a.EmpID = b.NTID where b.MngrNTID = '" & pubUser.Trim & "'")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            'leaveReportGrid.DataSource = dt
                            'leaveReportGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        End If
    End Sub

    Public Sub BindLogsReport()
        GetEmpInfo()

        Dim AccessLevel As String = ""

        Dim MngrNTID As String = ""
        If dtEmp.Rows.Count > 0 Then
            MngrNTID = dtEmp.Rows(0)("MngrNTID")
            AccessLevel = dtEmp.Rows(0)("AccessLevel")
        End If

        If AccessLevel = "24" Then
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select b.EmpName as EmpName, CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc, a.Activity_Status, CONVERT(varchar, a.Approved_Time, 0) as Approved_Time, Reason from tbl_HRMS_Employee_Activity a inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.BusinessSegment = 'Financial Services' and a.Activity_Status in ('Approved', 'Denied') order by EmpName")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            validationReportGrid.DataSource = dt
                            validationReportGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        Else
            Using con As New SqlConnection(connStr)
                Using cmd As New SqlCommand("select b.EmpName as EmpName, CONVERT(varchar(15), a.SchedDate, 107) as SchedDate, RIGHT(CONVERT(varchar, a.Start_Time, 100), 7) as ActivityStart, RIGHT(CONVERT(varchar, a.End_Time, 100), 7) as ActivityEnd, c.ReasonDesc, a.Activity_Status, CONVERT(varchar, a.Approved_Time, 0) as Approved_Time, Reason from tbl_HRMS_Employee_Activity a inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.MngrNTID = '" & pubUser.Trim & "' and a.Activity_Status in ('Approved', 'Denied') order by EmpName")
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            validationReportGrid.DataSource = dt
                            validationReportGrid.DataBind()
                        End Using
                    End Using
                End Using
            End Using
        End If
    End Sub

    <WebMethod> _
    Public Shared Function GetLeave(data As agentLeaveclass) As agentLeaveclass
        Dim cls As New clsConnection
        Dim lts As New List(Of leave)
        Dim rt As Integer = 1

        'Try
        Dim qry As String = "select a.ID, a.EmpID, b.EmpName as Name, CONVERT(varchar(15), a.LeaveDate, 107) as LeaveDate, CONVERT(varchar(15), a.DateApplied, 107) as AppliedDate, case a.isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, a.LeaveType, case a.isPaid when 0 then 'Unpaid' else 'Paid' end as Type, a.LeaveStatus as Status, CONVERT(varchar(15), a.DateApproved, 107) as ApprovedDate, ApprovedBy as ApprovedBy, a.DateApplied as DateApplied from tbl_HRMS_LeaveMaster a inner join tbl_HRMS_EmployeeMaster b on a.EmpID = b.NTID where b.MngrNTID = '" & data.usr & "'"
        Dim dt As DataTable = cls.GetData(qry)


        For i = 0 To dt.Rows.Count - 1

            Dim lt As New leave

            lt.id = dt.Rows(i)("id")

            lt.name = dt.Rows(i)("Name")
            lt.leavedate = dt.Rows(i)("LeaveDate")
            lt.applieddate = dt.Rows(i)("AppliedDate")

            lt.halfday = dt.Rows(i)("HalfDay").ToString.Trim
            lt.leavetype = dt.Rows(i)("LeaveType").ToString.Trim

            lt.paymenttype = dt.Rows(i)("Type").ToString.Trim

            lt.Status = dt.Rows(i)("Status")

            lt.ApprovedCanceledDate = IIf(Not IsDBNull(dt.Rows(i)("ApprovedDate")), dt.Rows(i)("ApprovedDate"), "")
            lt.ApprovedCancelledBy = IIf(Not IsDBNull(dt.Rows(i)("ApprovedBy")), dt.Rows(i)("ApprovedBy"), "")

            lt.seriesid = dt.Rows(i)("id").ToString.Trim

            lts.Add(lt)

        Next

        data.rt = dt.Rows.Count
        data.leaveTable = lts

        Return data
    End Function

    <WebMethod> _
    Public Shared Function GetSelectedDates(data As agentLeaveclass) As CancelResponse
        Dim cls As New clsConnection

        Dim id As String = ""
        Dim qry As String = ""
        Dim qry1 As String = ""

        Try
            For Each r As leave In data.leaveTable
                qry = "Select a.* from dbo.tbl_HRMS_Employee_Schedule_Backup a join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID where b.EmpName = '" & r.name & "' and a.SchedDate = '" & r.leavedate & "' order by id desc;"
                Dim dt As DataTable = cls.GetData(qry)

                If dt.Rows.Count > 0 Then
                    qry1 &= "Update tbl_HRMS_Employee_Schedule set " & _
                        "SchedIn = '" & dt.Rows(0)("SchedIN") & "'," & _
                        "SchedOut = '" & dt.Rows(0)("SchedOUT") & "'," & _
                        "Break1 = '" & dt.Rows(0)("Break1") & "'," & _
                        "Lunch = '" & dt.Rows(0)("Lunch") & "'," & _
                        "Break2 = '" & dt.Rows(0)("Break2") & "'," & _
                        "SchedType = '" & dt.Rows(0)("SchedType") & "'," & _
                        "Logout_Tag = '" & dt.Rows(0)("Logout_Tag") & "' " & _
                        "where LoginID = '" & data.usr & "' and scheddate  = '" & r.leavedate.Trim & "';"
                Else
                    qry1 &= "Delete a from tbl_HRMS_Employee_Schedule a join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID where b.EmpName = '" & r.name & "' and scheddate  = '" & r.leavedate.Trim & "';"
                End If
                id += r.id & ","

                Dim toadd As Double = 0
                If r.leavetype = "PTO" Then
                    If r.paymenttype.Equals("Paid") Then
                        If r.Status.Equals("Approved") Or r.Status.Equals("Pending") Then

                            If r.halfday = "NO" Then toadd = 1 Else toadd = 0.5

                            qry1 &= "update tbl_HRMS_EmployeeMaster set LeaveBal = LeaveBal + " & toadd & " where ntid = '" & data.usr & "';"

                        End If
                    End If
                ElseIf r.leavetype = "CTO" Then
                    If r.paymenttype.Equals("Paid") Then
                        If r.Status.Equals("Approved") Or r.Status.Equals("Pending") Then

                            If r.halfday = "NO" Then toadd = 1 Else toadd = 0.5

                            qry1 &= "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO + " & toadd & " where ntid = '" & data.usr & "';"

                        End If
                    End If
                End If

            Next

            id = Mid(id, 1, Len(id) - 1)

            qry1 &= "update dbo.tbl_HRMS_LeaveMaster set ApprovedBy = '" & data.usr & "', DateApproved = GETDATE(), LeaveStatus = 'Cancelled', LastDateModified = GETDATE() " & _
                     "where id in (" & id & ");"

            'qry1 &= "Update dbo.tbl_HRMS_and_user_status set status_tag = '3' where NTID = '" & data.usr & "';"

            qry1 &= "Select * from dbo.tbl_HRMS_EmployeeMaster where ntid = '" & data.usr & "';"

            Dim da As DataSet = cls.GetDataSet(qry1)

            Dim rt As New CancelResponse

            rt.updatedLeaveBal = da.Tables(0).Rows(0)("LeaveBal")

            rt.rt = 1

            Return rt
        Catch ex As Exception
            Dim rt As New CancelResponse
            rt.rt = 0
            rt.updatedLeaveBal = ex.ToString

            Return rt
        End Try

    End Function
End Class