﻿Imports System.Data

Public Class ErrorPage
	Inherits System.Web.UI.Page

	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String


	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/ErrorPage.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try


		GetEmpInfo()

		If Not Page.IsPostBack Then
			If dtEmp.Rows.Count > 0 Then
				If Session("Error") = 1 Then
					lblError.Text = "The link you opened is for TL and Above Only! Please click the link below to open the Agent Time Keeping Tool. Thanks!"
					HyperLink1.Visible = True
				ElseIf Session("Error") = 2 Then
					lblError.Text = "The tool is not available outside Altisource! Sorry!"
				End If
			Else
				If Session("Error") = 3 Then
					lblError.Text = "Please request access to our DEV Team. Kindly email: <a href='#'>REOReports@altisource.com</a>. Thanks!"
				End If
			End If
		End If
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

		dtEmp = cls.GetData(qry)

	End Sub

End Class