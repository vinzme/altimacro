﻿Imports System.Data.SqlClient
Imports System.Net
Imports System.Data

Public Class UserAdd
	Inherits System.Web.UI.Page
	Dim cls As New clsConnection
	Dim dtAccessType As New DataTable
	Dim pubUser As String = ""
	Dim dtBU As New DataTable
	Dim dtmngr As New DataTable
	Dim connString As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connString)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		If Not IsPostBack Then
			PopulateDDL()

			'    If dtEmp.Rows.Count > 0 Then

			'        'Get Employee Info
			'        employeeID = dtEmp.Rows(0)("EmpID")
			'        employeeName = dtEmp.Rows(0)("EmpName")
			'        employeeSupervisor = dtEmp.Rows(0)("MngrName")
			'        employeeDepartment = dtEmp.Rows(0)("DeptName")
			'        employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
			'        employeeApprover = dtEmp.Rows(0)("MngrName")
			'        empType = dtEmp.Rows(0)("EmpType")

			'        'Pass to Textbox
			'        empID.Text = employeeID
			'        empName.Text = employeeName
			'        supervisor.Text = employeeSupervisor
			'        dept.Text = employeeDepartment
			'        doj.Text = employeeDoj

			'    End If
			'ddlGender.Items.Add(New ListItem("--Select One Below--", "opt1"))
			'ddlEmpType.Items.Add(New ListItem("--Select One Below--", "opt1"))
			'ddlJobDesc.Items.Add(New ListItem("--Select One Below--", "opt1"))
			'ddlBusinessSegment.Items.Add(New ListItem("--Select One Below--", "opt1"))
			'ddlDeptName.Items.Add(New ListItem("--Select One Below--", "opt1"))

		End If



	End Sub


	Private Sub PopulateDDL()

        Dim query As String = "select DISTINCT EmpLevel from tbl_HRMS_EmployeeMaster where EmpLevel is not null order by EmpLevel"

        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlEmplevel.Items.Add(New ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlEmplevel.Items.Add(New ListItem(dtAccessType.Rows(x)("EmpLevel"), dtAccessType.Rows(x)("EmpLevel")))
            Next
        End If

        query = "select DISTINCT EmpName,EmpID,NTID from dbo.tbl_HRMS_EmployeeMaster where EmpName is not null and EmpID is not null and NTID is not null and EmpLevel not in ('EE') and AccessLevel is not null order by EmpName"

        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlMngrName.Items.Add(New ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlMngrName.Items.Add(New ListItem(dtAccessType.Rows(x)("EmpName"), dtAccessType.Rows(x)("EmpID") & "#" & dtAccessType.Rows(x)("NTID")))
            Next
        End If

        query = "select DISTINCT jobdesc from tbl_HRMS_EmployeeMaster where jobdesc is not null order by jobdesc"

        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlJobDesc.Items.Add(New ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlJobDesc.Items.Add(New ListItem(dtAccessType.Rows(x)("jobdesc"), dtAccessType.Rows(x)("jobdesc")))
            Next
        End If

        query = "select Distinct BusinessSegment from tbl_HRMS_EmployeeMaster where BusinessSegment is not null order by BusinessSegment"
        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlBusinessSegment.Items.Add(New ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlBusinessSegment.Items.Add(New ListItem(dtAccessType.Rows(x)("BusinessSegment"), dtAccessType.Rows(x)("BusinessSegment")))
            Next
        End If


        query = "select DISTINCT case when DeptCode is null then '0' else DeptCode end [DeptCode],DeptName from dbo.tbl_HRMS_EmployeeMaster where DeptCode is not null order by DeptName"
        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlDeptName.Items.Add(New ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlDeptName.Items.Add(New ListItem(dtAccessType.Rows(x)("DeptName"), dtAccessType.Rows(x)("DeptCode")))
            Next
        End If

        ddlBusinessUnit.Items.Add("--")
        txtbUnitHead.Items.Add("--")

    End Sub

    Private Sub btnInsertNewEmployee_Click(sender As Object, e As EventArgs) Handles btnInsertNewEmployee.Click
        Dim sb As New StringBuilder
        Dim al As String = "1"

        Dim fname As String = ""
        Dim lname As String = ""

        If txtempNo.Text = "" Then sb.Append("Employee Number is Required.\n\n")

        If txtfname.Text = "" Then sb.Append("Employee First Name is Required.\n\n")

        If txtlname.Text = "" Then sb.Append("Employee Last Name is Required.\n\n")

        If txtmname.Text = "" Then sb.Append("Employee Middle Name is Required.\n\n")

        If txtNTID.Text = "" Then sb.Append("NT ID is Required.\n\n")

        If ddlEmplevel.SelectedItem.Value = "opt1" Then sb.Append("Emp Level is Required.\n\n")
        'If txtDateJoined.Text = "" Then sb.Append("Employee Date of Joined is Required.\n\n")

        'If ddlEmplevel.Text = "opt1" Then sb.Append("Select Employee Level.\n\n")
        'If ddlGender.Text = "opt1" Then sb.Append("Select Gender.\n\n")

        'If ddlEmpType.Text = "opt1" Then sb.Append("Select Employee Type.\n\n")
        'If ddlJobDesc.Text = "opt1" Then sb.Append("Select Job Description.\n\n")
        If ddlMngrName.SelectedItem.Text = "" Then sb.Append("Select Manager.\n\n")

        If txtbUnitHead.SelectedItem.Text = "" Then sb.Append("Select Unit Head.\n\n")
        If ddlBusinessSegment.SelectedItem.Text = "" Then sb.Append("Select Business Segment.\n\n")
        If ddlBusinessUnit.SelectedItem.Text = "" Then sb.Append("Select Business Unit.\n\n")

        If ddlDeptName.SelectedItem.Text = "" Then sb.Append("Select Department.\n\n")


        'If txtbUnitHead.Text = "" Then sb.Append("Business Unit Head is Required!\n\n")


        If sb.ToString <> "" Then
            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('" & sb.ToString & "');", True)
            Exit Sub
        End If


        If ddlEmplevel.SelectedItem.Text = "EE" Then al = "1"
        If ddlEmplevel.SelectedItem.Text = "TL" Then al = "2"
        If ddlEmplevel.SelectedItem.Text = "MGR" Then al = "3"
        If ddlEmplevel.SelectedItem.Text = "AM" Then al = "3"
        If ddlEmplevel.SelectedItem.Text = "SR. MGR" Then al = "3"
        If ddlEmplevel.SelectedItem.Text = "DIR" Then al = "6"
        If ddlEmplevel.SelectedItem.Text = "VP" Then al = "7"

        'If ddlEmplevel.SelectedItem.Text = "MGR" Then al = "3"
        'If ddlEmplevel.SelectedItem.Text = "MGR" Then al = "3"

        'fname = Mid(txtEmpName.Text, 1, InStr(txtEmpName.Text, " ") - 1)
        'lname = Mid(txtEmpName.Text, InStr(txtEmpName.Text, " ") + 1, Len(txtEmpName.Text))

        Dim fullname = txtlname.Text.Trim & ", " & txtfname.Text.Trim & " " & txtmname.Text.Trim

        Dim query As String = ""

        query = "Select * from tbl_HRMS_EmployeeMaster where empid = '" & txtempNo.Text.Trim & "' or NTID = '" & txtNTID.Text.Trim & "'"
        Dim dt As DataTable = cls.GetData(query)

        If dt.Rows.Count = 0 Then
            query = "INSERT INTO tbl_HRMS_EmployeeMaster(EmpID, NTID, EmpName, EmpType, EmpLevel, EmpStatus, Gender, DateJoined, ContractEndDate, LeaveBal, LeaveBalCTO, Country, JobDesc, DeptCode, DeptName, MngrID, MngrName, MngrNTID, BusinessUnit, BusinessUnitHead, BusinessSegment, AccessLevel) "
            query += "VALUES('" & txtempNo.Text.Trim & "','" & txtNTID.Text.Trim & "','" & fullname & "','" & IIf(ddlEmpType.Text = "opt1", "", ddlEmpType.Text) & "','" & IIf(ddlEmplevel.SelectedItem.Text = "--Select One Below--", "", ddlEmplevel.SelectedItem.Text) & "','Employed'," & _
                "'" & IIf(ddlGender.Text.Trim = "opt1", "", ddlGender.Text.Trim) & "'," & _
                "'" & txtDateJoined.Text.Trim & "','N/A',0.0,0.0,'PHP'," & _
                "'" & IIf(ddlJobDesc.Text.Trim = "opt1", "", ddlJobDesc.Text.Trim) & "'," & _
                "'" & txtdepCode.Text.Trim & "'," & _
                "'" & IIf(ddlDeptName.SelectedItem.Text = "--Select One Below--", "", ddlDeptName.SelectedItem.Text) & "'," & _
                "'" & txtmngrID.Text.Trim & "'," & _
                "'" & IIf(ddlMngrName.SelectedItem.Text = "--Select One Below--", "", ddlMngrName.SelectedItem.Text) & "'," & _
                "'" & txtmngrNtId.Text.Trim & "'," & _
                "'" & IIf(ddlBusinessUnit.SelectedItem.Text.Trim = "--", "", ddlBusinessUnit.SelectedItem.Text.Trim) & "'," & _
                "'" & IIf(txtbUnitHead.SelectedItem.Text.Trim = "--", "", txtbUnitHead.SelectedItem.Text.Trim) & "'," & _
                "'" & IIf(ddlBusinessSegment.SelectedItem.Text.Trim = "--Select One Below--", "", ddlBusinessSegment.SelectedItem.Text.Trim) & "','" & al & "')"

            Dim cmdUpdate As New SqlCommand

            cmdUpdate.CommandText = query

            cmdUpdate.Connection = sqlConn

            sqlConn.Open()
            cmdUpdate.ExecuteNonQuery()
            sqlConn.Close()

            Dim wr As WebRequest = WebRequest.Create("http://hrms4103.cloudapp.net:81/webapi2/api/InsertUser?NTID=" & txtNTID.Text.Trim & "&FirstName=" & txtfname.Text.Trim & "&LastName=" & txtlname.Text.Trim & "&MiddleName=" & txtmname.Text.Trim & "&UserType=" & ddlEmplevel.SelectedItem.Text.Trim)
            wr.Timeout = 3500
            Try
                Dim response As HttpWebResponse = DirectCast(wr.GetResponse(), HttpWebResponse)
                'We know its going to fail but that dosent matter!!
            Catch ex As Exception
            End Try

            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('Success!');window.close();", True)
        Else

            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('Duplicate Empid or Ntid!');", True)

        End If
    End Sub



    Private Sub PopulateBU()
        Dim query As String

        query = "select Distinct BusinessUnit from tbl_HRMS_EmployeeMaster where BusinessUnit is not null and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' order by BusinessUnit"

        dtBU = cls.GetData(query)

        ddlBusinessUnit.Items.Add(New ListItem("--Select One Below--", "opt1"))
        For x As Integer = 0 To dtBU.Rows.Count - 1
            ddlBusinessUnit.Items.Add(dtBU.Rows(x)("BusinessUnit"))
        Next
    End Sub



	Private Sub ddlDeptName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlDeptName.SelectedIndexChanged
		txtdepCode.Text = ddlDeptName.SelectedValue
	End Sub

	Protected Sub ddlMngrName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlMngrName.SelectedIndexChanged
		Dim value As String = ddlMngrName.SelectedValue

		If InStr(value, "#") > 0 Then
			txtmngrID.Text = Mid(value, 1, InStr(value, "#") - 1)
			txtmngrNtId.Text = Mid(value, InStr(value, "#") + 1, Len(value))
		End If

		GetMngrDetails()
		If dtmngr.Rows.Count > 0 Then

			ddlBusinessSegment.SelectedItem.Text = dtmngr.Rows(0)("BusinessSegment")

			ddlBusinessUnit.Items.Clear()

			PopulateBU()

			ddlBusinessUnit.SelectedItem.Text = dtmngr.Rows(0)("BusinessUnit")
			txtbUnitHead.SelectedItem.Text = dtmngr.Rows(0)("BusinessUnitHead")
			ddlDeptName.SelectedItem.Text = dtmngr.Rows(0)("DeptName")
			txtdepCode.Text = dtmngr.Rows(0)("DeptCode")
		Else
			ddlBusinessSegment.SelectedItem.Text = "--"

			'ddlBusinessUnit.Items.Clear()

			'PopulateBU()

			ddlBusinessUnit.SelectedItem.Text = "--"
			txtbUnitHead.SelectedItem.Text = "--"
			ddlDeptName.SelectedItem.Text = "--"
			txtdepCode.Text = "--"
		End If
	End Sub

	Protected Sub ddlBusinessSegment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessSegment.SelectedIndexChanged
		'ddlBusinessUnit.Items.Clear()
		'PopulateBU()
	End Sub

	Private Sub GetMngrDetails()

		Dim query As String

		query = "select top 1 * from tbl_HRMS_EmployeeMaster where BusinessUnit is not null and NTID = '" & txtmngrNtId.Text.Trim & "'"

		dtmngr = cls.GetData(query)

	End Sub

	Private Sub ddlBusinessUnit_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessUnit.SelectedIndexChanged
		Dim query As String

		query = "select DISTINCT BusinessUnit,BusinessUnitHead,BusinessSegment from dbo.tbl_HRMS_EmployeeMaster where BusinessUnit = '" & ddlBusinessUnit.Text & "' and BusinessSegment='" & ddlBusinessSegment.Text.Trim & "' order by BusinessUnitHead"

		dtBU = cls.GetData(query)

		txtbUnitHead.Items.Clear()
		txtbUnitHead.Items.Add(New ListItem("--Select One Below--", "opt1"))
		For x As Integer = 0 To dtBU.Rows.Count - 1
			txtbUnitHead.Items.Add(dtBU.Rows(x)("BusinessUnitHead"))
		Next

	End Sub
End Class