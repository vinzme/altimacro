﻿Imports System.Data.SqlClient
Imports System.Net
Imports System.Net.NetworkInformation
Imports System.Data
Imports System.Web.Services

Public Class Home
	Inherits System.Web.UI.Page

	Dim pubUser As String
	Dim pubServerDateTime As String
	Dim pubServerDate As String
	Dim pubServerPrevDate As String
	Dim pubSchedDate As String
	Dim prevOUT As String
	Dim currIN As String

	Dim dtEmp As New DataTable
	Dim dtLastActivity As New DataTable
	Dim dtRange1 As New DataTable
	Dim dtRange2 As New DataTable
	Dim dtRange3 As New DataTable
	Dim dtPrevOut As New DataTable
	Dim dtCurrIn As New DataTable
	Dim dtCheckSched As New DataTable

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Dim cls As New clsConnection

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		Session.Clear()

		Try
			Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
			Dim sUser() As String = Split(DomainUser, "/")
			Dim sUserId As String = LCase(sUser(1))
			Session("userID") = sUserId
			pubUser = Session("userID")
			If Not Session("page") Is Nothing Then
				Response.Redirect(Session("page"))
			End If
		Catch ex As Exception
			Session("userID") = "devtest"
			pubUser = Session("userID")
			If Not Session("page") Is Nothing Then
				Response.Redirect(Session("page"))
			End If
		End Try

		If Session("userID") = "" Then
			Response.Redirect("LoginTL.aspx")
		Else
			pubUser = Session("userID")
		End If


		GetEmpInfo()
		GetServerDateTime()
		GetLastActivity()

		If Not IsPostBack Then

			'Label1.Text = HttpContext.Current.Request.UserHostAddress

			'Label2.Text = Label1.Text.Substring(0, 6).ToString()
			If dtEmp.Rows.Count > 0 Then
				If dtEmp.Rows(0)("accesslevel") = "1" Then
					Session("error") = 1
					Response.Redirect("errorpage.aspx")
				End If

				If dtLastActivity.Rows.Count > 0 Then
					If DBNull.Value.Equals(dtLastActivity.Rows(0)("end_time")) Then
						Response.Redirect("Index.aspx")
					End If
				Else
					Session("auth") = "1"
				End If
			Else
				Session("error") = 3
				Response.Redirect("errorpage.aspx")
			End If
		End If

	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' order by Start_Time desc, scheddate, seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub GetServerDateTime()

		Dim ConnStr As String
		Dim sSql As String

		Dim mserverdatetime As DateTime
		Dim mprevdatetime As DateTime

		ConnStr = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
		Dim MySqlConn As New SqlConnection(ConnStr)
		MySqlConn.Open()
		Try

			sSql = "Select getdate() as logdate, DATEADD(DAY,-1,GETDATE()) as prevday"

			Dim MySqlCmd As New SqlCommand(sSql, MySqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then

				While mReader.Read()

					mserverdatetime = mReader("logdate")

					mprevdatetime = mReader("prevday")

					pubServerDateTime = mReader("logdate")

					pubServerDate = Format(mserverdatetime, "yyyy-MM-dd")

					pubServerPrevDate = Format(mprevdatetime, "yyyy-MM-dd")

				End While

			End If

		Catch ex As Exception

		Finally
			MySqlConn.Close()
		End Try

	End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Function CheckForShoutOutMessage(pubUser As String) As MyClassfJQ

		Dim cls As New clsConnection
		Dim query As String
		Dim dtMessage As New DataTable
		Dim var As New MyClassfJQ
		Dim mID As Integer = 0

		var.hasMessage = False
		var.MessageStr = ""
		var.MessageID = mID

		query = "select * from tbl_HRMS_Shoutbox where Recipient = '" & pubUser.Trim & "' and Status = 0"

		dtMessage = cls.GetData(query)
		If dtMessage.Rows.Count > 0 Then

			If dtMessage.Rows(0)("Status") = 0 Then
				var.MessageStr = dtMessage.Rows(0)("Message")
				mID = dtMessage.Rows(0)("ID")
			End If

			If DateTime.Now.ToString >= dtMessage.Rows(0)("StartTime") And
				DateTime.Now.ToString <= dtMessage.Rows(0)("EndTime") Then
				var.hasMessage = True
			Else
				query = "update tbl_HRMS_Shoutbox set Status = 1, Timestamp = GETDATE() where Recipient = '" & pubUser.Trim & "' and ID = '" & mID & "'"
				cls.ExecuteQuery(query)
			End If
		Else

		End If

		Return var
	End Function

End Class