﻿function GetClientID(asp_net_id) {
    return $("[id$=" + asp_net_id + "]").attr("id");
};

$(document).ready(function () {

    var current_id = 0;
    $('#addBtn').click(function () {
        personalInfoDiv($('#personalInfo_00'));
        //nextElement($('#ddlMobileNum_00'));
        //nextElement($('#txtBoxMobileNum_00'));
        //nextElement($('#ddlHomeNum_00'));
        //nextElement($('#txtBoxHomeNum_00'));
        //nextElement($('#txtBoxPersonalEmail_00'));
        return false;
    })

    $('img').click(function () {

        var table = this.parentNode.parentNode.parentNode.children(0).has("select").id;

        var idStr = this.id;
        //var parent = $('#' + id).parent("div").first().children().attr("id");
        var parent = $(this).closest("div").attr("id");
        var div = this.parentNode.parentNode.parentNode.parentNode.id;
        //$(div).remove();
        //$('#' + div).remove();
        //alert(div);
    });

    function personalInfoDiv(personalInfo) {
        var newElement = personalInfo.clone(true, true);
        var id = current_id + 1;
        current_id = id;
        if (id < 3) {
            id = "0" + id;
            newElement.attr("id", personalInfo.attr("id").split("_")[0] + "_" + id);
            var txtBox = $('input', newElement).attr("id");
            var ddl = $('select', newElement).attr("id");
            var img = $('img', newElement).attr("id");
            $('input', newElement).attr("id", txtBox.split("_")[0] + "_" + id);
            $('select', newElement).attr("id", ddl.split("_")[0] + "_" + id);
            $('img', newElement).attr("id", img.split("_")[0] + "_" + id);       
            newElement.appendTo($("#personalInfoDiv"));
        }
    }

    function removeDiv(Div) {
        var removeBtn = $('#removeDiv');
    }


    ////$("#cloneEmergencyInfo").click(function () {
    ////    //we select the box clone it and insert it after the box
    ////    $("#emergencyInfo").clone()
    ////                      .show()
    ////                      //.removeClass("template")
    ////                      .insertAfter(".emergencyInfo:last");
    ////    return false;
    ////}).trigger("click");

    //var cloneEmergencyCntr = 0;

    //$(document).on("click", "#addDiv", function () {

    //    var $div = $('#personalInfo_:last');

    //    var num = parseInt($div.prop("id").match(/\d+/g), 10) + 1;

    //    var $clone = $div.clone().prop('id', 'emergencyInfo' + num);

    //    var $txtBox = $('div[id^="ContentPlaceHolder1_txtBoxEmergencyName"]:last');

        

    //    $div.after($clone).each(function () {
    //        var $cloneTxtBox = $txtBox.clone().prop('id', 'ContentPlaceHolder1_txtBoxEmergencyName' + num);

    //        $txtBox.after($cloneTxtBox);
    //    });


    //    //$("#emergencyInfo").clone()
    //    //                  .show()
    //    //                  //.removeClass("template")
    //    //                  .attr("id", "emergencyInfo" )
    //    //                  .insertAfter("#emergencyInfo:last");
    //    //cloneEmergencyCntr += 1;
    //    return false;
    //});

    //$(document).on("click", ".btn-danger", function () {
    //    var $div = $('div[id^="emergencyInfo"]:last');

    //    var num = parseInt($div.prop("id").match(/\d+/g), 10) + 1;
    //    $(this).closest($div.prop('id', 'emergencyInfo' + num)).remove();
    //    return false;
    //});

    //var txtBoxEmergencyName = GetClientID('txtBoxEmergencyName');
    //$("#cloneEmergencyInfo").click(function (e) {
    //    $('#emergencyInfo')
    //        .clone()
    //        .attr('id', 'emergencyInfo' + cloneEmergencyCntr)
    //        .appendTo("#emergencyInfo2");
    //    $("#emergencyInfo2").attr('style', 'display:block;margin-top:2px;');
    //    cloneEmergencyCntr = cloneEmergencyCntr + 1;
    //    return false;

    //    
    //});

//    //$("#cloneHistory").click(function (e) {
//    //    $('.empHistory:last').clone().insertAfter(".empHistory:last");
//    //    return false;
//    //});

//    //$("#cloneEducBackground").click(function (e) {
//    //    $('.educBackground:last').clone().insertAfter(".educBackground:last");
//    //    return false;
//    //});

//    //$("#cloneDependent").click(function (e) {
//    //    $('.dependentDetails2:last').clone().insertAfter(".dependentDetails2:last");
//    //    return false;
//    //});
});