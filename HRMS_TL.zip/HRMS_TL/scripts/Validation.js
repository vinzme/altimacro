﻿
$(document).ready(function () {
    var errBool = false;
    var errText = "";
    var errorPersonal = document.getElementById("errorPersonal");
    var txtBoxPersonalMobileNum = document.getElementById("txtBoxPersonalMobileNum");
    var txtBoxPersonalHomeNum = document.getElementById("txtBoxPersonalHomeNum");
    var txtBoxPersonalEmail = document.getElementById("txtBoxPersonalEmail");
    
    errorPersonal.style.visibility = 'hidden'

    $('#btnSavePersonalInfo').click(function () {

        //Check if mobile number is numeric
        if (!/^[0-9]+$/.test(txtBoxPersonalMobileNum.value)) {
            errText += 'Invalid mobile number!\n';
            txtBoxPersonalMobileNum.style.borderColor = 'red';
            errBool = true;
        }
        //Check if mobile number is < 10 or > 15
        else if (txtBoxPersonalMobileNum.value.length < 10 || txtBoxPersonalMobileNum.value.length > 15) {
            errText += 'Mobile number should be 10 - 15 digits only! (Excluding Country Code)\n';
            txtBoxPersonalMobileNum.style.borderColor = 'red';
            errBool = true;
        } else {
            txtBoxPersonalMobileNum.style.borderColor = 'green';
        }

        //Check if home number is numeric
        if (!/^[0-9].+$/.test(txtBoxPersonalHomeNum.value)) {
            errText += 'Invalid home number!\n';
            txtBoxPersonalHomeNum.style.borderColor = 'red';
            errBool = true;
        } else if (txtBoxPersonalHomeNum.value.length < 7 || txtBoxPersonalHomeNum.value.length > 15) {
            errText += 'Home number should be 7 - 15 digits only! (Excluding Country Code)\n';
            txtBoxPersonalHomeNum.style.borderColor = 'red';
            errBool = true;
        } else {
            txtBoxPersonalHomeNum.style.borderColor = 'green';
        }

        if (/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/.test(txtBoxPersonalEmail.value)) {
            txtBoxPersonalEmail.style.borderColor = 'green';
        } else {
            errText += 'Email format should be: sample@sample.com!\n';
            txtBoxPersonalEmail.style.borderColor = 'red';
            errBool = true;
        }

        if (errBool == true) {
            errorPersonal.style.visibility = 'visible';
            errorPersonal.style.color = 'red';
            errorPersonal.style.font = 'bold';
            errorPersonal.innerText = errText
            errText = "";
            return false;
        } else {
            errorPersonal.style.visibility = 'hidden';
        }
    });
});