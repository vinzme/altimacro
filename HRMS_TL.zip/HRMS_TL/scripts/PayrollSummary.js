﻿

$(document).ready(function () {

    $('#btnExportSummary').click(function () {
        //alert('btnExportSummary');
        exportSummarized();
    });

    $('#btnExportDetailed').click(function (e) {
        //alert('btnExportDetailed');
        exportDetailed(e);
    });

    datepicker();

    $.ajax({
        url: 'PayrollSummary.aspx/PopulateList',
        type: 'POST',
        contentType: 'application/json; charset=utf-8',
        success: function (data) {
            //console.log(data);

            $("#bs").empty();
            $("#bs").append("<option value='0'></option>");
            $.each(data.d.bs, function (id, value) {
                $("#bs").append("<option value='" + value + "'>" + value + "</option>");
            });

            $("#bu").empty();
            $("#bu").append("<option value='0'></option>");
            $.each(data.d.bu, function (id, value) {
                $("#bu").append("<option value='" + value + "'>" + value + "</option>");
            });

            $("#lvl").empty();
            $("#lvl").append("<option value='0'></option>");
            $.each(data.d.lvl, function (id, value) {
                $("#lvl").append("<option value='" + value + "'>" + value + "</option>");
            });
            //$("#lvl").append("<option value='TLABOVE'>TL and Above</option>");

            $("#isup").empty();
            $("#isup").append("<option value='0'></option>");
            $.each(data.d.isup, function (id, value) {
                $("#isup").append("<option value='" + value + "'>" + value + "</option>");
            });

        },
        error: function (response) {
            console.log(response.responseText);
        },
        failure: function (response) {
            console.log(response.responseText);
        }
    });

});


function btnSearch_click() {

    var bs = $("#bs option:selected").val()

    var bu = $("#bu option:selected").val();

    var empname = $("#empname").val();

    if (empname == '') { empname = '0'; }

    var lvl = $("#lvl option:selected").val();

    var isup = $("#isup option:selected").val();

    var dtFrom = $("#dtFrom").val();
    var dtTo = $("#dtTo").val();


    var myObj = ({

        bs: bs,
        bu: bu,
        empname: empname,
        isup: isup,
        lvl: lvl,

        dtTo: dtTo,
        dtFrom: dtFrom
    });

    //console.log(myObj);

    $("#divLOADER").fadeIn();
    $.ajax({
        url: 'PayrollSummary.aspx/btnGenerate_Click',
        type: 'POST',
        data: "{data: " + JSON.stringify(myObj) + "}",
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (data) {

            var d = $.parseJSON(data.d);
            //console.log(d);
            if (d.Success == true) {
                var toAppend = "";

                toAppend = "<tr>";
                $.each(d.data.columns, function (index, value) {
                    toAppend += "<th>" + value + "</th>";
                });
                toAppend += "</tr>";
                $("#tblLeave").bootstrapTable('destroy');
                $("#tblLeave thead").empty().append(toAppend);

                toAppend = "";
                $("#tblLeave tbody").empty();
                $.each(d.data.record, function (index, value) {
                    //console.log(value);
                    toAppend += "<tr>";
                    $.each(d.data.columns, function (index, val) {
                        var v = value[val];
                        if (v == null) { v = ''; } else { v = value[val]; }
                        toAppend += "<td>" + v + "</td>";
                    });
                    toAppend += "</tr>";
                });
                $("#tblLeave tbody").append(toAppend);
            } else {
                alertify.error("Something went wrong. Desc: " + d.Message);
            }

            $("#tblLeave").fadeIn();
            $("#divLOADER").fadeOut();

            $("#tblLeave").bootstrapTable({
                pagination: true,
                exportDataType: "all"
            });

           
        },
        error: function (response) {
            console.log(response.responseText);
        },
        failure: function (response) {
            console.log(response.responseText);
        }
    });

}

function empList(sender) {

    var val = $(sender).val();

    $.ajax({
        url: 'PayrollSummary.aspx/getEmpNames',
        type: 'POST',
        data: "{data: '" + val + "'}",
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (data) {
            //console.log(data);
            $("#data_empname").empty();
            $.each(data.d, function (i, d) {
                $("#data_empname").append("<option value='" + d.empname + "'>" + d.ntid + "</option>");
            });
        },
        error: function (response) {
            console.log(response.responseText);
        },
        failure: function (response) {
            console.log(response.responseText);
        }
    });
}

function datepicker() {
    $('.datepickerSum').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: "yy-mm-dd"
    });
}


function exportSummarized() {
    var dtFrom = $.trim($('#dtFrom').val());
    var dtTo = $.trim($('#dtTo').val());

    //var tableData = 'data between ' + dtFrom + ' and ' + dtTo + '<br /><br />';

    var tab_text = "<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j = 0;
    tab = document.getElementById('tblLeave'); // id of table

    for (j = 0 ; j < tab.rows.length ; j++) {
        tab_text = tab_text + tab.rows[j].innerHTML + "</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text = tab_text + "</table>";
    tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text = tab_text.replace(/<img[^>]*>/gi, ""); // remove if u want images in your table
    tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params


    //tableData += tab_text;

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html", "replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus();
        sa = txtArea1.document.execCommand("SaveAs", true, "Payroll " + dtFrom + " - " + dtTo + " .xls");
    }
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));
    return (sa);
}

function exportDetailed(e) {
    var dtFrom = $.trim($('#dtFrom').val());
    var dtTo = $.trim($('#dtTo').val());

    //var tableData = 'data between ' + dtFrom + ' and ' + dtTo + '<br /><br />';

    var tab_text = "<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j = 0;
    tab = document.getElementById('tblLeave'); // id of table

    for (j = 0 ; j < tab.rows.length ; j++) {
        tab_text = tab_text + tab.rows[j].innerHTML + "</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text = tab_text + "</table>";
    tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text = tab_text.replace(/<img[^>]*>/gi, ""); // remove if u want images in your table
    tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params


    //tableData += tab_text;

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html", "replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus();
        sa = txtArea1.document.execCommand("SaveAs", true, "Payroll " + dtFrom + " - " + dtTo + " .xls");
    }
    else {                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));
        e.preventDefault();
    }

    return (sa);
}


function request_click() {

    var from = "2016-11-01";
    var to = "2016-11-15";
    var segment = "Mortgage Services";
    var unit = "Property Preservation and Inspection";    

    var myObj = ({
        from: from,
        to: to,
        segment: segment,
        unit: unit
    });

    //var url = 'http://172.26.131.159/PayrollHours/api/payrollhours';
    var url = "http://localhost:50041/api/payrollhours";

    $("#divLOADER").fadeIn();
    $.ajax({
        url: url,
        type: 'POST',
        data: JSON.stringify(myObj),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (data) {

            //console.log(data);
            $("#tblLeave tbody").empty();
            $.each(data, function (index, value) {
                $("#tblLeave tbody").append("<tr>"
                    + "<td>" + value.Cut_Off + "</td>"
                    + "<td>" + value.Status + "</td>"                    
                    + "<td>" + value.EmpID + "</td>"
                    + "<td>" + value.EmpName + "</td>"
                    + "<td>" + value.NTID + "</td>"
                    + "<td>" + value.MngrID + "</td>"
                    + "<td>" + value.MngrName + "</td>"
                    + "<td>" + value.Scheduled_Start + "</td>"
                    + "<td>" + value.Scheduled_Out + "</td>"
                    + "<td>" + value.Log_In_Time + "</td>"
                    + "<td>" + value.Log_Out_Time + "</td>"
                    + "<td>" + value.TotalUnComputedHours + "</td>"
                    + "<td>" + value.TOTAL_ND_HRS + "</td>"
                    + "<td>" + value.TOTAL_REG_HRS + "</td>"
                    + "<td>" + value.TOTAL_OT_HRS + "</td>"
                    + "<td>" + value.RH_ND_HOURS + "</td>"
                    + "<td>" + value.RH_REG_HOURS + "</td>"
                    + "<td>" + value.RH_OT_HOURS + "</td>"
                    + "<td>" + value.SNW_ND_HOURS + "</td>"
                    + "<td>" + value.SNW_REG_HOURS + "</td>"
                    + "<td>" + value.SNW_OT_HOURS + "</td>"
                    + "<td>" + value.PTO_Whole_Day + "</td>"
                    + "<td>" + value.PTO_Half_Day + "</td>"
                    + "<td>" + value.Maternity + "</td>"
                    + "<td>" + value.Paternity + "</td>"
                    + "<td>" + value.SoloParent + "</td>"
                    + "<td>" + value.NDRestDay + "</td>"
                    + "<td>" + value.RestDay + "</td>"
                    + "<td>" + value.RestDayOT + "</td>"
                    + "<td>" + value.RD_RH_ND_HOURS + "</td>"
                    + "<td>" + value.RD_RH_REG_HOURS + "</td>"
                    + "<td>" + value.RD_RH_OT_HOURS + "</td>"
                    + "<td>" + value.RD_SNW_ND_HOURS + "</td>"
                    + "<td>" + value.RD_SNW_REG_HOURS + "</td>"
                    + "<td>" + value.RD_SNW_OT_HOURS + "</td>"
                    + "</tr>");
            });

            //$("#tblLeave").bootstrapTable({
            //    data: data.d,
            //    height: 625
            //});

            $("#tblLeave").fadeIn();
            $("#divLOADER").fadeOut();
        },
        error: function (response) {
            console.log(response.responseText);
        },
        failure: function (response) {
            console.log(response.responseText);
        }
    });

}


//var prm = Sys.WebForms.PageRequestManager.getInstance();

//prm.add_endRequest(function () {

//    //var prm = Sys.WebForms.PageRequestManager.getInstance();
//    //prm.add_endRequest(function () {
//    // Again put all your jQuery code here

   


//});


