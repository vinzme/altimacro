﻿function busconnect(url, data, funcname, myresult) {
    
    $.ajax({
        type: "POST",
        url: url + funcname,
        data: data,
        contentType: 'application/json',
        success: function (result) {
            myresult(result.d);
        },
        failure: function (response) {
            console.log(response.d);
        },
        error: function (response) {
            console.log(response.responseText);
        }
    });
}
function busconnect2(url, data, myresult, methodtype) {

    $.ajax({
        type: methodtype,
        url: url,
        data: data,
        contentType: 'application/json',
        success: function (result) {
           myresult(result);
        },
        failure: function (response) {
            console.log(response.d);
        },
        error: function (response) {
            console.log(response.responseText);
        }
    });
}