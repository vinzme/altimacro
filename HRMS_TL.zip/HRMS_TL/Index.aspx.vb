﻿Imports System.Data.SqlClient
Imports System.Net.Mail
Imports System.Web.Services
Imports System.Data

Public Class Index
	Inherits System.Web.UI.Page

	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String
	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String
	Dim leaveDate As String
	Dim lastDateApplied As String
	Dim leaveType As String
	Dim halfDay As String
	Dim empType As String

	Dim pubUserMode As String
	Dim ExpiredMinutes As Integer

	Dim pubUserStatus As String
	Dim pubUserStatusTag As String
	Dim pubServerDateTime As String
	Dim pubServerDate As String
	Dim pubPrevDate As String
	Dim pubLastSchedDate As String
	Dim pubActivityID As Integer
	Dim pubIdleTimeInserted As Boolean = False
	Dim pubIdleMinutes As Integer = 0
	Dim pubClickOKIdle As Boolean = False
	Dim pubAspectNRStatus As String

	Dim dtChkHoliday As DataTable
	Dim dtChkLeave As DataTable
	Dim dtChkLeaveExisting As DataTable
	Dim dtChkIfRD As DataTable

	Dim dtHoliday_spcW As New DataTable
	Dim dtHoliday_reg As New DataTable

	Dim dtHolidays As New DataTable
	Dim dtLastActivity As New DataTable
	Dim dtLastDateApplied As New DataTable
	Dim dtSelectedLeaveDates As New DataTable
	Dim dtAlreadySelected As New DataTable

	Dim dtPrevSched As New DataTable
	Dim dtCurrSched As New DataTable
	Dim dtBetween As New DataTable
	Dim dtChkDateTime As New DataTable

	Dim dtCheckSched As New DataTable
	Dim dtCurrIn As New DataTable
	Dim dtPrevOut As New DataTable
	Dim dtRange1 As New DataTable
	Dim dtRange2 As New DataTable
	Dim dtRange3 As New DataTable
	Dim dtTodaySched As New DataTable
	Dim dtCount As New DataTable
	Dim dtNews As New DataTable
	Dim dtGetDrCt As New DataTable
	Dim dtLeaveInfo As New DataTable
	Dim dtLeaveCount As New DataTable

	Dim dtScheduleBackup As New DataTable

	Dim pubSchedDate As String
	'Dim pubServerPrevDate As String
	Dim prevout As String
	Dim currin As String
	Dim pubSeriesID As String
	Dim todayStartTime As String
	Dim todayEndTime As String

	Dim fullName As String = ""

	Dim dtLogin As DateTime
	Dim gSelectedDate As String
	Dim gAlreadySelected As String

	Dim totaltime As Integer = 0

	'Leave Controls
	Dim pubLeaveDate As String
	Dim pubHalfDay As String
	Dim pubLeaveType As String
	Dim pubLeavePayment As String
	Dim pubLeaveStatus As String
	Dim pubSeries As String
	Dim pubCancel As String
	Dim pubPayment As String

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Index.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		userID.Text = pubUser

		'Get Employee Info
		GetEmpInfo()

		'Populate Holidays in the Calendar
		PopulateHolidays(Val(lblMonth.Text))

		If Not Page.IsPostBack Then

			CreateNewsPanel()

			Dim date15 As String
			Dim date30 As String
			'Dim date as String
			'"7/16/2016"
			date15 = Format(DateValue(Now).Date, "MM/dd/yyyy")

			date15 = date15.Substring(0, 3) + "15" + date15.Substring(5, 5)
			date30 = date15.Substring(0, 3) + "30" + date15.Substring(5, 5)

			If Session("tag1") = 1 Then
				Page.ClientScript.RegisterStartupScript(Me.GetType(), "ClickModal", "clickModal();", True)

				Session("tag1") = 0
			End If

			If Session("tag2") = 1 Then
				Page.ClientScript.RegisterStartupScript(Me.GetType(), "ClickModal2", "clickModal2();", True)

				Session("tag2") = 0
			End If

			GetServerDateTime()
			GetLastActivity()
			If dtLastActivity.Rows.Count > 0 Then
				GetPrevSchedOut()

				CountLogins()
				'Get the Last Leave Date of Employee
				LastLeave()

				If dtPrevSched.Rows.Count > 0 Then
					If Not IsDBNull(dtPrevSched.Rows(0)("prevout")) Then
						prevout = dtPrevSched.Rows(0)("prevout")
					End If
				Else
					prevout = ""
				End If

				CheckDateTime()

				'Check the Last Leave of Employee
				If dtChkLeave.Rows.Count > 0 Then
					lblLastLeave.Text = dtChkLeave.Rows(0)("LastLeave")
				End If
			End If

			'Check if dtEmp count is greater than 0
			If dtEmp.Rows.Count > 0 Then

				'Get Employee Info
				employeeID = dtEmp.Rows(0)("EmpID")
				employeeName = dtEmp.Rows(0)("EmpName")
				employeeSupervisor = dtEmp.Rows(0)("MngrName")
				employeeDepartment = dtEmp.Rows(0)("DeptName")
				employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
				employeeApprover = dtEmp.Rows(0)("MngrName")
				empType = dtEmp.Rows(0)("EmpType")

				Session("EmpName") = employeeName
				Session("visorNTID") = dtEmp.Rows(0)("MngrNTID")

				'Pass to Textbox
				empID.Text = employeeID
				empName.Text = employeeName
				supervisor.Text = employeeSupervisor
				dept.Text = employeeDepartment
				doj.Text = employeeDoj
				approver.Text = employeeApprover

				PopulateHolidays(Today.Month)

				lblMonth.Text = Today.Month

				'Get the Leave Balance of the Employee
				lblLeaveBalPTO.Text = IIf(IsDBNull(dtEmp.Rows(0)("LeaveBal")), "00", dtEmp.Rows(0)("LeaveBal"))
				lblLeaveBalCTO.Text = IIf(IsDBNull(dtEmp.Rows(0)("LeaveBalCTO")), "00", dtEmp.Rows(0)("LeaveBalCTO"))

			End If

		End If

	End Sub

	Private Sub ProcessNews()
		Dim sql As String = ""
		sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"
		dtNews = cls.GetData(sql)
	End Sub
	Private Sub CreateNewsPanel()
		Dim str As String = ""

		ProcessNews()
		If dtNews.Rows.Count > 0 Then
			For x As Integer = 0 To dtNews.Rows.Count - 1
				str &= "<li class='news-item'>"
				str &= "<table cellpadding='4'>"
				str &= "<tr>"
				str &= "<td>"
				str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
                str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a onclick = ""window.open('" & dtNews.Rows(x)("imgNews") & "', '_Parent', 'toolbar=0,scrollbars=0,resizable=0,top=0,left=20%,width=450,height=850');"" href='#'>Read more...</a></td>"
				str &= "<tr>"
				str &= "</table>"
				str &= "</li>"
			Next

			lt1.Text = str

		End If
	End Sub

	Private Sub CountLogins()
		Dim query As String

		query = "select COUNT(ReasonID) as ReasonID from dbo.tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & pubUser.Trim & "' and SchedDate = '" & pubLastSchedDate.Trim & "' and ReasonID = '2'"

		dtCount = cls.GetData(query)
	End Sub

	Private Sub GetMySchedule()
		Try
			GetRange1()

			If dtRange1.Rows.Count = 0 Then
				InsertSchedule()
				GetRange1()
			End If

			If dtRange1.Rows(0)("Range1") = 1 Then
				pubSchedDate = dtRange1.Rows(0)("SchedDate")
			Else
				GetRange2()

				If dtRange2.Rows(0)("Range2") = 1 Then
					pubSchedDate = dtRange2.Rows(0)("SchedDate")
				Else
					GetCurrIN()

					If Not IsDBNull(dtCurrIn.Rows(0)("CurrIN")) Then
						currin = dtCurrIn.Rows(0)("CurrIN")
					Else
						CheckSchedule()

						If dtCheckSched.Rows.Count > 0 Then
							UpdateSchedule()
							GetCurrIN()
						Else
							InsertSchedule()
							GetCurrIN()
						End If
						currin = dtCurrIn.Rows(0)("CurrIN")
					End If

					GetRange3()

					If dtRange3.Rows(0)("Range3") = 1 Then
						pubSchedDate = dtRange3.Rows(0)("SchedDate")
					End If
				End If
			End If

		Catch ex As Exception

		End Try

	End Sub

	Private Sub GetRange1()
		Dim query As String

		query = "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range1, SchedDate from " & _
						"dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtRange1 = cls.GetData(query)
	End Sub

	Private Sub GetRange2()
		Dim query As String

		query = "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range2, SchedDate from " & _
			"dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubPrevDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtRange2 = cls.GetData(query)
	End Sub

	Private Sub GetRange3()
		Dim query As String

		query = "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range3, SchedDate from " & _
					"dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtRange3 = cls.GetData(query)
	End Sub

	Private Sub GetPrevOUT()
		Dim query As String

		query = "Select DATEADD(HOUR,4,SchedOUT) as PrevOUT from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubPrevDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtPrevOut = cls.GetData(query)

	End Sub

	Private Sub GetCurrIN()
		Dim query As String

		query = "Select DATEADD(hour,-4,SchedIN) as CurrIN from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtCurrIn = cls.GetData(query)
	End Sub

	Private Sub CheckSchedule()
		Dim query As String

		query = "select * from tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtCheckSched = cls.GetData(query)
	End Sub

	Private Sub UpdateSchedule()
		Dim cmdUpdateSchedule As New SqlCommand

		cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = CAST('" & pubServerDateTime.Trim & "' as datetime), SchedOUT = dateadd(HH, 9, CAST('" & pubServerDateTime.Trim & "' as datetime)), EditedBy = 'System Update', DateEdited = CAST('" & pubServerDateTime.Trim & "' as datetime) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubServerDate.Trim & "'"

		cmdUpdateSchedule.Connection = sqlConn
		sqlConn.Open()
		cmdUpdateSchedule.ExecuteNonQuery()
		sqlConn.Close()
	End Sub

	Private Sub InsertSchedule()
		Dim cmdInsertSchedule As New SqlCommand

		cmdInsertSchedule.CommandText = "insert into tbl_HRMS_Employee_Schedule(LoginID, SchedDate, SchedIN, SchedOUT, Logout_Tag, SchedType, UploadedBy, DateUploaded) " & _
										"values('" & pubUser.Trim & "', '" & pubServerDate.Trim & "', CAST('" & pubServerDateTime.Trim & "' as datetime), dateadd(HH, 9, CAST('" & pubServerDateTime.Trim & "' as datetime)), 'NO', 'IN', 'System Upload', '" & pubServerDateTime.Trim & "')"

		cmdInsertSchedule.Connection = sqlConn
		sqlConn.Open()
		cmdInsertSchedule.ExecuteNonQuery()
		sqlConn.Close()
	End Sub

	Private Sub GetTodaySched()
		Dim query As String

		query = "select * from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubLastSchedDate.Trim & "'"

		dtTodaySched = cls.GetData(query)

		todayStartTime = dtTodaySched.Rows(0)("SchedIN")
		todayEndTime = dtTodaySched.Rows(0)("SchedOUT")
	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid, scheddate from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' order by Start_Time desc, scheddate, seriesid desc"

		dtLastActivity = cls.GetData(query)

		If dtLastActivity.Rows.Count > 0 Then
			pubSeriesID = dtLastActivity.Rows(0)("SeriesID")
			pubLastSchedDate = dtLastActivity.Rows(0)("SchedDate")
		End If
		'pubLoginTime = dtLastAcitivty.Rows(0)("Start_Time")
	End Sub

	Private Sub GetPrevSchedOut()
		Dim query As String

		query = "select DATEADD(HH, 4, schedout) as prevout from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubLastSchedDate.Trim & "'"

		dtPrevSched = cls.GetData(query)
	End Sub

	Private Sub GetCurrSchedIn()
		Dim query As String

		query = "select DATEADD(HH, -4, schedin) as currin from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubServerDate.Trim & "'"

		dtCurrSched = cls.GetData(query)
	End Sub

	Private Sub GetBetweenOutIn()
		Dim query As String

		query = "select case when '" & pubServerDateTime.Trim & "' between CAST('" & prevout & "' as datetime) and CAST('" & currin & "' as datetime) then 1 else 0 end as betweenOutIn"

		dtBetween = cls.GetData(query)
	End Sub

	Private Sub CheckDateTime()
		Dim query As String

		query = "select case when '" & pubServerDateTime.Trim & "' > CAST('" & prevout & "' as datetime) then 1 else 0 end as ChkDateTime"

		dtChkDateTime = cls.GetData(query)
	End Sub

	Private Sub UpdateWorkingEndTime()
		GetServerDateTime()
		GetLastActivity()

		Dim cmdUpdateTime As New SqlCommand

		cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set End_Time = '" & pubServerDateTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"

		Try
			cmdUpdateTime.Connection = sqlConn
			sqlConn.Open()
			cmdUpdateTime.ExecuteNonQuery()
			sqlConn.Close()
		Catch ex As Exception

		End Try
	End Sub

	Private Sub UpdateWorkingMinHour()
		GetLastActivity()

		Dim cmdUpdateTime As New SqlCommand

		cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = CAST(DATEDIFF(MI, Start_Time, End_Time) as decimal), TotalTimeHour = cast(DATEDIFF(MINUTE,Start_Time,End_Time) as decimal)/60 where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"

		Try
			cmdUpdateTime.Connection = sqlConn
			sqlConn.Open()
			cmdUpdateTime.ExecuteNonQuery()
			sqlConn.Close()
		Catch ex As Exception

		End Try
	End Sub

	Private Sub UpdateWorkingEndTimeLate()
		GetServerDateTime()
		GetLastActivity()

		Dim cmdUpdateTime As New SqlCommand

		cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set End_Time = '" & todayEndTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"

		Try
			cmdUpdateTime.Connection = sqlConn
			sqlConn.Open()
			cmdUpdateTime.ExecuteNonQuery()
			sqlConn.Close()
		Catch ex As Exception

		End Try
	End Sub

	Private Sub ForcedLogout()
		GetServerDateTime()
		GetLastActivity()

		Dim cmdUpdateTime As New SqlCommand

		cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & prevout & "', '" & prevout & "', '" & pubLastSchedDate.Trim & "', 16)"

		Try
			cmdUpdateTime.Connection = sqlConn
			sqlConn.Open()
			cmdUpdateTime.ExecuteNonQuery()
			sqlConn.Close()
		Catch ex As Exception

		End Try
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

		dtEmp = cls.GetData(qry)

	End Sub

	Public Sub LastLeave()
		Dim query As String = ""

		query = "select top 1 EmpID, Case when '" & pubServerDateTime.Trim & "' >=  MAX(LeaveDate) then CONVERT(varchar(20), LeaveDate, 107) else NULL end as LastLeave, LastDateModified from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser.Trim & "' and leavedate <= '" & pubServerDateTime.Trim & "' and LeaveStatus = 'Approved' group by EmpID, LeaveDate, LastDateModified order by LastDateModified desc"

		dtChkLeave = cls.GetData(query)
	End Sub

	Private Sub PopulateHolidays(ByVal month As Integer)
		Dim msql As String = ""

		msql = "select * from tbl_HRMS_HolidayMaster (nolock) where DATEPART(MONTH, HolDate) = " & _
			month & " and DATEPART(year, HolDate) = '" & System.TimeZoneInfo.ConvertTime(Now(), TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time")).Year & _
			"' and DeletedBy is null and DateDeleted is null union all select '1' as ID, 'Sunday' as HolDay, LeaveDate as HolDate, 'Leave' as HolDesc, 'Leave' as HolType, 'All' as CoveredGroup, NULL as DeletedBy, Null as DateDeleted from " & _
			"dbo.tbl_HRMS_LeaveMaster where EmpID = '" & pubUser.Trim & "' and DATEPART(MONTH, LeaveDate) = " & month & " and DATEPART(year, LeaveDate) = '" & _
			System.TimeZoneInfo.ConvertTime(Now(), TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time")).Year & "' and LeaveStatus in('Pending','Approved')"

		dtHoliday_reg = cls.GetData(msql)

	End Sub

	'Populate Calendar with days
	Private Sub Calendar1_DayRender(sender As Object, e As DayRenderEventArgs) Handles Calendar1.DayRender
		Dim ar As New ArrayList()	'ArrayList For Dates
		Dim ar2 As New ArrayList() 'ArrayList for Holiday Type
		Dim h As Integer = 0

		For h = 0 To dtHoliday_reg.Rows.Count - 1
			ar.Add(dtHoliday_reg.Rows(h)(2))
			ar2.Add(dtHoliday_reg.Rows(h)(4))
		Next

		For x As Integer = 0 To ar.Count - 1
			If e.Day.[Date].ToShortDateString() = String.Format("{0:d}", DirectCast(ar(x), Date)) Then
				Select Case ar2(x).ToString.Trim
					Case "Regular"
						e.Cell.BackColor = System.Drawing.Color.Red
						e.Cell.ForeColor = System.Drawing.Color.White
					Case "Special Non-Working"
						e.Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#ED872D")
						e.Cell.ForeColor = System.Drawing.Color.White
					Case "Leave"
						e.Cell.BackColor = System.Drawing.Color.Green
						e.Cell.ForeColor = System.Drawing.Color.White
				End Select
			End If
		Next

		gAlreadySelected = e.Day.[Date].ToShortDateString()
		DateAlreadySelected()
		If dtAlreadySelected.Rows.Count > 0 Then
			If e.Day.[Date].ToShortDateString() = dtAlreadySelected.Rows(0)("LeaveDate") Then
				e.Cell.BackColor = System.Drawing.ColorTranslator.FromHtml("#88BD23")
				e.Cell.ForeColor = System.Drawing.Color.White
			End If
		End If
	End Sub

	Private Sub DateAlreadySelected()
		Dim query As String

		query = "Select LeaveDate from tbl_HRMS_LeaveTrans (nolock) where LeaveDate = '" & gAlreadySelected.Trim & "' and Userid = '" & pubUser.Trim & "'"

		dtAlreadySelected = cls.GetData(query)
	End Sub

	Protected Sub Calendar1_VisibleMonthChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MonthChangedEventArgs) Handles Calendar1.VisibleMonthChanged
		PopulateHolidays(e.NewDate.Month)
		lblMonth.Text = e.NewDate.Month.ToString
	End Sub

	'Selecting a Day on the calendar for leave
	Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
		Dim holiday As String = ""
		gSelectedDate = Calendar1.SelectedDate.ToString("MM-dd-yyyy")
		CheckIfRD()
		If dtChkIfRD.Rows.Count = 0 Then
			gSelectedDate = Calendar1.SelectedDate.ToString("MM-dd-yyyy")
			CheckIfLeaveExisting()
			If dtChkLeaveExisting.Rows.Count = 0 Then
				CheckIfLeaveDateSelected()
				If dtChkLeave.Rows.Count = 0 Then

					CheckHoliday()
					If dtChkHoliday.Rows.Count > 0 Then
						holiday = dtChkHoliday.Rows(0)("HolType")
					Else
						holiday = "d"
					End If

					ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: ApplyDate('" & gSelectedDate & "'); getLeaveTypes('" & holiday & "');", True)
				End If
			End If
		Else
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript: alert('Date selected is in " & dtChkIfRD.Rows(0)("SchedType") & " on your schedule. Please check your schedule with your supervisor.');", True)
		End If

	End Sub

	Private Sub LoopLeaveGrid()

		InsertIntoLeaveMaster()

		Dim qry As String = ""
		Dim dtTrans As New DataTable
		qry = "select * from tbl_HRMS_LeaveTrans where userid = '" & pubUser & "'"

		dtTrans = cls.GetData(qry)

		UpdateLeaveBal()

	End Sub

	Private Sub UpdateLeaveBal()
		Dim qry As String = ""
		Dim qry2 As String = ""
		Dim checkTransPTO As String = ""
		Dim checkTransCTO As String = ""
		Dim dtTransPTO As New DataTable
		Dim dtTransCTO As New DataTable

		checkTransPTO = "select SUM(case when HalfDay = 'YES' then 0.5 else 1 end) [count] from tbl_hrms_LeaveTrans where UserID = '" & pubUser & "' and LeaveType <> 'CTO' and LeaveType <> 'LOA'"

		dtTransPTO = cls.GetData(checkTransPTO)

		checkTransCTO = "select SUM(case when HalfDay = 'YES' then 0.5 else 1 end) [count] from tbl_hrms_LeaveTrans where UserID = '" & pubUser & "' and LeaveType = 'CTO'"

		dtTransCTO = cls.GetData(checkTransCTO)

		If Not IsDBNull(dtTransPTO.Rows(0)("count")) Then
			qry = "update tbl_HRMS_EmployeeMaster set LeaveBal = LeaveBal - (select SUM(case when HalfDay = 'YES' then 0.5 else 1 end) [count] from tbl_hrms_LeaveTrans where UserID = '" & pubUser & "' and LeaveType <> 'CTO' and LeaveType <> 'LOA') where ntid = '" & pubUser & "'"
			cls.ExecuteQuery(qry)
		End If

		If Not IsDBNull(dtTransCTO.Rows(0)("count")) Then
			qry2 = "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO - (select SUM(case when HalfDay = 'YES' then 0.5 else 1 end) [count] from tbl_hrms_LeaveTrans where UserID = '" & pubUser & "' and LeaveType = 'CTO') where ntid = '" & pubUser & "'"
			cls.ExecuteQuery(qry2)
		End If
	End Sub

	Private Sub CheckIfRD()

		Dim qry As String = ""

		qry = "Select * from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedType in ('RD', 'PTO', 'CTO') and SchedDate = '" & gSelectedDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

		dtChkIfRD = cls.GetData(qry)


	End Sub

	Public Function PopulateLeaveType() As Data.DataSet

		If empType = "Contractual" Then
			Dim ad As SqlDataAdapter = New SqlDataAdapter("Select LType as prompt from dbo.tbl_HRMS_LeaveType (nolock) where Gender in(Select substring(a.Gender,1,1) as Gender from tbl_HRMS_EmployeeMaster a where a.NTID = '" & pubUser.Trim & "') and LType = 'LOA'  ", sqlConn)
			Dim ds As Data.DataSet = New Data.DataSet()
			ad.Fill(ds, "tblLeaveType")
			Return ds
		Else
			Dim ad As SqlDataAdapter = New SqlDataAdapter("Select LType as prompt from dbo.tbl_HRMS_LeaveType (nolock) where Gender in(Select substring(a.Gender,1,1) as Gender from tbl_HRMS_EmployeeMaster a where a.NTID = '" & pubUser.Trim & "') ", sqlConn)
			Dim ds As Data.DataSet = New Data.DataSet()
			ad.Fill(ds, "tblLeaveType")
			Return ds
		End If

	End Function

	Private Sub CheckHoliday()

		Dim qry As String = ""

		qry = "Select * from tbl_HRMS_HolidayMaster where HolDate = '" & gSelectedDate.Trim & "'"

		dtChkHoliday = cls.GetData(qry)

	End Sub

	Private Sub CheckIfLeaveExisting()

		Dim qry As String = ""

		qry = "Select LeaveDate from tbl_HRMS_LeaveMaster (nolock) where LeaveDate = '" & gSelectedDate.Trim & "' and EmpID = '" & pubUser.Trim & "' " & _
				"and LeaveStatus <> 'Self-cancelled' and LeaveStatus <> 'Denied'"

		dtChkLeaveExisting = cls.GetData(qry)

	End Sub

	Private Sub CheckIfLeaveDateSelected()

		Dim qry As String = ""

		qry = "Select LeaveDate from tbl_HRMS_LeaveMaster (nolock) where LeaveDate = '" & gSelectedDate.Trim & "' and Userid = '" & pubUser.Trim & "'"

		dtChkLeave = cls.GetData(qry)

	End Sub

	Private Sub CheckCountLeave()

		Dim qry As String = ""

		Dim cls As New clsConnection

		qry = "Select SUM(CASE WHEN CAST(HalfDay as varchar) = 'YES' then 0.5 else case when LeavePayment = 'Paid' then 1.0 else 0 end end) [LeaveCount] from dbo.tbl_HRMS_LeaveTrans a where userID = '" & pubUser.Trim & "' and LeavePayment = 'Paid'"

		dtLeaveCount = cls.GetData(qry)

	End Sub

	Public Class LvTrans
		Public SerialID As String
		Public Halfday As String
		Public LeavePayment As String
		Public CurrentLeave As String
		Public CurrentUsr As String
	End Class

	<WebMethod(EnableSession:=True)> _
	Public Shared Function UpdateHalfday(LvTrans As LvTrans) As String
		Dim cls As New clsConnection
		Dim qry As String = ""

		Dim TempLeavePaid As Double = 0
		Dim remain As Double = 0
		Dim topay As Double = 0

		If LvTrans.Halfday = "YES" Then topay = 0.5 Else topay = 1

		cls.ExecuteQuery("UPDATE tbl_HRMS_LeaveTrans SET HalfDay = '" & LvTrans.Halfday & "' WHERE SerialID = " & LvTrans.SerialID)
		TempLeavePaid = JQCountPaidInLeaveGrid(LvTrans.CurrentUsr)

		remain = CDbl(LvTrans.CurrentLeave) - TempLeavePaid

		If remain <= 0 Then
			LvTrans.LeavePayment = "Unpaid"
		Else
			LvTrans.LeavePayment = "Paid"
		End If


		cls.ExecuteQuery("UPDATE tbl_HRMS_LeaveTrans SET LeavePayment = '" & LvTrans.LeavePayment & "' WHERE SerialID = " & LvTrans.SerialID)

		Return LvTrans.LeavePayment

	End Function

	Public Shared Function JQCountPaidInLeaveGrid(usr As String) As Double

		Dim qry As String = ""
		Dim ctr As Double = 0
		Dim cls As New clsConnection
		Dim dtLeaveCount As New DataTable

		qry += "Select SUM("
		qry += "case when LeaveType <> 'LOA' then "
		qry += "CASE WHEN CAST(HalfDay as varchar) = 'YES' then 0.5 "
		qry += "else "
		qry += "case when LeavePayment = 'Paid' then 1.0 "
		qry += "else 0 end "
		qry += "End "
		qry += "else 0 "
		qry += "end) [LeaveCount] "
		qry += "from dbo.tbl_HRMS_LeaveTrans a "
		qry += "where userID = '" & usr.Trim & "' and LeavePayment = 'Paid' "

		dtLeaveCount = cls.GetData(qry)

		If IsDBNull(dtLeaveCount.Rows(0)("LeaveCount")) Then ctr = 0 Else ctr = dtLeaveCount.Rows(0)("LeaveCount")

		Return ctr
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function DropDownList2_SelectedIndexChanged(LvTrans As LvTrans) As String
		Dim cls As New clsConnection

		Dim TempLeavePaid As Double = 0
		Dim remain As Double = 0
		Dim toPay As Double = 0

		If LvTrans.Halfday = "YES" Then toPay = 0.5 Else toPay = 1

		cls.ExecuteQuery("UPDATE tbl_HRMS_LeaveTrans SET LeaveType = '" & LvTrans.LeavePayment & "' WHERE SerialID = " & LvTrans.SerialID)

		TempLeavePaid = JQCountPaidInLeaveGrid(LvTrans.CurrentUsr)

		If LvTrans.Halfday <> "LOA" Then

			remain = Math.Abs(TempLeavePaid - Convert.ToDouble(LvTrans.CurrentLeave))

			If toPay > remain Then
				LvTrans.LeavePayment = "Unpaid"
			Else
				LvTrans.LeavePayment = "Paid"
			End If
		Else
			LvTrans.LeavePayment = "Unpaid"
		End If

		cls.ExecuteQuery("UPDATE tbl_HRMS_LeaveTrans SET LeavePayment = '" & LvTrans.Halfday & "' WHERE SerialID = " & LvTrans.SerialID)

		Return LvTrans.LeavePayment
	End Function



	Private Sub InsertLeaveTrans()
		Dim cmdText As String = ""
		Dim lc As String = ""
		Dim remain As Double = 0
		Dim topay As Double = 1

		Dim cmdUpdate As New SqlCommand

		If CDbl(lblLeaveBalPTO.Text) > 0 Then

			CheckCountLeave()
			If IsDBNull(dtLeaveCount.Rows(0)("LeaveCount")) Then lc = 0 Else lc = dtLeaveCount.Rows(0)("LeaveCount")
			remain = Math.Abs(CDbl(lc) - CDbl(lblLeaveBalPTO.Text))

			If topay > remain Then
				cmdText = "Unpaid"
			Else
				cmdText = "Paid"
			End If

			cmdUpdate.CommandText = "insert into tbl_HRMS_LeaveTrans(Userid,LeaveDate,LeavePayment,HalfDay) values('" & pubUser.Trim & "','" & gSelectedDate.Trim & "','" & cmdText & "','NO')"
		Else
			cmdUpdate.CommandText = "insert into tbl_HRMS_LeaveTrans(Userid,LeaveDate,LeavePayment,HalfDay) values('" & pubUser.Trim & "','" & gSelectedDate.Trim & "','UnPaid','NO')"
		End If

		cmdUpdate.Connection = sqlConn
		cmdUpdate.Connection.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub DeleteLeaveTrans()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "delete from tbl_HRMS_LeaveTrans where SerialID = '" & pubSeries.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub DeleteLeaveTrans2()

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = "delete from tbl_HRMS_LeaveTrans where UserID = '" & pubUser.Trim & "'"

		cmdUpdate.Connection = sqlConn
		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

	End Sub

	Private Sub getDrCount()
		Dim query As String
		query = "select * from dbo.tbl_HRMS_LeaveMaster where ApprovedBy='" & Session("visorNTID") & "' and EmpID='" & pubUser.Trim & "' and datepart(month,LeaveDate) = datepart(month,GETDATE())"
		dtGetDrCt = cls.GetData(query)
	End Sub


	Private Sub emailNotifier()
		On Error GoTo err

		Dim drct As String = "0"
		Dim vslot As String = "1"
		Dim sender As String = ""

		getDrCount()
		If dtGetDrCt.Rows.Count > 0 Then
			drct = dtGetDrCt.Rows.Count
		End If

		'EMAIL PART
		'Dim client As New SmtpClient("Internal-Mail.ascorp.com")
		Dim client As New SmtpClient("apprelay.ascorp.com")
		client.Port = 25
		client.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials

		sender = pubUser.Trim
		Dim from As New MailAddress(sender & "@altisource.com", "HRMS Email Notifier", System.Text.Encoding.UTF8)

		Dim [to] As New MailAddress(Session("visorNTID") & "@altisource.com")

		Dim message As New MailMessage(from, [to])

		message.Body = "<b>" & Session("EmpName") & "</b> is requesting for Leave. below are the details. <br /><br />"
		message.Body &= Session("tblLeaveLst")
		message.Body &= "<br />Click <a href='http://172.26.131.159/HRMS_TL/DirectReports.aspx?tabDR=lnkLeaves'><b>here</b></a> to approve/disapprove"

		message.Body &= "<br /><br /><br />Regards,<br />HRMS"
		message.Subject = "HRMS - " & Session("EmpName") & " - Application for Leave"

		message.IsBodyHtml = True
		message.SubjectEncoding = System.Text.Encoding.UTF8


		client.Send(message)


		Exit Sub

err:
		Session("ERR") = "SENDER: " & sender & "@altisource.com " & Err.Description

		from = New MailAddress(pubUser.Trim & "@altisource.com", "HRMS Email Notifier", System.Text.Encoding.UTF8)
		[to] = New MailAddress("sainibha@altisource.com")

		message.Body = "ERR :" & Err.Description

		client.Send(message)

	End Sub


	Private Sub GetLeaveInformation()
		Dim query As String

		query = "select * from dbo.tbl_HRMS_LeaveMaster where LeaveDate in (select LeaveDate from dbo.tbl_HRMS_LeaveTrans where UserID='" & pubUser.Trim & "' and LeaveStatus <> 'Self-cancelled') and EmpID='" & pubUser.Trim & "'"

		dtLeaveInfo = cls.GetData(query)
	End Sub

	Protected Sub BtnLeaveSubmit_Click(sender As Object, e As EventArgs) Handles BtnLeaveSubmit.Click

		LoopLeaveGrid()

		GetLeaveInformation()
		DeleteLeaveTrans2()
		Session("tblLeaveLst") = ""
		If dtLeaveInfo.Rows.Count > 0 Then

			Session("tblLeaveLst") = "<style>table, th, td {border: 1px solid #ddd !important; }table {border-collapse: collapse; }tr:nth-child(even) {background-color: #f2f2f2}th {background-color: #4CAF50;color: white; }</style><table style=''><tr><td>Leave Date</td><td>Halfday</td><td>Leave Type</td><td>Paid</td></tr>"
			For x As Integer = 0 To dtLeaveInfo.Rows.Count - 1
				Session("tblLeaveLst") += "<tr>"
				'Session("tblLeaveLst") += "<td>"

				Session("tblLeaveLst") += "<td>" & dtLeaveInfo.Rows(x)("LeaveDate") & "</td>"

				If dtLeaveInfo.Rows(x)("isHalfDay") = 1 Then Session("tblLeaveLst") += "<td>YES</td>" Else Session("tblLeaveLst") += "<td>NO</td>"

				Session("tblLeaveLst") += "<td>" & dtLeaveInfo.Rows(x)("LeaveType") & "</td>"

				If dtLeaveInfo.Rows(x)("isPaid") = 1 Then Session("tblLeaveLst") += "<td>YES</td>" Else Session("tblLeaveLst") += "<td>NO</td>"

				'Session("tblLeaveLst") += "</td>"
				Session("tblLeaveLst") += "</tr>"
			Next
			Session("tblLeaveLst") += "</table>"
		End If
		'emailNotifier()

		Response.Redirect("Index.aspx")

	End Sub

	Private Sub InsertIntoLeaveMaster()

		Dim qry As String = ""

		qry += "insert into tbl_HRMS_LeaveMaster(EmpID,LeaveDate,isHalfDay,LeaveType,isPaid,DateApplied,LeaveStatus,Submitted) "
		qry += "Select UserID as EmpID, CAST(LeaveDate as DATE)[LeaveDate], case when Halfday = 'NO' then 0 else 1 end [isHalfDay],"
		qry += "LeaveType, case LeavePayment when 'Paid' then '1' when 'UnPaid' then '0' end as isPaid, "
		qry += "CAST(GETDATE() as date) as DateApplied, 'Pending' as LeaveStatus, 'NO' as Submitted from tbl_hrms_LeaveTrans  where UserID = '" & pubUser & "'"

		cls.ExecuteQuery(qry)

	End Sub

	Private Sub GetServerDateTime()

		Dim query As String

		Dim mserverdatetime As DateTime
		Dim mprevdate As Date


		Try
			sqlConn.Open()
			query = "select getdate() as logdate, DATEADD(DAY,-1,GETDATE()) as prevday"

			Dim MySqlCmd As New SqlCommand(query, sqlConn)
			Dim mReader As SqlDataReader

			mReader = MySqlCmd.ExecuteReader()
			If mReader.HasRows Then

				While mReader.Read()

					mserverdatetime = mReader("logdate")
					mprevdate = mReader("prevday")

					pubServerDateTime = mserverdatetime
					pubServerDate = Format(mserverdatetime, "yyyy-MM-dd")
					pubPrevDate = Format(mprevdate, "yyyy-MM-dd")

				End While

			End If

		Catch ex As Exception

		Finally
			sqlConn.Close()
		End Try

	End Sub

	Private Sub GetLastDateApplied()

		Dim query As String

		query = "select top 1 * from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser.Trim & "' order by DateApplied desc"

		dtLastDateApplied = cls.GetData(query)
	End Sub

	Private Sub SelectedLeaveDates()

		Dim query As String

		query = "select * from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser.Trim & "' and ApprovedBy IS NULL and DateApproved IS NULL order by LastDateModified desc"

		dtLastDateApplied = cls.GetData(query)

	End Sub

	<WebMethod> _
	Public Shared Function GetSelectedDates(data As agentLeaveclass) As CancelResponse
		Dim cls As New clsConnection

		Dim id As String = ""
		Dim qry As String = ""
		Dim qry1 As String = ""

		Try
			For Each r As leave In data.leaveTable
				qry = "Select * from dbo.tbl_HRMS_Employee_Schedule_Backup where LoginID = '" & data.usr & "' and SchedDate = '" & r.leavedate & "' order by id desc;"
				Dim dt As DataTable = cls.GetData(qry)

				If dt.Rows.Count > 0 Then
					qry1 &= "Update tbl_HRMS_Employee_Schedule set " & _
						"SchedIn = '" & dt.Rows(0)("SchedIN") & "'," & _
						"SchedOut = '" & dt.Rows(0)("SchedOUT") & "'," & _
						"Break1 = '" & dt.Rows(0)("Break1") & "'," & _
						"Lunch = '" & dt.Rows(0)("Lunch") & "'," & _
						"Break2 = '" & dt.Rows(0)("Break2") & "'," & _
						"SchedType = '" & dt.Rows(0)("SchedType") & "'," & _
						"Logout_Tag = '" & dt.Rows(0)("Logout_Tag") & "' " & _
						"where LoginID = '" & data.usr & "' and scheddate  = '" & r.leavedate.Trim & "';"
				Else
					qry1 &= "Delete tbl_HRMS_Employee_Schedule where LoginID = '" & data.usr & "' and scheddate  = '" & r.leavedate.Trim & "';"
				End If
				id += r.id & ","

				Dim toadd As Double = 0
				If r.leavetype <> "CTO" And r.leavetype <> "LWOP" Then
					If r.paymenttype.Equals("Paid") Then
						If r.Status.Equals("Approved") Or r.Status.Equals("Pending") Then

							If r.halfday = "NO" Then toadd = 1 Else toadd = 0.5

							qry1 &= "update tbl_HRMS_EmployeeMaster set LeaveBal = LeaveBal + " & toadd & " where ntid = '" & data.usr & "';"

						End If
					End If
				ElseIf r.leavetype = "CTO" Then
					If r.paymenttype.Equals("Paid") Then
						If r.Status.Equals("Approved") Or r.Status.Equals("Pending") Then

							If r.halfday = "NO" Then toadd = 1 Else toadd = 0.5

							qry1 &= "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO + " & toadd & " where ntid = '" & data.usr & "';"

						End If
					End If
				End If

			Next

			id = Mid(id, 1, Len(id) - 1)

			qry1 &= "update dbo.tbl_HRMS_LeaveMaster set ApprovedBy = '" & data.usr & "', DateApproved = GETDATE(), LeaveStatus = 'Self-cancelled', LastDateModified = GETDATE() " & _
					 "where id in (" & id & ");"

			qry1 &= "Update dbo.tbl_HRMS_and_user_status set status_tag = '3' where NTID = '" & data.usr & "';"

			qry1 &= "Select * from dbo.tbl_HRMS_EmployeeMaster where ntid = '" & data.usr & "';"

			Dim da As DataSet = cls.GetDataSet(qry1)

			Dim rt As New CancelResponse

			rt.updatedLeaveBal = da.Tables(0).Rows(0)("LeaveBal")

			rt.rt = 1

			Return rt
		Catch ex As Exception
			Dim rt As New CancelResponse
			rt.rt = 0
			rt.updatedLeaveBal = ex.ToString

			Return rt
		End Try

	End Function

	Private Sub CheckBackUpSched(loginid As String, scheddate As String)
		Dim qry = ""

		qry = "select * from tbl_HRMS_Employee_Schedule_Backup (nolock) where LoginID = '" & loginid & "' and SchedDate = '" & scheddate & "' order by SchedDate"

		dtScheduleBackup = cls.GetData(qry)
	End Sub

	<WebMethod> _
	Public Shared Function PopulateLeaveType(usr As String) As List(Of String)

		Dim list As New List(Of String)

		Dim cls As New clsConnection

		Dim qry = "Select * from dbo.tbl_HRMS_EmployeeMaster where ntid = '" & usr & "'"

		Dim dtemp As DataTable = cls.GetData(qry)

		If dtemp.Rows(0)("EmpType") = "Regular" Then
			qry = "Select LType as prompt from dbo.tbl_HRMS_LeaveType where Gender in(Select substring(Gender,1,1) as Gender from tbl_HRMS_EmployeeMaster where NTID = '" & usr.Trim & "') "
		Else
			qry = "Select LType as prompt from dbo.tbl_HRMS_LeaveType where LType <> 'PTO' and Gender in(Select substring(Gender,1,1) as Gender from tbl_HRMS_EmployeeMaster where NTID = '" & usr.Trim & "') "
		End If

		dtemp = cls.GetData(qry)

		For i = 0 To dtemp.Rows.Count - 1

			list.Add(dtemp.Rows(i)("prompt").ToString.Trim)

		Next

		Return list
	End Function

	<WebMethod> _
	Public Shared Function AppendToTemp(data As agentLeaveclass) As agentLeaveclass
		Dim cls As New clsConnection
		Dim ct As Double = 0
		Dim ct2 As Double = 0
		Dim rt As Integer = 1
		Dim toadd As Double = 0
		Dim paid As String = ""
		Try
			Dim qry As String = ""

			qry = "select SUM(case when LeaveType = 'PTO' then case when HalfDay = 'YES' then 0.5 else 1 end else 0 end) [PTO], SUM(case when LeaveType = 'CTO' then case when HalfDay = 'YES' then 0.5 else 1 end else 0 end) [CTO] from tbl_hrms_LeaveTrans where UserID = '" & data.usr & "' and LeaveType <> 'LOA';"
			qry += "select * from dbo.tbl_HRMS_EmployeeMaster where ntid = '" & data.usr & "';"
			Dim da As DataSet = cls.GetDataSet(qry)

			If da.Tables(0).Rows.Count > 0 Then
				If data.selLeaveType = "CTO" Then
					If IsDBNull(da.Tables(0).Rows(0)(1)) = False Then
						ct = da.Tables(0).Rows(0)(1)
					End If
				Else
					If IsDBNull(da.Tables(0).Rows(0)(0)) = False Then
						ct = da.Tables(0).Rows(0)(0)
					End If
				End If
			End If

			If data.selLeaveType <> "LOA" Then
				paid = "Paid"
				If data.selHalfDay = "YES" Then
					toadd += 0.5
				Else
					toadd += 1
				End If
			Else
				paid = "UnPaid"
			End If

			Dim lv As Double = 0
			Dim lv2 As Double = 0

			If data.selLeaveType = "CTO" Then
				If IsDBNull(da.Tables(1).Rows(0)("LeaveBalCTO")) = False Then lv = da.Tables(1).Rows(0)("LeaveBalCTO")

				If (ct + toadd) <= lv Then
					qry = "insert into tbl_HRMS_LeaveTrans(Userid,LeaveDate,LeavePayment,HalfDay,LeaveType) values" & _
															"('" & data.usr & "','" & data.txtleavedate.Trim & "','" & paid & "','" & data.selHalfDay & "','" & data.selLeaveType & "')"
					cls.ExecuteQuery(qry)
				Else
					rt = 0
					data.errMsg = "Insufficient Credit Balance."
				End If
			Else
				If IsDBNull(da.Tables(1).Rows(0)("LeaveBal")) = False Then lv2 = da.Tables(1).Rows(0)("LeaveBal")

				If (ct2 + toadd) <= lv2 Then
					qry = "insert into tbl_HRMS_LeaveTrans(Userid,LeaveDate,LeavePayment,HalfDay,LeaveType) values" & _
															"('" & data.usr & "','" & data.txtleavedate.Trim & "','" & paid & "','" & data.selHalfDay & "','" & data.selLeaveType & "')"
					cls.ExecuteQuery(qry)
				Else
					rt = 0
					data.errMsg = "Insufficient Credit Balance."
				End If
			End If



		Catch ex As Exception
			rt = 0
			data.errMsg = ex.Message
		End Try

		data.rt = rt

		Return data
	End Function

	<WebMethod> _
	Public Shared Function GetLeaveTrans(data As agentLeaveclass) As agentLeaveclass
		Dim cls As New clsConnection
		Dim lts As New List(Of leavetrans)
		Dim rt As Integer = 1

		Try
			Dim qry As String = "Select CAST(LeaveDate as date) [LeaveDate],HalfDay,LeaveType,LeavePayment,SerialID from tbl_HRMS_LeaveTrans where UserID = '" & data.usr & "' order by LeaveDate"
			Dim dt As DataTable = cls.GetData(qry)


			For i = 0 To dt.Rows.Count - 1

				Dim lt As New leavetrans

				lt.leavedate = dt.Rows(i)("LeaveDate")
				lt.halfday = dt.Rows(i)("HalfDay").ToString.Trim
				lt.leavetype = dt.Rows(i)("LeaveType").ToString.Trim
				lt.paymenttype = dt.Rows(i)("LeavePayment").ToString.Trim
				lt.seriesid = dt.Rows(i)("SerialID").ToString.Trim

				lts.Add(lt)

			Next

			data.rt = dt.Rows.Count
			data.leavetransTable = lts

		Catch ex As Exception

		End Try

		Return data
	End Function

	<WebMethod> _
	Public Shared Function GetLeave(data As agentLeaveclass) As agentLeaveclass
		Dim cls As New clsConnection
		Dim lts As New List(Of leave)
		Dim rt As Integer = 1

		'Try
		Dim qry As String = "select id, Convert(varchar(15),LeaveDate, 107) as LeaveDate, Convert(varchar(15),DateApplied, 107) as AppliedDate, case isHalfDay when 0 then 'NO' else 'YES' end as HalfDay, LeaveType, case isPaid when 0 then 'Unpaid' else 'Paid' end as Type, LeaveStatus as Status, Convert(varchar(15),DateApproved, 107) as ApprovedOrCanceled, LastDateModified from tbl_HRMS_LeaveMaster where EmpID = '" & data.usr & "'"
		Dim dt As DataTable = cls.GetData(qry)


		For i = 0 To dt.Rows.Count - 1

			Dim lt As New leave

			lt.id = dt.Rows(i)("id")

			lt.leavedate = dt.Rows(i)("LeaveDate")
			lt.applieddate = dt.Rows(i)("AppliedDate")

			lt.halfday = dt.Rows(i)("HalfDay").ToString.Trim
			lt.leavetype = dt.Rows(i)("LeaveType").ToString.Trim

			lt.paymenttype = dt.Rows(i)("Type").ToString.Trim

			lt.Status = dt.Rows(i)("Status")

			lt.ApprovedCanceledDate = IIf(Not IsDBNull(dt.Rows(i)("ApprovedOrCanceled")), dt.Rows(i)("ApprovedOrCanceled"), "")

			lt.seriesid = dt.Rows(i)("id").ToString.Trim

			lts.Add(lt)

		Next

		data.rt = dt.Rows.Count
		data.leaveTable = lts

		'Catch ex As Exception
		'    data.errMsg = ex.ToString()
		'End Try

		Return data
	End Function

	<WebMethod> _
	Public Shared Function deleteSelectedLeaveTrans(data As leavetrans) As Integer
		Dim cls As New clsConnection
		Dim lts As New List(Of leavetrans)
		Dim rt As Integer = 1

		Try

			Dim qry As String = "delete tbl_HRMS_LeaveTrans where SerialID = " & data.seriesid
			cls.ExecuteQuery(qry)

		Catch ex As Exception
			rt = 0
		End Try

		Return rt
	End Function

	'Protected Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs)
	'	'Dim gRow As GridViewRow = dateSelectedGrid.Rows
	'	Dim ddl As DropDownList = sender

	'	Dim row As GridViewRow = ddl.NamingContainer

	'	'MsgBox(row.RowIndex)
	'	Dim ddlChange As DropDownList = DirectCast(dateSelectedGrid.Rows(row.RowIndex).FindControl("DropDownList2"), DropDownList)
	'	Dim lblPayment As Label = DirectCast(dateSelectedGrid.Rows(row.RowIndex).FindControl("Label1"), Label)

	'	If Not ddl Is Nothing Then
	'		If Not ddl.SelectedItem Is Nothing Then
	'			Dim strLeaveType As String = ddl.SelectedItem.Text.Trim
	'			If strLeaveType <> "CTO" Then
	'				If strLeaveType <> "LWOP" Then
	'					If Convert.ToDouble(lblLeaveBalPTO.Text) <= 0 Then
	'						lblPayment.Text = "Unpaid"
	'					Else
	'						lblPayment.Text = "Paid"
	'					End If
	'				Else
	'					lblPayment.Text = "Unpaid"
	'				End If
	'			Else
	'				If Convert.ToDouble(lblLeaveBalCTO.Text) <= 0 Then
	'					lblPayment.Text = "Unpaid"
	'				Else
	'					lblPayment.Text = "Paid"
	'				End If
	'			End If
	'		End If
	'	End If
	'End Sub

	Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
		Dim cmdDelete As New SqlCommand

		cmdDelete.CommandText = "delete from tbl_HRMS_LeaveTrans where Userid = '" & pubUser.Trim & "'"

		Try
			sqlConn.Open()
			cmdDelete.Connection = sqlConn
			cmdDelete.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try

		Response.Redirect("Index.aspx")
	End Sub

End Class