﻿Imports System.Web.Services
Imports System.Data
Imports Newtonsoft.Json

Public Class Reports
	Inherits System.Web.UI.Page

	<WebMethod()>
	Public Shared Function GetSUGGESTION(ByVal str As String, ByVal type As String) As String()
		Dim Employees As New List(Of String)()
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		If type = "Employee" Then
			dt = clsconnection.GetData("SELECT TOP 10 EmpName as itemname FROM tbl_HRMS_EmployeeMaster WHERE EmpName LIKE '%" & Trim(clsSTRING.SetQuotedStr(str)) & "%';")
		ElseIf type = "BusinessUnit" Then
			dt = clsconnection.GetData("SELECT TOP 10 BusinessUnit as itemname FROM tbl_HRMS_EmployeeMaster WHERE BusinessUnit LIKE '%" & Trim(clsSTRING.SetQuotedStr(str)) & "%' GROUP BY BusinessUnit;")
		ElseIf type = "Manager" Then
			dt = clsconnection.GetData("SELECT TOP 10 EmpName as itemname FROM tbl_HRMS_EmployeeMaster WHERE EmpName LIKE '%" & Trim(clsSTRING.SetQuotedStr(str)) & "%' AND EmpLevel = 'MGR';")
		ElseIf type = "BusinessSegment" Then
			dt = clsconnection.GetData("SELECT TOP 10 BusinessSegment as itemname FROM tbl_HRMS_EmployeeMaster WHERE BusinessSegment LIKE '%" & Trim(clsSTRING.SetQuotedStr(str)) & "%' GROUP BY BusinessSegment;")
		ElseIf type = "TL" Then
			dt = clsconnection.GetData("SELECT TOP 10 EmpName as itemname FROM tbl_HRMS_EmployeeMaster WHERE EmpName LIKE '%" & Trim(clsSTRING.SetQuotedStr(str)) & "%' AND EmpLevel = 'TL';")
		End If
		Dim x As Integer
		x = 0
		Do Until x = dt.Rows.Count
			Employees.Add(dt.Rows(x).Item("itemname").ToString)
			x = x + 1
		Loop
		Return Employees.ToArray
	End Function

	<WebMethod()>
	Public Shared Function GetTardiness(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, insman, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim Listofabsencescount As New List(Of MonthlyIndividual)
		x = 0
		Do Until x = dt.Rows.Count
			Dim TardinessCount As New MonthlyIndividual
			TardinessCount.Name = dt.Rows(x).Item("EmpName").ToString
			Listofabsencescount.Add(TardinessCount)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.TardinessCount = Listofabsencescount
		x = 0
		Dim loginIDS As String
		Dim dtTARDINESS As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectabsences As String
			selectabsences = "SELECT c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) as mymonth,  COUNT(c.EmpName) as mycount FROM tbl_HRMS_Employee_Schedule a LEFT JOIN " _
						   & "tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate  = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.ReasonID = '1' AND DATEDIFF(minute, a.SchedIN, b.Start_Time) > 0 AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) ORDER BY c.EmpName"

			newds = clsconnection.GetDataSet(selectabsences)
			dtTARDINESS = newds.Tables(0)

		End If

		x = 0
		If dtTARDINESS.Rows.Count > 0 Then
			Do Until x = dtTARDINESS.Rows.Count
				Dim y As Integer = 0
				Dim empname, monthname, mycount As String
				empname = dtTARDINESS.Rows(x).Item("EmpName")
				monthname = dtTARDINESS.Rows(x).Item("mymonth")
				mycount = dtTARDINESS.Rows(x).Item("mycount")
				Do Until y = NewReport.TardinessCount.Count
					If (empname = NewReport.TardinessCount.Item(y).Name) Then
						If (monthname = "January") Then
							NewReport.TardinessCount.Item(y).January = mycount
						ElseIf (monthname = "February") Then
							NewReport.TardinessCount.Item(y).February = mycount
						ElseIf (monthname = "March") Then
							NewReport.TardinessCount.Item(y).March = mycount
						ElseIf (monthname = "April") Then
							NewReport.TardinessCount.Item(y).April = mycount
						ElseIf (monthname = "May") Then
							NewReport.TardinessCount.Item(y).May = mycount
						ElseIf (monthname = "June") Then
							NewReport.TardinessCount.Item(y).June = mycount
						ElseIf (monthname = "July") Then
							NewReport.TardinessCount.Item(y).July = mycount
						ElseIf (monthname = "August") Then
							NewReport.TardinessCount.Item(y).August = mycount
						ElseIf (monthname = "September") Then
							NewReport.TardinessCount.Item(y).September = mycount
						ElseIf (monthname = "October") Then
							NewReport.TardinessCount.Item(y).October = mycount
						ElseIf (monthname = "November") Then
							NewReport.TardinessCount.Item(y).November = mycount
						ElseIf (monthname = "December") Then
							NewReport.TardinessCount.Item(y).December = mycount
						End If
						y = NewReport.TardinessCount.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function

	<WebMethod()>
	Public Shared Function GetOverBreaks(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, insman, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(Trim(myteam_leader.Item(x).ToString)) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim Listofabsencescount As New List(Of MonthlyIndividual)
		x = 0
		Do Until x = dt.Rows.Count
			Dim TardinessCount As New MonthlyIndividual
			TardinessCount.Name = dt.Rows(x).Item("EmpName").ToString
			Listofabsencescount.Add(TardinessCount)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.TardinessCount = Listofabsencescount
		x = 0
		Dim loginIDS As String
		Dim dtTARDINESS As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectabsences As String
			selectabsences = "SELECT c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) as mymonth,  (COUNT(c.EmpName)) as mycount FROM tbl_HRMS_Employee_Schedule a INNER JOIN " _
						   & "(SELECT LoginID, SchedDate, SUM(DATEDIFF(minute, Start_Time, End_Time)) as break_duration FROM tbl_HRMS_Employee_Activity WHERE ReasonID IN (9,10,11) GROUP BY LoginID, SchedDate) b ON a.LoginID = b.LoginID AND a.SchedDate  = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.break_duration > 90 AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) ORDER BY c.EmpName"

			newds = clsconnection.GetDataSet(selectabsences)
			dtTARDINESS = newds.Tables(0)

		End If

		x = 0
		If dtTARDINESS.Rows.Count > 0 Then
			Do Until x = dtTARDINESS.Rows.Count
				Dim y As Integer = 0
				Dim empname, monthname, mycount As String
				empname = dtTARDINESS.Rows(x).Item("EmpName")
				monthname = dtTARDINESS.Rows(x).Item("mymonth")
				mycount = dtTARDINESS.Rows(x).Item("mycount")
				Do Until y = NewReport.TardinessCount.Count
					If (empname = NewReport.TardinessCount.Item(y).Name) Then
						If (monthname = "January") Then
							NewReport.TardinessCount.Item(y).January = mycount
						ElseIf (monthname = "February") Then
							NewReport.TardinessCount.Item(y).February = mycount
						ElseIf (monthname = "March") Then
							NewReport.TardinessCount.Item(y).March = mycount
						ElseIf (monthname = "April") Then
							NewReport.TardinessCount.Item(y).April = mycount
						ElseIf (monthname = "May") Then
							NewReport.TardinessCount.Item(y).May = mycount
						ElseIf (monthname = "June") Then
							NewReport.TardinessCount.Item(y).June = mycount
						ElseIf (monthname = "July") Then
							NewReport.TardinessCount.Item(y).July = mycount
						ElseIf (monthname = "August") Then
							NewReport.TardinessCount.Item(y).August = mycount
						ElseIf (monthname = "September") Then
							NewReport.TardinessCount.Item(y).September = mycount
						ElseIf (monthname = "October") Then
							NewReport.TardinessCount.Item(y).October = mycount
						ElseIf (monthname = "November") Then
							NewReport.TardinessCount.Item(y).November = mycount
						ElseIf (monthname = "December") Then
							NewReport.TardinessCount.Item(y).December = mycount
						End If
						y = NewReport.TardinessCount.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function

	<WebMethod()>
	Public Shared Function GetAbsences(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, insman, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim Listofabsencescount As New List(Of MonthlyIndividual)
		x = 0
		Do Until x = dt.Rows.Count
			Dim TardinessCount As New MonthlyIndividual
			TardinessCount.Name = dt.Rows(x).Item("EmpName").ToString
			Listofabsencescount.Add(TardinessCount)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.TardinessCount = Listofabsencescount
		x = 0
		Dim loginIDS As String
		Dim dtTARDINESS As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectabsences As String
			selectabsences = "SELECT c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) as mymonth, count(DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)))" _
							& " as mycount FROM tbl_HRMS_Employee_Schedule a LEFT JOIN tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate " _
							& " = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.SeriesID is NULL AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' " _
							& " GROUP BY c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) ORDER BY c.EmpName"

			newds = clsconnection.GetDataSet(selectabsences)
			dtTARDINESS = newds.Tables(0)

		End If

		x = 0
		If dtTARDINESS.Rows.Count > 0 Then
			Do Until x = dtTARDINESS.Rows.Count
				Dim y As Integer = 0
				Dim empname, monthname, mycount As String
				empname = dtTARDINESS.Rows(x).Item("EmpName")
				monthname = dtTARDINESS.Rows(x).Item("mymonth")
				mycount = dtTARDINESS.Rows(x).Item("mycount")
				Do Until y = NewReport.TardinessCount.Count
					If (empname = NewReport.TardinessCount.Item(y).Name) Then
						If (monthname = "January") Then
							NewReport.TardinessCount.Item(y).January = mycount
						ElseIf (monthname = "February") Then
							NewReport.TardinessCount.Item(y).February = mycount
						ElseIf (monthname = "March") Then
							NewReport.TardinessCount.Item(y).March = mycount
						ElseIf (monthname = "April") Then
							NewReport.TardinessCount.Item(y).April = mycount
						ElseIf (monthname = "May") Then
							NewReport.TardinessCount.Item(y).May = mycount
						ElseIf (monthname = "June") Then
							NewReport.TardinessCount.Item(y).June = mycount
						ElseIf (monthname = "July") Then
							NewReport.TardinessCount.Item(y).July = mycount
						ElseIf (monthname = "August") Then
							NewReport.TardinessCount.Item(y).August = mycount
						ElseIf (monthname = "September") Then
							NewReport.TardinessCount.Item(y).September = mycount
						ElseIf (monthname = "October") Then
							NewReport.TardinessCount.Item(y).October = mycount
						ElseIf (monthname = "November") Then
							NewReport.TardinessCount.Item(y).November = mycount
						ElseIf (monthname = "December") Then
							NewReport.TardinessCount.Item(y).December = mycount
						End If
						y = NewReport.TardinessCount.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function
	<WebMethod()>
	Public Shared Function GetEmployeeList(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, insman, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim Listofabsencescount As New List(Of MonthlyIndividual)
		x = 0
		Do Until x = dt.Rows.Count
			Dim absentcount As New MonthlyIndividual
			absentcount.Name = dt.Rows(x).Item("EmpName").ToString
			Listofabsencescount.Add(absentcount)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.AbsentCount = Listofabsencescount
		x = 0
		Dim loginIDS As String
		Dim dtabsences, dtTardiness, dtPTO, dtCTO, dtABSENCESCOUNT As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectabsences As String
			selectabsences = "SELECT count(c.BusinessUnit) as mycount, c.BusinessUnit FROM tbl_HRMS_Employee_Schedule a LEFT JOIN tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate " _
							& "= b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.SeriesID is NULL AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.BusinessUnit order BY c.BusinessUnit;" _
							& "SELECT count(c.BusinessUnit) as mycount, c.BusinessUnit FROM tbl_HRMS_Employee_Schedule a INNER JOIN tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate " _
							& "= b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.ReasonID = '1' AND DATEDIFF(minute, a.SchedIN, b.Start_Time) > 0 AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.BusinessUnit order BY c.BusinessUnit;" _
							& "SELECT count(c.BusinessUnit) as mycount, c.BusinessUnit FROM tbl_HRMS_Employee_Schedule a INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'PTO' AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.BusinessUnit order BY c.BusinessUnit;" _
							& "SELECT count(c.BusinessUnit) as mycount, c.BusinessUnit FROM tbl_HRMS_Employee_Schedule a INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'CTO' AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' GROUP BY c.BusinessUnit order BY c.BusinessUnit;" _
							& "SELECT c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) as mymonth, count(DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)))" _
							& " as mycount FROM tbl_HRMS_Employee_Schedule a LEFT JOIN tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate " _
							& " = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND b.SeriesID is NULL AND a.LoginID IN (" & loginIDS & ") AND a.SchedDate BETWEEN '" & mydata.DateStarted & "' AND '" & mydata.DateEnded & "' " _
							& " GROUP BY c.EmpName, DATENAME(MONTH, DATEADD(MONTH, DATEPART(month, a.scheddate), -1)) ORDER BY c.EmpName"

			newds = clsconnection.GetDataSet(selectabsences)
			dtabsences = newds.Tables(0)
			dtTardiness = newds.Tables(1)
			dtPTO = newds.Tables(2)
			dtCTO = newds.Tables(3)
			dtABSENCESCOUNT = newds.Tables(4)
		End If
		Dim Absences As New List(Of ReportITEMS)
		x = 0
		If dtabsences.Rows.Count > 0 Then
			Do Until x = dtabsences.Rows.Count
				Dim Absencesitem As New ReportITEMS
				Absencesitem.y = dtabsences.Rows(x).Item("mycount")
				Absencesitem.indexLabel = dtabsences.Rows(x).Item("BusinessUnit")
				Absences.Add(Absencesitem)
				x = x + 1
			Loop
		End If
		NewReport.Absences = Absences
		Dim Tardiness As New List(Of ReportITEMS)
		x = 0
		If dtTardiness.Rows.Count > 0 Then

			Do Until x = dtTardiness.Rows.Count
				Dim Tardinessitem As New ReportITEMS
				Tardinessitem.y = dtTardiness.Rows(x).Item("mycount")
				Tardinessitem.indexLabel = dtTardiness.Rows(x).Item("BusinessUnit")
				Tardiness.Add(Tardinessitem)
				x = x + 1
			Loop

		End If
		NewReport.Tardiness = Tardiness
		Dim PTO As New List(Of ReportITEMS)
		x = 0
		If dtPTO.Rows.Count > 0 Then

			Do Until x = dtPTO.Rows.Count
				Dim PTOitem As New ReportITEMS
				PTOitem.y = dtPTO.Rows(x).Item("mycount")
				PTOitem.indexLabel = dtPTO.Rows(x).Item("BusinessUnit")
				PTO.Add(PTOitem)
				x = x + 1
			Loop

		End If
		NewReport.PTO = PTO
		Dim CTO As New List(Of ReportITEMS)
		x = 0
		If dtCTO.Rows.Count > 0 Then

			Do Until x = dtCTO.Rows.Count
				Dim CTOitem As New ReportITEMS
				CTOitem.y = dtCTO.Rows(x).Item("mycount")
				CTOitem.indexLabel = dtCTO.Rows(x).Item("BusinessUnit")
				CTO.Add(CTOitem)
				x = x + 1
			Loop
		End If
		NewReport.CTO = CTO
		x = 0
		If dtABSENCESCOUNT.Rows.Count > 0 Then
			Do Until x = dtABSENCESCOUNT.Rows.Count
				Dim y As Integer = 0
				Dim empname, monthname, mycount As String
				empname = dtABSENCESCOUNT.Rows(x).Item("EmpName")
				monthname = dtABSENCESCOUNT.Rows(x).Item("mymonth")
				mycount = dtABSENCESCOUNT.Rows(x).Item("mycount")
				Do Until y = NewReport.AbsentCount.Count
					If (empname = NewReport.AbsentCount.Item(y).Name) Then
						If (monthname = "January") Then
							NewReport.AbsentCount.Item(y).January = mycount
						ElseIf (monthname = "February") Then
							NewReport.AbsentCount.Item(y).February = mycount
						ElseIf (monthname = "March") Then
							NewReport.AbsentCount.Item(y).March = mycount
						ElseIf (monthname = "April") Then
							NewReport.AbsentCount.Item(y).April = mycount
						ElseIf (monthname = "May") Then
							NewReport.AbsentCount.Item(y).May = mycount
						ElseIf (monthname = "June") Then
							NewReport.AbsentCount.Item(y).June = mycount
						ElseIf (monthname = "July") Then
							NewReport.AbsentCount.Item(y).July = mycount
						ElseIf (monthname = "August") Then
							NewReport.AbsentCount.Item(y).August = mycount
						ElseIf (monthname = "September") Then
							NewReport.AbsentCount.Item(y).September = mycount
						ElseIf (monthname = "October") Then
							NewReport.AbsentCount.Item(y).October = mycount
						ElseIf (monthname = "November") Then
							NewReport.AbsentCount.Item(y).November = mycount
						ElseIf (monthname = "December") Then
							NewReport.AbsentCount.Item(y).December = mycount
						End If
						y = NewReport.AbsentCount.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function
	<WebMethod()>
	Public Shared Function GetTardinessCalendar(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim ListofTardinessCalendar As New List(Of Calendar)
		x = 0
		Do Until x = dt.Rows.Count
			Dim TardinessCalendar As New Calendar
			TardinessCalendar.Name = dt.Rows(x).Item("EmpName").ToString
			ListofTardinessCalendar.Add(TardinessCalendar)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.TardinessCalendar = ListofTardinessCalendar
		x = 0
		Dim loginIDS As String
		Dim dtTARDINESS As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectTardiness As String
			selectTardiness = "SELECT c.EmpName, a.SchedDate, b.myStartTime, DATEDIFF(minute, a.SchedIN, b.myStartTime) as minutes, CASE WHEN DATEDIFF(minute, a.SchedIN, b.myStartTime) > 0 THEN 1 ELSE 0 END as mytag  FROM tbl_HRMS_Employee_Schedule a LEFT JOIN " _
							 & "(SELECT loginID, SchedDate, MIN(Start_Time) as myStartTime, MIN(ReasonID) as myReasonID FROM tbl_HRMS_Employee_Activity WHERE ReasonID =  1 GROUP BY loginID, SchedDate) as b ON a.LoginID = b.LoginID AND a.SchedDate  = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND a.LoginID IN (" & loginIDS & ") AND  a.scheddate BETWEEN '" & mydata.mydate & "' AND DATEADD(DAY, 6, '" & mydata.mydate & "') ORDER BY c.EmpName"

			newds = clsconnection.GetDataSet(selectTardiness)
			dtTARDINESS = newds.Tables(0)

		End If


		Dim day1, day2, day3, day4, day5, day6, day7 As String
		day1 = CDate(mydata.mydate)
		day2 = DateAdd(DateInterval.Day, 1, CDate(mydata.mydate))
		day3 = DateAdd(DateInterval.Day, 2, CDate(mydata.mydate))
		day4 = DateAdd(DateInterval.Day, 3, CDate(mydata.mydate))
		day5 = DateAdd(DateInterval.Day, 4, CDate(mydata.mydate))
		day6 = DateAdd(DateInterval.Day, 5, CDate(mydata.mydate))
		day7 = DateAdd(DateInterval.Day, 6, CDate(mydata.mydate))
		x = 0
		If dtTARDINESS.Rows.Count > 0 Then
			Do Until x = dtTARDINESS.Rows.Count
				Dim y As Integer = 0
				Dim empname, scheddate, mytag As String
				empname = dtTARDINESS.Rows(x).Item("EmpName")
				scheddate = dtTARDINESS.Rows(x).Item("scheddate")
				mytag = dtTARDINESS.Rows(x).Item("mytag")
				Do Until y = NewReport.TardinessCalendar.Count
					If (empname = NewReport.TardinessCalendar.Item(y).Name) Then
						If (CDate(scheddate) = CDate(day1)) Then
							NewReport.TardinessCalendar.Item(y).Day1 = mytag
						ElseIf (CDate(scheddate) = CDate(day2)) Then
							NewReport.TardinessCalendar.Item(y).Day2 = mytag
						ElseIf (CDate(scheddate) = CDate(day3)) Then
							NewReport.TardinessCalendar.Item(y).Day3 = mytag
						ElseIf (CDate(scheddate) = CDate(day4)) Then
							NewReport.TardinessCalendar.Item(y).Day4 = mytag
						ElseIf (CDate(scheddate) = CDate(day5)) Then
							NewReport.TardinessCalendar.Item(y).Day5 = mytag
						ElseIf (CDate(scheddate) = CDate(day6)) Then
							NewReport.TardinessCalendar.Item(y).Day6 = mytag
						ElseIf (CDate(scheddate) = CDate(day7)) Then
							NewReport.TardinessCalendar.Item(y).Day7 = mytag
						End If
						If mytag = 1 Then
							NewReport.TardinessCalendar.Item(y).Total = CInt(NewReport.TardinessCalendar.Item(y).Total) + 1
						End If
						y = NewReport.TardinessCalendar.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function
	<WebMethod()>
	Public Shared Function GetAbsencesCalendar(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim ListofAbsencesCalendar As New List(Of Calendar)
		x = 0
		Do Until x = dt.Rows.Count
			Dim AbsencesCalendar As New Calendar
			AbsencesCalendar.Name = dt.Rows(x).Item("EmpName").ToString
			ListofAbsencesCalendar.Add(AbsencesCalendar)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.AbsencesCalendar = ListofAbsencesCalendar
		x = 0
		Dim loginIDS As String
		Dim dtABSENCES As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectAbsencess As String
			selectAbsencess = "SELECT c.EmpName, a.SchedDate, b.SeriesID, CASE WHEN b.SeriesID is NULL THEN 1 ELSE 0 END as mytag FROM tbl_HRMS_Employee_Schedule a LEFT JOIN " _
							& " tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID " _
							& " WHERE a.SchedType = 'IN' AND a.LoginID IN (" & loginIDS & ") AND a.scheddate BETWEEN '" & mydata.mydate & "' AND DATEADD(DAY, 6, '" & mydata.mydate & "') ORDER BY c.EmpName"
			newds = clsconnection.GetDataSet(selectAbsencess)
			dtABSENCES = newds.Tables(0)

		End If


		Dim day1, day2, day3, day4, day5, day6, day7 As String
		day1 = CDate(mydata.mydate)
		day2 = DateAdd(DateInterval.Day, 1, CDate(mydata.mydate))
		day3 = DateAdd(DateInterval.Day, 2, CDate(mydata.mydate))
		day4 = DateAdd(DateInterval.Day, 3, CDate(mydata.mydate))
		day5 = DateAdd(DateInterval.Day, 4, CDate(mydata.mydate))
		day6 = DateAdd(DateInterval.Day, 5, CDate(mydata.mydate))
		day7 = DateAdd(DateInterval.Day, 6, CDate(mydata.mydate))
		x = 0
		If dtABSENCES.Rows.Count > 0 Then
			Do Until x = dtABSENCES.Rows.Count
				Dim y As Integer = 0
				Dim empname, scheddate, mytag As String
				empname = dtABSENCES.Rows(x).Item("EmpName")
				scheddate = dtABSENCES.Rows(x).Item("scheddate")
				mytag = dtABSENCES.Rows(x).Item("mytag")
				Do Until y = NewReport.AbsencesCalendar.Count
					If (empname = NewReport.AbsencesCalendar.Item(y).Name) Then
						If (CDate(scheddate) = CDate(day1)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day1 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day1 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day2)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day2 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day2 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day3)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day3 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day3 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day4)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day4 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day4 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day5)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day5 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day5 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day6)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day6 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day6 = mytag
							End If
						ElseIf (CDate(scheddate) = CDate(day7)) Then
							If CDate(scheddate) > Now.Date Then
								NewReport.AbsencesCalendar.Item(y).Day7 = 0
							Else
								NewReport.AbsencesCalendar.Item(y).Day7 = mytag
							End If
						End If
						If mytag = 1 Then
							NewReport.AbsencesCalendar.Item(y).Total = CInt(NewReport.AbsencesCalendar.Item(y).Total) + 1
						End If
						y = NewReport.AbsencesCalendar.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function

	<WebMethod()>
	Public Shared Function GetOverbreaksCalendar(ByVal mydata As ReceiveList) As MyReport
		Dim Employees As New List(Of String)()
		Dim NewReport As New MyReport
		Dim dt As New DataTable
		Dim clsconnection As New clsConnection
		Dim clsSTRING As New clsSTRING
		Dim myemployees, mybusiness_segment, mybusiness_unit, mymanager, myteam_leader As List(Of String)
		myemployees = mydata.Employee
		mybusiness_segment = mydata.Business_Segment
		mybusiness_unit = mydata.Business_Unit
		mymanager = mydata.Manager
		myteam_leader = mydata.Team_Leader
		Dim x As Integer = 0
		Dim insemp, insbs, insbu, instl As String
		If myemployees.Count > 0 Then
			Dim employeeitems As String
			Do Until x = myemployees.Count
				employeeitems = employeeitems & "'" & Trim(myemployees.Item(x).ToString) & "',"
				x = x + 1
			Loop
			employeeitems = employeeitems.Remove(employeeitems.Length - 1)
			insemp = "AND EmpName IN (" & employeeitems & ")"
		End If
		x = 0
		If mybusiness_segment.Count > 0 Then
			Dim bsitems As String
			Do Until x = mybusiness_segment.Count
				bsitems = bsitems & "'" & Trim(mybusiness_segment.Item(x).ToString) & "',"
				x = x + 1
			Loop
			bsitems = bsitems.Remove(bsitems.Length - 1)
			insbs = "AND BusinessSegment IN (" & bsitems & ")"
		End If
		x = 0
		If mybusiness_unit.Count > 0 Then
			Dim buitems As String
			Do Until x = mybusiness_unit.Count
				buitems = buitems & "'" & Trim(mybusiness_unit.Item(x).ToString) & "',"
				x = x + 1
			Loop
			buitems = buitems.Remove(buitems.Length - 1)
			insbu = "AND BusinessUnit IN (" & buitems & ")"
		End If
		x = 0
		If myteam_leader.Count > 0 Then
			Dim tl_items As String
			Do Until x = myteam_leader.Count
				tl_items = tl_items & "'" & Trim(myteam_leader.Item(x).ToString) & "',"
				x = x + 1
			Loop
			tl_items = tl_items.Remove(tl_items.Length - 1)
			instl = "AND MngrName IN (" & tl_items & ")"
		End If
		'If (myteam_leader.Count = 0 And mybusiness_unit.Count = 0 And mybusiness_segment.Count = 0 And myemployees.Count = 0) Then
		'    dt = clsconnection.GetData("SELECT NTID FROM tbl_HRMS_EmployeeMaster")
		'Else
		Dim selectntids As String
		selectntids = "SELECT NTID, EmpName FROM tbl_HRMS_EmployeeMaster WHERE AccessLevel is not Null AND BusinessUnit IN ('Choice','Hubzu','Revel','Property Preservation and Inspection','Rental Property Management')" & insemp & " " & insbs & " " & insbu & " " & instl & " ORDER BY NTID"
		dt = clsconnection.GetData(selectntids)
		'End If
		Dim ListofAbsencesCalendar As New List(Of Calendar)
		x = 0
		Do Until x = dt.Rows.Count
			Dim AbsencesCalendar As New Calendar
			AbsencesCalendar.Name = dt.Rows(x).Item("EmpName").ToString
			ListofAbsencesCalendar.Add(AbsencesCalendar)
			Employees.Add(dt.Rows(x).Item("NTID").ToString)
			x = x + 1
		Loop
		NewReport.AbsencesCalendar = ListofAbsencesCalendar
		x = 0
		Dim loginIDS As String
		Dim dtABSENCES As New DataTable
		Dim newds As New DataSet
		If Employees.Count > 0 Then
			Do Until x = Employees.Count
				loginIDS = loginIDS & "'" & Employees.Item(x).ToString & "',"
				x = x + 1
			Loop
			loginIDS = loginIDS.Remove(loginIDS.Length - 1)
			Dim selectAbsencess As String
			selectAbsencess = "SELECT c.EmpName, a.SchedDate,  break_duration, CASE WHEN break_duration > 90 THEN 1 ELSE 0 END as mytag  FROM tbl_HRMS_Employee_Schedule a INNER JOIN " _
							& "(SELECT LoginID, SchedDate, SUM(DATEDIFF(minute, Start_Time, End_Time)) as break_duration FROM tbl_HRMS_Employee_Activity b WHERE ReasonID IN (9,10,11) GROUP BY LoginID, SchedDate) as b ON a.LoginID = b.LoginID AND a.SchedDate  = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID WHERE a.SchedType = 'IN' AND a.LoginID IN (" & loginIDS & ") AND a.scheddate BETWEEN '" & mydata.mydate & "' AND DATEADD(DAY, 6, '" & mydata.mydate & "') ORDER BY c.EmpName"


			'selectAbsencess = "SELECT c.EmpName, a.SchedDate, b.SeriesID, CASE WHEN b.SeriesID is NULL THEN 1 ELSE 0 END as mytag FROM tbl_HRMS_Employee_Schedule a LEFT JOIN " _
			'                & " tbl_HRMS_Employee_Activity b ON a.LoginID = b.LoginID AND a.SchedDate = b.SchedDate INNER JOIN tbl_HRMS_EmployeeMaster c ON a.LoginID = c.NTID " _
			'                & " WHERE a.SchedType = 'IN' AND a.LoginID IN (" & loginIDS & ") AND a.scheddate BETWEEN '" & mydata.mydate & "' AND DATEADD(DAY, 5, '" & mydata.mydate & "') ORDER BY c.EmpName"
			newds = clsconnection.GetDataSet(selectAbsencess)
			dtABSENCES = newds.Tables(0)

		End If


		Dim day1, day2, day3, day4, day5, day6, day7 As String
		day1 = CDate(mydata.mydate)
		day2 = DateAdd(DateInterval.Day, 1, CDate(mydata.mydate))
		day3 = DateAdd(DateInterval.Day, 2, CDate(mydata.mydate))
		day4 = DateAdd(DateInterval.Day, 3, CDate(mydata.mydate))
		day5 = DateAdd(DateInterval.Day, 4, CDate(mydata.mydate))
		day6 = DateAdd(DateInterval.Day, 5, CDate(mydata.mydate))
		day7 = DateAdd(DateInterval.Day, 6, CDate(mydata.mydate))
		x = 0
		If dtABSENCES.Rows.Count > 0 Then
			Do Until x = dtABSENCES.Rows.Count
				Dim y As Integer = 0
				Dim empname, scheddate, mytag As String
				empname = dtABSENCES.Rows(x).Item("EmpName")
				scheddate = dtABSENCES.Rows(x).Item("scheddate")
				mytag = dtABSENCES.Rows(x).Item("mytag")
				Do Until y = NewReport.AbsencesCalendar.Count
					If (empname = NewReport.AbsencesCalendar.Item(y).Name) Then
						If (CDate(scheddate) = CDate(day1)) Then
							NewReport.AbsencesCalendar.Item(y).Day1 = mytag
						ElseIf (CDate(scheddate) = CDate(day2)) Then
							NewReport.AbsencesCalendar.Item(y).Day2 = mytag
						ElseIf (CDate(scheddate) = CDate(day3)) Then
							NewReport.AbsencesCalendar.Item(y).Day3 = mytag
						ElseIf (CDate(scheddate) = CDate(day4)) Then
							NewReport.AbsencesCalendar.Item(y).Day4 = mytag
						ElseIf (CDate(scheddate) = CDate(day5)) Then
							NewReport.AbsencesCalendar.Item(y).Day5 = mytag
						ElseIf (CDate(scheddate) = CDate(day6)) Then
							NewReport.AbsencesCalendar.Item(y).Day6 = mytag
						ElseIf (CDate(scheddate) = CDate(day7)) Then
							NewReport.AbsencesCalendar.Item(y).Day7 = mytag
						End If
						If mytag = 1 Then
							NewReport.AbsencesCalendar.Item(y).Total = CInt(NewReport.AbsencesCalendar.Item(y).Total) + 1
						End If
						y = NewReport.AbsencesCalendar.Count - 1
					End If
					y = y + 1
				Loop
				x = x + 1
			Loop
		End If
		Return NewReport
	End Function


	<WebMethod()>
	Public Shared Function GetUsagePercentage(UsageReport As UsageReport) As UsageReport

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtusage As New DataTable
		Dim x As Integer = 0

		qry = ""

		qry += "SELECT BusinessUnit,HeadCount, "
		qry += "CAST(CAST(notUsing as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [NotUsingPercentage],"
		qry += "CAST(CAST(Using as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [UsingPercentage],"
		qry += "CAST(CAST(Present as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [PresentPercentage],"
		qry += "CAST(CAST(Absent as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [AbsentPercentage],	"
		qry += "CAST(CAST(RestDay as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [RestDayPercentage],"
		qry += "CAST(CAST(Leave as DECIMAL(9,2)) / CAST(dataCount as DECIMAL(9,2))*100 as DECIMAL(9,1)) [LeavePercentage] "
		qry += "FROM (SELECT  mMain.BusinessUnit,"
		qry += "headct.ct [HeadCount],"
		qry += "SUM(case when data.NotUsing IS null then 1 else 0 end) [NotUsing],"
		qry += "SUM(case when data.Using is null then 0 else data.Using end) [Using],"
		qry += "SUM(case when data.Present is null then 0 else data.Present end) [Present],"
		qry += "SUM(case when data.Absent is null then 0 else data.Absent end) [Absent],"
		qry += "SUM(case when data.RestDay is null then 0 else data.RestDay end) [RestDay],"
		qry += "SUM(case when data.Leave is null then 0 else data.Leave end) [Leave],"
		qry += "SUM(1) [dataCount] "
		qry += "FROM dbo.tbl_HRMS_EmployeeMaster mMain "
		qry += "OUTER APPLY(SELECT * FROM (SELECT SchedDate,BusinessUnit,EmpName,MngrName,"
		qry += "case when (Select top 1 1 [a] from dbo.tbl_HRMS_Employee_Activity where LoginID = a.NTID and SchedDate = a.SchedDate) is Not null then 	0 "
		qry += "else "
		qry += "case when Leave = 1 then 0 "
		qry += "else "
		qry += "case when RestDay = 1 then 0 "
		qry += "else "
		qry += "case when (Select top 1 1 [a] from dbo.tbl_HRMS_Employee_Schedule where SchedDate = a.SchedDate and LoginID = a.NTID) is Not null then 0 "
		qry += "else 1  end "
		qry += "End End End "
		qry += "[NotUsing],"
		qry += "present + Absent + RestDay + Leave [Using], "
		qry += "Present, Absent, RestDay, Leave, a.NTID "
		qry += "FROM (Select sc.SchedDate,"
		qry += "empMain.BusinessUnit, "
		qry += "empMain.EmpName,"
		qry += "empMain.MngrName,"
		qry += "'' [NotUsing], "
		qry += "'' [Using],	"
		qry += "case when sc.SchedType = 'RD' then 0 "
		qry += "else "
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') = 'L' then 0 "
		qry += "else "
		qry += "case when (Select top 1 1 [status] from dbo.tbl_HRMS_Employee_Activity where LoginID = empMain.NTID and SchedDate = sc.SchedDate) is null then 0 else 1 end "
		qry += "End "
		qry += "end [Present],"
		qry += "case when (Select top 1 1 [status] from dbo.tbl_HRMS_Employee_Activity where LoginID = empMain.NTID and SchedDate = sc.SchedDate) is null then "
		qry += "case when sc.SchedType <> 'RD' then "
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') = 'L' then 0 "
		qry += "else 1 "
		qry += "End "
		qry += "else 0 "
		qry += "End "
		qry += "else 0 "
		qry += "end [Absent],"
		qry += "case when sc.SchedType = 'RD' then 1 else 0 end  [RestDay],"
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') is null then 0 else 1 end [Leave],"
		qry += "empMain.NTID "
		qry += "from dbo.tbl_HRMS_EmployeeMaster empMain join  dbo.tbl_HRMS_Employee_Schedule sc on empMain.NTID = sc.LoginID "
		qry += "WHERE  empMain.BusinessUnit Is Not null and empMain.AccessLevel is not null and sc.SchedDate between '" & UsageReport.dtFrom.Trim & "' and '" & UsageReport.dtTo.Trim & "') a "
		qry += "WHERE a.NTID = mMain.NTID and mMain.AccessLevel is not null) b) data "
		qry += "outer apply (Select SUM(1) [ct] from tbl_HRMS_EmployeeMaster where BusinessUnit = mMain.BusinessUnit and AccessLevel is not null) headct "
		qry += "WHERE mMain.AccessLevel Is Not null And mMain.BusinessUnit Is Not null "
		qry += "group by mMain.BusinessUnit, headct.ct) final "

		dtusage = cls.GetData(qry)

		Dim PercentagTables As New List(Of PercentageTable)

		x = 0
		Do Until x = dtusage.Rows.Count

			Dim PercentagTable As New PercentageTable

			PercentagTable.bu = dtusage.Rows(x).Item("BusinessUnit")
			PercentagTable.headcount = dtusage.Rows(x).Item("HeadCount")
			PercentagTable.notusing = dtusage.Rows(x).Item("NotUsingPercentage") & "%"
			PercentagTable.vusing = dtusage.Rows(x).Item("UsingPercentage") & "%"

			PercentagTable.present = dtusage.Rows(x).Item("PresentPercentage") & "%"
			PercentagTable.absent = dtusage.Rows(x).Item("AbsentPercentage") & "%"
			PercentagTable.restday = dtusage.Rows(x).Item("RestDayPercentage") & "%"
			PercentagTable.leave = dtusage.Rows(x).Item("LeavePercentage") & "%"

			PercentagTables.Add(PercentagTable)

			x = x + 1
		Loop
		UsageReport.tblSUMMARY = PercentagTables

		Return UsageReport
	End Function

	<WebMethod()>
	Public Shared Function GetUsageReportCount(UsageReport As UsageReport) As UsageReport
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtUsage As New DataTable

		qry = ""

		qry += "SELECT SchedDate,mMain.BusinessUnit,mMain.EmpName,mMain.MngrName,"
		qry += "case when data.NotUsing IS null then 1 else 0 end [NotUsing],"
		qry += "case when data.Using is null then 0 else data.Using end [Using],"
		qry += "case when data.Present is null then 0 else data.Present end [Present],"
		qry += "case when data.Absent is null then 0 else data.Absent end [Absent],"
		qry += "case when data.RestDay is null then 0 else data.RestDay end [RestDay],"
		qry += "case when data.Leave is null then 0 else data.Leave end [Leave]"

		qry += "FROM dbo.tbl_HRMS_EmployeeMaster mMain "

		qry += "OUTER APPLY(SELECT * FROM (SELECT SchedDate,BusinessUnit,EmpName,MngrName,"
		qry += "case when (Select top 1 1 [a] from dbo.tbl_HRMS_Employee_Activity where LoginID = a.NTID and SchedDate = a.SchedDate) is Not null then 	0 "
		qry += "else "
		qry += "case when Leave = 1 then 0 "
		qry += "else "
		qry += "case when RestDay = 1 then 0 "
		qry += "else "
		qry += "case when (Select top 1 1 [a] from dbo.tbl_HRMS_Employee_Schedule where SchedDate = a.SchedDate and LoginID = a.NTID) is Not null then 0 "
		qry += "else 1  end "
		qry += "End "
		qry += "End "
		qry += "End "
		qry += "[NotUsing],"

		qry += "present + Absent + RestDay + Leave [Using], "

		qry += "Present, Absent, RestDay, Leave, a.NTID "

		qry += "FROM (Select sc.SchedDate, "
		qry += "empMain.BusinessUnit, "
		qry += "empMain.EmpName,"
		qry += "empMain.MngrName,"
		qry += "'' [NotUsing], "
		qry += "'' [Using],	"

		qry += "case when sc.SchedType = 'RD' then 0 "
		qry += "else "
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') = 'L' then 0 "
		qry += "else "
		qry += "case when (Select top 1 1 [status] from dbo.tbl_HRMS_Employee_Activity where LoginID = empMain.NTID and SchedDate = sc.SchedDate) is null then 0 else 1 end "
		qry += "End "
		qry += "end [Present],"

		qry += "case when (Select top 1 1 [status] from dbo.tbl_HRMS_Employee_Activity where LoginID = empMain.NTID and SchedDate = sc.SchedDate) is null then "
		qry += "case when sc.SchedType <> 'RD' then "
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') = 'L' then 0 "
		qry += "else 1 "
		qry += "End "
		qry += "else 0 "
		qry += "End "
		qry += "else 0 "
		qry += "end [Absent],"

		qry += "case when sc.SchedType = 'RD' then 1 else 0 end  [RestDay],"
		qry += "case when (Select top 1 'L' [Status] from dbo.tbl_HRMS_LeaveMaster where empID = empMain.NTID and LeaveDate = sc.SchedDate and LeaveStatus = 'Approved') is null then 0 else 1 end [Leave], "
		qry += "empMain.NTID "
		qry += "from dbo.tbl_HRMS_EmployeeMaster empMain join  dbo.tbl_HRMS_Employee_Schedule sc on empMain.NTID = sc.LoginID "

		qry += "WHERE  empMain.BusinessUnit Is Not null and empMain.AccessLevel is not null and sc.SchedDate between '" & UsageReport.dtFrom.Trim & "' and '" & UsageReport.dtTo.Trim & "') a "

		qry += "WHERE a.NTID = mMain.NTID and mMain.AccessLevel is not null) b "

		qry += ") data "

		qry += "outer apply (Select SUM(1) [ct] from tbl_HRMS_EmployeeMaster where BusinessUnit = mMain.BusinessUnit and AccessLevel is not null) headct "

		qry += "WHERE mMain.AccessLevel Is Not null And mMain.BusinessUnit Is Not null "

		qry += "order by mMain.BusinessUnit,mMain.EmpName,data.SchedDate "

		dtUsage = cls.GetData(qry)

		Dim PercentagCounts As New List(Of PercentagCount)

		Dim x As Integer = 0
		Do Until x = dtUsage.Rows.Count

			Dim PercentagCount As New PercentagCount

			If IsDBNull(dtUsage.Rows(x).Item("SchedDate")) = False Then PercentagCount.SchedDate = dtUsage.Rows(x).Item("SchedDate") Else PercentagCount.SchedDate = "--"
			PercentagCount.BusinessUnit = dtUsage.Rows(x).Item("BusinessUnit")
			PercentagCount.EmpName = dtUsage.Rows(x).Item("EmpName")
			PercentagCount.MngrName = dtUsage.Rows(x).Item("MngrName")
			PercentagCount.vNotUsing = dtUsage.Rows(x).Item("NotUsing")
			PercentagCount.vUsing = dtUsage.Rows(x).Item("Using")
			PercentagCount.Present = dtUsage.Rows(x).Item("Present")
			PercentagCount.Absent = dtUsage.Rows(x).Item("Absent")
			PercentagCount.RestDay = dtUsage.Rows(x).Item("RestDay")
			PercentagCount.Leave = dtUsage.Rows(x).Item("Leave")

			PercentagCounts.Add(PercentagCount)
			x = x + 1
		Loop

		UsageReport.tblPERCENTAGE = PercentagCounts


		Return UsageReport
	End Function

	<WebMethod()>
	Public Shared Function GetLeaveReport(LeaveReport As LeaveReport) As LeaveReport

		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim dtLeave As New DataTable
		Dim x As Integer = 0

		qry = ""
		If LeaveReport.strLvl = "24" Then
			qry += "select "
			qry += "tblEmp.EmpID, "
			qry += "tblEmp.EmpName, "
			qry += "tblLeave.LeaveDate, "
			qry += "tblLeave.LeaveType, "
			qry += "case when tblLeave.isHalfDay = 0 then 'YES' else 'NO' end [HalfDay], "
			qry += "tblLeave.DateApplied, "
			qry += "tblLeave.LeaveStatus, "
			qry += "tblLeave.DateApplied, "
			qry += "(select EmpName from tbl_HRMS_EmployeeMaster where NTID = tblLeave.ApprovedBy) [ApprovedBy] "
			qry += "from tbl_HRMS_LeaveMaster tblLeave "
			qry += "join tbl_HRMS_EmployeeMaster tblEmp "
			qry += "on tblLeave.EmpID = tblEmp.NTID "
			qry += "where "
			If LeaveReport.ddlStatus <> "All" Then
				qry += "tblLeave.LeaveStatus = '" & LeaveReport.ddlStatus & "' and "
			End If
			qry += "tblEmp.BusinessSegment = 'Financial Services' and "
			qry += "tblLeave.LeaveDate between '" & LeaveReport.dtFrom & "' and '" & LeaveReport.dtTo & "'"
		Else
			qry += "select "
			qry += "tblEmp.EmpID, "
			qry += "tblEmp.EmpName, "
			qry += "tblLeave.LeaveDate, "
			qry += "tblLeave.LeaveType, "
			qry += "case when tblLeave.isHalfDay = 0 then 'YES' else 'NO' end [HalfDay], "
			qry += "tblLeave.DateApplied, "
			qry += "tblLeave.LeaveStatus, "
			qry += "tblLeave.DateApplied, "
			qry += "(select EmpName from tbl_HRMS_EmployeeMaster where NTID = tblLeave.ApprovedBy) [ApprovedBy] "
			qry += "from tbl_HRMS_LeaveMaster tblLeave "
			qry += "join tbl_HRMS_EmployeeMaster tblEmp "
			qry += "on tblLeave.EmpID = tblEmp.NTID "
			qry += "where "
			If LeaveReport.ddlStatus <> "All" Then
				qry += "tblLeave.LeaveStatus = '" & LeaveReport.ddlStatus & "' and "
			End If
			qry += "tblEmp.MngrNTID = '" & LeaveReport.strUser & "' and "
			qry += "tblLeave.LeaveDate between '" & LeaveReport.dtFrom & "' and '" & LeaveReport.dtTo & "'"
		End If
		

		dtLeave = cls.GetData(qry)

		Dim LeaveTables As New List(Of LeaveReportTable)

		x = 0
		Do Until x = dtLeave.Rows.Count

			Dim LeaveTable As New LeaveReportTable

			LeaveTable.empCode = dtLeave.Rows(x).Item("EmpID")
			LeaveTable.empName = dtLeave.Rows(x).Item("EmpName")
			LeaveTable.leaveDate = dtLeave.Rows(x).Item("LeaveDate")
			LeaveTable.leaveType = dtLeave.Rows(x).Item("LeaveType")
			LeaveTable.isHalfDay = dtLeave.Rows(x).Item("HalfDay")
			LeaveTable.appliedDate = dtLeave.Rows(x).Item("DateApplied")
			LeaveTable.status = dtLeave.Rows(x).Item("LeaveStatus")
			LeaveTable.approveDate = dtLeave.Rows(x).Item("DateApplied")
			If Not IsDBNull(dtLeave.Rows(x).Item("ApprovedBy")) Then
				LeaveTable.approverName = dtLeave.Rows(x).Item("ApprovedBy")
			Else
				LeaveTable.approverName = ""
			End If

			LeaveTables.Add(LeaveTable)

			x = x + 1
		Loop
		LeaveReport.tblLeave = LeaveTables

		Return LeaveReport
	End Function

	<WebMethod()>
	Public Shared Sub SaveSchedUpload()

	End Sub

End Class