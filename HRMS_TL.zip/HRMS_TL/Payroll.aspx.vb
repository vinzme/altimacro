﻿Imports System.Data.SqlClient
Imports System.Drawing
'Imports ClosedXML.Excel
Imports System.IO
Imports System.Data

Public Class Payroll

	Inherits System.Web.UI.Page

	Dim cls As New clsConnection

	Dim pubUser As String

	Dim dtEmp As New DataTable
	Dim dtEmp2 As New DataTable

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Payroll.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		If Not IsPostBack Then
			PopulateTreeView()
		End If
	End Sub

	Private Sub GetEmpInfo()
		Dim query As String

		query = "select * from tbl_HRMS_EmployeeMaster (nolock) where ntid = '" & pubUser.Trim & "'"

		dtEmp = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo2()
		Dim query As String

		query = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & TreeView1.SelectedValue.Trim & "'"

		dtEmp2 = cls.GetData(query)
	End Sub

	Private Sub PopulateTreeView()

		GetEmpInfo()
		Dim MngrNTID As String = ""
		Dim AccessLevel As String = ""
		If dtEmp.Rows.Count > 0 Then
			MngrNTID = dtEmp.Rows(0)("MngrNTID")
			AccessLevel = dtEmp.Rows(0)("AccessLevel")
		End If

		If AccessLevel = "24" Then
			Dim query As String = "select Empname, NTID from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null order by EmpName"
			Dim parentAdapter As New SqlDataAdapter(query, sqlConn)

			Dim dtParent As DataTable = New DataTable()

			parentAdapter.Fill(dtParent)
			Dim index As Integer = -1
			Dim drParent As DataRow
			For Each drParent In dtParent.Rows
				Dim query2 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where BusinessSegment = 'Financial Services' and AccessLevel is not null order by EmpName"
				Dim childAdapter As New SqlDataAdapter(query2, sqlConn)
				Dim dtChild As DataTable = New DataTable()
				childAdapter.Fill(dtChild)
				index = index + 1
				Dim parent As TreeNode = New TreeNode()
				parent.Value = drParent("NTID").ToString()
				parent.Text = drParent("EmpName").ToString()
				TreeView1.Nodes.Add(parent)
				Dim drChild As DataRow
				For Each drChild In dtChild.Rows
					Dim query3 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drChild("NTID").ToString() & "' and AccessLevel is not null order by EmpName"
					Dim child2Adapter As New SqlDataAdapter(query3, sqlConn)
					Dim dtChild2 As DataTable = New DataTable()
					child2Adapter.Fill(dtChild2)
					'index = index + 1
					Dim parent2 As TreeNode = New TreeNode()
					parent2.Value = drChild("NTID").ToString()
					parent2.Text = drChild("EmpName").ToString()
					TreeView1.Nodes(index).ChildNodes.Add(parent2)
					Dim drChild2 As DataRow
					For Each drChild2 In dtChild2.Rows
						Dim query4 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drChild2("NTID").ToString() & "' and AccessLevel is not null order by EmpName"
						Dim child3Adapter As New SqlDataAdapter(query4, sqlConn)
						Dim dtChild3 As DataTable = New DataTable()
						child3Adapter.Fill(dtChild3)
						'If dtChild3.Rows.Count > 0 Then
						Dim child As TreeNode = New TreeNode()
						child.Value = drChild2("NTID").ToString()
						child.Text = drChild2("EmpName").ToString()
						parent2.ChildNodes.Add(child)
						'End If
					Next
				Next
			Next
		Else
			Dim query As String = "select Empname, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & MngrNTID & "' and AccessLevel is not null order by EmpName"
			Dim parentAdapter As New SqlDataAdapter(query, sqlConn)

			Dim dtParent As DataTable = New DataTable()

			parentAdapter.Fill(dtParent)
			Dim index As Integer = -1
			Dim drParent As DataRow
			For Each drParent In dtParent.Rows
				Dim query2 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drParent("NTID").ToString & "' and AccessLevel is not null order by EmpName"
				Dim childAdapter As New SqlDataAdapter(query2, sqlConn)
				Dim dtChild As DataTable = New DataTable()
				childAdapter.Fill(dtChild)
				index = index + 1
				Dim parent As TreeNode = New TreeNode()
				parent.Value = drParent("NTID").ToString()
				parent.Text = drParent("EmpName").ToString()
				TreeView1.Nodes.Add(parent)
				Dim drChild As DataRow
				For Each drChild In dtChild.Rows
					Dim query3 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drChild("NTID").ToString() & "' and AccessLevel is not null order by EmpName"
					Dim child2Adapter As New SqlDataAdapter(query3, sqlConn)
					Dim dtChild2 As DataTable = New DataTable()
					child2Adapter.Fill(dtChild2)
					'index = index + 1
					Dim parent2 As TreeNode = New TreeNode()
					parent2.Value = drChild("NTID").ToString()
					parent2.Text = drChild("EmpName").ToString()
					TreeView1.Nodes(index).ChildNodes.Add(parent2)
					Dim drChild2 As DataRow
					For Each drChild2 In dtChild2.Rows
						Dim query4 As String = "select EmpName, NTID from tbl_HRMS_EmployeeMaster (nolock) where MngrNTID = '" & drChild2("NTID").ToString() & "' and AccessLevel is not null order by EmpName"
						Dim child3Adapter As New SqlDataAdapter(query4, sqlConn)
						Dim dtChild3 As DataTable = New DataTable()
						child3Adapter.Fill(dtChild3)
						'If dtChild3.Rows.Count > 0 Then
						Dim child As TreeNode = New TreeNode()
						child.Value = drChild2("NTID").ToString()
						child.Text = drChild2("EmpName").ToString()
						parent2.ChildNodes.Add(child)
						'End If
					Next
				Next
			Next
		End If



	End Sub

	Private Sub GenerateReport()

		GetEmpInfo()
		Dim MngrNTID As String = ""
		Dim AccessLevel As String = ""
		If dtEmp.Rows.Count > 0 Then
			MngrNTID = dtEmp.Rows(0)("MngrNTID")
			AccessLevel = dtEmp.Rows(0)("AccessLevel")
		End If

		Dim sb As New StringBuilder


		sb.Append("Select sched.SchedDate [Cut_Off],    ")
		sb.Append("case when sched.SchedType is not null then	Case When sched.SchedType <> '' then 		Case When sched.SchedType = 'IN' Then 			(Case When sched.SchedIN is not null and EmpLogIn.Start_Time is null Then 'Absent' Else 'Present' end) 		Else 			sched.SchedType 		End 	else			(Case When EmpLogIn.Start_Time is null Then 'Absent' Else 'Present' end) 		end else	(Case When EmpLogIn.Start_Time is null Then 'Absent' Else 'Present' end) 	end as [Status],")
		sb.Append("EMP.EmpID, EMP.EmpName,    ")
		sb.Append("EMP.NTID, EMP.MngrID, EMP.MngrName,    ")
		sb.Append("case when CONVERT(varchar(20), CAST(sched.SchedIN as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(sched.SchedIN as Time), 100) end [Scheduled Start],    ")
		sb.Append("case when CONVERT(varchar(20), CAST(sched.SchedOUT as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(sched.SchedOUT as Time), 100) end [Scheduled Out],    ")
		sb.Append("case when CONVERT(varchar(20), CAST(EmpLogIn.Start_Time as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(EmpLogIn.Start_Time as Time), 100) end [Log In Time],    ")
		sb.Append("case when CONVERT(varchar(20), CAST(EmpLogOut.End_Time as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(EmpLogOut.End_Time as Time), 100) end [Log Out Time],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then    ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0.00    ")
		sb.Append("else    ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 0 then     ")
		sb.Append("case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then 0     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))     ")
		sb.Append("end    ")
		sb.Append("else 0    ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end    ")
		sb.Append("[TOTAL_ND_HRS],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0     ")
		sb.Append("else     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 8 then 8    ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end     ")
		sb.Append("end     ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end [TOTAL_REG_HRS],    ")
		sb.Append("case when DO.Status = 1 then    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS NULL OR TOTALHRS.[TotTimeHour] = 0 then 0     ")
		sb.Append("else    ")
		sb.Append("(case when SUM(CAST(isQualified.DaysPresent as decimal(15,2))) < RD.SetValue1 then (     ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then     ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) > 0 then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end )     ")
		sb.Append("else 0     ")
		sb.Append("end )    ")
		sb.Append("else    ")
		sb.Append("(case when isApprovedLeave.isHalfDay is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > DO.SetValue1 then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0    ")
		sb.Append("else CAST(TOTALHRS.[TotTimeHour] as decimal(15,2)) - CAST(DO.SetValue1 as decimal(15,2))     ")
		sb.Append("end     ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end )     ")
		sb.Append("end )     ")
		sb.Append("end    ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end    ")
		sb.Append("else 0    ")
		sb.Append("end [TOTAL_OT_HRS],    ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then     ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )     ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then '0.00'    ")
		sb.Append("else    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )     ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end [RH_ND_HOURS],     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then    ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'     ")
		sb.Append("else 8    ")
		sb.Append("end )     ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00    ")
		sb.Append("else    ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'     ")
		sb.Append("else 8    ")
		sb.Append("end )     ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end as [RH_REG_HOURS],     ")
		sb.Append("case when DO.Status=1 then    ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then    ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end)    ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00    ")
		sb.Append("else    ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end)    ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end [RH_OT_HOURS],     ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null then 0     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))     ")
		sb.Append("end)     ")
		sb.Append("else 0     ")
		sb.Append("end as [SNW_ND_HOURS],     ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then     ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then 0     ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end)     ")
		sb.Append("else 0 end as [SNW_REG_HOURS],     ")
		sb.Append("case when do.Status=1 then    ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then     ")
		sb.Append("( case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end )     ")
		sb.Append("else 0     ")
		sb.Append("end    ")
		sb.Append("else 0    ")
		sb.Append("end [SNW_OT_HOURS],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PTO' then     ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 8.00 else 0.00 end     ")
		sb.Append("else 0 end    ")
		sb.Append("end [PTO Whole Day],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'CTO' then     ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 8.00 else 0.00 end     ")
		sb.Append("else 0 end    ")
		sb.Append("end [CTO Whole Day],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PTO' then     ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 0.00 else 4.00 end     ")
		sb.Append("else 0.00 end    ")
		sb.Append("end [PTO Half Day],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'CTO' then     ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 0.00 else 4.00 end     ")
		sb.Append("else 0.00 end    ")
		sb.Append("end [CTO Half Day],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'MATERNITY LEAVE' then 8.00 else 0.00 end    ")
		sb.Append("end [Maternity],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PATERNITY LEAVE' then 8.00 else 0.00 end    ")
		sb.Append("end [Paternity],    ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00    ")
		sb.Append("else     ")
		sb.Append("case when isApprovedLeave.LeaveType = 'SOLO PARENT' then     ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 8.00 else 0.00 end     ")
		sb.Append("else 0.00 end    ")
		sb.Append("end [SoloParent],    ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when isApprovedLeave.LeaveType is null then    ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0.00    ")
		sb.Append("else    ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 0 then     ")
		sb.Append("case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then 0     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))     ")
		sb.Append("end    ")
		sb.Append("else 0    ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end    ")
		sb.Append("else 0 end  [NDRestDay],    ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when isApprovedLeave.LeaveType is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0     ")
		sb.Append("else     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 8 then 8    ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end     ")
		sb.Append("end     ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end    ")
		sb.Append("else 0 end  [RestDay],    ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when DO.Status = 1 then     ")
		sb.Append("case when isApprovedLeave.LeaveType is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS NULL OR TOTALHRS.[TotTimeHour] = 0 then 0     ")
		sb.Append("else    ")
		sb.Append("(case when SUM(CAST(isQualified.DaysPresent as decimal(15,2))) < RD.SetValue1 then (     ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then     ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) > 0 then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end )     ")
		sb.Append("else 0     ")
		sb.Append("end )    ")
		sb.Append("else    ")
		sb.Append("(case when isApprovedLeave.isHalfDay is null then     ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > DO.SetValue1 then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0    ")
		sb.Append("else CAST(TOTALHRS.[TotTimeHour] as decimal(15,2)) - CAST(DO.SetValue1 as decimal(15,2))     ")
		sb.Append("end     ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end )     ")
		sb.Append("end )     ")
		sb.Append("end    ")
		sb.Append("else     ")
		sb.Append("0    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end    ")
		sb.Append("else 0 end  [RestDayOT],    ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then     ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )     ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then '0.00'    ")
		sb.Append("else    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )     ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0    ")
		sb.Append("end [RD_RH_ND_HOURS],     ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then    ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'     ")
		sb.Append("else 8    ")
		sb.Append("end )     ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00    ")
		sb.Append("else    ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'     ")
		sb.Append("else 8    ")
		sb.Append("end )     ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0 end [RD_RH_REG_HOURS],     ")
		sb.Append("case when do.Status=1 then    ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then    ")
		sb.Append("case when ispresent.SD is not null then    ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end)    ")
		sb.Append("else    ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00    ")
		sb.Append("else    ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end)    ")
		sb.Append("end    ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end    ")
		sb.Append("else 0    ")
		sb.Append("end as [RD_RH_OT_HOURS],     ")
		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then    ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null then 0     ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))     ")
		sb.Append("end)     ")
		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0    ")
		sb.Append("end as [RD_SNW_ND_HOURS],     ")

		sb.Append("case when sched.SchedType = 'RD' then     ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then     ")

		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then 0     ")
		sb.Append("else TOTALHRS.[TotTimeHour]     ")
		sb.Append("end)     ")

		sb.Append("else 0     ")
		sb.Append("end    ")
		sb.Append("else 0     ")
		sb.Append("end as [RD_SNW_REG_HOURS],     ")

		sb.Append("case when DO.Status = 1 then    ")
		sb.Append("case when sched.SchedType = 'RD' then    ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then     ")

		sb.Append("( case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0     ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))     ")
		sb.Append("end )     ")

		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0     ")
		sb.Append("end     ")
		sb.Append("else 0    ")
		sb.Append("end [RD_SNW_OT_HOURS]    ")

		sb.Append("from tbl_HRMS_Employee_Schedule sched     ")
		sb.Append("inner join tbl_HRMS_EmployeeMaster Emp     ")
		sb.Append("on sched.LoginID=Emp.NTID     ")

		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='ND' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') ND     ")
		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='DO' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') DO    ")
		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='RD' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') RD    ")

		sb.Append("outer apply(select top 1 scheddate, start_time, reasonid from tbl_HRMS_Employee_Activity where Loginid = Emp.NTID and scheddate = sched.SchedDate and reasonid = 1 order by start_time asc)     ")
		sb.Append("EmpLogIn     ")
		sb.Append("outer apply(select top 1 a.scheddate, a.end_time, a.reasonid from tbl_HRMS_Employee_Activity a left join tbl_HRMS_Employee_Schedule b on b.scheddate = a.scheddate where a.Loginid = Emp.NTID and a.scheddate = sched.SchedDate and a.reasonid in (14,16) order by a.end_time asc)     ")
		sb.Append("EmpLogOut     ")
		sb.Append("outer apply(Select EmpID,LeaveDate,isHalfDay,LeaveType from tbl_HRMS_LeaveMaster where empID = emp.NTID and LeaveDate = sched.SchedDate and isPaid='1' and LeaveStatus='Approved')     ")
		sb.Append("isApprovedLeave     ")

		sb.Append("outer apply(Select     ")
		sb.Append("case when CAST(sched.SchedIN as datetime) > CAST(EmpLogIn.Start_Time as datetime) then     ")
		sb.Append("case when sched.SchedIN > CAST(CAST(CAST(sched.SchedIN as date)as varchar) +' '+ nd.SetValue1 as datetime) then ( sched.SchedIN )     ")
		sb.Append("else CAST(CAST(sched.SchedIN as date)as varchar) +' '+ nd.SetValue1 end      ")
		sb.Append("else     ")
		sb.Append("case when EmpLogIn.Start_Time > CAST(CAST(CAST(EmpLogIn.Start_Time as date)as varchar) +' '+ nd.SetValue1 as datetime) then ( EmpLogIn.Start_Time )     ")
		sb.Append("else CAST(CAST(EmpLogIn.Start_Time as date)as varchar) +' '+ nd.SetValue1 end     ")
		sb.Append("end [ND1]) ProcessForND1     ")

		sb.Append("outer apply(Select case when EmpLogOut.End_Time < CAST(CAST(CAST(EmpLogOut.End_Time as date)as varchar) +' '+ nd.SetValue2 as datetime) then EmpLogOut.End_Time else CAST(CAST(EmpLogOut.End_Time as date)as varchar) +' '+ nd.SetValue2 end [ND2])     ")
		sb.Append("ProcessForND2      ")

		sb.Append("outer apply(Select     ")
		sb.Append("case when SUM(CAST(TotalTimeHour as decimal(15,2))) is not null then     ")
		sb.Append("case when emp.EmpLevel = 'EE' and emp.AccessLevel = 1 then    ")
		sb.Append("(SUM(case when EEApproval is not null then CAST(TotalTimeHour as decimal(15,2)) else 0 end))    ")
		sb.Append("else    ")
		sb.Append("(SUM(CAST(TotalTimeHour as decimal(15,2))))    ")
		sb.Append("end    ")
		sb.Append("else     ")
		sb.Append("(case when isApprovedLeave.isHalfDay is not null then     ")
		sb.Append("(case when isApprovedLeave.isHalfDay = 1 then     ")
		sb.Append("(case when Emp.EmpType = 'Regular' then 4.00 else 4.50 end)     ")
		sb.Append("else    ")
		sb.Append("(case when Emp.EmpType = 'Regular' then 8.00 else 9.00 end)     ")
		sb.Append("end)     ")
		sb.Append("else 0 end)    ")
		sb.Append("end [TotTimeHour]    ")
		sb.Append("from dbo.tbl_HRMS_Employee_Activity     ")
		sb.Append("where     ")

		sb.Append("LoginID = EMP.NTID     ")
		sb.Append("and SchedDate = sched.SchedDate     ")
		sb.Append("and isPaid='YES'     ")

		sb.Append("and Activity_Tag <> 'ADJ' or     ")

		sb.Append("LoginID = EMP.NTID     ")
		sb.Append("and SchedDate = sched.SchedDate     ")
		sb.Append("and isPaid='YES'     ")

		sb.Append("and Activity_Tag is null    ")

		sb.Append(")    ")
		sb.Append("TOTALHRS    ")

		sb.Append("outer apply(Select * from dbo.tbl_HRMS_HolidayMaster where HolDate = sched.SchedDate and DeletedBy is null)     ")
		sb.Append("ifHoliday    ")
		sb.Append("outer apply(Select sched.SchedDate, (Select case when SUM(CAST(b.TotalTimeHour as decimal(15,2))) > 0 then '1' else(case when a.SchedType = 'RD' then '0' else '0' end) end from dbo.tbl_HRMS_Employee_Activity b where b.LoginID = a.LoginID and b.SchedDate = a.SchedDate group by b.LoginID ) as [DaysPresent] from dbo.tbl_HRMS_Employee_Schedule a where a.LoginID = Emp.NTID and a.SchedDate between dateadd(d,(RD.SetValue1-1)*-1,sched.SchedDate) and sched.SchedDate )     ")
		sb.Append("isQualified    ")
		sb.Append("outer apply(Select top 1 IPb.SchedDate [SD] from dbo.tbl_HRMS_Employee_Activity IPa inner join dbo.tbl_HRMS_Employee_Schedule IPb on IPa.LoginID = IPb.LoginID and IPa.SchedDate = IPb.SchedDate where CAST(IPb.SchedDate as DATE) < CAST(sched.SchedDate as DATE) and IPb.LoginID = Emp.NTID order by IPb.SchedDate DESC )    ")
		sb.Append("isPresent    ")
		sb.Append("where     ")

		If AccessLevel = "24" Then

			sb.Append("BusinessSegment = 'Financial Services' and ")
			sb.Append("sched.SchedDate between CAST('" & txtBoxDateFrom.Text.Trim & "' as date) and CAST('" & txtBoxDateTo.Text.Trim & "' as date) ")

		Else

			If EmpLvl.Text.Trim = "EE" Then
				sb.Append("NTID = '" & EmpNT.Text.Trim & "' and ")
			Else
				sb.Append("MngrNTID = '" & EmpNT.Text.Trim & "' and ")
			End If
			sb.Append("sched.SchedDate between CAST('" & txtBoxDateFrom.Text.Trim & "' as date) and CAST('" & txtBoxDateTo.Text.Trim & "' as date) ")
		End If

		sb.Append("and Emp.empType is not null and Emp.AccessLevel is not null    ")
		sb.Append("group by EMP.NTID, EMP.MngrID, EMP.MngrName, EMP.EmpID, EMP.EmpName,EMP.EmpLevel, sched.SchedDate, ProcessForND1.ND1, ProcessForND2.ND2, TOTALHRS.[TotTimeHour], DO.SetValue1, ifHoliday.HolType, EmpLogIn.Start_Time, EmpLogOut.End_Time, isApprovedLeave.isHalfDay, sched.SchedIN, sched.SchedOUT,RD.SetValue1,ispresent.SD,isApprovedLeave.LeaveType,sched.SchedType    ")
		sb.Append(",nd.SetValue1,do.Status,rd.Id,isQualified.SchedDate    ")
		sb.Append("order by Emp.NTID, sched.SchedDate    ")


		Try
			Dim query As String = sb.ToString()

			Dim myAdapter As New SqlDataAdapter(query, sqlConn)

			sqlConn.Open()

			payrollReportsGrid.Visible = True
			Dim ds As Data.DataSet = New Data.DataSet

			myAdapter.Fill(ds)

			payrollReportsGrid.DataSource = ds.Tables(0)

			payrollReportsGrid.DataBind()

			sqlConn.Close()

		Catch ex As Exception
			payrollReportsGrid.Visible = False
			payrollReportsGrid.DataSource = Nothing
		End Try

		lblDates.Text = "Date From: <b>" & Convert.ToDateTime(txtBoxDateFrom.Text.Trim).ToString("MMM dd, yyyy") & "</b> to <b>" & Convert.ToDateTime(txtBoxDateTo.Text.Trim).ToString("MMM dd, yyyy") & "</b>"
	End Sub

	Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click

		Dim sb As New StringBuilder
		Dim errors As String = ""

		If txtBoxDateFrom.Text = "" Then
			errors += "Please Enter Date From Field. <br /> "
		End If

		If txtBoxDateTo.Text = "" Then
			errors += "Please Enter Date To Field. <br /> "
		End If

		UpdatePanel2.Update()

		If EmpNT.Text = "" Then
			errors += "Please Select a name from the treeview. <br /> "
		End If

		If errors <> "" Then
			ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "ClickModal", "$('#lblError').html('" & errors & "'); clickModal5();", True)
		Else
			GenerateReport()
		End If


		'payrollReportsGrid.Visible = True
	End Sub

	Private Sub TreeView1_SelectedNodeChanged(sender As Object, e As EventArgs) Handles TreeView1.SelectedNodeChanged
		lblDateFrom.Text = txtBoxDateFrom.Text.Trim
		lblDateTo.Text = txtBoxDateTo.Text.Trim
		GetEmpInfo2()
		MngrName.Text = TreeView1.SelectedNode.Text.Trim
		EmpNT.Text = dtEmp2.Rows(0)("NTID")
		EmpLvl.Text = dtEmp2.Rows(0)("EmpLevel")
		TreeView1.SelectedNodeStyle.BackColor = Drawing.Color.SteelBlue
		TreeView1.SelectedNodeStyle.ForeColor = Drawing.Color.White
		UpdatePanel2.Update()
	End Sub

	Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
		lblDates.Text = ""
		payrollReportsGrid.Visible = False
	End Sub

	Protected Sub ExportToExcel(sender As Object, e As EventArgs)

		'Response.ClearContent()
		'Response.AddHeader("content-disposition", "attachment; filename=Payroll " & txtBoxDateFrom.Text.Trim & " - " & txtBoxDateTo.Text.Trim & ".xls")
		'Response.ContentType = "application/excel"
		'Dim sw As New System.IO.StringWriter()
		'Dim htw As New HtmlTextWriter(sw)
		''To Export all pages
		''payrollReportsGrid.AllowPaging = False
		''Me.BindGrid()

		'payrollReportsGrid.HeaderRow.BackColor = Color.White
		'For Each cell As TableCell In payrollReportsGrid.HeaderRow.Cells
		'    cell.BackColor = payrollReportsGrid.HeaderStyle.BackColor
		'Next
		'For Each row As GridViewRow In payrollReportsGrid.Rows
		'    row.BackColor = Color.White
		'    For Each cell As TableCell In row.Cells
		'        If row.RowIndex Mod 2 = 0 Then
		'            cell.BackColor = payrollReportsGrid.AlternatingRowStyle.BackColor
		'        Else
		'            cell.BackColor = payrollReportsGrid.RowStyle.BackColor
		'        End If
		'        cell.CssClass = "textmode"
		'    Next
		'Next
		'payrollReportsGrid.RenderControl(htw)
		'Response.Write(sw.ToString())
		'Response.[End]()

		'Response.Clear()

		'' Set the type and filename
		'Response.AddHeader("content-disposition", "attachment;filename=Payroll " & txtBoxDateFrom.Text.Trim & " - " & txtBoxDateTo.Text.Trim & ".xls")
		'Response.Charset = ""
		'Response.ContentType = "application/vnd.xls"

		'' Add the HTML from the GridView to a StringWriter so we can write it out later
		'Dim sw As System.IO.StringWriter = New System.IO.StringWriter
		'Dim hw As System.Web.UI.HtmlTextWriter = New HtmlTextWriter(sw)
		'payrollReportsGrid.RenderControl(hw)

		'' Write out the data
		'Response.Write(sw.ToString)
		'Response.End()

		Response.Clear()
		Response.Buffer = True
		Response.AddHeader("content-disposition", "attachment;filename=Payroll " & txtBoxDateFrom.Text.Trim & " - " & txtBoxDateTo.Text.Trim & ".xls")
		Response.Charset = ""
		Response.ContentType = "application/vnd.ms-excel"
		Using sw As New StringWriter()
			Dim hw As New HtmlTextWriter(sw)

			'To Export all pages
			'payrollReportsGrid.AllowPaging = False
			'Me.BindGrid()

			payrollReportsGrid.HeaderRow.BackColor = Color.White
			For Each cell As TableCell In payrollReportsGrid.HeaderRow.Cells
				cell.BackColor = payrollReportsGrid.HeaderStyle.BackColor
			Next
			For Each row As GridViewRow In payrollReportsGrid.Rows
				row.BackColor = Color.White
				For Each cell As TableCell In row.Cells
					If row.RowIndex Mod 2 = 0 Then
						cell.BackColor = payrollReportsGrid.AlternatingRowStyle.BackColor
					Else
						cell.BackColor = payrollReportsGrid.RowStyle.BackColor
					End If
					cell.CssClass = "textmode"
				Next
			Next

			payrollReportsGrid.RenderControl(hw)
			'style to format numbers to string
			Dim style As String = "<style> .textmode { } </style>"
			Response.Write(style)
			Response.Output.Write(sw.ToString())
			Response.Flush()
			Response.[End]()
		End Using

	End Sub

	Public Overrides Sub VerifyRenderingInServerForm(control As Control)
		' Verifies that the control is rendered
	End Sub
End Class