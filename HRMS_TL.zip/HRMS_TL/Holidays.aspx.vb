﻿Imports System.Data
Imports System.Web.Services

Public Class Holidays
	Inherits System.Web.UI.Page

	Dim dtLastActivity As DataTable
	Dim dtNews As New DataTable
	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String
	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Holidays.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		GetEmpInfo()

		If Not Page.IsPostBack Then

			CreateNewsPanel()

			GetLastActivity()

			'If dtLastActivity.Rows(0)("reasonid") = 14 Or
			'    dtLastActivity.Rows(0)("reasonid") = 16 Then

			'    Response.Redirect("Home.aspx")
			'Else
			If dtEmp.Rows.Count > 0 Then

				employeeID = dtEmp.Rows(0)("EmpID")
				employeeName = dtEmp.Rows(0)("EmpName")
				employeeSupervisor = dtEmp.Rows(0)("MngrName")
				employeeDepartment = dtEmp.Rows(0)("DeptName")
				'employeeLocation = dtEmp.Rows(0)("Location")
				employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
				employeeApprover = dtEmp.Rows(0)("MngrName")

				empID.Text = employeeID
				empName.Text = employeeName
				supervisor.Text = employeeSupervisor
				dept.Text = employeeDepartment
				'Loc.Text = employeeLocation
				doj.Text = employeeDoj

				Dim year As String = Convert.ToInt32(DateTime.Now.Year).ToString

				Dim yearRes As String = ""

				yearRes = year.Substring(2)

				Dim items As New List(Of ListItem)()
				For i As Integer = -16 To 0
					'Populating the Year Values in dropdown
					items.Add(New ListItem(DateTime.Now.AddYears(i).Year, DateTime.Now.AddYears(i).Year))
				Next

				For j As Integer = 1 To 4
					'Populating the Year Values in dropdown
					items.Add(New ListItem(DateTime.Now.AddYears(j).Year, DateTime.Now.AddYears(j).Year))
				Next

				DropDownList1.DataSource = items
				DropDownList1.DataBind()
				DropDownList1.Items(Convert.ToInt32(yearRes) - 1).Selected = True


			End If
		End If
		'End If
	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity where loginid = '" & pubUser.Trim & "' order by seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "'"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub ProcessNews()
		Dim sql As String = ""
		sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"
		dtNews = cls.GetData(sql)
	End Sub
	Private Sub CreateNewsPanel()
		Dim str As String = ""

		ProcessNews()
		If dtNews.Rows.Count > 0 Then
			For x As Integer = 0 To dtNews.Rows.Count - 1
				str &= "<li class='news-item'>"
				str &= "<table cellpadding='4'>"
				str &= "<tr>"
				str &= "<td>"
				str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
				str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a onclick = ""window.open('" & dtNews.Rows(x)("imgNews") & "', '_Parent', 'toolbar=0,scrollbars=0,resizable=0,top=0,left=20%,width=800,height=700');"" href='#'>Read more...</a></td>"
				str &= "<tr>"
				str &= "</table>"
				str &= "</li>"
			Next

			lt1.Text = str

		End If

	End Sub

	Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
		Dim query As String = "select HolDesc [Description], CONVERT(varchar(15), HolDate, 107) [Date], HolDay [Day], HolType [Type] from tbl_HRMS_HolidayMaster where YEAR(HolDate) = '" + DropDownList1.SelectedItem.Text + "' and DeletedBy is null order by Holdate"

		Dim dtHoliday As DataTable = New DataTable

		dtHoliday = cls.GetData(query)

		If dtHoliday.Rows.Count > 0 Then
			holidayGrid.DataSourceID = ""
			holidayGrid.DataSource = dtHoliday
			holidayGrid.DataBind()
		Else
			holidayGrid.EmptyDataText = "No record found for the year " & DropDownList1.SelectedItem.Text
			holidayGrid.DataSourceID = ""
			holidayGrid.DataSource = Nothing
			holidayGrid.DataBind()
		End If
	End Sub
End Class