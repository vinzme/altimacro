﻿Imports System.Data.SqlClient
Imports System.Data

Public Class HolidaysHR
	Inherits System.Web.UI.Page

	Dim pubUser As String
	Dim desc As String
	Dim holdate As String
	Dim holday As String
	Dim type As String

	Dim dtSelectedItem As New DataTable
	Dim dtNews As New DataTable
	Dim cls As New clsConnection
	Dim dtEmp As New DataTable

	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String

	'Connections
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/HolidaysHR.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		GetEmpInfo()
		If Not Page.IsPostBack Then
			CreateNewsPanel()

			If dtEmp.Rows.Count > 0 Then

				employeeID = dtEmp.Rows(0)("EmpID")
				employeeName = dtEmp.Rows(0)("EmpName")
				employeeSupervisor = dtEmp.Rows(0)("MngrName")
				employeeDepartment = dtEmp.Rows(0)("DeptName")
				'employeeLocation = dtEmp.Rows(0)("Location")
				employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
				employeeApprover = dtEmp.Rows(0)("MngrName")

				empID.Text = employeeID
				empName.Text = employeeName
				supervisor.Text = employeeSupervisor
				dept.Text = employeeDepartment
				'Loc.Text = employeeLocation
				doj.Text = employeeDoj
				
				Dim year As String = Convert.ToInt32(DateTime.Now.Year).ToString

				Dim yearRes As String = ""

				yearRes = year.Substring(2)

				Dim items As New List(Of ListItem)()
				For i As Integer = -16 To 0
					'Populating the Year Values in dropdown
					items.Add(New ListItem(DateTime.Now.AddYears(i).Year, DateTime.Now.AddYears(i).Year))
				Next

				For j As Integer = 1 To 4
					'Populating the Year Values in dropdown
					items.Add(New ListItem(DateTime.Now.AddYears(j).Year, DateTime.Now.AddYears(j).Year))
				Next

				DropDownList1.DataSource = items
				DropDownList1.DataBind()
				DropDownList1.Items(Convert.ToInt32(yearRes) - 1).Selected = True
			End If
		End If
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub GetSelectedItem()
		dtSelectedItem.Columns.AddRange(New DataColumn(4) {New DataColumn("ID"), New DataColumn("Description"), New DataColumn("Date"), New DataColumn("Day"), New DataColumn("Type")})

		For Each row As GridViewRow In holidayGrid.Rows
			If row.RowType = DataControlRowType.DataRow Then
				Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("chkRow"), CheckBox)
				If chkRow.Checked Then
					Dim lblID As Label = TryCast(row.Cells(0).FindControl("lblID"), Label)
					Dim strID As String = lblID.Text
					Dim lblDesc As Label = TryCast(row.Cells(0).FindControl("lblDesc"), Label)
					desc = lblDesc.Text
					Dim lblDate As Label = TryCast(row.Cells(0).FindControl("lblDate"), Label)
					holdate = lblDate.Text
					Dim lblDay As Label = TryCast(row.Cells(0).FindControl("lblDay"), Label)
					holday = lblDay.Text
					Dim lblType As Label = TryCast(row.Cells(0).FindControl("lblType"), Label)
					type = lblType.Text

					dtSelectedItem.Rows.Add(strID, desc, holdate, holdate, type)
				End If
			End If
		Next
		DeleteHoliday()
	End Sub

	Private Sub DeleteHoliday()
		For x As Integer = 0 To dtSelectedItem.Rows.Count - 1
			Dim cmdDelete As New SqlCommand

			cmdDelete.CommandText = "update tbl_HRMS_HolidayMaster set DeletedBy = '" & pubUser.Trim & "', DateDeleted = GETDATE() where ID = " & dtSelectedItem.Rows(x)("ID") & ""

			Try
				sqlConn.Open()
				cmdDelete.Connection = sqlConn
				cmdDelete.ExecuteNonQuery()
			Catch ex As Exception
			Finally
				sqlConn.Close()
			End Try
		Next
	End Sub

	Private Sub btnDelHol_Click(sender As Object, e As EventArgs) Handles btnDelHol.Click
		GetSelectedItem()
		holidayGrid.DataBind()
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "ClickModal", "$('#lblMsg1').text('Delete Successful!'); clickModal7();", True)
	End Sub

	Private Sub btnAddHol_Click(sender As Object, e As EventArgs) Handles btnAddHol.Click
		'Page.ClientScript.RegisterStartupScript(Me.GetType(), "ClickModal", "clickHolidayModal();", True)
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "ClickModal", "clickHolidayModal();", True)
	End Sub

	Private Sub btnAddHoliday_Click(sender As Object, e As EventArgs) Handles btnAddHoliday.Click
		Dim cmdAdd As New SqlCommand

		Dim dayOfWeek As String = Convert.ToDateTime(txtBoxAddDate.Text).DayOfWeek.ToString()

		If InStr(txtBoxAddDesc.Text.Trim, "'") > 0 Then
			txtBoxAddDesc.Text = txtBoxAddDesc.Text.Trim.Replace("'", "''")
		End If

		cmdAdd.CommandText = "insert into tbl_HRMS_HolidayMaster(Holday, HolDate, HolDesc, HolType, CoveredGroup) values('" & dayOfWeek & "', '" & txtBoxAddDate.Text.Trim & "', '" & txtBoxAddDesc.Text.Trim & "',  '" & ddlAddType.SelectedItem.Text.Trim & "', 'All')"

		Try
			sqlConn.Open()
			cmdAdd.Connection = sqlConn
			cmdAdd.ExecuteNonQuery()
		Catch ex As Exception
		Finally
			sqlConn.Close()
		End Try
		holidayGrid.DataBind()
		'Page.ClientScript.RegisterStartupScript(Me.GetType(), "ClickModal", "$('#lblMsg').text('Add Successful!'); clickModal7();", True)
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "ClickModal", "$('#lblMsg1').text('Add Successful!'); clickModal7();", True)


	End Sub

	Protected Sub holidayGrid_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs)
		Dim ID As Label = TryCast(holidayGrid.Rows(e.RowIndex).FindControl("lblID"), Label)
		Dim txtBoxDesc As TextBox = TryCast(holidayGrid.Rows(e.RowIndex).FindControl("txtBoxDesc"), TextBox)
		Dim txtBoxDate As TextBox = TryCast(holidayGrid.Rows(e.RowIndex).FindControl("txtBoxDate"), TextBox)
		Dim lblEditDay As Label = TryCast(holidayGrid.Rows(e.RowIndex).FindControl("lblEditDay"), Label)
		Dim ddlEditType As DropDownList = TryCast(holidayGrid.Rows(e.RowIndex).FindControl("ddlEditType"), DropDownList)

		If InStr(txtBoxDesc.Text, "'") > 0 Then
			txtBoxDesc.Text = txtBoxDesc.Text.Trim.Replace("'", "''")
		End If

		Dim cmdUpdate As String = "Update tbl_HRMS_HolidayMaster set HolDesc = '" & txtBoxDesc.Text & "', HolDate = '" & txtBoxDate.Text & "', HolDay = '" & lblEditDay.Text & "', HolType = '" & ddlEditType.SelectedItem.Text & "', CoveredGroup = 'All' where ID=" & Convert.ToInt32(ID.Text)

		holidayDatasource.UpdateCommand = cmdUpdate

		holidayGrid.EditIndex = -1
		holidayGrid.DataBind()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "ClickModal", "$('#lblMsg1').text('Update Successful!'); clickModal7();", True)
	End Sub

	Private Sub ProcessNews()
		Dim sql As String = ""
		sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"
		dtNews = cls.GetData(sql)
	End Sub
	Private Sub CreateNewsPanel()
		Dim str As String = ""

		ProcessNews()
		If dtNews.Rows.Count > 0 Then
			For x As Integer = 0 To dtNews.Rows.Count - 1
				str &= "<li class='news-item'>"
				str &= "<table cellpadding='4'>"
				str &= "<tr>"
				str &= "<td>"
				str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
				str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a onclick = ""window.open('" & dtNews.Rows(x)("imgNews") & "', '_Parent', 'toolbar=0,scrollbars=0,resizable=0,top=0,left=20%,width=800,height=700');"" href='#'>Read more...</a></td>"
				str &= "<tr>"
				str &= "</table>"
				str &= "</li>"
			Next

			lt1.Text = str

		End If

	End Sub

	Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
		Dim query As String = "select ID, HolDesc [Description], CONVERT(varchar(15), HolDate, 107) [Date], HolDay [Day], HolType [Type] from tbl_HRMS_HolidayMaster where YEAR(HolDate) = '" + DropDownList1.SelectedItem.Text + "' and DeletedBy is null order by Holdate"

		Dim dtHoliday As DataTable = New DataTable

		dtHoliday = cls.GetData(query)

		If dtHoliday.Rows.Count > 0 Then
			holidayGrid.DataSourceID = ""
			holidayGrid.DataSource = dtHoliday
			holidayGrid.DataBind()
		Else
			holidayGrid.EmptyDataText = "No record found for the year " & DropDownList1.SelectedItem.Text
			holidayGrid.DataSourceID = ""
			holidayGrid.DataSource = Nothing
			holidayGrid.DataBind()
		End If
	End Sub
End Class