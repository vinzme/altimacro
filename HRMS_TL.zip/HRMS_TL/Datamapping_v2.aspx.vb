﻿Imports System.Web.Services
Imports System.Data.OleDb
Imports HRMS.Datamapping
Imports System.Data

Public Class Datamapping_v2
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		Dim pubUser As String = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Datamapping_v2.aspx"
			Response.Redirect("~/Home.aspx")
		End If
	End Sub
	<WebMethod(EnableSession:=True)> _
	Public Shared Function getSTANDARDHEADER(ByVal myitem As String) As List(Of String)
		Dim Standard As New List(Of String)
		Standard.Add("NTID")
		Standard.Add("FIRSTNAME")
		Standard.Add("LASTNAME")
		Standard.Add("MIDDLENAME")
		Standard.Add("SUFFIX")
		Standard.Add("CARDNAME")
		Standard.Add("BIRTHDAY")
		Standard.Add("PLACEOFBIRTH")
		Standard.Add("NATIONALITY")
		Standard.Add("NATCOUNTRY")
		Standard.Add("GENDER")
		Standard.Add("MOBILE")
		Standard.Add("TELPHONE")
		Standard.Add("PRESHOUSENUMBER")
		Standard.Add("PRESHOUSEADDRESS")
		Standard.Add("PRESCOUNTRY")
		Standard.Add("PRESREGION")
		Standard.Add("PRESPROVINCE")
		Standard.Add("PRESZIPCODE")
		Standard.Add("PRESCITY")
		Standard.Add("PERMHOUSENUMBER")
		Standard.Add("PERMHOUSEADDRESS")
		Standard.Add("PERMCOUNTRY")
		Standard.Add("PERMREGION")
		Standard.Add("PERMPROVINCE")
		Standard.Add("PERMZIPCODE")
		Standard.Add("PERMCITY")
		Standard.Add("EMAILADD")
		Standard.Add("EMPLOYERNAME")
		Standard.Add("TIN")
		Standard.Add("CIVILSTATUS")
		Standard.Add("MOTHFIRSTNAME")
		Standard.Add("MOTHLASTNAME")
		Standard.Add("MOTHMIDDLENAME")
		Standard.Add("MOTHSUFFIX")
		Standard.Add("NUMBEROFPADS")
		Standard.Add("OTHERDETAILS")
		Return Standard
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function getUPLOADEDDATA(ByVal filename As String) As List(Of MyFields)
		Dim myListoffields As List(Of MyFields) = New List(Of MyFields)
		Dim ds As New DataSet
		Dim pathToSave_100 As String
		pathToSave_100 = HttpContext.Current.Server.MapPath("~/flatfiles/") & filename

		Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;" & "Data Source=" & pathToSave_100 & ";" & "Extended Properties=Excel 8.0;"
		Dim excelData As New OleDbDataAdapter("SELECT * FROM [Sheet1$]", connectionString)
		excelData.TableMappings.Add("Table", "ExcelSheet")
		excelData.Fill(ds)
		Dim x As Integer
		x = 0
		Dim dt As New DataTable
		dt = ds.Tables(0)
		Dim myitems As String
		Do Until x = dt.Columns.Count
			Dim MyFields As MyFields = New MyFields
			myitems = dt.Columns(x).ColumnName
			MyFields.FieldName = myitems
			MyFields.SampleData = dt.Rows(0).Item(myitems).ToString()
			myListoffields.Add(MyFields)
			x = x + 1
		Loop
		Return myListoffields
	End Function
	Public Class MyFields
		Public FieldName As String
		Public SampleData As String
	End Class
	Public Class FlatFileLookUp
		Public standard As String
		Public newfield As String
	End Class
	<WebMethod(EnableSession:=True)> _
	Public Shared Function matchHEADER(ByVal filename As String, ByVal myitem As List(Of FlatFileLookUp)) As String
		Dim connection = New clsConnection2
		Dim pathToSave_100 As String
		Try
			Dim clsstring As New clsSTRING()

			pathToSave_100 = HttpContext.Current.Server.MapPath("~/flatfiles/") & filename
			Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;" & "Data Source=" & pathToSave_100 & ";" & "Extended Properties=Excel 8.0;"
			Dim excelData As New OleDbDataAdapter("SELECT * FROM [Sheet1$]", connectionString)
			Dim ds As New DataSet
			excelData.TableMappings.Add("Table", "ExcelSheet")
			excelData.Fill(ds)
			Dim x As Integer
			x = 0
			Dim dt As New DataTable
			dt = ds.Tables(0)

			Dim dt2 As New DataTable
			Do Until x = myitem.Count
				dt2.Columns.Add(Trim(myitem.Item(x).standard))


				x = x + 1
			Loop

			x = 0
			Do Until x = dt.Rows.Count

				Dim dr As DataRow = dt2.NewRow
				Dim y As Integer = 0
				Do Until y = dt2.Columns.Count
					If myitem.Item(y).newfield Is Nothing Then
						dr.Item(Trim(myitem.Item(y).standard)) = ""
					Else
						dr.Item(Trim(myitem.Item(y).standard)) = clsstring.IIF(dt.Rows(x).Item(Trim(myitem.Item(y).newfield)), "")
					End If


					y = y + 1
				Loop



				dt2.Rows.Add(dr)
				x = x + 1
			Loop
			Dim insertbulk As String
			insertbulk = "INSERT INTO Temporary_Profile (FIRSTNAME, LASTNAME, MIDDLENAME, SUFFIX, CARDNAME, BIRTHDAY, PLACEOFBIRTH, NATIONALITY, NATCOUNTRY, GENDER, MOBILE, TELPHONE, PRESHOUSENUMBER, PRESHOUSEADDRESS, PRESCOUNTRY, PRESREGION, PRESPROVINCE, PRESZIPCODE, PRESCITY, PERMHOUSENUMBER, PERMHOUSEADDRESS, PERMCOUNTRY, PERMREGION, PERMPROVINCE, PERMZIPCODE, PERMCITY, EMAILADD, EMPLOYERNAME, TIN, CIVILSTATUS, MOTHFIRSTNAME, MOTHLASTNAME, MOTHMIDDLENAME, MOTHSUFFIX, NUMBEROFPADS, OTHERDETAILS, NTID) VALUES "
			Dim z As Integer
			z = 0

			Do Until z = dt2.Rows.Count

				Dim FIRSTNAME, LASTNAME, MIDDLENAME, SUFFIX, CARDNAME, BIRTHDAY, PLACEOFBIRTH, NATIONALITY, NATCOUNTRY, GENDER, MOBILE, TELPHONE, PRESHOUSENUMBER, PRESHOUSEADDRESS, PRESCOUNTRY, PRESREGION, PRESPROVINCE, PRESZIPCODE, PRESCITY, PERMHOUSENUMBER, PERMHOUSEADDRESS, PERMCOUNTRY, PERMREGION, PERMPROVINCE, PERMZIPCODE, PERMCITY, EMAILADD, EMPLOYERNAME, TIN, CIVILSTATUS, MOTHFIRSTNAME, MOTHLASTNAME, MOTHMIDDLENAME, MOTHSUFFIX, NUMBEROFPADS, OTHERDETAILS, NTID As String

				NTID = dt2.Rows(z).Item("NTID")
				FIRSTNAME = dt2.Rows(z).Item("FIRSTNAME")
				LASTNAME = dt2.Rows(z).Item("LASTNAME")
				MIDDLENAME = dt2.Rows(z).Item("MIDDLENAME")
				SUFFIX = dt2.Rows(z).Item("SUFFIX")
				CARDNAME = dt2.Rows(z).Item("CARDNAME")
				BIRTHDAY = dt2.Rows(z).Item("BIRTHDAY")
				PLACEOFBIRTH = dt2.Rows(z).Item("PLACEOFBIRTH")
				NATIONALITY = dt2.Rows(z).Item("NATIONALITY")
				NATCOUNTRY = dt2.Rows(z).Item("NATCOUNTRY")
				GENDER = dt2.Rows(z).Item("GENDER")
				MOBILE = dt2.Rows(z).Item("MOBILE")
				TELPHONE = dt2.Rows(z).Item("TELPHONE")
				PRESHOUSENUMBER = dt2.Rows(z).Item("PRESHOUSENUMBER")
				PRESHOUSEADDRESS = dt2.Rows(z).Item("PRESHOUSEADDRESS")
				PRESCOUNTRY = dt2.Rows(z).Item("PRESCOUNTRY")
				PRESREGION = dt2.Rows(z).Item("PRESREGION")
				PRESPROVINCE = dt2.Rows(z).Item("PRESPROVINCE")
				PRESZIPCODE = dt2.Rows(z).Item("PRESZIPCODE")
				PRESCITY = dt2.Rows(z).Item("PRESCITY")
				PERMHOUSENUMBER = dt2.Rows(z).Item("PERMHOUSENUMBER")
				PERMHOUSEADDRESS = dt2.Rows(z).Item("PERMHOUSEADDRESS")
				PERMCOUNTRY = dt2.Rows(z).Item("PERMCOUNTRY")
				PERMREGION = dt2.Rows(z).Item("PERMREGION")
				PERMPROVINCE = dt2.Rows(z).Item("PERMPROVINCE")
				PERMZIPCODE = dt2.Rows(z).Item("PERMZIPCODE")
				PERMCITY = dt2.Rows(z).Item("PERMCITY")
				EMAILADD = dt2.Rows(z).Item("EMAILADD")
				EMPLOYERNAME = dt2.Rows(z).Item("EMPLOYERNAME")
				TIN = dt2.Rows(z).Item("TIN")
				CIVILSTATUS = dt2.Rows(z).Item("CIVILSTATUS")
				MOTHFIRSTNAME = dt2.Rows(z).Item("MOTHFIRSTNAME")
				MOTHLASTNAME = dt2.Rows(z).Item("MOTHLASTNAME")
				MOTHMIDDLENAME = dt2.Rows(z).Item("MOTHMIDDLENAME")
				MOTHSUFFIX = dt2.Rows(z).Item("MOTHSUFFIX")
				NUMBEROFPADS = dt2.Rows(z).Item("NUMBEROFPADS")
				OTHERDETAILS = dt2.Rows(z).Item("OTHERDETAILS")



				insertbulk = insertbulk & "('" & FIRSTNAME & "','" & LASTNAME & "','" & MIDDLENAME & "','" & SUFFIX & "','" & CARDNAME & "','" & BIRTHDAY & "','" & PLACEOFBIRTH & "','" & NATIONALITY & "','" & NATCOUNTRY & "','" & GENDER & "','" & MOBILE & "','" & TELPHONE & "','" & PRESHOUSENUMBER & "','" & PRESHOUSEADDRESS & "','" & PRESCOUNTRY & "','" & PRESREGION & "','" & PRESPROVINCE & "','" & PRESZIPCODE & "','" & PRESCITY & "','" & PERMHOUSENUMBER & "','" & PERMHOUSEADDRESS & "','" & PERMCOUNTRY & "','" & PERMREGION & "','" & PERMPROVINCE & "','" & PERMZIPCODE & "','" & PERMCITY & "','" & EMAILADD & "','" & EMPLOYERNAME & "','" & TIN & "','" & CIVILSTATUS & "','" & MOTHFIRSTNAME & "','" & MOTHLASTNAME & "','" & MOTHMIDDLENAME & "','" & MOTHSUFFIX & "','" & NUMBEROFPADS & "','" & OTHERDETAILS & "','" & NTID & "'),"
				z = z + 1
			Loop
			insertbulk = insertbulk.Remove(insertbulk.Length - 1)
			Dim dt1 As New DataTable
			dt1 = connection.GetData(insertbulk & ";SELECT 2;")

			Return "0"
		Catch ex As Exception

			Return "1"
		End Try
	End Function
End Class