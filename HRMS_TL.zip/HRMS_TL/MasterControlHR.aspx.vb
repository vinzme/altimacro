﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Services
Imports iTextSharp.text.pdf
Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports System.Data
Imports Newtonsoft.Json

Public Class MasterControlHR
    Inherits System.Web.UI.Page

    'Dim cn As New ADODB.Connection
    'Dim rs As New ADODB.Recordset
    'Dim connStr As String = "Provider=SQLOLEDB;Data Source=DAV8DBHSND01;Initial Catalog=MIS_MLA_UAT;Persist Security Info=True;User ID=mis414;Password=juchUt4a;"
    Dim connStr As String = "PROVIDER=SQLOLEDB;" & ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim pubUser As String

    Dim employeeID As String
    Dim employeeName As String
    Dim employeeSupervisor As String
    Dim employeeDepartment As String
    Dim employeeLocation As String
    Dim employeeDoj As String
    Dim employeeApprover As String
    Dim leaveDate As String
    Dim lastDateApplied As String
    Dim leaveType As String
    Dim halfDay As String
    Dim empType As String

    Dim dtBU As New DataTable
    Dim dtEmpLevel As New DataTable
    Dim dtManager As New DataTable
    Dim dtAccessType As New DataTable
    Dim dtEmp As New DataTable
    Dim cls As New clsConnection
    Dim dtCheckCount As New DataTable
    Dim dtNews As New DataTable

    Dim connString As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim sqlConn As SqlConnection = New SqlConnection(connString)

    Dim sql As String

    '	Sub Connect()
    '		On Error GoTo err
    '		If cn.State = 1 Then cn.Close()
    '		cn.Open(connStr)
    '		Exit Sub
    'err:
    '		MsgBox(Err.Description)
    '	End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        pubUser = Session("userID")

        If pubUser Is Nothing Then
            Session("page") = "~/MasterControlHR.aspx"
            Response.Redirect("~/Home.aspx")
        End If

        'Try
        '	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
        '	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

        '	Dim sUser() As String = Split(DomainUser, "/")

        '	'Dim sDomain As String = suser(0)
        '	Dim sUserId As String = LCase(sUser(1))

        '	pubUser = sUserId
        '	pubUser = "sainibha"
        'Catch ex As Exception
        '	pubUser = "sainibha"
        'End Try

        'btnSaveEmployeeInfo.Attributes.Add("OnClick", "this.disabled=true;" + ClientScript.GetPostBackEventReference(btnSaveEmployeeInfo, Nothing) + ";document.getElementById('BtnNo').disabled = true;")

        'CreateNewsPanel()

        GetEmpInfo()
        If Not IsPostBack Then
            ddlBusinessUnit.Items.Add("--")
            ddlImmediateSuperior.Items.Add("--")
            PopulateDDL()
            Session("pubUser") = pubUser.Trim

        End If
    End Sub

    'Sub defaultSettings()
    '	rs.AddNew()
    '	rs(1).Value = txtregPercent.ToolTip
    '	rs(3).Value = "100%"
    '	rs(5).Value = Now
    '	rs(6).Value = pubUser
    '	rs.Update()

    '	rs.AddNew()
    '	rs(1).Value = txtSpecPercent.ToolTip
    '	rs(3).Value = "30%"
    '	rs(5).Value = Now
    '	rs(6).Value = pubUser
    '	rs.Update()

    '	rs.AddNew()
    '	rs(1).Value = txtDailyHours.ToolTip
    '	rs(3).Value = "8"
    '	rs(5).Value = Now
    '	rs(6).Value = pubUser
    '	rs.Update()

    '	rs.AddNew()
    '	rs(1).Value = txtRestsDay.ToolTip
    '	rs(3).Value = "8"
    '	rs(5).Value = Now
    '	rs(6).Value = pubUser
    '	rs.Update()

    '	rs.AddNew()
    '	rs(1).Value = txtNDTimeStart.ToolTip
    '	rs(3).Value = "10:00"
    '	rs(4).Value = "06:00"
    '	rs(5).Value = Now
    '	rs(6).Value = pubUser
    '	rs.Update()

    'End Sub

    Private Sub GetEmpInfo()

        Dim qry As String = ""

        qry = "select * from dbo.tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

        dtEmp = cls.GetData(qry)

    End Sub

    Private Sub PopulateDDL()

        Dim query As String = "select Distinct BusinessSegment from tbl_HRMS_EmployeeMaster where BusinessSegment is not null order by BusinessSegment"
        Dim val As String = ""

        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlBusinessSegment.Items.Add(New System.Web.UI.WebControls.ListItem("--Select One Below--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                ddlBusinessSegment.Items.Add(New System.Web.UI.WebControls.ListItem(dtAccessType.Rows(x)("BusinessSegment"), dtAccessType.Rows(x)("BusinessSegment")))
            Next
        End If

        query = "select * from tbl_HRMS_AccesType where DeletedBy is null"

        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlDropAccessType.Items.Add(New System.Web.UI.WebControls.ListItem("", "opt1"))
            ddlEmpLevel.Items.Add(New System.Web.UI.WebControls.ListItem("--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1

                ddlDropAccessType.Items.Add(New System.Web.UI.WebControls.ListItem(dtAccessType.Rows(x)("Access"), dtAccessType.Rows(x)("id")))
                ddlEmpLevel.Items.Add(New System.Web.UI.WebControls.ListItem(dtAccessType.Rows(x)("Access"), dtAccessType.Rows(x)("id")))

            Next
        End If

        query = "select * from dbo.tbl_HRMS_PAYROLL_CAT where deletedbyanddate is null order by Category"
        dtAccessType = cls.GetData(query)

        If dtAccessType.Rows.Count Then
            ddlEmpCategory.Items.Add(New System.Web.UI.WebControls.ListItem("--", "opt1"))
            For x As Integer = 0 To dtAccessType.Rows.Count - 1
                val = dtAccessType.Rows(x)("EmpLevel") & "-" & dtAccessType.Rows(x)("Category")
                ddlEmpCategory.Items.Add(New System.Web.UI.WebControls.ListItem(val, val))
            Next
        End If

    End Sub

    Private Sub PopulateManager()
        Dim empLevel As String
        Dim levels As String = ""

        Dim sb1 As New StringBuilder

        sb1.Append("select Distinct  ")
        sb1.Append("MngrNTID  ")
        sb1.Append("from tbl_HRMS_EmployeeMaster  ")
        sb1.Append("where  ")

        If ddlEmpLevel.SelectedItem.Text.Trim <> "--" Then
            sb1.Append("EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' and ")
        End If

        sb1.Append("BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' and ")
        sb1.Append("MngrNTID is not null ")
        sb1.Append("order by  ")
        sb1.Append("MngrNTID ")

        empLevel = sb1.ToString()

        dtEmpLevel = cls.GetData(empLevel)

        For x As Integer = 0 To dtEmpLevel.Rows.Count - 1
            If x = dtEmpLevel.Rows.Count - 1 Then
                levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "'"
            Else
                levels += "'" & dtEmpLevel.Rows(x)("MngrNTID") & "',"
            End If
        Next

        Dim query As String

        Dim sb2 As New StringBuilder

        sb2.Append("select ")
        sb2.Append("EmpName, ")
        sb2.Append("EmpLevel ")
        sb2.Append("from tbl_HRMS_EmployeeMaster ")
        sb2.Append("where ")
        sb2.Append("NTID in (" & levels.Trim & ")")
        sb2.Append("order by ")
        sb2.Append("EmpName ")

        query = sb2.ToString()

        dtManager = cls.GetData(query)

        ddlImmediateSuperior.Items.Add("--")
        For x As Integer = 0 To dtManager.Rows.Count - 1
            ddlImmediateSuperior.Items.Add(dtManager.Rows(x)("EmpName"))
        Next
    End Sub

    Private Sub ddlBusinessSegment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessSegment.SelectedIndexChanged
        ddlBusinessUnit.Items.Clear()
        PopulateBU()
    End Sub

    Private Sub PopulateBU()
        Dim query As String

        query = "select Distinct BusinessUnit from tbl_HRMS_EmployeeMaster where BusinessUnit is not null and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' order by BusinessUnit"

        dtBU = cls.GetData(query)

        ddlBusinessUnit.Items.Add("--")
        For x As Integer = 0 To dtBU.Rows.Count - 1
            ddlBusinessUnit.Items.Add(dtBU.Rows(x)("BusinessUnit"))
        Next
    End Sub

    Private Sub ddlBusinessUnit_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessUnit.SelectedIndexChanged
        ddlImmediateSuperior.Items.Clear()
        PopulateManager()
    End Sub

    Private Sub ddlEmpLevel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlEmpLevel.SelectedIndexChanged
        ddlImmediateSuperior.Items.Clear()
        PopulateManager()
    End Sub

    Protected Sub btnSearch_Click1(sender As Object, e As EventArgs) Handles btnSearch.Click

        Dim sb As New StringBuilder
        Dim str As String = ""
        Dim val As String = ""

        'dsAccesstypes.SelectCommand = Nothing
        'dsAccesstypes.DataBind()
        dsCurrentFunction.SelectCommand = Nothing
        dsCurrentFunction.DataBind()
        dsOtherFunction.SelectCommand = Nothing
        dsOtherFunction.DataBind()

        'If ddlBusinessUnit.Items.Count = 0 Then
        '    str += "Please Select Business Unit!\n"
        'Else
        '    If ddlBusinessUnit.Text = "--" Then
        '        str += "Please Select Business Unit!\n"
        '    End If
        'End If

        'If ddlImmediateSuperior.Items.Count = 0 Then
        '    str += "Please Select Immediate Superior!\n"
        'Else
        '    If ddlImmediateSuperior.Text = "--" Then
        '        str += "Please Select Immediate Superior!\n"
        '    End If
        'End If

        'If str <> "" Then GoTo alert

        str = ("Select EmpID,EmpName,emp.EmpLevel [EmpLevel],NTID,emp.EmpPayHrsCat,act.Access,act.id,emp.ModifiedBy,emp.DateModified ")
        str += ("from dbo.tbl_HRMS_EmployeeMaster emp ")
        str += ("left join dbo.tbl_HRMS_AccesType act ")
        str += ("on emp.AccessLevel = act.id ")

        If rbtnActive.Checked = True Then val = "is not null " Else val = "is null "

        str += ("where AccessLevel " & val)

        If txtEmployeeName.Text <> "" Then
            str += ("And EmpName Like '%" & txtEmployeeName.Text.Trim & "%' ")
        End If

        If ddlBusinessSegment.Items.Count > 0 Then
            If ddlBusinessSegment.SelectedItem.Text.Trim <> "--Select One Below--" Then
                str += (" and emp.BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
            End If
        End If

        If ddlBusinessUnit.Items.Count > 0 Then
            If ddlBusinessUnit.SelectedItem.Text.Trim <> "--" Then
                str += ("and emp.BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
            End If
        End If

        If ddlEmpLevel.Items.Count > 0 Then
            If ddlEmpLevel.SelectedItem.Text.Trim <> "--" Then
                str += ("and emp.EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
            End If
        End If

        ' str = sb.ToString

        If ddlImmediateSuperior.Items.Count > 0 Then
            If ddlImmediateSuperior.SelectedItem.Text.Trim <> "--" Then
                str += "and emp.MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' "
            End If
        End If


        str += "Order by "
        str += "emp.NTID "
        'sb.Append("Order by ")
        'sb.Append("emp.NTID ")

        SqlDataSource1.SelectCommand = str
        SqlDataSource1.DataBind()

        Session("sql") = str

        Exit Sub
alert:
        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
       "javascript:alertify.error('" & str & "');", True)

    End Sub

    Private Sub ddlDropAccessType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlDropAccessType.SelectedIndexChanged

        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        For Each dr In GridView1.Rows
            If gindex = -1 Then
                gindex = 0
            End If

            Dim isselected As CheckBox = DirectCast(GridView1.Rows(gindex).FindControl("chkselect"), CheckBox)

            If isselected.Checked = True Then

                Dim lblaccess As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblaccess"), Label)
                Dim modifiedby As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblmodifiedby"), Label)
                Dim datemodified As Label = DirectCast(GridView1.Rows(gindex).FindControl("lbldatemodified"), Label)

                lblaccess.Text = ddlDropAccessType.SelectedItem.Text
                lblaccess.ToolTip = ddlDropAccessType.Text

                modifiedby.Text = pubUser.Trim
                datemodified.Text = "modified"

            End If

            gindex += 1
        Next

        'Dim query As String



    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        Dim paycatval As String

        If GridView1.Rows.Count = 0 Then ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alertify.error('Please Select A Record');", True)

        For Each dr In GridView1.Rows
            If gindex = -1 Then
                gindex = 0
            End If

            Dim isSelected As CheckBox = DirectCast(GridView1.Rows(gindex).FindControl("chkSelect"), CheckBox)

            Dim lblAccess As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblAccess"), Label)

            Dim ModifiedBy As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblModifiedBy"), Label)
            Dim DateModified As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblDateModified"), Label)

            Dim PayCat As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblCategory"), Label)
            If PayCat.Text = "" Then paycatval = "NULL" Else paycatval = PayCat.Text

            If isSelected.Checked = True Then
                Dim cmdUpdate As New SqlCommand

                cmdUpdate.CommandText = "UPDATE tbl_HRMS_EmployeeMaster SET AccessLevel = " & lblAccess.ToolTip & ", EmpPayHrsCat = '" & paycatval & "',ModifiedBy = '" & ModifiedBy.Text.Trim & "',DateModified = GETDATE()  where NTID = '" & isSelected.ToolTip & "'"

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()
                cmdUpdate.ExecuteNonQuery()
                sqlConn.Close()
            End If

            gindex += 1
        Next

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
      "javascript:alertify.success('Successfully Updated! ');", True)

        SqlDataSource1.SelectCommand = Session("sql")
        SqlDataSource1.DataBind()

    End Sub

    Private Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Dim fquery As String = ""
        Dim query As String = ""
        Dim sql As String = ""

        SqlDataSource1.SelectCommand = Nothing
        SqlDataSource1.DataBind()

        Select Case e.CommandName
            Case "Select"
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = GridView2.Rows(rowindex)

                Dim lblAccess As Label = DirectCast(GridView2.Rows(row.RowIndex).FindControl("lblAccess"), Label)

                Session("SelType") = lblAccess.Text

                query = "select AccessType,b.Description [Functions],b.controlID from tbl_HRMS_Control a inner join tbl_HRMS_Functions b on a.Functions = b.ControlID where AccessType='" & lblAccess.Text.Trim & "'"
                dsCurrentFunction.SelectCommand = query
                dsCurrentFunction.DataBind()
                Session("query") = query


                query = "select a.Description, a.ControlID from tbl_HRMS_Functions a where a.ControlID NOT IN (select a.Functions from tbl_HRMS_Control a where a.AccessType = '" & lblAccess.Text.Trim & "')"

                fquery = query
                dtCheckCount = cls.GetData(query)

                If dtCheckCount.Rows.Count > 0 Then
                    sql = fquery
                Else

                    query = "select * from dbo.tbl_HRMS_Control where AccessType = '" & lblAccess.Text.Trim & "'"

                    dtCheckCount = cls.GetData(query)

                    If dtCheckCount.Rows.Count > 0 Then
                        sql = Nothing
                    Else
                        sql = "select Description,ControlID from dbo.tbl_HRMS_Functions"
                    End If

                End If

                dsOtherFunction.SelectCommand = sql
                dsOtherFunction.DataBind()
                Session("sql") = sql
            Case "Update"

                'Session("pubUser") = pubUser.Trim
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = GridView2.Rows(rowindex)
                'Dim lblAccess As Label = DirectCast(GridView2.Rows(row.RowIndex).FindControl("lblAccess"), Label)
                Dim lblAccessOnEdit As TextBox = DirectCast(GridView2.Rows(row.RowIndex).FindControl("lblAccessOnEdit"), TextBox)

                sql = "UPDATE dbo.tbl_HRMS_AccesType set Access = '" & lblAccessOnEdit.Text.Trim & "', EditedBy = '" & pubUser.Trim & "', DateEdited = GETDATE() where Access = '" & lblAccessOnEdit.ToolTip.Trim & "'"


                Dim cmdUpdate As New SqlCommand

                cmdUpdate.CommandText = sql

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()

                cmdUpdate.ExecuteNonQuery()

                sql = "UPDATE dbo.tbl_HRMS_Control set AccessType='" & lblAccessOnEdit.Text.Trim & "' where AccessType='" & lblAccessOnEdit.ToolTip.Trim & "'"
                cmdUpdate.CommandText = sql
                cmdUpdate.ExecuteNonQuery()

                sqlConn.Close()

                sql = "select * from dbo.tbl_HRMS_AccesType where deletedby is null"
                dsAccesstypes.SelectCommand = sql
                dsAccesstypes.DataBind()

            Case "Delete"
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = GridView2.Rows(rowindex)

                Dim lblAccessOnEdit As Label = DirectCast(GridView2.Rows(row.RowIndex).FindControl("lblAccess"), Label)

                Session("pubUser") = pubUser.Trim

                Session("ATid") = lblAccessOnEdit.ToolTip
        End Select


    End Sub
    Function alert(str As String) As Boolean
        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
     "javascript:alert('" & str & "');", True)
        Return True
    End Function

    Private Sub imgBtnApply_Click(sender As Object, e As ImageClickEventArgs) Handles imgBtnApply.Click

        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        Dim str As String = ""

        If GridView3.Rows.Count > 0 Then

            For Each dr In GridView3.Rows
                If gindex = -1 Then
                    gindex = 0
                End If

                Dim isSelected As CheckBox = DirectCast(GridView3.Rows(gindex).FindControl("OtherFunctionSelect"), CheckBox)
                If isSelected.Checked = True Then str += "('" & Session("SelType") & "','" & isSelected.ToolTip & "','" & pubUser.Trim & "',GETDATE(),'New'), "



                gindex += 1
            Next

            If str <> "" Then
                Dim cmdUpdate As New SqlCommand
                str = Mid(str, 1, Len(str) - 2)
                cmdUpdate.CommandText = "INSERT INTO tbl_HRMS_Control VALUES " & str

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()
                cmdUpdate.ExecuteNonQuery()
                sqlConn.Close()

                dsCurrentFunction.SelectCommand = Session("query")
                dsCurrentFunction.DataBind()

                dsOtherFunction.SelectCommand = Session("sql")
                dsOtherFunction.DataBind()
            End If

        End If

    End Sub

    Private Sub imgBtnRemove_Click(sender As Object, e As ImageClickEventArgs) Handles imgBtnRemove.Click
        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        Dim str As String = ""

        If GridView4.Rows.Count > 0 Then

            For Each dr In GridView4.Rows
                If gindex = -1 Then
                    gindex = 0
                End If

                Dim isSelected As CheckBox = DirectCast(GridView4.Rows(gindex).FindControl("CurrentFunctionSelect"), CheckBox)

                If isSelected.Checked = True Then str += "AccessType = '" & Session("SelType") & "' and Functions = '" & isSelected.ToolTip & "' or "

                gindex += 1
            Next

            If str <> "" Then
                Dim cmdUpdate As New SqlCommand
                str = Mid(str, 1, Len(str) - 4)
                cmdUpdate.CommandText = "Delete tbl_HRMS_Control Where " & str

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()
                cmdUpdate.ExecuteNonQuery()
                sqlConn.Close()

                dsCurrentFunction.SelectCommand = Session("query")
                dsCurrentFunction.DataBind()

                dsOtherFunction.SelectCommand = Session("sql")
                dsOtherFunction.DataBind()
            End If

        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        For Each dr In GridView1.Rows
            If gindex = -1 Then
                gindex = 0
            End If

            Dim isSelected As CheckBox = DirectCast(GridView1.Rows(gindex).FindControl("chkSelect"), CheckBox)

            If isSelected.Checked = True Then

                'Dim lblAccess As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblAccess"), Label)

                Dim ModifiedBy As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblModifiedBy"), Label)
                Dim DateModified As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblDateModified"), Label)

                'lblAccess.Text = ddlDropAccessType.SelectedItem.Text
                'lblAccess.ToolTip = ddlDropAccessType.Text

                ModifiedBy.Text = pubUser.Trim
                DateModified.Text = "Set Inactive"

                Dim cmdUpdate As New SqlCommand

                cmdUpdate.CommandText = "UPDATE tbl_HRMS_EmployeeMaster SET AccessLevel = Null,ModifiedBy = '" & ModifiedBy.Text.Trim & "',DateModified = GETDATE()  where NTID = '" & isSelected.ToolTip & "'"

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()
                cmdUpdate.ExecuteNonQuery()
                sqlConn.Close()

            End If

            gindex += 1
        Next

        SqlDataSource1.SelectCommand = Session("sql")
        SqlDataSource1.DataBind()

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alertify.success('Successfully Modified to Inactive!.');", True)

    End Sub

    Protected Sub GridView2_RowDeleted(sender As Object, e As GridViewDeletedEventArgs)

        If e.AffectedRows > 0 Then
            sql = "select * from dbo.tbl_HRMS_AccesType where deletedby is null"
            dsAccesstypes.SelectCommand = sql
            dsAccesstypes.DataBind()

            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alertify.success('Deletion success.');", True)
        Else
            ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alertify.error('No Record Deleted.');", True)
        End If

    End Sub

    Protected Sub GridView5_RowDeleted(sender As Object, e As GridViewDeletedEventArgs)

        SqlDataSource2.SelectCommand = "SELECT ReasonID,ReasonDesc,Category,ReasonDescription,CASE WHEN ExcludeonPayment = 'YES' then 'UnPaid' else 'Paid' end [CategoryType],ModifiedBy,Active,ModifiedDate FROM [tbl_HRMS_PAY_Reason] WHERE Category <> 'None' and active <> 'Deleted'"
        SqlDataSource2.DataBind()

        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alertify.success('Deletion Success..');", True)
    End Sub

    Private Sub GridView5_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView5.RowCommand
        'Alert(e.CommandName)
        Select Case e.CommandName
            Case "Edit"
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = GridView5.Rows(rowindex)

                Dim ImgBtnDel As ImageButton = DirectCast(GridView5.Rows(row.RowIndex).FindControl("imgBtnDelete"), ImageButton)
                ImgBtnDel.Enabled = False

                'UpdatePanel6.Update()

            Case "Update"
                Dim rowindex As Integer = CInt(e.CommandArgument)
                Dim row As GridViewRow = GridView5.Rows(rowindex)

                Dim findMyControl As DropDownList = DirectCast(GridView5.Rows(row.RowIndex).FindControl("ddlPaid"), DropDownList)
                Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView5.Rows(row.RowIndex).FindControl("chkStatus"), CheckBox)

                If findMyControl.SelectedValue = "Paid" Then Session("ExCludeOnPayment") = "NO" Else Session("ExCludeOnPayment") = "YES"
                If lblHrsWorkedSeriesID.Checked = True Then Session("ChecKValue") = "1" Else Session("ChecKValue") = "0"

            Case "Delete"

                SqlDataSource2.DeleteCommand = "Update tbl_HRMS_PAY_Reason set Active = 'Deleted' where ReasonID = '" & e.CommandArgument & "'"
                SqlDataSource2.DataBind()

        End Select

    End Sub

    Sub OnDSUpdatedHandler(ByVal source As Object, ByVal e As SqlDataSourceStatusEventArgs)
        If e.AffectedRows > 0 Then

            alert(Request.LogonUserIdentity.Name & " changed user information successfully!")
        Else
            alert("No data updated!")
        End If
    End Sub

    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetEmpLevel() As List(Of String)

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim str As New List(Of String)

        qry = "select DISTINCT EmpLevel from dbo.tbl_HRMS_EmployeeMaster where EmpLevel is not null order by emplevel"
        dt = cls.GetData(qry)

        For i As Integer = 0 To dt.Rows.Count - 1
            str.Add(dt.Rows(i)("EmpLevel").ToString())
        Next

        Return str
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function AddCategory(str As String, EmpLevel As String, Usr As String) As Integer

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As Integer


        qry = "SELECT * FROM dbo.tbl_HRMS_PAYROLL_CAT WHERE Category = '" & str.Trim & "' and DeletedByAndDate is null and EmpLevel = '" & EmpLevel & "'"
        dt = cls.ExecuteScalarQuery(qry)

        If dt > 0 Then

            dt = 2
        Else
            qry = "INSERT INTO dbo.tbl_HRMS_PAYROLL_CAT(Category, Emplevel, AddedByAndDate) VALUES('" & Replace(str.Trim, " ", "_") & "','" & EmpLevel.Trim & "','" & Usr.Trim & "@" & Now.ToString & "')"
            dt = cls.ExecuteQuery(qry)
        End If

        Return dt
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetEmpCat(EmpLevel As String) As EmployeeCategoryObj

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim rt As New EmployeeCategoryObj

        Dim str As New List(Of CategoryType)

        qry = "select * from dbo.tbl_HRMS_PAYROLL_CAT where deletedbyanddate is null and EmpLevel = '" & EmpLevel.Trim & "'"
        dt = cls.GetData(qry)

        For i As Integer = 0 To dt.Rows.Count - 1

            Dim cat As New CategoryType
            cat.catID = dt.Rows(i)("id").ToString()
            cat.category = dt.Rows(i)("Category").ToString()
            str.Add(cat)

        Next

        rt.ListOfCategoryCount = dt.Rows.Count
        rt.ListOfCategory = str

        Return rt

    End Function


    <WebMethod(EnableSession:=True)> _
    Public Shared Function EmpCatDelete(data As MyMasterControl) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)

        qry = "UPDATE dbo.tbl_HRMS_MasterControl set DeletedByAndDate = '" & data.usr.Trim & "@" & Now.ToString & "' where EmpLevel = '" & data.ELvl & "' and Category = '" & data.Val & "'"
        rt = cls.ExecuteQuery(qry)

        qry = "UPDATE dbo.tbl_HRMS_PAYROLL_CAT set DeletedByAndDate = '" & data.usr.Trim & "@" & Now.ToString & "' where id = " & data.id.Trim
        rt = cls.ExecuteQuery(qry)

        Return rt
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetLeaveList() As EmployeeCategoryObj

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim rt As New EmployeeCategoryObj

        Dim str As New List(Of LeaveList)

        qry = "Select * from dbo.tbl_HRMS_Leave_Core where DeletedByAndDate is null order by LeaveName"
        dt = cls.GetData(qry)

        For i As Integer = 0 To dt.Rows.Count - 1

            Dim leave As New LeaveList

            leave.id = dt.Rows(i)("id").ToString()
            leave.LeaveName = dt.Rows(i)("LeaveName").ToString()
            leave.ModifedByAndDateTime = dt.Rows(i)("ModifiedByAndDate").ToString()

            leave.Gender = dt.Rows(i)("Gender").ToString()
            'leave.EmpLevel = dt.Rows(i)("EmpLevel").ToString()
            'leave.EmpCategory = dt.Rows(i)("EmpCategory").ToString()

            'leave.idOfApproverTable = dt.Rows(i)("idOfApproverTable").ToString()
            'leave.idOfCutOff = dt.Rows(i)("idOfCutOff").ToString()

            str.Add(leave)

        Next

        rt.ListOfLeave = str

        Return rt

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function AddLeave(desc As String, usr As String) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)

        qry = "Select * from tbl_HRMS_Leave_Core where LeaveName = '" & desc.Trim & "' and DeletedByAndDate is null"
        rt = cls.ExecuteScalarQuery(qry)

        If rt = 0 Then
            qry = "INSERT INTO dbo.tbl_HRMS_Leave_Core(LeaveName, AddedByAndDate, ModifiedByAndDate) VALUES ('" & desc.Trim & "','" & usr.Trim & "@" & Now.ToString & "','" & usr.Trim & "@" & Now.ToString & "')"
            rt = cls.ExecuteQuery(qry)
        Else
            rt = 2
        End If

        Return rt
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function DeleteLeave(id As String, usr As String) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)

        qry = "UPDATE dbo.tbl_HRMS_Leave_Core SET DeletedByAndDate =  '" & usr.Trim & "@" & Now.ToString & "' WHERE id = " & id
        rt = cls.ExecuteQuery(qry)

        Return rt

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function UpdateLeave(id As String, usr As String) As Integer
        'Dim cls As New clsConnection
        'Dim qry As String = ""
        ''Dim dt As New DataTable
        'Dim rt As New Integer

        ''Dim str As New List(Of CategoryType)

        'qry = "UPDATE dbo.tbl_HRMS_Leave_Core SET DeletedByAndDate =  '" & usr.Trim & "@" & Now.ToString & "' WHERE id = " & id
        'rt = cls.ExecuteQuery(qry)

        'Return rt

    End Function


    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetEmpCatUpdate(data As MyMasterControl) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)

        qry = "UPDATE dbo.tbl_HRMS_PAYROLL_CAT set Category = '" & data.Val.Trim & "', LastModifiedByAndDate = '" & data.usr.Trim & "@" & Now.ToString & "' where id = " & data.id.Trim
        rt = cls.ExecuteQuery(qry)

        Return rt
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetMCSettings(data As MyMasterControl) As EmployeeCategoryObj
        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim rt As New Integer
        Dim core As New EmployeeCategoryObj

        Dim str As New List(Of MyMasterControl)

        qry = "Select * from tbl_HRMS_MasterControl where Category = '" & data.Val.Trim & "' and EmpLevel = '" & data.ELvl & "'"
        dt = cls.GetData(qry)

        Dim mc As New MyMasterControl

        If dt.Rows.Count > 0 Then mc.Mode = "1" Else mc.Mode = "0"

        For i = 0 To dt.Rows.Count - 1

            mc.PTO = IIf(dt.Rows(i)("Settings") = "PA", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.PTO <> "", mc.PTO, ""))
            mc.CTO = IIf(dt.Rows(i)("Settings") = "CA", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.CTO <> "", mc.CTO, ""))
            mc.RH = IIf(dt.Rows(i)("Settings") = "RH", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.RH <> "", mc.RH, ""))
            mc.SH = IIf(dt.Rows(i)("Settings") = "SH", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.SH <> "", mc.SH, ""))
            mc.vDO = IIf(dt.Rows(i)("Settings") = "DO", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.vDO <> "", mc.vDO, ""))
            mc.RDO = IIf(dt.Rows(i)("Settings") = "RD", IIf(IsDBNull(dt.Rows(i)("SetValue1")), "--", dt.Rows(i)("SetValue1")), IIf(mc.RDO <> "", mc.RDO, ""))

            If dt.Rows(i)("Settings") = "ND" Then
                If dt.Rows(i)("SetValue1") <> " " And Not IsDBNull(dt.Rows(i)("SetValue1")) Then
                    mc.ND1 = Mid(dt.Rows(i)("SetValue1"), 1, Len(dt.Rows(i)("SetValue1")) - 3)
                    mc.ND1AMPM = Right(dt.Rows(i)("SetValue1"), 2)
                End If
            Else
                IIf(mc.ND1 <> "", mc.ND1, "")
            End If

            If dt.Rows(i)("Settings") = "ND" Then
                If dt.Rows(i)("SetValue2") <> " " And Not IsDBNull(dt.Rows(i)("SetValue2")) Then
                    mc.ND2 = Mid(dt.Rows(i)("SetValue2"), 1, Len(dt.Rows(i)("SetValue2")) - 3)
                    mc.ND2AMPM = Right(dt.Rows(i)("SetValue2"), 2)
                End If
            Else
                IIf(mc.ND2 <> "", mc.ND2, "")
            End If

            mc.ITT = IIf(dt.Rows(i)("Settings") = "IT", dt.Rows(i)("SetValue1"), IIf(mc.ITT <> "", mc.ITT, ""))
            mc.ELI = IIf(dt.Rows(i)("Settings") = "EL", dt.Rows(i)("SetValue1"), IIf(mc.ELI <> "", mc.ELI, ""))

            mc.PTOChk = IIf(dt.Rows(i)("Settings") = "PA", dt.Rows(i)("Status"), IIf(mc.PTOChk <> "", mc.PTOChk, ""))
            mc.CTOChk = IIf(dt.Rows(i)("Settings") = "CA", dt.Rows(i)("Status"), IIf(mc.CTOChk <> "", mc.CTOChk, ""))
            mc.RHChk = IIf(dt.Rows(i)("Settings") = "RH", dt.Rows(i)("Status"), IIf(mc.RHChk <> "", mc.RHChk, ""))
            mc.SHChk = IIf(dt.Rows(i)("Settings") = "SH", dt.Rows(i)("Status"), IIf(mc.SHChk <> "", mc.SHChk, ""))
            mc.DOChk = IIf(dt.Rows(i)("Settings") = "DO", dt.Rows(i)("Status"), IIf(mc.DOChk <> "", mc.DOChk, ""))
            mc.RDOChk = IIf(dt.Rows(i)("Settings") = "RD", dt.Rows(i)("Status"), IIf(mc.RDOChk <> "", mc.RDOChk, ""))
            mc.NDChk = IIf(dt.Rows(i)("Settings") = "ND", dt.Rows(i)("Status"), IIf(mc.NDChk <> "", mc.NDChk, ""))
            mc.ITTChk = IIf(dt.Rows(i)("Settings") = "IT", dt.Rows(i)("Status"), IIf(mc.ITTChk <> "", mc.ITTChk, ""))
            mc.ELIChk = IIf(dt.Rows(i)("Settings") = "EL", dt.Rows(i)("Status"), IIf(mc.ELIChk <> "", mc.ELIChk, ""))

            mc.SSSChk = IIf(dt.Rows(i)("Settings") = "SSS", dt.Rows(i)("Status"), IIf(mc.SSSChk <> "", mc.SSSChk, ""))
            mc.PHChk = IIf(dt.Rows(i)("Settings") = "PH", dt.Rows(i)("Status"), IIf(mc.PHChk <> "", mc.PHChk, ""))
            mc.HDMFChk = IIf(dt.Rows(i)("Settings") = "HDMF", dt.Rows(i)("Status"), IIf(mc.HDMFChk <> "", mc.HDMFChk, ""))
            mc.TaxChk = IIf(dt.Rows(i)("Settings") = "TAX", dt.Rows(i)("Status"), IIf(mc.TaxChk <> "", mc.TaxChk, ""))
            mc.m13Chk = IIf(dt.Rows(i)("Settings") = "M13", dt.Rows(i)("Status"), IIf(mc.m13Chk <> "", mc.m13Chk, ""))
            mc.PsChk = IIf(dt.Rows(i)("Settings") = "PS", dt.Rows(i)("Status"), IIf(mc.PsChk <> "", mc.PsChk, ""))

            mc.modiPTO = IIf(dt.Rows(i)("Settings") = "PA", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modiPTO <> "", mc.modiPTO, ""))
            mc.modiCTO = IIf(dt.Rows(i)("Settings") = "CA", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modiCTO <> "", mc.modiCTO, ""))
            mc.modirh = IIf(dt.Rows(i)("Settings") = "RH", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modirh <> "", mc.modirh, ""))
            mc.modish = IIf(dt.Rows(i)("Settings") = "SH", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modish <> "", mc.modish, ""))
            mc.modido = IIf(dt.Rows(i)("Settings") = "DO", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modido <> "", mc.modido, ""))
            mc.modirdo = IIf(dt.Rows(i)("Settings") = "RD", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modirdo <> "", mc.modirdo, ""))
            mc.modind = IIf(dt.Rows(i)("Settings") = "ND", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modind <> "", mc.modind, ""))
            mc.modiitt = IIf(dt.Rows(i)("Settings") = "IT", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modiitt <> "", mc.modiitt, ""))
            mc.modieli = IIf(dt.Rows(i)("Settings") = "EL", dt.Rows(i)("ModifiedBy") & "-" & dt.Rows(i)("ModifiedDate"), IIf(mc.modieli <> "", mc.modieli, ""))

        Next
        str.Add(mc)

        core.ListMyMasterControl = str
        Return core
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function InsertSettings(data As MyMasterControl) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim values As String = ""
        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)
        '        PA
        '        CA
        '        RH
        '        SH
        '        DO
        '            RD
        '            ND
        '            IT
        '            EL

        qry = "select * from dbo.tbl_HRMS_MasterControl where Category = '" & data.Val & "' and EmpLevel = '" & data.ELvl & "'"
        rt = cls.ExecuteScalarQuery(qry)
        If rt = 0 Then

            values += "('PA','" & data.PTO.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.PTOChk & "','" & data.ELvl & "'),"
            values += "('CA','" & data.CTO.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.CTOChk & "','" & data.ELvl & "'),"
            values += "('RH','" & data.RH.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.RHChk & "','" & data.ELvl & "'),"
            values += "('SH','" & data.SH.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.SHChk & "','" & data.ELvl & "'),"
            values += "('DO','" & data.vDO.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.DOChk & "','" & data.ELvl & "'),"
            values += "('RD','" & data.RDO.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.RDOChk & "','" & data.ELvl & "'),"
            values += "('ND','" & data.ND1.Trim & " " & data.ND1AMPM & "','" & data.ND2.Trim & " " & data.ND2AMPM & "',GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.NDChk & "','" & data.ELvl & "'),"
            values += "('IT','" & data.ITT.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ITTChk & "','" & data.ELvl & "'),"
            values += "('EL','" & data.ELI.Trim & "',NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"

            values += "('SSS',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"
            values += "('PH',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"
            values += "('HDMF',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"
            values += "('TAX',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"
            values += "('M13',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"
            values += "('PS',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & data.ELIChk & "','" & data.ELvl & "')"


            qry = "INSERT INTO tbl_HRMS_MasterControl(Settings, SetValue1,SetValue2, ModifiedDate, ModifiedBy, Category, Status, EmpLevel) "
            qry += "VALUES" & values

            rt = cls.ExecuteQuery(qry)
            'Else

            '    qry += "UPDATE tbl_HRMS_MasterControl SET SetValue1 = '@SetValue1',SetValue2 = '@SetValue2', ModifiedDate = '@ModifiedDate', "
            '    qry += "ModifiedBy = '" & data.usr & "', Category = '@Category', Status = '@Status' "
            '    qry += "WHERE Settings = '" & data.Val & "' "

            '    rt = 0
        End If

        Return rt

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function ApplySettings(data As MyMasterControl) As Integer
        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim values As String = ""
        Dim insvalues As String = ""

        'Dim dt As New DataTable
        Dim rt As New Integer

        'Dim str As New List(Of CategoryType)
        '        PA
        '        CA
        '        RH
        '        SH
        '        DO
        '            RD
        '            ND
        '            IT
        '            EL
        Dim sv1, sv2, stat As String


        If data.Settings = "PA" Then
            sv1 = data.PTO : sv2 = "NULL" : stat = data.PTOChk
        ElseIf data.Settings = "CA" Then
            sv1 = data.CTO : sv2 = "NULL" : stat = data.CTOChk
        ElseIf data.Settings = "RH" Then
            sv1 = data.RH : sv2 = "NULL" : stat = data.RHChk
        ElseIf data.Settings = "SH" Then
            sv1 = data.SH : sv2 = "NULL" : stat = data.SHChk
        ElseIf data.Settings = "DO" Then
            sv1 = data.vDO : sv2 = "NULL" : stat = data.DOChk
        ElseIf data.Settings = "RD" Then
            sv1 = data.RDO : sv2 = "NULL" : stat = data.RDOChk
        ElseIf data.Settings = "IT" Then
            sv1 = data.ITT : sv2 = "NULL" : stat = data.ITTChk
        ElseIf data.Settings = "EL" Then
            sv1 = data.ELI : sv2 = "NULL" : stat = data.ELIChk
        ElseIf data.Settings = "SSS" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.SSSChk
        ElseIf data.Settings = "PH" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.PHChk
        ElseIf data.Settings = "HDMF" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.HDMFChk
        ElseIf data.Settings = "TAX" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.TaxChk
        ElseIf data.Settings = "M13" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.m13Chk
        ElseIf data.Settings = "PS" Then
            sv1 = "NULL" : sv2 = "NULL" : stat = data.PsChk
        Else
            sv1 = data.ND1.Trim & " " & data.ND1AMPM : sv2 = data.ND2.Trim & " " & data.ND2AMPM : stat = data.NDChk

        End If

        qry = "Select * from tbl_HRMS_MasterControl where Category = '" & data.Val & "' and EmpLevel = '" & data.ELvl & "' and Settings = '" & data.Settings & "'"
        rt = cls.ExecuteScalarQuery(qry)

        If rt > 0 Then
            values += "SetValue1='" & sv1 & "',SetValue2='" & sv2 & "',ModifiedDate=GETDATE(),ModifiedBy='" & data.usr & "',Category='" & data.Val & "',Status='" & stat & "',EmpLevel='" & data.ELvl & "'"
            qry = "UPDATE dbo.tbl_HRMS_MasterControl SET " & values & " where Category = '" & data.Val & "' and EmpLevel = '" & data.ELvl & "' and Settings = '" & data.Settings & "'"
        Else
            insvalues += "('" & data.Settings & "',NULL,NULL,GETDATE(),'" & data.usr & "','" & data.Val & "','" & stat & "','" & data.ELvl & "')"
            qry = "INSERT INTO tbl_HRMS_MasterControl(Settings, SetValue1,SetValue2, ModifiedDate, ModifiedBy, Category, Status, EmpLevel) "
            qry += "VALUES" & insvalues
        End If

        rt = cls.ExecuteQuery(qry)

        Return rt

    End Function

    Private Sub ddlEmpCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlEmpCategory.SelectedIndexChanged

        Dim dr As GridViewRow
        Dim gindex As Integer = -1
        Dim cLevel As String = ""
        Dim cText As String = ""
        For Each dr In GridView1.Rows
            If gindex = -1 Then
                gindex = 0
            End If

            Dim isselected As CheckBox = DirectCast(GridView1.Rows(gindex).FindControl("chkSelect"), CheckBox)

            If isselected.Checked = True Then

                Dim lblPayCat As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblCategory"), Label)
                Dim modifiedby As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblModifiedBy"), Label)
                Dim datemodified As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblDateModified"), Label)
                Dim lblEmpLevel As Label = DirectCast(GridView1.Rows(gindex).FindControl("lblEmpLevel"), Label)

                'lblaccess.Text = ddlDropAccessType.SelectedItem.Text
                'lblaccess.ToolTip = ddlDropAccessType.Text
                If ddlEmpCategory.SelectedItem.Text <> "" Then
                    cLevel = Mid(ddlEmpCategory.SelectedItem.Text, 1, InStr(ddlEmpCategory.SelectedItem.Text, "-") - 1)

                    cText = Mid(ddlEmpCategory.SelectedItem.Text, InStr(ddlEmpCategory.SelectedItem.Text, "-") + 1, Len(ddlEmpCategory.SelectedItem.Text))

                    If lblEmpLevel.Text = cLevel Then

                        lblPayCat.Text = cText

                        modifiedby.Text = pubUser.Trim
                        datemodified.Text = "modified"

                    End If
                End If
            End If

            gindex += 1
        Next

        'Dim query As String

    End Sub


    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetLeaveCat() As EmployeeCategoryObj

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim rt As New EmployeeCategoryObj

        Dim str As New List(Of CategoryType)

        qry = "select * from dbo.tbl_HRMS_PAYROLL_CAT where deletedbyanddate is null order by EmpLevel,Category"
        dt = cls.GetData(qry)

        For i As Integer = 0 To dt.Rows.Count - 1

            Dim cat As New CategoryType
            cat.catID = dt.Rows(i)("id").ToString()
            cat.category = dt.Rows(i)("Category").ToString()
            cat.catEmpLevel = dt.Rows(i)("EmpLevel").ToString()
            str.Add(cat)

        Next

        rt.ListOfCategoryCount = dt.Rows.Count
        rt.ListOfCategory = str

        Return rt

    End Function
    <WebMethod(EnableSession:=True)> _
    Public Shared Function LeaveSpecification(id As String, cat As String) As EmployeeCategoryObj

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable
        Dim rt As New EmployeeCategoryObj

        Dim str As New List(Of CategoryType)
        Dim da As New DataSet
        Dim dtgender As DataTable

        qry = "Select * from tbl_HRMS_Leave_Core where LeaveName = '" & id & "';"
        qry += "Select * from tbl_HRMS_Leave_Settings where leaveid = '" & id & "' and EmpCategory = '" & cat & "'"

        da = cls.GetDataSet(qry)

        dtgender = da.Tables(0)
        dt = da.Tables(1)

        rt.LeaveRecordCount = dt.Rows.Count

        If dt.Rows.Count > 0 Then
            Dim tblAppID As String = dt.Rows(0)("ApproverTable")
            Dim tblCutoffId As String = dt.Rows(0)("CutOff")

            rt.LeaveGender = dtgender.Rows(0)("Gender")
            rt.LeavePaid = dtgender.Rows(0)("Paid")

            qry = "Select * from tbl_HRMS_Leave_Settings_Approver where id = '" & tblAppID & "'"
            dt = cls.GetData(qry)

            Dim appList As New List(Of Approver)

            For i As Integer = 0 To dt.Rows.Count - 1
                Dim app As New Approver
                app.Approver = dt.Rows(i)("Approver")
                app.ApproverIndex = dt.Rows(i)("aOrder")

                appList.Add(app)

            Next

            rt.ListOfApprover = appList

            qry = "Select * from tbl_HRMS_Leave_Settings_CutOff where id = '" & tblCutoffId & "'"
            dt = cls.GetData(qry)

            Dim CutOffList As New List(Of CutOff)

            For i As Integer = 0 To dt.Rows.Count - 1
                Dim cf As New CutOff

                cf.lvFrom = dt.Rows(i)("lvFrom")
                cf.lvTo = dt.Rows(i)("lvTo")
                cf.lvApproved = dt.Rows(i)("shouldApprovedBy")

                CutOffList.Add(cf)

            Next

            rt.ListOfCutOff = CutOffList
        End If

        Return rt

    End Function
    <WebMethod(EnableSession:=True)> _
    Public Shared Function SaveLeaveSettings(data As EmployeeCategoryObj) As Integer

        Dim cls As New clsConnection
        Dim qry As String = ""
        Dim dt As New DataTable

        Dim rt As Integer

        Dim str As New List(Of CategoryType)
        Dim da As New DataSet

        qry = "update tbl_HRMS_Leave_Core set Paid='" & data.LeavePaid & "', Gender = '" & data.LeaveGender & "',ModifiedByAndDate = '" & data.usr & "@" & Now.ToString & "' where leavename = '" & data.Leave & "';"
        qry += "Delete tbl_HRMS_Leave_Settings where leaveid = '" & data.Leave & "' and EmpCategory = '" & data.Categ & "';"

        qry += "insert into tbl_HRMS_Leave_Settings(leaveid,EmpCategory,ApproverTable,CutOff) VALUES('" & data.Leave & "','" & data.Categ & "','" & data.Leave & data.Categ & "','" & data.Leave & data.Categ & "');"

        qry += "delete tbl_HRMS_Leave_Settings_Approver where id = '" & data.Leave & data.Categ & "';"

        qry += "insert into tbl_HRMS_Leave_Settings_Approver(id,Approver,aOrder) values"
        For i = 0 To data.ListOfApprover.Count - 1
            qry += "('" & data.Leave & data.Categ & "','" & data.ListOfApprover(i).Approver & "','" & data.ListOfApprover(i).ApproverIndex & "'),"
        Next
        qry = Mid(qry, 1, Len(qry) - 1)
        qry += ";"

        qry += "delete tbl_HRMS_Leave_Settings_CutOff where id = '" & data.Leave & data.Categ & "';"

        qry += "insert into tbl_HRMS_Leave_Settings_CutOff(id,lvFrom,lvTo,shouldApprovedBy) values"
        For i = 0 To data.ListOfCutOff.Count - 1
            qry += "('" & data.Leave & data.Categ & "','" & data.ListOfCutOff(i).lvFrom & "','" & data.ListOfCutOff(i).lvTo & "','" & data.ListOfCutOff(i).lvApproved & "'),"
        Next
        qry = Mid(qry, 1, Len(qry) - 1)
        qry += ";"
        rt = cls.ExecuteQuery(qry)


        Return rt

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function updateM13(data As m13) As Integer

        Dim rt As Integer = 0
        Dim cls As New clsConnection
        Dim exist As Integer = 0
        Dim qry As String = "Select * from tbl_hrms_M13_Settings where category = '" & data.Val & "' and emplevel = '" & data.Elvl & "'"

        exist = cls.ExecuteScalarQuery(qry)

        If exist > 0 Then
            qry = "UPDATE tbl_hrms_M13_Settings SET " _
                        & "title = '" & data.txtsbDesc.Trim & "'," _
                        & "ps = '" & data.selPayoutScheme & "'," _
                        & "firstPayFrom = '" & data.txt1pf & "'," _
                        & "firstPayTo = '" & data.txt1pt & "'," _
                        & "SecondPayFrom = '" & data.txt2pf & "'," _
                        & "SecondPayTo = '" & data.txt2pt & "'," _
                        & "ThirdPayFrom = '" & data.txt3pf & "'," _
                        & "ThirdPayTo = '" & data.txt3pt & "'," _
                        & "ForthPayFrom = '" & data.txt4pf & "'," _
                        & "ForthPayTo = '" & data.txt4pt & "'," _
                        & "lastmodifiedby = '" & data.usr & " @' + cast(GETDATE() as varchar)," _
                        & "income = '" & data.selSalary & "'," _
                        & "operator1 = '" & data.selOperator & "'," _
                        & "list1 = '" & data.selPrimary & "'," _
                        & "operator2 = '" & data.selOperator2 & "'," _
                        & "list2 = '" & data.selSecondary & "'," _
                        & "divideby = '" & data.txtdvBy & "' " _
            & "WHERE category = '" & data.Val & "' and emplevel = '" & data.Elvl & "'"

        Else

            qry = "INSERT INTO tbl_hrms_M13_Settings(category,emplevel,title,ps,firstpayfrom,firstpayto,secondpayfrom,secondpayto,thirdpayfrom,thirdpayto,forthpayfrom,forthpayto,lastmodifiedby,income,operator1,list1,operator2,list2,divideby)"
            qry += "VALUES('" & data.Val & "','" & data.Elvl & "','" & data.txtsbDesc.Trim & "','" & data.selPayoutScheme & "','" & data.txt1pf & "', '" & data.txt1pt & "','" & data.txt2pf & "', '" & data.txt2pt & "','" & data.txt3pf & "', '" & data.txt3pt & "','" & data.txt4pf & "', '" & data.txt4pt & "','" & data.usr & " @' + cast(GETDATE() as varchar),'" & data.selSalary & "','" & data.selOperator & "','" & data.selPrimary & "','" & data.selOperator2 & "','" & data.selSecondary & "','" & data.txtdvBy & "')"

        End If

        rt = cls.ExecuteQuery(qry)

        Return rt


    End Function


    <WebMethod(EnableSession:=True)> _
    Public Shared Function fetchM13(data As m13) As m13

        'Dim rt As New m13

        Dim cls As New clsConnection
        Dim dt As New DataTable

        Dim qry As String = "Select * from tbl_hrms_M13_Settings where category = '" & data.Val & "' and emplevel = '" & data.Elvl & "'"

        dt = cls.GetData(qry)

        data.fetchCount = dt.Rows.Count

        If dt.Rows.Count > 0 Then

            data.selSalary = dt.Rows(0)("income")
            data.selOperator = dt.Rows(0)("operator1")
            data.selPrimary = dt.Rows(0)("list1")
            data.selOperator2 = dt.Rows(0)("operator2")
            data.selSecondary = dt.Rows(0)("list2")
            data.txtdvBy = dt.Rows(0)("divideby")
            data.txtsbDesc = dt.Rows(0)("title")
            data.selPayoutScheme = dt.Rows(0)("ps")

            data.txt1pf = dt.Rows(0)("firstpayfrom")
            data.txt1pt = dt.Rows(0)("firstpayto")
            data.txt2pf = dt.Rows(0)("secondpayfrom")
            data.txt2pt = dt.Rows(0)("secondpayto")
            data.txt3pf = dt.Rows(0)("thirdpayfrom")
            data.txt3pt = dt.Rows(0)("thirdpayto")
            data.txt4pf = dt.Rows(0)("forthpayfrom")
            data.txt4pt = dt.Rows(0)("forthpayto")

        End If

        Return data

    End Function


    <WebMethod(EnableSession:=True)> _
    Public Shared Function updatePs(data As Ps) As Ps
        Dim i As Integer = 0
        Dim rt As Integer = 0
        Dim cls As New clsConnection
        Dim exist As Integer = 0
        Dim qry As String = "delete tbl_hrms_PS_Settings where category = '" & data.Val & "' and emplevel = '" & data.Elvl & "'"

        cls.ExecuteScalarQuery(qry)

        qry = "INSERT INTO tbl_hrms_PS_Settings(category,emplevel,ps,payfrom,payto,payday,lastmodifiedby) VALUES"

        For i = 0 To data.payouts.Count - 1
            qry += "('" & data.Val & "','" & data.Elvl & "','" & data.selPayoutscheme & "','" & data.payouts(i).dtfrom & "','" & data.payouts(i).dtto & "','" & data.payouts(i).dtpay & "','" & data.usr & "' + cast(GETDATE() as varchar)),"
        Next

        qry = Mid(qry, 1, Len(qry) - 1)

        data.fetchCount = cls.ExecuteQuery(qry)

        Return data
    End Function


    <WebMethod(EnableSession:=True)> _
    Public Shared Function fetchPs(data As Ps) As Ps

        'Dim rt As New m13

        Dim cls As New clsConnection
        Dim dt As New DataTable
        Dim payouts As New List(Of payout)


        Dim qry As String = "Select * from tbl_hrms_PS_Settings where category = '" & data.Val & "' and emplevel = '" & data.Elvl & "'"

        dt = cls.GetData(qry)

        data.fetchCount = dt.Rows.Count

        For i = 0 To dt.Rows.Count - 1
            Dim payout As New payout

            data.selPayoutscheme = dt.Rows(i)("ps")
            payout.dtfrom = dt.Rows(i)("payfrom")
            payout.dtto = dt.Rows(i)("payto")
            payout.dtpay = dt.Rows(i)("payday")

            payouts.Add(payout)

        Next


        data.payouts = payouts

        Return data

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function saveCp(data As cD) As cD

        'Dim rt As New m13

        Dim cls As New clsConnection
        Dim sql As String = ""

        Dim insert_tbl_HRMS_CompanyDetails As String = "insert into tbl_HRMS_CompanyDetails(companydetails,companyname,othertradingname,address,telephone,fax,generalemail,webpage,companyregistration,dateofregistration) values"
        insert_tbl_HRMS_CompanyDetails += "('" & data.txtcDetails & "','" & data.txtcName & "','" & data.txtOTN & "','" & data.txtAddress & "','" & data.txttel & "','" & data.txtfax & "','" & data.txtemail & "','" & data.txtwebpage & "','" & data.txtcRegNo & "','" & data.txtDateofReg & "');"

        Dim insert_tbl_HRMS_EmployerDetails As String = "insert into tbl_HRMS_EmployerDetails(Name,IDNum,EmailAdd,TIN,SSS,PhilHealth,Type) values"
        insert_tbl_HRMS_EmployerDetails += "('" & data.txtemployerName & "','" & data.txtemployerid & "','" & data.txtemployeremail & "','" & data.txtTIN & "','" & data.txtSSS & "','','" & data.eType & "')"

        Dim checkifHasRecord As String = "Select * from tbl_HRMS_CompanyDetails;Select * from tbl_HRMS_EmployerDetails"

        Dim da As New DataSet

        da = cls.GetDataSet(checkifHasRecord)

        Dim dt As DataTable = da.Tables(0)

        If dt.Rows.Count = 0 Then
            sql += insert_tbl_HRMS_CompanyDetails
        Else
            sql += "UPDATE tbl_HRMS_CompanyDetails set " & _
            "CompanyDetails = '" & data.txtcDetails & "'," & _
            "CompanyName = '" & data.txtcName & "'," & _
            "OtherTradingName = '" & data.txtOTN & "'," & _
            "Address = '" & data.txtAddress & "'," & _
            "Telephone = '" & data.txttel & "'," & _
            "Fax = '" & data.txtfax & "'," & _
            "GeneralEmail = '" & data.txtemail & "'," & _
            "WebPage = '" & data.txtwebpage & "'," & _
            "CompanyRegistration = '" & data.txtcRegNo & "'," & _
            "DateOfRegistration = '" & data.txtDateofReg & "'"
        End If

        dt = da.Tables(1)

        If dt.Rows.Count = 0 Then
            sql += insert_tbl_HRMS_EmployerDetails
        Else

            sql += "UPDATE tbl_HRMS_EmployerDetails set " & _
            "Name = '" & data.txtemployerName & "'," & _
            "IDNum = '" & data.txtemployerid & "'," & _
            "EmailAdd = '" & data.txtemployeremail & "'," & _
            "TIN = '" & data.txtTIN & "'," & _
            "SSS = '" & data.txtSSS & "'," & _
            "PhilHealth = ''," & _
            "Type = '" & data.eType & "'"

        End If

        data.fetchCount = cls.ExecuteScalarQuery(sql)

        Return data

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function getCp() As cD

        'Dim rt As New m13
        Dim data As New cD

        Dim cls As New clsConnection
        Dim sql As String = "Select * from tbl_HRMS_CompanyDetails; Select * from tbl_HRMS_EmployerDetails; select * from dbo.tbl_HRMS_EmployeeMaster where AccessLevel is not null"

        Dim da As DataSet = cls.GetDataSet(sql)

        Dim dt As DataTable = da.Tables(0)

        data.fetchCount = dt.Rows.Count

        data.txtcDetails = dt.Rows(0)("CompanyDetails")
        data.txtcName = dt.Rows(0)("CompanyName")
        data.txtOTN = dt.Rows(0)("OtherTradingName")
        data.txtAddress = dt.Rows(0)("Address")
        data.txttel = dt.Rows(0)("Telephone")
        data.txtfax = dt.Rows(0)("Fax")
        data.txtemail = dt.Rows(0)("GeneralEmail")
        data.txtwebpage = dt.Rows(0)("WebPage")
        data.txtcRegNo = dt.Rows(0)("CompanyRegistration")


        data.txtDateofReg = dt.Rows(0)("DateOfRegistration")

        data.txtNumberOfEMployees = da.Tables(2).Rows.Count

        'data.txtregaddIf = dt.Rows(0)("")

        dt = da.Tables(1)

        data.txtemployerName = dt.Rows(0)("Name")

        data.txtemployerid = dt.Rows(0)("IDNum")

        data.txtemployeremail = dt.Rows(0)("EmailAdd")
        data.txtTIN = dt.Rows(0)("TIN")

        data.txtSSS = dt.Rows(0)("SSS")

        If dt.Rows(0)("Type") = "SELF" Then
            data.chkSE = "1"
            data.chkHO = "0"
            data.chkGov = "0"
            data.chkPriv = "0"
            data.eType = "SELF"
        ElseIf dt.Rows(0)("Type") = "HOUS" Then
            data.chkSE = "0"
            data.chkHO = "1"
            data.chkGov = "0"
            data.chkPriv = "0"
            data.eType = "HOUS"
        ElseIf dt.Rows(0)("Type") = "GOVT" Then
            data.chkSE = "0"
            data.chkHO = "0"
            data.chkGov = "1"
            data.chkPriv = "0"
            data.eType = "GOVT"
        Else
            data.chkSE = "0"
            data.chkHO = "0"
            data.chkGov = "0"
            data.chkPriv = "1"
            data.eType = "PRIV"
        End If

        Return data

    End Function



    <WebMethod> _
    Public Shared Function getNews() As String
        Dim d As New List(Of tblNews)
        Dim cls As New clsConnection

        Dim qry = "select * from dbo.tbl_HRMS_News where removeBy is null"

        Dim dt = cls.GetData(qry)

        For i = 0 To dt.Rows.Count - 1
            Dim n As New tblNews

            n.id = dt.Rows(i)("id")
            n.subject = dt.Rows(i)("newsSubject")
            n.Imagepath = dt.Rows(i)("imgNews")
            n.addedBy = dt.Rows(i)("addedBy")
            n.addedDate = dt.Rows(i)("addedDate")

            d.Add(n)
        Next

        Return JsonConvert.SerializeObject(New With { _
            Key .status = True, _
            Key .message = "Success", _
            Key .data = d
        })

        'Return ""

    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function deleteNews(id As String) As String

        Try
            Dim usr As String = HttpContext.Current.Session("userID")

            Dim cls As New clsConnection

            Dim qry = "update dbo.tbl_HRMS_News set removeBy = '" & usr & "' , removeDate = GETDATE() Where id = " & id

            Dim dt = cls.ExecuteQuery(qry)

            Return JsonConvert.SerializeObject(New With { _
                Key .status = True, _
                Key .message = "Success"
            })

        Catch ex As Exception
            Return JsonConvert.SerializeObject(New With { _
                Key .status = False, _
                Key .message = "Something Went Wrong: " & ex.Message
            })
        End Try
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Shared Function AddNews(subj As String, path As String) As String

        path = path.Replace("""", "")
        path = path.Replace("\", "/")

        subj = subj.Replace("""", "")

        path = Mid(path, InStr(path, "news"), Len(path))

        Try
            Dim usr As String = HttpContext.Current.Session("userID")

            Dim cls As New clsConnection

            Dim qry = "insert into dbo.tbl_HRMS_News (imgNews, newsSubject, addedBy, addedDate) VALUES "
            qry &= " ('" & path & "','" & subj & "','" & usr & "',GETDATE()) "

            Dim dt = cls.ExecuteQuery(qry)

            Return JsonConvert.SerializeObject(New With { _
                Key .status = True, _
                Key .message = "Success"
            })

        Catch ex As Exception
            Return JsonConvert.SerializeObject(New With { _
                Key .status = False, _
                Key .message = "Something Went Wrong: " & ex.Message
            })
        End Try
    End Function


End Class