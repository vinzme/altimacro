﻿Imports System.Data

Public Class Surveys
	Inherits System.Web.UI.Page

	Dim dtEmp As New DataTable
	Dim cls As New clsConnection
	Dim pubUser As String
	Dim employeeID As String
	Dim employeeName As String
	Dim employeeSupervisor As String
	Dim employeeDepartment As String
	Dim employeeLocation As String
	Dim employeeDoj As String
	Dim employeeApprover As String

	Dim pubUserMode As String
	Dim ExpiredMinutes As Integer

	Dim pubUserStatus As String
	Dim pubUserStatusTag As String
	Dim pubServerDateTime As String
	Dim pubActivityID As Integer
	Dim pubIdleTimeInserted As Boolean = False
	Dim pubIdleMinutes As Integer = 0
	Dim pubClickOKIdle As Boolean = False
	Dim pubAspectNRStatus As String

	Dim dtChkHoliday As DataTable
	Dim dtChkLeave As DataTable
	Dim dtChkLeaveExisting As DataTable
	Dim dtHoliday_spcW As New DataTable
	Dim dtHoliday_reg As New DataTable
	Dim dtHolidays As New DataTable
	Dim dtLastActivity As New DataTable
	Dim dtNews As New DataTable

	Dim fullName As String = ""

	Dim dtLogin As DateTime
	Dim gSelectedDate As String

	Dim totaltime As Integer = 0

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/Surveys.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try


		GetEmpInfo()

		If Not Page.IsPostBack Then
			CreateNewsPanel()
			GetLastActivity()

			'If dtLastActivity.Rows(0)("reasonid") = 14 Or
			'    dtLastActivity.Rows(0)("reasonid") = 16 Then

			'    Response.Redirect("Home.aspx")
			'Else

			If dtEmp.Rows.Count > 0 Then

				employeeID = dtEmp.Rows(0)("EmpID")
				employeeName = dtEmp.Rows(0)("EmpName")
				employeeSupervisor = dtEmp.Rows(0)("MngrName")
				employeeDepartment = dtEmp.Rows(0)("DeptName")
				'employeeLocation = dtEmp.Rows(0)("Location")
				employeeDoj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
				employeeApprover = dtEmp.Rows(0)("MngrName")

				empID.Text = employeeID
				empName.Text = employeeName
				supervisor.Text = employeeSupervisor
				dept.Text = employeeDepartment
				doj.Text = employeeDoj
			End If
		End If
		'End If
	End Sub

	Private Sub GetLastActivity()
		Dim query As String

		query = "select top 1 reason, seriesid, loginid, start_time, end_time, cast(cast(DATEDIFF(minute,Start_Time,End_Time) as decimal) as nvarchar(18)) as totaltimemin, totaltimehour, reasonid from dbo.tbl_HRMS_Employee_Activity where loginid = '" & pubUser.Trim & "' order by seriesid desc"

		dtLastActivity = cls.GetData(query)
	End Sub

	Private Sub GetEmpInfo()

		Dim qry As String = ""

		qry = "select * from tbl_HRMS_EmployeeMaster where NTID = '" & pubUser.Trim & "'"

		dtEmp = cls.GetData(qry)

	End Sub

	Private Sub ProcessNews()
		Dim sql As String = ""
		sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"
		dtNews = cls.GetData(sql)
	End Sub
	Private Sub CreateNewsPanel()
		Dim str As String = ""

		ProcessNews()
		If dtNews.Rows.Count > 0 Then
			For x As Integer = 0 To dtNews.Rows.Count - 1
				str &= "<li class='news-item'>"
				str &= "<table cellpadding='4'>"
				str &= "<tr>"
				str &= "<td>"
				str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
				str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a onclick = ""window.open('" & dtNews.Rows(x)("imgNews") & "', '_Parent', 'toolbar=0,scrollbars=0,resizable=0,top=0,left=20%,width=800,height=700');"" href='#'>Read more...</a></td>"
				str &= "<tr>"
				str &= "</table>"
				str &= "</li>"
			Next

			lt1.Text = str

		End If

	End Sub

End Class