﻿#Region "Imports"

Imports System.Data.SqlClient
Imports System.Data.DataSet
Imports System.Security.Principal
Imports System.Web.UI.Page
Imports System.IO
Imports System.Data
Imports System.Net
Imports System
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Threading

#End Region

Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Dim pubUserMode As String
    Dim ExpiredMinutes As Integer

    Dim dtLogsPending As New DataTable
    Dim dtLeavesPending As New DataTable
    Dim dtFunction As New DataTable

    Dim dtEmp As New DataTable
    Dim dtEEToDoLogs1 As New DataTable
    Dim dtEEToDoLogs2 As New DataTable
    Dim dtEEToDoLogs3 As New DataTable
    Dim dtEEToDoLogs4 As New DataTable
    Dim cls As New clsConnection
    Dim pubUser As String
    Dim empId As String
    Dim empName As String
    Dim supervisor As String
    Dim department As String
    Dim emplvl As String
    Dim doj As String
    Dim accessLvl As String
    Dim category As String

    Dim msgIDset As String
    Dim msgID As String

    'Dim cls As New clsConnection
    'Dim pubUser As String
    Dim pubUserStatus As String
    Dim pubUserStatusTag As String
    Dim pubServerDateTime As String
    Dim pubActivityID As Integer
    Dim pubIdleTimeInserted As Boolean = False
    Dim pubIdleMinutes As Integer = 0
    Dim pubClickOKIdle As Boolean = False
    Dim pubAspectNRStatus As String

    Dim pubSeriesID As String
    Dim pubLoginTime As String

    Dim pubSchedDate As String
    Dim pubSchedDate2 As String
    Dim pubServerDate As String
    Dim pubServerDate2 As String
    Dim pubServerPrevDate As String
    Dim pubSchedLastAct As String
    Dim pubSchedType As String
    Dim pubServerDateTime2 As String
    Dim pubServerPrevDate2 As String

    Dim prevOUT As String
    Dim currIN As String
    Dim todayStartTime As String
    Dim todayEndTime As String
    Dim todayEndTimePlusFour As String
    Dim pubReasonID As String
    Dim pubSeriesID2 As String
    Dim pubLoginTime2 As String
    Dim pubReasonID2 As String
    Dim pubSchedLastAct2 As String

    Dim dtRange1_2 As New DataTable
    Dim dtRange2_2 As New DataTable
    Dim dtRange3_2 As New DataTable
    Dim dtCurrIn2 As New DataTable
    Dim dtCheckSched2 As New DataTable
    Dim dtTodaySched2 As New DataTable
    Dim dtUserStatus As New DataTable
    Dim dtLateWorking As New DataTable

    Dim dtCountLogs As New DataTable
    Dim dtCountLeaves As New DataTable
    Dim dtCountCutOffLeaves As New DataTable

    Dim dtMessage As New DataTable

    Dim currIN2 As String
    Dim todayStartTime2 As String
    Dim todayEndTime2 As String

    'Dim dtEmp As New DataTable

    Dim dtChkHoliday As DataTable
    Dim dtChkLeave As DataTable
    Dim dtChkLeaveExisting As DataTable
    Dim dtHoliday_spcW As New DataTable
    Dim dtHoliday_reg As New DataTable
    Dim dtHolidays As New DataTable
    Dim dtLastAcitivty As New DataTable

    Dim dtRange1 As New DataSet
    Dim dtRange2 As New DataTable
    Dim dtRange3 As New DataTable
    Dim dtPrevOut As New DataTable
    Dim dtCurrIn As New DataTable
    Dim dtCheckSched As New DataTable

    Dim dtChkLogins As New DataTable
    Dim dtSched As New DataTable
    Dim dtCheckBeyondTwoHrs As New DataTable
    Dim dtSched2 As New DataTable
    Dim dtSchedType As New DataTable
    Dim dtTodaySched As New DataTable
    Dim dtEarly As New DataTable
    Dim dtSchedOutPlusFour As New DataTable
    Dim dtLastAcitivty2 As New DataTable
    Dim dtCTOVal As New DataTable

    Dim fullName As String = ""
    Dim serverTime As String

    Dim dtLogin As DateTime
    Dim gSelectedDate As String

    Dim totaltime As Integer = 0

    'Declare a new instance of the structure LASTINPUTINFO contained in GetLastInputInfo. 
    Dim lastInputInf As New LASTINPUTINFO()

    'The following code calls the library user32.dll GetLastInputInfo and function. 
    <DllImport("user32.dll")>
    Shared Function GetLastInputInfo(ByRef plii As LASTINPUTINFO) As Boolean
    End Function

    <StructLayout(LayoutKind.Sequential)>
    Structure LASTINPUTINFO
        <MarshalAs(UnmanagedType.U4)>
        Public cbSize As Integer
        <MarshalAs(UnmanagedType.U4)>
        Public dwTime As Integer
    End Structure

    'Connections
    Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim sqlConn As SqlConnection = New SqlConnection(connStr)

    '#Region "Events"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        pubUser = Session("userID")

        userID.Text = pubUser

        GetEmpInfo()
        LastLeave()

        GetLastActivity()

        reasonID.Text = pubReasonID
        rID.InnerText = pubReasonID

        CountLogs()
        CountLeaves()

        Dim logs As Integer = 0
        Dim leaves As Integer = 0
        Dim cutOffLeaves As Integer = 0

        If dtCountLogs.Rows.Count > 0 Then
            logs = Convert.ToInt32(dtCountLogs.Rows(0)("PendingLogs"))
            pendingLogs.InnerText = logs.ToString()
        Else
            logs = 0
            pendingLogs.InnerText = logs.ToString()
        End If

        If dtCountLeaves.Rows.Count > 0 Then
            leaves = Convert.ToInt32(dtCountLeaves.Rows(0)("PendingLeave"))
        Else
            leaves = 0
        End If

        directReportsNotifs.Text = logs + leaves

        If DateTime.Now.Day = 22 Then
            CountCutOffLeaves("16", "22")
        ElseIf DateTime.Now.Day = 7 Then
            CountCutOffLeaves("01", "07")
        End If

        If dtCountCutOffLeaves.Rows.Count > 0 Then
            cutOffLeaves = Convert.ToInt32(dtCountCutOffLeaves.Rows(0)("PendingLeave"))
            pendingLeaves.InnerText = cutOffLeaves.ToString()
        Else
            cutOffLeaves = 0
            pendingLeaves.InnerText = cutOffLeaves.ToString()
        End If



        If dtEmp.Rows.Count > 0 Then
            empId = dtEmp.Rows(0)("EmpID")
            empName = dtEmp.Rows(0)("EmpName")
            If Not IsDBNull(dtEmp.Rows(0)("MngrName")) Then
                supervisor = dtEmp.Rows(0)("MngrName")
            Else
                supervisor = ""
            End If
            department = dtEmp.Rows(0)("DeptName")
            emplvl = dtEmp.Rows(0)("EmpLevel")
            doj = CDate(dtEmp.Rows(0)("DateJoined")).ToString("MMMM dd, yyyy")
            accessLvl = dtEmp.Rows(0)("AccessLevel")
            lblLvl.InnerText = accessLvl
            lblBU.InnerText = dtEmp.Rows(0)("BusinessUnit")
            If Not IsDBNull(dtEmp.Rows(0)("EmpPayHRSCat")) Then
                category = dtEmp.Rows(0)("EmpPayHRSCat")
            End If
        End If

        If Not Page.IsPostBack Then

            userName.Text = empName

            lblDay.Text = System.TimeZoneInfo.ConvertTime(Now(), TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time")).DayOfWeek.ToString
            lblToday.Text = System.TimeZoneInfo.ConvertTime(Now(), TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time")).Date.ToString("MMMM dd, yyyy")
            If Session("auth") = "1" Then
                LoginAuth()
            End If
        End If

        If dtEmp.Rows.Count > 0 Then
            GetMenu()
        End If

    End Sub

    Private Sub CountLogs()
        Dim query As String

        query = "select Count(a.Activity_Status) as PendingLogs from tbl_HRMS_Employee_Activity (nolock) a  inner join tbl_HRMS_EmployeeMaster b on a.LoginID = b.NTID inner join tbl_HRMS_PAY_Reason c on a.ReasonID = c.ReasonID where b.MngrNTID = '" & pubUser.Trim & "' and a.Activity_Status = 'Pending' and a.ReasonID not in (1,14)"

        dtCountLogs = cls.GetData(query)
    End Sub

    Private Sub CountLeaves()
        Dim query As String

        query = "select Count(a.LeaveStatus) as PendingLeave from tbl_HRMS_LeaveMaster a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.EmpID = b.NTID where b.NTID in ( select NTID from tbl_HRMS_EmployeeMaster where MngrNTID = '" & pubUser.Trim & "') and a.LeaveStatus = 'Pending'"

        dtCountLeaves = cls.GetData(query)
    End Sub

    Private Sub CountCutOffLeaves(firstDate As String, secondDate As String)
        Dim query As String

        query = "select a.LeaveDate from tbl_HRMS_LeaveMaster a (nolock) inner join tbl_HRMS_EmployeeMaster b (nolock) on a.EmpID = b.NTID where b.NTID in ( select NTID from tbl_HRMS_EmployeeMaster where MngrNTID = '" & pubUser.Trim & "') and a.LeaveStatus = 'Pending' and LeaveDate between CAST(CAST(MONTH(GETDATE()) as varchar(1)) + '/" & firstDate & "/2016' as date) and CAST(CAST(MONTH(GETDATE()) as varchar(1)) + '/" & secondDate & "/2016' as date)"

        dtCountCutOffLeaves = cls.GetData(query)
    End Sub

    Private Sub GetEmpInfo()

        Dim qry As String = ""

        qry = "select * from tbl_HRMS_EmployeeMaster (nolock) where NTID = '" & pubUser.Trim & "' and AccessLevel is not null"

        dtEmp = cls.GetData(qry)

    End Sub

    Public Sub LastLeave()
        Dim query As String = ""

        query += "select EmpID, MAX(LeaveDate) as LastLeave from tbl_HRMS_LeaveMaster (nolock) where EmpID = '" & pubUser & "' group by EmpID"

        dtChkLeave = cls.GetData(query)
    End Sub

    Private Sub GetLastActivity()
        Dim query As String

        query = "select top 1 SeriesID, LoginID, Start_Time, End_Time, SchedDate, Reasonid from tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & pubUser.Trim & "' order by Start_Time desc, scheddate, seriesid desc"

        dtLastAcitivty = cls.GetData(query)

        If dtLastAcitivty.Rows.Count > 0 Then
            pubSeriesID = dtLastAcitivty.Rows(0)("SeriesID")
            pubLoginTime = dtLastAcitivty.Rows(0)("Start_Time")
            pubReasonID = dtLastAcitivty.Rows(0)("Reasonid")
            pubSchedLastAct = dtLastAcitivty.Rows(0)("SchedDate")
        End If

    End Sub

    Private Sub CheckHoliday()

        Dim qry As String = ""

        qry = "Select * from tbl_HRMS_HolidayMaster (nolock) where HolDate = CAST(GETDATE() as date) and DeletedBy is null"

        dtChkHoliday = cls.GetData(qry)

    End Sub

    Private Sub CheckLogins()
        Dim query As String

        query = "select * from dbo.tbl_HRMS_Employee_Activity (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "' and ReasonID = 1"

        dtChkLogins = cls.GetData(query)
    End Sub

    Private Sub CheckMasterControl()
        Dim query As String

        query = "select * from tbl_HRMS_MasterControl where Settings = 'CA' and EmpLevel = '" & emplvl & "' and Category = '" & category & "'"

        dtCTOVal = cls.GetData(query)
    End Sub

    Private Sub AddCTO()
        CheckMasterControl()

        Dim ctoVal As String = ""

        If dtCTOVal.Rows.Count > 0 Then
            If Not IsDBNull(dtCTOVal.Rows(0)("SetValue1")) Then
                ctoVal = dtCTOVal.Rows(0)("SetValue1")
            End If
        Else
            ctoVal = "0"
        End If

        Try
            Dim cmdUpdateCTO As New SqlCommand

            cmdUpdateCTO.CommandText = "update tbl_HRMS_EmployeeMaster set LeaveBalCTO = LeaveBalCTO + " & ctoVal.Trim & " where NTID = '" & pubUser.Trim & "'"

            cmdUpdateCTO.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateCTO.ExecuteNonQuery()
            sqlConn.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        LoginAuth()
    End Sub

    Private Sub LoginAuth()
        GetEmpInfo()

        If dtEmp.Rows(0)("AccessLevel") <> "1" Then
            GetServerDateTime()
            GetMySchedule()
            GetLastActivity()
            CheckIfEarly()

            If dtEarly.Rows.Count > 0 Then
                If dtEarly.Rows(0)("Login") = 1 Then
                    WorkingEarly()
                End If
            End If

            Login()
            Working()

            If dtEmp.Rows(0)("EmpType") <> "Contractual" Then
                CheckHoliday()
                If dtChkHoliday.Rows.Count > 0 Then
                    If pubSchedDate = dtChkHoliday.Rows(0)("Holdate") Then
                        CheckLogins()
                        If dtChkLogins.Rows.Count = 1 Then
                            If emplvl.Trim <> "EE" Then
                                AddCTO()
                            End If
                        End If
                    End If
                End If
            End If

            If directReportsNotifs.Text <> 0 Then
                Session("tag1") = 1
            End If

            Dim datenow As Date
            Dim date15 As Date
            Dim eom As Date

            datenow = Format(DateValue(Now).Date, "MM/dd/yyyy")

            date15 = New DateTime(datenow.Year, datenow.Month, 15)
            eom = New DateTime(datenow.Year, datenow.Month, 1)

            eom = eom.AddMonths(1).AddDays(-1)

            If DateTime.Now.ToShortDateString() = DateAdd(DateInterval.Day, -2, Convert.ToDateTime(date15)).ToShortDateString() Or
               DateTime.Now.ToShortDateString() = DateAdd(DateInterval.Day, -2, Convert.ToDateTime(eom)).ToShortDateString() Then
                Session("tag2") = 1
            End If
            Session("auth") = 0
            Response.Redirect("Index.aspx")
        Else
            Session("Error") = 1
            Response.Redirect("ErrorPage.aspx")
        End If
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click

        'If directReportsNotifs.Text <> "0" Then
        '	Dim str As String = rID.InnerText
        '	ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "clickModal5();", True)
        '	'Page.ClientScript.RegisterClientScriptBlock(GetType(Page), "alert", "javascript:alert('Please validate all logs in Direct Reports!')")
        'Else
        GetServerDateTime()
        'GetMySchedule()
        'CheckIfLate()
        GetLastActivity()
        GetTodaySched()
        'If dtLateWorking.Rows(0)("Logout") = "1" Then
        '    UpdateLateStatus()
        'End If

        If pubReasonID = "2" Then

            If pubUser = "ladiaoer" Or
                pubUser = "encaboma" Or
                pubUser = "osunarex" Or
                pubUser = "lumarkje" Or
                pubUser = "manlangj" Or
                pubUser = "liriolan" Then

                UpdateWorkingEndTime()
            Else
                If pubServerDateTime.Trim > todayEndTime.Trim Then
                    UpdateWorkingEndTimeLate()
                Else
                    UpdateWorkingEndTime()
                End If
            End If

            UpdateWorkingMinHour()

            Logout()
        End If
        Session("tag1") = 0
        Session("tag2") = 0
        'Local/Server
        Response.Redirect("Home.aspx")
        'Azure
        'Response.Redirect("LoginTL.aspx")
        'End If
    End Sub

    Private Sub CheckIfLate()
        Dim query As String

        query = "select case when GETDATE() >= SchedOUT then 1 else 0 end as Logout from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "'"

        dtLateWorking = cls.GetData(query)
    End Sub

    Private Sub UpdateLateStatus()
        Dim cmdUpdateLateStatus As New SqlCommand

        cmdUpdateLateStatus.CommandText = "update tbl_HRMS_and_user_status set LateLogout = 1, scheddate = '" & pubSchedDate.Trim & "' where NTID = '" & pubUser.Trim & "'"

        Try
            sqlConn.Open()
            cmdUpdateLateStatus.Connection = sqlConn
            cmdUpdateLateStatus.ExecuteNonQuery()
            cmdUpdateLateStatus.Dispose()
        Catch ex As Exception

        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub LoginFromHome()
        Dim loginTime As String

        loginTime = DateTime.Now.ToString.Trim

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID, Activity_Status) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & LblSchedDateShort.Text.Trim & "', 1, 'Logged In From Home')"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub Login()
        Dim loginTime As String

        loginTime = DateTime.Now.ToString.Trim

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & LblSchedDateShort.Text.Trim & "', 1);" & _
                                    "insert into tbl_Test(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & LblSchedDateShort.Text.Trim & "', 1);"
        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub Working()
        GetServerDateTime()
        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', GETDATE(), '" & pubSchedDate.Trim & "', 2);" & _
                                    "insert into tbl_Test(LoginID, Start_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', GETDATE(), '" & pubSchedDate.Trim & "', 2);"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub CheckUserStatus()
        Dim query As String

        query = "select * from tbl_HRMS_and_user_status (nolock) where NTID = '" & pubUser.Trim & "'"

        dtUserStatus = cls.GetData(query)
    End Sub

    Private Sub WorkingEarly()

        CheckUserStatus()
        Dim cmdUpdateEarlyTime As New SqlCommand
        If dtUserStatus.Rows.Count > 0 Then
            cmdUpdateEarlyTime.CommandText = "update tbl_HRMS_and_user_status set status_tag = 1, SchedDate = '" & pubSchedDate.Trim & "', EarlyLogin = 1 where NTID = '" & pubUser.Trim & "'"
        Else
            cmdUpdateEarlyTime.CommandText = "insert into tbl_HRMS_and_user_status(NTID, status_tag, SchedDate, EarlyLogin) " & _
                                             "values('" & pubUser.Trim & "', 1, '" & pubSchedDate.Trim & "', 1);"
        End If

        Try
            cmdUpdateEarlyTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateEarlyTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try

    End Sub

    Private Sub UpdateWorkingEndTime()
        GetServerDateTime()
        GetLastActivity()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set End_Time = '" & pubServerDateTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "';" & _
                                    "update tbl_Test set End_Time = '" & pubServerDateTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub CheckSchedType()
        Dim query As String

        query = "select SchedType from tbl_HRMS_Employee_Schedule (nolock) where Scheddate = '" & pubSchedLastAct.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtSchedType = cls.GetData(query)

        pubSchedType = dtSchedType.Rows(0)("SchedType")

    End Sub

    Private Sub UpdateWorkingMinHour()
        GetLastActivity()
        CheckSchedType()

        Dim cmdUpdateTime As New SqlCommand

        If pubSchedType = "IN" Then
            cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = CAST(DATEDIFF(MI, Start_Time, End_Time) as decimal), TotalTimeHour = cast(DATEDIFF(MINUTE,Start_Time,End_Time) as decimal)/60 where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "';" & _
                                        "update tbl_Test set TotalTimeMin = CAST(DATEDIFF(MI, Start_Time, End_Time) as decimal), TotalTimeHour = cast(DATEDIFF(MINUTE,Start_Time,End_Time) as decimal)/60 where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"
        Else
            cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = 0, TotalTimeHour = 0, Activity_Status = 'Pending' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "';" & _
                                        "update tbl_Test set TotalTimeMin = 0, TotalTimeHour = 0, Activity_Status = 'Pending' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"
        End If

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub LogoutFromHome()
        GetServerDateTime()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID, Activity_Status) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubSchedLastAct.Trim & "', 14, 'Logged Out From Home')"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub Logout()
        GetServerDateTime()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubSchedLastAct.Trim & "', 14);" & _
                                    "insert tbl_Test(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubServerDateTime.Trim & "', '" & pubSchedLastAct.Trim & "', 14)"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub UpdateWorkingEndTimeLate()
        GetServerDateTime()
        GetLastActivity()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set End_Time = '" & todayEndTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "';" & _
                                    "update tbl_Test set End_Time = '" & todayEndTime.Trim & "', IsPaid = 'YES' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID.Trim & "'"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub LogoutLate()
        GetServerDateTime()
        GetMySchedule()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & todayEndTime.Trim & "', '" & todayEndTime.Trim & "', '" & pubSchedDate.Trim & "', 14)"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetServerDateTime()

        Dim ConnStr As String
        Dim sSql As String

        Dim mserverdatetime As DateTime
        Dim mprevdatetime As DateTime

        ConnStr = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
        Dim MySqlConn As New SqlConnection(ConnStr)
        MySqlConn.Open()
        'Try

        sSql = "Select getdate() as logdate, DATEADD(DAY,-1,GETDATE()) as prevday"

        Dim MySqlCmd As New SqlCommand(sSql, MySqlConn)
        Dim mReader As SqlDataReader

        mReader = MySqlCmd.ExecuteReader()
        If mReader.HasRows Then

            While mReader.Read()

                mserverdatetime = mReader("logdate")

                mprevdatetime = mReader("prevday")

                pubServerDateTime = mReader("logdate")
                pubServerDateTime2 = mReader("logdate")
                pubServerDate = Format(mserverdatetime, "yyyy-MM-dd")
                pubServerDate2 = Format(mserverdatetime, "yyyy-MM-dd")
                pubServerPrevDate = Format(mprevdatetime, "yyyy-MM-dd")
                pubServerPrevDate2 = Format(mprevdatetime, "yyyy-MM-dd")
            End While

        End If

        'Catch ex As Exception

        'Finally
        MySqlConn.Close()
        'End Try

    End Sub

    Private Sub GetMySchedule()
        Try

            GetRange1()

            If dtRange1.Tables(0).Rows.Count = 0 Then
                InsertSchedule()
                GetRange1()
                'ElseIf dtRange1.Tables(1).Rows.Count = 0 Then
                '	InsertSchedule()
                '	GetRange1()
            End If

            If dtRange1.Tables.Count > 1 Then
                If dtRange1.Tables(0).Rows(0)("Range1") = 1 Then
                    UpdateSchedule()
                    GetCurrIN()

                    GetRange3()

                    If dtRange3.Rows(0)("Range3") = 1 Then
                        LblSchedDateShort.Text = dtRange3.Rows(0)("SchedDate")
                        pubSchedDate = dtRange3.Rows(0)("SchedDate")
                    End If
                    'LblSchedDateShort.Text = dtRange1.Tables(0).Rows(0)("SchedDate")
                    'pubSchedDate = dtRange1.Tables(0).Rows(0)("SchedDate")
                ElseIf dtRange1.Tables(1).Rows(0)("Range1") = 1 Then
                    LblSchedDateShort.Text = dtRange1.Tables(0).Rows(0)("SchedDate")
                    pubSchedDate = dtRange1.Tables(0).Rows(0)("SchedDate")
                ElseIf dtRange1.Tables(2).Rows(0)("Range1") = 1 Then
                    LblSchedDateShort.Text = dtRange1.Tables(1).Rows(0)("SchedDate")
                    pubSchedDate = dtRange1.Tables(1).Rows(0)("SchedDate")
                ElseIf dtRange1.Tables(3).Rows.Count > 0 Then

                    If dtRange1.Tables(2).Rows(0)("Range1") = 1 Then
                        LblSchedDateShort.Text = dtRange1.Tables(1).Rows(0)("SchedDate")
                        pubSchedDate = dtRange1.Tables(1).Rows(0)("SchedDate")
                    End If
                ElseIf dtRange1.Tables(3).Rows.Count = 0 Then
                    InsertSchedule()
                    GetCurrIN()

                    GetRange3()

                    If dtRange3.Rows(0)("Range3") = 1 Then
                        LblSchedDateShort.Text = dtRange3.Rows(0)("SchedDate")
                        pubSchedDate = dtRange3.Rows(0)("SchedDate")
                    End If
                Else
                    GetRange2()

                    If dtRange2.Rows(0)("Range2") = 1 Then
                        If dtRange2.Rows(0)("SchedType") = "RD" Then
                            Dim dateSched As Date = dtRange2.Rows(0)("SchedDate")
                            Dim strDate As String = Convert.ToDateTime(DateAdd(DateInterval.Day, +1, dateSched)).ToShortDateString

                            LblSchedDateShort.Text = strDate
                            pubSchedDate = strDate
                        Else
                            LblSchedDateShort.Text = dtRange2.Rows(0)("SchedDate")
                            pubSchedDate = dtRange2.Rows(0)("SchedDate")
                        End If
                    Else
                        'GetPrevOUT()
                        GetCurrIN()

                        'prevOUT = dtPrevOut.Rows(0)("PrevOUT")
                        If Not IsDBNull(dtCurrIn.Rows(0)("CurrIN")) Then
                            currIN = dtCurrIn.Rows(0)("CurrIN")
                        Else
                            CheckSchedule()

                            If dtCheckSched.Rows.Count > 0 Then
                                UpdateSchedule()
                                GetCurrIN()
                            Else
                                InsertSchedule()
                                GetCurrIN()
                            End If
                            currIN = dtCurrIn.Rows(0)("CurrIN")
                        End If

                        GetRange3()

                        If dtRange3.Rows(0)("Range3") = 1 Then
                            LblSchedDateShort.Text = dtRange3.Rows(0)("SchedDate")
                            pubSchedDate = dtRange3.Rows(0)("SchedDate")
                        End If
                    End If
                End If
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub GetRange1()
        Dim query As String

        query = "Select CASE WHEN SchedType = 'RD' then 1 else 0 end as Range1, SchedDate, SchedType from " & _
                        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "';"
        query += "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range1, SchedDate, SchedType from " & _
                        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "';"
        query += "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range1, SchedDate, SchedType from " & _
                        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = DATEADD(D,-1,'" & pubServerDate.Trim & "') and LoginID = '" & pubUser.Trim & "';"
        query += "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range1, SchedDate, SchedType from " & _
                        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = DATEADD(D,1,'" & pubServerDate.Trim & "') and LoginID = '" & pubUser.Trim & "';"

        dtRange1 = cls.GetDataSet(query)
    End Sub

    Private Sub GetRange2()
        Dim query As String

        query = "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range2, SchedDate, SchedType from " & _
        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerPrevDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtRange2 = cls.GetData(query)

    End Sub

    Private Sub GetRange3()
        Dim query As String

        query = "Select CASE WHEN CAST('" & pubServerDateTime.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range3, SchedDate from " & _
                    "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtRange3 = cls.GetData(query)
    End Sub

    Private Sub GetPrevOUT()
        Dim query As String
        Dim query2 As String

        Dim dtPrev As New DataTable

        Do

            If dtPrevOut.Rows.Count > 0 Then
                If IsDBNull(dtPrevOut.Rows(0)("PrevOUT")) Then

                    query2 = "select dateadd(day, -1, CAST('" & pubServerPrevDate.Trim & "' as date)) as prevDay"

                    dtPrev = cls.GetData(query2)

                    pubServerPrevDate = dtPrev.Rows(0)("prevDay")
                End If
            End If

            query = "Select DATEADD(HOUR,4,SchedOUT) as PrevOUT from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerPrevDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

            dtPrevOut = cls.GetData(query)

        Loop Until IsDBNull(dtPrevOut.Rows(0)("PrevOUT")) = False

    End Sub

    Private Sub GetCurrIN()
        Dim query As String

        query = "Select DATEADD(hour,-4,SchedIN) as CurrIN from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtCurrIn = cls.GetData(query)
    End Sub

    Private Sub CheckSchedule()
        Dim query As String

        query = "select * from tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtCheckSched = cls.GetData(query)
    End Sub

    Private Sub UpdateSchedule()
        Dim cmdUpdateSchedule As New SqlCommand

        cmdUpdateSchedule.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = CAST('" & pubServerDateTime.Trim & "' as datetime), SchedOUT = dateadd(HH, 9, CAST('" & pubServerDateTime.Trim & "' as datetime)), EditedBy = 'System Update', DateEdited = CAST('" & pubServerDateTime.Trim & "' as datetime) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubServerDate.Trim & "'"

        Try
            cmdUpdateSchedule.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateSchedule.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub InsertSchedule()
        Dim cmdInsertSchedule As New SqlCommand

        cmdInsertSchedule.CommandText = "insert into tbl_HRMS_Employee_Schedule(LoginID, SchedDate, SchedIN, SchedOUT, Logout_Tag, SchedType, UploadedBy, DateUploaded) " & _
                                        "values('" & pubUser.Trim & "', '" & pubServerDate.Trim & "', CAST('" & pubServerDateTime.Trim & "' as datetime), dateadd(HH, 9, CAST('" & pubServerDateTime.Trim & "' as datetime)), 'NO', 'IN', 'System Upload', '" & pubServerDateTime.Trim & "')"

        Try
            cmdInsertSchedule.Connection = sqlConn
            sqlConn.Open()
            cmdInsertSchedule.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetNextDayDate()

        Dim ConnStr As String
        Dim sSql As String
        Dim i As Integer

        Dim mserverdatetime As DateTime

        ConnStr = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()

        Dim MySqlConn As New SqlConnection(ConnStr)
        MySqlConn.Open()
        Try
            i = 0

            sSql = "Select dateadd(day,1,CAST('" & pubServerDateTime.Trim & "' AS DATETIME)) as nextday"

            Dim MySqlCmd As New SqlCommand(sSql, MySqlConn)
            Dim mReader As SqlDataReader

            mReader = MySqlCmd.ExecuteReader()
            If mReader.HasRows Then
                While mReader.Read()

                    mserverdatetime = mReader("nextday")

                    pubServerDate2 = Format(mserverdatetime, "MMM dd yyyy")

                End While

            End If

        Catch ex As Exception

        Finally
            MySqlConn.Close()
        End Try

    End Sub

    Private Sub GetSchedIfRD()

        Dim ConnStr As String
        Dim sSql As String
        Dim i As Integer

        ConnStr = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()

        Dim MySqlConn As New SqlConnection(ConnStr)
        MySqlConn.Open()
        Try
            i = 0

            sSql = "Select SchedIN from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "' and SchedType = 'RD'"

            Dim MySqlCmd As New SqlCommand(sSql, MySqlConn)
            Dim mReader As SqlDataReader

            mReader = MySqlCmd.ExecuteReader()
            If mReader.HasRows Then

                LblSchedType.Text = "RD"
                UpdateEmployeeSchedule()

            Else

                InsertIntoEmployeeSchedule()

            End If

        Catch ex As Exception

        Finally
            MySqlConn.Close()
        End Try

    End Sub

    Private Sub UpdateEmployeeSchedule()

        Dim ConnStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
        Dim MySqlConn As New SqlConnection(ConnStr)

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update dbo.tbl_HRMS_Employee_Schedule set SchedIN = CAST('" & pubServerDateTime.Trim & _
                                    "' AS DATETIME), SchedOUT = dateadd(hour,9,CAST('" & pubServerDateTime.Trim & _
                                    "' AS DATETIME)) where SchedDate = '" & pubServerDate.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        cmdUpdate.Connection = MySqlConn
        cmdUpdate.Connection.Open()
        cmdUpdate.ExecuteNonQuery()
        MySqlConn.Close()

    End Sub

    Private Sub InsertIntoEmployeeSchedule()

        Dim ConnStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
        Dim MySqlConn As New SqlConnection(ConnStr)

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "insert into dbo.tbl_HRMS_Employee_Schedule(LoginID,SchedDate,SchedIN,SchedOUT,Logout_Tag,SchedType) " & _
                        "Select '" & pubUser.Trim & "' as LoginID, '" & pubServerDate.Trim & "' as SchedDate, CAST('" & pubServerDateTime.Trim & "' AS DATETIME) as SchedIN," & _
                            "dateadd(hour,9,CAST('" & pubServerDateTime.Trim & "' AS DATETIME)) as SchedOut, 'NO'  as Logout_Tag, 'IN' as Sched_Type"

        cmdUpdate.Connection = MySqlConn
        cmdUpdate.Connection.Open()
        cmdUpdate.ExecuteNonQuery()
        MySqlConn.Close()

    End Sub

    Private Sub GetSched()
        Dim query As String

        query = "select SchedOUT from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "'"

        dtSched = cls.GetData(query)
    End Sub

    Private Sub CheckIfBeyondTwoHrs()
        Dim query As String

        query = "select case when getdate() = DATEADD(HH, +4, schedout) then 1 else 0 end as Logout from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedLastAct2.Trim & "'"

        dtCheckBeyondTwoHrs = cls.GetData(query)
    End Sub

    'Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
    '	'Timer1.Enabled = False
    '	'UpdateProgress1.Visible = False

    '	GetMessage()

    '	If IsPostBack Then
    '		If dtMessage.Rows.Count > 0 Then
    '			lblMessage.Text = ""
    '			'For x As Integer = 0 To dtMessage.Rows.Count - 1
    '			If dtMessage.Rows(0)("Status") = 0 Then
    '				lblMessage.Text = dtMessage.Rows(0)("Message")
    '				msgID = dtMessage.Rows(0)("ID")

    '				If DateTime.Now.ToString >= dtMessage.Rows(0)("StartTime") And
    '					DateTime.Now.ToString <= dtMessage.Rows(0)("EndTime") Then
    '					msgDiv.Visible = True
    '				Else

    '					msgDiv.Visible = False
    '					'msgID = msgIDset.ToString().Remove(msgIDset.Length - 1, 1)
    '					UpdateMessageStatus()

    '				End If
    '				UpdatePanel4.Update()
    '			End If
    '			'Next
    '		End If
    '		IsPostBack.Equals(False)
    '	End If
    'End Sub

    Private Sub GetMessage()
        Dim query As String

        query = "select * from tbl_HRMS_Shoutbox (nolock) where Recipient = '" & pubUser.Trim & "' and Status = 0"

        dtMessage = cls.GetData(query)
    End Sub

    Private Sub UpdateMessageStatus()
        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = "update tbl_HRMS_Shoutbox set Status = 1, Timestamp = GETDATE() where Recipient = '" & pubUser.Trim & "' and ID = '" & msgID.Trim & "'"

        Try
            sqlConn.Open()
            cmdUpdate.Connection = sqlConn
            cmdUpdate.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetTodaySched()
        Dim query As String

        query = "select * from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedLastAct.Trim & "'"

        dtTodaySched = cls.GetData(query)

        todayStartTime = dtTodaySched.Rows(0)("SchedIN")
        todayEndTime = dtTodaySched.Rows(0)("SchedOUT")
    End Sub

    Private Sub CheckIfEarly()
        Dim query As String

        query = "select case when DATEDIFF(SS, schedin, GETDATE()) < 0 then 1 else 0 end as Login from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "'"

        dtEarly = cls.GetData(query)
    End Sub

    Private Sub UpdateEarlyWorking()
        Dim cmdUpdateEarlyWorking As New SqlCommand

        cmdUpdateEarlyWorking.CommandText = "update tbl_HRMS_Employee_Acitivty set end_time = '" & todayStartTime2.Trim & "' where seriesid = '" & pubSeriesID2.Trim & "' and loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedLastAct2.Trim & "'"

        Try
            cmdUpdateEarlyWorking.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateEarlyWorking.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try

        Dim cmdUpdateWorking As New SqlCommand

        cmdUpdateWorking.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & todayStartTime2.Trim & "', '" & pubSchedLastAct2.Trim & "', 2)"

        Try
            cmdUpdateWorking.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateWorking.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetMySchedule2()
        Try
            GetRange1_2()

            If dtRange1_2.Rows(0)("Range1") = 1 Then
                'LblSchedDateShort.Text = dtRange1.Rows(0)("SchedDate")
                pubSchedDate2 = dtRange1_2.Rows(0)("SchedDate")
            End If

        Catch ex As Exception

        End Try

    End Sub

    'Private Sub GetSched2()
    '    Dim query As String

    '    query = "select SchedIN, SchedOUT from tbl_HRMS_Employee_Schedule where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "'"

    '    dtSched2 = cls.GetData(query)
    'End Sub

    Private Sub UpdateWorkingEndTime2()
        GetServerDateTime()
        GetLastActivity2()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set End_Time = '" & todayEndTime2.Trim & "' where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID2.Trim & "'"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub UpdateWorkingMinHour2()
        GetLastActivity()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "update tbl_HRMS_Employee_Activity set TotalTimeMin = CAST(DATEDIFF(MI, Start_Time, End_Time) as decimal), TotalTimeHour = cast(DATEDIFF(MINUTE,Start_Time,End_Time) as decimal)/60 where LoginID = '" & pubUser.Trim & "' and SeriesID = '" & pubSeriesID2.Trim & "'"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub ForcedLogout()
        GetServerDateTime()
        GetMySchedule()
        GetSchedoutPlusFour()

        Dim cmdUpdateTime As New SqlCommand

        cmdUpdateTime.CommandText = "insert into tbl_HRMS_Employee_Activity(LoginID, Start_Time, End_Time, SchedDate, ReasonID) values('" & pubUser.Trim & "', '" & todayEndTimePlusFour.Trim & "', '" & todayEndTimePlusFour.Trim & "', '" & pubSchedDate2.Trim & "', 16)"

        Try
            cmdUpdateTime.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateTime.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetSchedoutPlusFour()
        Dim query As String

        query = "select DATEADD(HH,4,schedout) as end_time from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate.Trim & "'"

        dtSchedOutPlusFour = cls.GetData(query)

        todayEndTimePlusFour = dtSchedOutPlusFour.Rows(0)("end_time")
    End Sub

    Private Sub GetRange1_2()
        Dim query As String

        query = "Select CASE WHEN CAST('" & pubServerDateTime2.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range1, SchedDate from " & _
                        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubSchedLastAct.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtRange1_2 = cls.GetData(query)
    End Sub

    Private Sub GetRange2_2()
        Dim query As String

        query = "Select CASE WHEN CAST('" & pubServerDateTime2.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range2, SchedDate from " & _
        "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubSchedLastAct.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtRange2_2 = cls.GetData(query)

    End Sub

    Private Sub GetRange3_2()
        Dim query As String

        query = "Select CASE WHEN CAST('" & pubServerDateTime2.Trim & "' AS DATETIME) BETWEEN DATEADD(hour,-4,SchedIN) AND DATEADD(hour,4,Schedout) then 1 else 0 end as Range3, SchedDate from " & _
                    "dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubSchedLastAct.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtRange3_2 = cls.GetData(query)
    End Sub

    Private Sub GetCurrIN2()
        Dim query As String

        query = "Select DATEADD(hour,-4,SchedIN) as CurrIN from dbo.tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate2.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtCurrIn2 = cls.GetData(query)
    End Sub

    Private Sub CheckSchedule2()
        Dim query As String

        query = "select * from tbl_HRMS_Employee_Schedule (nolock) where SchedDate = '" & pubServerDate2.Trim & "' and LoginID = '" & pubUser.Trim & "'"

        dtCheckSched2 = cls.GetData(query)
    End Sub

    Private Sub UpdateSchedule2()
        Dim cmdUpdateSchedule2 As New SqlCommand

        cmdUpdateSchedule2.CommandText = "update tbl_HRMS_Employee_Schedule set SchedIN = CAST('" & pubServerDateTime2.Trim & "' as datetime), SchedOUT = dateadd(HH, 9, CAST('" & pubServerDateTime2.Trim & "' as datetime)), EditedBy = 'System Update', DateEdited = CAST('" & pubServerDateTime2.Trim & "' as datetime) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubServerDate2.Trim & "'"

        Try
            cmdUpdateSchedule2.Connection = sqlConn
            sqlConn.Open()
            cmdUpdateSchedule2.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub InsertSchedule2()
        Dim cmdInsertSchedule2 As New SqlCommand

        cmdInsertSchedule2.CommandText = "insert into tbl_HRMS_Employee_Schedule(LoginID, SchedDate, SchedIN, SchedOUT, Logout_Tag, SchedType, UploadedBy, DateUploaded) " & _
                                        "values('" & pubUser.Trim & "', '" & pubServerDate2.Trim & "', CAST('" & pubServerDateTime2.Trim & "' as datetime), dateadd(HH, 9, CAST('" & pubServerDateTime2.Trim & "' as datetime)), 'NO', 'IN', 'System Upload', '" & pubServerDateTime2.Trim & "')"

        Try
            cmdInsertSchedule2.Connection = sqlConn
            sqlConn.Open()
            cmdInsertSchedule2.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetTodaySched2()
        GetServerDateTime()
        Dim query As String

        query = "select * from tbl_HRMS_Employee_Schedule (nolock) where loginid = '" & pubUser.Trim & "' and scheddate = '" & pubSchedDate2.Trim & "'"

        dtTodaySched2 = cls.GetData(query)

        todayStartTime2 = dtTodaySched2.Rows(0)("SchedIN")
        todayEndTime2 = dtTodaySched2.Rows(0)("SchedOUT")
    End Sub

    Private Sub GetLastActivity2()
        Dim query As String

        query = "select top 1 SeriesID, LoginID, Start_Time, End_Time, SchedDate, Reasonid from tbl_HRMS_Employee_Activity (nolock) where LoginID = '" & pubUser.Trim & "' order by Start_Time desc, scheddate, seriesid desc"

        dtLastAcitivty2 = cls.GetData(query)

        pubSeriesID2 = dtLastAcitivty2.Rows(0)("SeriesID")
        pubLoginTime2 = dtLastAcitivty2.Rows(0)("Start_Time")
        pubReasonID2 = dtLastAcitivty2.Rows(0)("Reasonid")
        pubSchedLastAct2 = dtLastAcitivty2.Rows(0)("SchedDate")
    End Sub

    Private Sub UpdateNoLogout()
        Dim cmdUpdateNoLogout As New SqlCommand

        cmdUpdateNoLogout.CommandText = "update tbl_HRMS_and_user_status set scheddate = '" & pubSchedLastAct2.Trim & "', NoLogout = 1, status_tag = 16 where ntid = '" & pubUser.Trim & "'"

        Try
            sqlConn.Open()
            cmdUpdateNoLogout.Connection = sqlConn
            cmdUpdateNoLogout.ExecuteNonQuery()
            cmdUpdateNoLogout.Dispose()
        Catch ex As Exception
        Finally
            sqlConn.Close()
        End Try
    End Sub

    Private Sub GetMenu()

        GetFunctions()
        If dtFunction.Rows.Count Then
            For x = 0 To dtFunction.Rows.Count - 1
                Dim myControl1 As Control
                If pubUser = "orculloj" Or
                    pubUser = "devtest" Or
                    pubUser = "lamzonde" Or
                    pubUser = "eyajoel" Then
                    myControl1 = FindControl(dtFunction.Rows(x)("ControlID"))
                Else
                    myControl1 = FindControl(dtFunction.Rows(x)("Functions"))
                End If
                If (Not myControl1 Is Nothing) Then
                    ' Get control's parent.
                    'Dim myControl2 As Control = myControl1.Parent
                    'Response.Write("Parent of the text box is : " & myControl2.ID)
                    myControl1.Visible = True
                    'Else
                    '    Response.Write("Control not found.....")
                End If
            Next
        End If

    End Sub

    Private Sub GetFunctions()

        Dim qry As String = ""

        If pubUser = "orculloj" Or
            pubUser = "devtest" Or
            pubUser = "lamzonde" Or
            pubUser = "eyajoel" Then
            qry = "select * from dbo.tbl_HRMS_Functions"
        Else
            qry = "select a.* from tbl_HRMS_Control a join tbl_HRMS_AccesType b on a.AccessType = b.Access where b.ID = '" & accessLvl.Trim & "'"
        End If

        dtFunction = cls.GetData(qry)

    End Sub

End Class