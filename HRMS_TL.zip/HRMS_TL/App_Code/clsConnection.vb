﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
Imports System

Public Class clsConnection
	'Dim ConString As String = "Server=DAV8DBHSND01;Initial Catalog=MIS_MLA_UAT;Persist Security Info=True;User ID=mis414;Password=juchUt4a"
	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()

    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    'Dim clsmail As New clsEmail

    Private _command As New SqlCommand

    Public FUNC As New clsFunctions

    Public Function GetData(ByVal Query As String) As DataTable

        Dim dt As New DataTable
        Try
			con = New SqlConnection(connStr)
			con.Open()
			da = New SqlDataAdapter(Query, con)
			da.Fill(dt)
			con.Close()
			Return dt
		Catch ex As Exception
			Return dt
        End Try

	End Function

	Public Function GetDataSet(ByVal strQuery As String) As DataSet
		con = New SqlConnection(connStr)
		Try

			Dim mycmd As New SqlCommand(strQuery, con)

			mycmd.CommandTimeout = 3000

			mycmd.CommandType = CommandType.Text


			Dim myDataAdapter As New SqlDataAdapter(mycmd)

			Dim myDataSet As New DataSet

			Call myDataAdapter.Fill(myDataSet)

			Call myDataAdapter.Dispose()

			Return myDataSet
		Catch ex As SqlException
			Call MsgBox(ex.Message & vbCr & "Contact administrator.", MsgBoxStyle.Critical, "Error!")
			Return Nothing
		Finally
			Call con.Close()
		End Try
	End Function


	Public Function ExecuteQuery(ByVal query As String) As Integer

		Dim i As Integer

		Try
			con = New SqlConnection(connStr)
			con.Open()
			_command.Connection = con
			_command.CommandType = CommandType.Text
			_command.CommandText = query
			'_command.CommandTimeout = 180

			i = _command.ExecuteNonQuery()
			_command.Dispose()
		Catch ex As Exception
			i = 0
			'clsmail.CreateSendEmail("An error occurred while exceing the query..." & vbCrLf & vbCrLf & query & vbCrLf & vbCrLf & ex.ToString)
		End Try

		Return i
	End Function

	Public Sub SQLBulkCopy(ByVal table As String, ByVal dtb As DataTable)

		con = New SqlConnection(connStr)
		con.Open()

		Using copy As New SqlBulkCopy(con)
			copy.DestinationTableName = table
			'copy.BulkCopyTimeout = 120
			copy.WriteToServer(dtb)
		End Using
	End Sub

	Public Function ExecuteScalarQuery(ByVal query As String) As Integer

		Dim i As Integer

		Try
			con = New SqlConnection(connStr)
			con.Open()
			_command.Connection = con
			_command.CommandType = CommandType.Text
			_command.CommandText = query
			'_command.CommandTimeout = 180

			i = _command.ExecuteScalar()
			_command.Dispose()
			con.Close()
		Catch ex As Exception
			i = 0
			'clsmail.CreateSendEmail("An error occurred while exceing the query..." & vbCrLf & vbCrLf & query & vbCrLf & vbCrLf & ex.ToString)
		End Try

		Return i
	End Function

   

End Class

