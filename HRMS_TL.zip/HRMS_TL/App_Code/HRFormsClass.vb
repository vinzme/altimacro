﻿Public Class HRFormsClass
	
	Public Class BusinessSegmentList
		Public strBS As String
	End Class

	Public Class BusinessSegment
		Public tblBusinessSegment As List(Of BusinessSegmentList)
	End Class

	Public Class BusinessUnitList
		Public strBU As String
	End Class

	Public Class BusinessUnit
		Public tblBusinessUnit As List(Of BusinessUnitList)
	End Class

	Public Class ImmediateSuperiorList
		Public strIS As String
	End Class

	Public Class ImmediateSuperior
		Public strBU As String
		Public strLvl As String

		Public tblImmediateSuperior As List(Of ImmediateSuperiorList)
	End Class

	Public Class EmployeeList
		Public empNum As String
		Public empName As String
		Public empIS As String
		Public empDeptName As String
		Public empDeptCode As String
	End Class

	Public Class Employee
		Public strBS As String
		Public strBU As String
		Public strLvl As String
		Public strIS As String
		Public strName As String
		Public strForm As String
		Public strFormGroup As String
		Public path As String

		Public tblEmployee As List(Of EmployeeList)
	End Class

	Public Class Forms
		Public path As String
	End Class

	Public Class Form
		Public tblDocumentsPersonal As List(Of FormList)
		Public tblDocumentsCompany As List(Of FormList)
	End Class

	Public Class FormList
		Public formName As String
		Public codeName As String
		Public type As String
	End Class
End Class
