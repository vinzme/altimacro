﻿Imports Microsoft.VisualBasic
Imports System.Data

Public Class clsFunctions

    Public Function GetAllColumnName(dt As DataTable) As List(Of String)
        Dim rt = New List(Of String)()
        For Each column As DataColumn In dt.Columns
            rt.Add(column.ColumnName)
        Next

        Return rt
    End Function


    Public Function convertAllColumnsToString(dt As DataTable) As DataTable
        Dim dtCloned As DataTable = dt.Clone()
        For i As Integer = 0 To dt.Columns.Count - 1
            dtCloned.Columns(i).DataType = GetType(String)
        Next

        For Each row As DataRow In dt.Rows
            dtCloned.ImportRow(row)
        Next

        Return dtCloned
    End Function

End Class
