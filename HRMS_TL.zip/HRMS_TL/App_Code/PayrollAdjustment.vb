﻿Imports Microsoft.VisualBasic
Imports System.Data

Public Class PopulateList
    Public bs As List(Of String)
    Public bu As List(Of String)
    Public lvl As List(Of String)
    Public isup As List(Of String)
    Public empname As String
    Public additionType As List(Of String)
    Public adjustmentType As List(Of String)
End Class

Public Class getList
    Public bs As String
    Public bu As String
    Public lvl As String
    Public isup As String
    Public empname As String
    Public addType As String
    Public adjType As String
    Public dtFrom As String
    Public dtTo As String
    Public tabType As String
End Class

Public Class tblADJ
    Public d As New List(Of tblAdjColumn)
    Public count As Integer
End Class

Public Class tblAdjColumn
    Public id As String
    Public empid As String
    Public empname As String
    Public department As String
    Public emplevel As String
    Public isup As String
    Public tType As String
    Public pdHrs As String
    Public adjHrs As String
    Public vdate As String
    Public paidOn As String
    Public adjAmount As String
    Public payoutDate As String
    Public ICPMonthApplicable As String
    Public ICPPrevious As String
    Public ICPAdjAmount As String
    Public ICPPayoutDate As String
    Public ICPAddAmount As String
    Public DDHours As String
    Public DDOn As String
    Public DDAmt As String
    Public MonthOfLoan As String
    Public AmortAmount As String
    Public payoutSchedule As String
End Class

Public Class toUpdate
    Public id As String
    Public value As String
    Public payout As String
End Class

Public Class autoEmpName
    Public ntid As String
    Public empname As String

End Class