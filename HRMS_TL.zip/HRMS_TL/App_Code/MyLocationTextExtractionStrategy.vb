﻿Imports iTextSharp.text.pdf.parser


'Helper class that stores our rectangle and text
Public Class RectAndText
	Public Rect As iTextSharp.text.Rectangle
	Public Text As [String]
	Public Sub New(rect As iTextSharp.text.Rectangle, text As [String])
		Me.Rect = rect
		Me.Text = text.Trim
	End Sub
End Class


Public Class MyLocationTextExtractionStrategy
	Inherits LocationTextExtractionStrategy
	'Hold each coordinate
	Public myPoints As New List(Of RectAndText)()

	'Automatically called for each chunk of text in the PDF
	Public Overrides Sub RenderText(renderInfo As TextRenderInfo)
		MyBase.RenderText(renderInfo)

		'Get the bounding box for the chunk of text
		Dim bottomLeft = renderInfo.GetDescentLine().GetStartPoint()
		Dim topRight = renderInfo.GetAscentLine().GetEndPoint()

		'Create a rectangle from it
		Dim rect = New iTextSharp.text.Rectangle(bottomLeft(Vector.I1), bottomLeft(Vector.I2), topRight(Vector.I1), topRight(Vector.I2))

		'Add this to our main collection
		Me.myPoints.Add(New RectAndText(rect, renderInfo.GetText()))
	End Sub
End Class