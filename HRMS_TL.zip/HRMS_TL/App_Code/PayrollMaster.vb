﻿Public Class PayrollMasterClass

    Public ntid As String


    Public dtfrom As String
    Public dtto As String
    Public pyday As String


    Public cutoff_date As String

    Public bs As String
    Public bu As String
    Public elvl As String

    Public mcut As String
    Public mcutoff As String

    Public fCount As String

    Public tblPayrollBreakdown As List(Of PayrollBreakdown)

End Class

Public Class PayrollBreakdown

    Public pyday As String
    Public mcut As String
    Public mcutoff As String
    Public dtfrom As String
    Public dtto As String

    Public empId As String
    Public ntid As String
    Public empname As String

    Public cutoff_date As String
    Public tax_status As String
    Public monthly_rate As String

    Public semi_rate As String
    Public daily_rate As String
    Public hourly_rate As String

    Public reg As String
    Public restday As String
    Public spchld As String
    Public rd_spchld As String

    Public reghld As String
    Public rd_reghld As String

    Public regOt As String
    Public spc_rh_res_OT As String

    Public ndReg As String
    Public nd_spc_rh_rest As String

    Public nd_rd_rhd As String
    Public nd_rd_spc As String


    Public reg_hrs As String
    Public restday_hrs As String
    Public spchld_hrs As String
    Public rd_spchld_hrs As String

    Public reghld_hrs As String
    Public rd_reghld_hrs As String

    Public regOt_hrs As String
    Public spc_rh_res_OT_hrs As String

    Public ndReg_hrs As String
    Public nd_spc_rh_rest_hrs As String

    Public nd_rd_rhd_hrs As String
    Public nd_rd_spc_hrs As String

    Public total_salary As String

    Public adjustments As List(Of adjustment_table)

    Public total_before_tax_deduct As String
    Public taxable_amount As String

    Public tax_bracket As String
    Public tax_over As String
    Public tax_initial As String
    Public tax_over_amt As String
    Public tax_deduction As String

    Public net_pay As String

    Public com As String


    Public bs As String
    Public bu As String
    Public elvl As String

End Class

Public Class Adjustments_Data

    Public basic_salary As String
    Public total_salary As String
    'Public taxable_amt As String
    Public tax_status As String
    Public cutoff_date As String
    Public payid As String

End Class

Public Class AdjustmentTax

    Public cutoff_date As String
    Public payid As String
    Public deduct_desc As String
    Public deduct_cost As String

    Public tax_bracket As String
    Public over As String
    Public taxover As String
    Public initial As String

    Public tax_deduct As String

End Class

Public Class adjustment_table

    Public cutoff_date As String
    Public payid As String
    Public deduct_desc As String
    Public deduct_cost As String

End Class

Public Class generate_adjustments
    Public adjustments As List(Of adjustment_table)
    Public total_before_tax_deduct As String
    Public taxable_amount As String

    Public tax_bracket As String
    Public tax_over_prcnt As String
    Public tax_initial As String
    Public tax_over_amount As String
    Public tax_deduction As String

End Class

Public Class tax_deduct

    Public tax_bracket As String
    Public tax_over As String
    Public tax_initial As String
    Public tax_over_amt As String
    Public tax_deduction As String

End Class

Public Class viewPSPDF
    'Public fn As String
    Public cutoff_date As String
    Public ntid As String
    Public eid As String
End Class

Public Class Dropdownlists
    Public BusinessSegments As List(Of String)
    Public BusinessUnits As List(Of String)
End Class


Public Class payslipclass

    Public usr As String

    Public payday As List(Of paydayList)

    'Public paydayMonth As List(Of String)

    Public payct As Integer

    Public year As String

End Class

Public Class paydayList
    Public paydayMonth As String

    Public paydays As List(Of String)

    Public cutoff_date As String
    Public eId As String

End Class