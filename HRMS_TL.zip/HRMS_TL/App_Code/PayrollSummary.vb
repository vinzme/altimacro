﻿Imports Microsoft.VisualBasic

Public Class PSgetList

    Public bs As String
    Public bu As String
    Public lvl As String
    Public isup As String
    Public empname As String
    Public addType As String
    Public adjType As String
    Public dtFrom As String
    Public dtTo As String
    Public tabType As String

End Class

Public Class payrollTableReturn
    Public Cut_Off As String
    Public Status As String
    Public emplevel As String
    Public EmpID As String
    Public EmpName As String
    Public NTID As String
    Public MngrID As String
    Public MngrName As String
    Public Scheduled_Start As String
    Public Scheduled_Out As String
    Public Log_In_Time As String
    Public Log_Out_Time As String
    Public TotalUnComputedHours As String
    Public TOTAL_ND_HRS As String
    Public TOTAL_REG_HRS As String
    Public TOTAL_OT_HRS As String
    Public RH_ND_HOURS As String
    Public RH_REG_HOURS As String
    Public RH_OT_HOURS As String
    Public SNW_ND_HOURS As String
    Public SNW_REG_HOURS As String
    Public SNW_OT_HOURS As String
    Public PTO_Whole_Day As String
    Public PTO_Half_Day As String
    Public Maternity As String
    Public Paternity As String
    Public SoloParent As String
    Public NDRestDay As String
    Public RestDay As String
    Public RestDayOT As String
    Public RD_RH_ND_HOURS As String
    Public RD_RH_REG_HOURS As String
    Public RD_RH_OT_HOURS As String
    Public RD_SNW_ND_HOURS As String
    Public RD_SNW_REG_HOURS As String
    Public RD_SNW_OT_HOURS As String

End Class