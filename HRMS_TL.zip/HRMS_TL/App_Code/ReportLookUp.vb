﻿Imports Microsoft.VisualBasic


Public Class ReceiveList
    Public Business_Segment As List(Of String)
    Public Business_Unit As List(Of String)
    Public Manager As List(Of String)
    Public Team_Leader As List(Of String)
    Public Employee As List(Of String)
    Public DateStarted As String
    Public DateEnded As String
    Public mydate As String
End Class

Public Class ReportITEMS
    Public y As String
    Public indexLabel As String
End Class

Public Class MonthlyIndividual
    Public Name As String
    Public January As String = 0
    Public February As String = 0
    Public March As String = 0
    Public April As String = 0
    Public May As String = 0
    Public June As String = 0
    Public July As String = 0
    Public August As String = 0
    Public September As String = 0
    Public October As String = 0
    Public November As String = 0
    Public December As String = 0
End Class
Public Class Calendar
    Public Name As String
    Public Day1 As String = 0
    Public Day2 As String = 0
    Public Day3 As String = 0
    Public Day4 As String = 0
    Public Day5 As String = 0
    Public Day6 As String = 0
    Public Day7 As String = 0
    Public Total As String = 0
End Class

Public Class MyReport
    Public Absences As List(Of ReportITEMS)
    Public Tardiness As List(Of ReportITEMS)
    Public PTO As List(Of ReportITEMS)
    Public CTO As List(Of ReportITEMS)
    Public AbsentCount As List(Of MonthlyIndividual)
    Public TardinessCount As List(Of MonthlyIndividual)
    Public TardinessCalendar As List(Of Calendar)
    Public AbsencesCalendar As List(Of Calendar)
    Public OverBreaksCalendar As List(Of Calendar)
End Class

Public Class UsageReport
    Public dtFrom As String
    Public dtTo As String

    Public tblPERCENTAGE As List(Of PercentagCount)
    Public tblSUMMARY As List(Of PercentageTable)

End Class

Public Class PercentagCount
    Public SchedDate As String
    Public BusinessUnit As String
    Public HeadCount As String
    Public EmpName As String
    Public MngrName As String
    Public vUsing As String
    Public vNotUsing As String
    Public Present As String
    Public Absent As String
    Public RestDay As String
    Public Leave As String
End Class

Public Class PercentageTable
    Public bu As String
    Public headcount As String
    Public notusing As String
    Public vusing As String
    Public present As String
    Public absent As String
    Public restday As String
    Public leave As String
End Class

Public Class LeaveReport
	Public dtFrom As String
	Public dtTo As String
	Public ddlStatus As String
	Public strUser As String
	Public strLvl As String

	Public tblLeave As List(Of LeaveReportTable)
End Class

Public Class LeaveReportTable
	Public empCode As String
	Public empName As String
	Public leaveDate As String
	Public leaveType As String
	Public isHalfDay As String
	Public appliedDate As String
	Public status As String
	Public approveDate As String
	Public approverName As String
End Class
Public Class CategoryType
	Public catID As String
	Public category As String
	Public catEmpLevel As String

End Class

Public Class LeaveList
	Public id As String
	Public LeaveName As String
	Public ModifedByAndDateTime As String

	Public Gender As String
	Public EmpLevel As String
	Public EmpCategory As String

	Public idOfApproverTable As String
	Public idOfCutOff As String
End Class

Public Class EmployeeCategoryObj

	Public ListOfCategoryCount As String
	Public ListOfCategory As List(Of CategoryType)
	Public ListOfLeave As List(Of LeaveList)
	Public ListMyMasterControl As List(Of MyMasterControl)

	Public ListOfApprover As List(Of Approver)
	Public ListOfCutOff As List(Of CutOff)

	Public LeaveGender As String
	Public LeavePaid As String
	Public Leave As String
	Public Categ As String
	Public CategDesc As String

	Public LeaveRecordCount As Integer
	Public usr As String

End Class

Public Class MyMasterControl


	Public PTO As String
	Public CTO As String
	Public RH As String
	Public SH As String
	Public vDO As String
	Public RDO As String
	Public ND1 As String
	Public ND1AMPM As String
	Public ND2 As String
	Public ND2AMPM As String
	Public ITT As String
	Public ELI As String

	Public PTOChk As String
	Public CTOChk As String
	Public RHChk As String
	Public SHChk As String
	Public DOChk As String
	Public RDOChk As String
	Public NDChk As String
	Public ITTChk As String
	Public ELIChk As String

    Public SSSChk As String
    Public PHChk As String
    Public HDMFChk As String
    Public TaxChk As String
    Public m13Chk As String
    Public PsChk As String

	Public modiPTO As String
	Public modiCTO As String
	Public modirh As String
	Public modish As String
	Public modido As String
	Public modirdo As String
	Public modind As String
	Public modiitt As String
	Public modieli As String

	Public Val As String
	Public Val2 As String
	Public id As String
	Public usr As String
	Public ELvl As String

	Public Mode As String

	Public Settings As String


End Class

Public Class Approver
	Public Approver As String
	Public ApproverIndex As String

End Class

Public Class CutOff
	Public lvFrom As String
	Public lvTo As String

	Public lvApproved As String

End Class

Public Class m13
    Public selSalary As String
    Public selOperator As String
    Public selPrimary As String
    Public selOperator2 As String
    Public selSecondary As String
    Public txtdvBy As String
    Public txtsbDesc As String
    Public selPayoutScheme As String
    Public txt1pf As String
    Public txt1pt As String
    Public txt2pf As String
    Public txt2pt As String
    Public txt3pf As String
    Public txt3pt As String
    Public txt4pf As String
    Public txt4pt As String

    Public Val As String
    Public Elvl As String
    Public usr As String


    Public fetchCount As Integer

End Class

Public Class payout
	Public dtfrom As String
	Public dtto As String
	Public dtpay As String

	Public dtscheme As String
End Class

Public Class Ps

	Public payouts As List(Of payout)
	Public selPayoutscheme As String


	Public Val As String
	Public Elvl As String
	Public usr As String


	Public fetchCount As Integer
End Class


Public Class cD

    Public txtcDetails As String
    Public txtcName As String
    Public txtOTN As String
    Public txtAddress As String
    Public txttel As String
    Public txtfax As String
    Public txtemail As String
    Public txtwebpage As String
    Public txtcRegNo As String


    Public txtDateofReg As String
    Public txtNumberOfEMployees As String

    Public txtregaddIf As String
    Public txtemployerName As String

    Public txtemployerid As String

    Public txtemployeremail As String
    Public txtTIN As String


    Public txtSSS As String


    Public chkSE As String
    Public chkHO As String
    Public chkGov As String

	Public chkPriv As String

	Public eType As String


	Public fetchCount As Integer

End Class

Public Class Request
	Public formName As String
	Public empLevel As String
	Public isPrint As String
	Public isSend As String
	Public isShare As String
	Public isSigned As String
	Public isSignPerm As String
	Public isSignPrint As String
	Public isAuto As String
	Public isAutoDays As String
	Public days As String
	Public firstSig As String
	Public firstBackup As String
	Public secondSig As String
	Public secondBackup As String

End Class

Public Class Document
	Public tblDocument As List(Of DocumentList)
End Class

Public Class DocumentList
	Public companyName As String
	Public address As String
	Public zip As String
	Public telephone As String
	Public fax As String
	Public generalEmail As String
	Public tin As String
	Public sss As String
	Public philHealth As String
	Public hdmf As String
	Public webPage As String
	Public companyRegistration As String
	Public dateOfRegistration As String
End Class

Public Class Form
	Public tblDocumentsPersonal As List(Of FormList)
	Public tblDocumentsCompany As List(Of FormList)
End Class

Public Class FormList
	Public formName As String
	Public codeName As String
	Public type As String
End Class

Public Class Subject
	Public tblSubject As List(Of SubjectList)
End Class

Public Class SubjectList
	Public Subject As String
	Public SubSubject As String
	Public ModifiedBy As String
	Public DateModified As String
	Public Modified As String
End Class