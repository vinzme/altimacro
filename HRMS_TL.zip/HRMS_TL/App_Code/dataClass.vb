﻿Imports Microsoft.VisualBasic

Public Class MyClassfJQ
	Public hasMessage As Boolean
	Public MessageStr As String
	Public MessageID As Integer
End Class

Public Class LogInForm
	Public user As String
	Public pw As String
End Class

Public Class CheckValidateLogs
	Public pCount As Integer
	Public pDate As List(Of String)

End Class

Public Class agentLeaveclass

	Public txtleavedate As String

	Public selHalfDay As String

	Public selLeaveType As String

	Public PaymentType As String

	Public usr As String

	Public rt As Integer

	Public leavetransTable As New List(Of leavetrans)

	Public leaveTable As New List(Of leave)

	Public errMsg As String

End Class

Public Class leavetrans

	Public leavedate As String
	Public halfday As String
	Public leavetype As String
	Public paymenttype As String
	Public seriesid As String

End Class

Public Class leave

	Public id As String
	Public name As String
	Public leavedate As String
	Public applieddate As String
	Public halfday As String
	Public leavetype As String
	Public paymenttype As String
	Public Status As String
	Public ApprovedCanceledDate As String
	Public ApprovedCancelledBy As String

	Public seriesid As String

End Class

Public Class CancelResponse
	Public rt As Integer = 0
	Public updatedLeaveBal As String

End Class

Public Class SavedDocs
	Public tblSavedDocs As List(Of SavedDocsList)
End Class

Public Class SavedDocsList
	Public docName As String
	Public createdBy As String
	Public dateModified As String
End Class