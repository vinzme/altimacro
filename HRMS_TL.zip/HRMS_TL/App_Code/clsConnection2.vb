﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
Imports System
Public Class clsConnection2
    Dim ConString As String = "Server=hrms-svr.database.windows.net,1433;Database=HRMS_DB;User Id=hrms_svr_admin@hrms-svr;Password=securedmgt@1230;"
    'Dim ConString As String = ConfigurationManager.ConnectionStrings("DAVConnectionString").ConnectionString.ToString()

    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    'Dim clsmail As New clsEmail

    Private _command As New SqlCommand

    Public Function GetData(ByVal Query As String) As DataTable

        Dim dt As New DataTable
        Try
            con = New SqlConnection(ConString)
            con.Open()
            da = New SqlDataAdapter(Query, con)
            da.Fill(dt)
            con.Close()
            Return dt
        Catch ex As Exception
            Return dt
        End Try
    End Function

    Public Function ExecuteQuery(ByVal query As String) As Integer

        Dim i As Integer

        Try
            con = New SqlConnection(ConString)
            con.Open()
            _command.Connection = con
            _command.CommandType = CommandType.Text
            _command.CommandText = query
            '_command.CommandTimeout = 180

            i = _command.ExecuteNonQuery()
            _command.Dispose()
        Catch ex As Exception
            i = 0
            'clsmail.CreateSendEmail("An error occurred while exceing the query..." & vbCrLf & vbCrLf & query & vbCrLf & vbCrLf & ex.ToString)
        End Try

        Return i
    End Function

    Public Sub SQLBulkCopy(ByVal table As String, ByVal dtb As DataTable)

        con = New SqlConnection(ConString)
        con.Open()

        Using copy As New SqlBulkCopy(con)
            copy.DestinationTableName = table
            'copy.BulkCopyTimeout = 120
            copy.WriteToServer(dtb)
        End Using
    End Sub
    Public Function GetDataSet(ByVal strQuery As String) As DataSet
        con = New SqlConnection(ConString)
        Try
            Dim myDataAdapter As New SqlDataAdapter(strQuery, con)
            Dim myDataSet As New DataSet
            Call myDataAdapter.Fill(myDataSet)
            Call myDataAdapter.Dispose()
            Return myDataSet
        Catch ex As SqlException
            Call MsgBox(ex.Message & vbCr & "Contact administrator.", MsgBoxStyle.Critical, "Error!")
            Return Nothing
        Finally
            Call con.Close()
        End Try
    End Function
End Class
