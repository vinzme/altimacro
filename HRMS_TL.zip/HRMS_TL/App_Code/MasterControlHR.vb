﻿Imports Microsoft.VisualBasic

Public Class clsMasterControlHR
    Public Function qString(str As String) As String
        Dim rt As String
        If str <> "" Then rt = "'" & str & "'" Else rt = "NULL"
        Return rt
    End Function

    Public Function FirstDayOfMonth(ByVal sourceDate As DateTime) As DateTime
        Return New DateTime(sourceDate.Year, sourceDate.Month, 1)

    End Function

    Public Function LastDayOfMonth(ByVal sourceDate As DateTime) As DateTime
        Dim lastDay As DateTime = New DateTime(sourceDate.Year, sourceDate.Month, 1)
        Return lastDay.AddMonths(1).AddDays(-1)

    End Function

    Public Function convertToIntmDay(str As String) As Integer
        Dim rt As Integer

        If str = "First" Then
            rt = 1
        ElseIf str = "Second" Then
            rt = 2
        ElseIf str = "Third" Then
            rt = 3
        ElseIf str = "Fourth" Then
            rt = 4
        Else
            rt = 0
        End If

        Return rt
    End Function

    Public Function changemTheToValue(str As String) As Integer
        Dim rt As Integer = 0
        If LCase(str) = "first" Then
            rt = 1
        ElseIf LCase(str) = "second" Then
            rt = 2
        ElseIf LCase(str) = "third" Then
            rt = 3
        ElseIf LCase(str) = "forth" Then
            rt = 4
        Else
            rt = 5
        End If
        Return rt
    End Function


    Public Function GetFirstSundayInMonth(ByVal month As Integer, ByVal year As Integer) As DateTime

        ' Create a start date for the 1st day of the month   
        Dim startDate As DateTime = New DateTime(year, month, 1)

        ' Keep looping, adding day's to the start date until sunday is reached  
        While startDate.DayOfWeek <> DayOfWeek.Sunday
            startDate = startDate.AddDays(1)
        End While

        ' Then return date of first sunday of month  
        Return startDate

    End Function

    Public Function changemDayFirstToNum(str As String) As Integer
        Dim rt As Integer

        If LCase(str) = "sunday" Then
            rt = 0
        ElseIf LCase(str) = "monday" Then
            rt = 1
        ElseIf LCase(str) = "tuesday" Then
            rt = 2
        ElseIf LCase(str) = "wednesday" Then
            rt = 3
        ElseIf LCase(str) = "thursday" Then
            rt = 4
        ElseIf LCase(str) = "friday" Then
            rt = 5
        ElseIf LCase(str) = "saturday" Then
            rt = 6
        End If

        Return rt
    End Function
End Class


Public Class tblNews

    Public id As Integer
    Public subject As String
    Public Imagepath As String
    Public addedBy As String
    Public addedDate As String

End Class