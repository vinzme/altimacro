﻿Imports Microsoft.VisualBasic

Public Class Schedule
	Public strUser As String
	Public strDateFrom As String
	Public strDateTo As String

	Public tblSchedule As List(Of ScheduleValues)
End Class

Public Class ScheduleValues
	Public strDate As String
	Public strDay As String
	Public strLogin As String
	Public strBreak1 As String
	Public strLunch As String
	Public strBreak2 As String
	Public strLogout As String
End Class
