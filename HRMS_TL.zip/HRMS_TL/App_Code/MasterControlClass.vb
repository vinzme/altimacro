﻿
Public Class SchedRulesTable
	Public id As String
	Public ruleName As String
	Public modifiedBy As String
	Public modifiedDate As String
	Public businessUnit As String
	Public modifierLevel As String
	Public modifier As String
	Public personToModifyLevel As String
	Public personToModify As String
End Class

Public Class SchedRulesDesc
	Public ruleName As String
	Public strBU As String
	Public strModifier As String
	Public strPersonToModify As String
	Public strTag As String

	Public tblSchedRulesDesc As List(Of SchedRulesTable)

	Public tblModifier As List(Of SchedRulesModifierList)

	Public tblEscalateTo As List(Of EscalateToList)

	Public tblPersonToModifyList As List(Of SchedRulesPersonToModifyList)

End Class

Public Class EscalateToList
	Public ListOfEscalation As List(Of EscalateToName)
End Class

Public Class EscalateToName
	Public EmpName As String
	Public NTID As String
End Class

Public Class SchedRulesModifierList
	Public ListOfModifier As List(Of SchedRulesModifierName)
End Class

Public Class SchedRulesModifierName
	Public modifierName As String
	Public modifierNTID As String
End Class

Public Class SchedRulesPersonToModifyList
	Public ListOfPersonToModify As List(Of SchedRulesPersonToModify)
End Class

Public Class SchedRulesPersonToModify
	Public personToModify As String
	Public personToModifyNTID As String
End Class

'LOGS

Public Class LogsRulesTable
	Public id As String
	Public ruleName As String
	Public modifiedBy As String
	Public modifiedDate As String
	Public businessUnit As String
	Public modifierLevel As String
	Public modifier As String
	Public personToModifyLevel As String
	Public personToModify As String
End Class

Public Class LogsRulesDesc
	Public ruleName As String
	Public strBU As String
	Public strModifier As String
	Public strPersonToModify As String
	Public strTag As String

	Public tblLogsRulesDesc As List(Of LogsRulesTable)

	Public tblLogsModifier As List(Of LogsRulesModifierList)

	Public tblLogsPersonToModifyList As List(Of LogsRulesPersonToModifyList)

End Class

Public Class LogsRulesModifierList
	Public ListOfLogsModifier As List(Of LogsRulesModifierName)
End Class

Public Class LogsRulesModifierName
	Public modifierName As String
	Public modifierNTID As String
End Class

Public Class LogsRulesPersonToModifyList
	Public ListOfLogsPersonToModify As List(Of LogsRulesPersonToModify)
End Class

Public Class LogsRulesPersonToModify
	Public personToModify As String
	Public personToModifyNTID As String
End Class