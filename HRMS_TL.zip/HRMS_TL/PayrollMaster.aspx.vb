﻿Imports System.Web.Services
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.Data
Imports System.Diagnostics

Public Class PayrollMaster
	Inherits System.Web.UI.Page

	Shared Function tbl_PaySlipMaster(data As PayrollMasterClass, ByRef rCutOff As String) As String

		Dim qry As String
		rCutOff = DateValue(data.dtfrom).ToString("yyyy-MM-dd") & "-" & DateValue(data.dtto).ToString("yyyy-MM-dd")


		qry = "delete tbl_HRMS_PayslipMaster where  cutoff_date = '" & rCutOff & "';"

		qry &= "insert into tbl_HRMS_PayslipMaster(payday,cutoff_from,cutoff_to,gmonth,runindex,NTID, cutoff_date, tax_status, monthly, semi_monthly, daily, hourly, reg_hrs, reg, rest_hrs, rest, rest_pt, "
		qry &= "spchld_hrs,spchld,spchld_pt,rest_spday_hrs,rest_spday,rest_spday_pt,reg_hld_hrs,reg_hld,reg_hld_pt,restday_reghld_hrs,restday_reghld,"
		qry &= "restday_reghld_pt,reg_ot_hrs,reg_ot,reg_ot_rt,rest_ot_hrs,rest_ot,rest_ot_pt,nd_reg_hrs,nd_reg,nd_reg_pt,nd_rest_hrs,nd_rest,nd_rest_pt,"
		qry &= "nd_hrd_hrs,nd_hrd,nd_hrd_pt,nd_spc_hrs,nd_spc,nd_spc_pt) "

		qry &= "SELECT '" & data.pyday & "','" & data.dtfrom & "','" & data.dtto & "','" & data.mcut & "','" & data.mcutoff & "',"
		qry &= "vRaw.NTID,"
		qry &= "'" & rCutOff.Trim & "' [cutoff_date],"
		qry &= "stat.tax_status,"
		qry &= "CAST(stat.monthly as money) [monthly],"
		qry &= "CAST(stat.monthly/2 as money) [semi_monthly],"
		qry &= "CAST(stat.monthly as money) / 21 [Daily],"
		qry &= "(CAST(stat.monthly as money)/21)/8  [Hourly],"
		qry &= "vraw.REG [reg_hrs],"
		qry &= "(CAST(stat.monthly as money)/21)/8 * vraw.REG  [reg],"

		qry &= "vraw.REST_DAY [rest_hrs],"
		qry &= "vraw.REST_DAY*(((CAST(stat.monthly as money)/21)/8) * Addrate.RD) [rest],"
		qry &= "Addrate.RD [rest_pt],"

		qry &= "vraw.SPCHLD [spchld_hrs],"
		qry &= "vraw.SPCHLD*(((CAST(stat.monthly as money)/21)/8) * Addrate.SPCHLD) [spchld],"
		qry &= "Addrate.SPCHLD [spchld_pt],"

		qry &= "vraw.RESTDAY_SPCHLD [rest_spday_hrs],"
		qry &= "vraw.RESTDAY_SPCHLD*(((CAST(stat.monthly as money)/21)/8) * Addrate.RESTDAY_SPCHLD) [rest_spday],"
		qry &= "Addrate.RESTDAY_SPCHLD [rest_spday_pt],"

		qry &= "vraw.RESTDAY_REGHLD [reg_hld_hrs],"
		qry &= "vraw.RESTDAY_REGHLD*(((CAST(stat.monthly as money)/21)/8) * Addrate.RESTDAY_REGHLD) [reg_hld],"
		qry &= "Addrate.RESTDAY_REGHLD [reg_hld_pt],"

		qry &= "vRaw.[RESTDAY_REGHLD] [restday_reghld_hrs],"
		qry &= "vRaw.[RESTDAY_REGHLD]*(((CAST(stat.monthly as money)/21)/8) * Addrate.RESTDAY_REGHLD) [restday_reghld],"
		qry &= "Addrate.RESTDAY_REGHLD [restday_reghld_pt],"

		qry &= "vraw.Reg_OT [reg_ot_hrs],"
		qry &= "vraw.Reg_OT*(((CAST(stat.monthly as money)/21)/8) * Addrate.Reg_OT) [reg_ot],"
		qry &= "Addrate.Reg_OT [reg_ot_pt],"

		qry &= "vraw.[SPC/RHD/Rest_OT] [rest_ot_hrs],"
		qry &= "cast(vraw.[SPC/RHD/Rest_OT]as decimal(5,2))*(((CAST(stat.monthly as money)/21)/8) * Addrate.SPC_RHD_Rest_OT) [rest_ot],"
		qry &= "Addrate.SPC_RHD_Rest_OT [rest_ot_pt],"

		qry &= "vraw.ND_REG [nd_reg_hrs],"
		qry &= "(vraw.ND_REG*(CAST(stat.monthly as money)/21)/8)*Addrate.ND_REG [nd_reg],"
		qry &= "Addrate.ND_REG [nd_reg_pt],"

		qry &= "vraw.[ND SPC/RHD/REST] [nd_rest_hrs],"
		qry &= "vraw.[ND SPC/RHD/REST]*((CAST(stat.monthly as money)/21)/8*addrate.RD)*addrate.ND_REG [nd_rest],"
		qry &= "cast(addrate.RD as varchar) + 'x' + cast(addrate.ND_REG as varchar)  [nd_rest_pt],"

		qry &= "vraw.[ND_RD_RHD] [nd_hrd_hrs],"
		qry &= "vraw.[ND_RD_RHD]*((CAST(stat.monthly as money)/21)/8*addrate.REGHLD)*addrate.ND_REG [nd_hrd],"
		qry &= "cast(addrate.REGHLD as varchar) + 'x' + CAST(addrate.ND_REG as varchar) [nd_hrd_pt],"

		qry &= "vraw.[ND_RD_SPC] [nd_spc_hrs],"
		qry &= "vraw.[ND_RD_SPC]*((CAST(stat.monthly as money)/21)/8*addrate.ND_RD_SPC)*addrate.ND_REG  [nd_spc],"
		qry &= "cast(addrate.ND_RD_SPC as varchar) + 'x' + CAST(addrate.ND_REG as varchar) [nd_spc_pt] "

		qry &= "FROM (Select a.EmpID, a.ntid, a.empname,"
		qry &= "b.tax_status [Tax_Status],b.monthly [Monthly_Rate],"

		qry &= "SUM(CAST(a.Total_REG_Hrs as decimal(5,2))) [REG],"
		qry &= "SUM(CAST(a.[RestDay] as decimal(5,2))) [REST_DAY],"
		qry &= "SUM(CAST(a.SH_REG_Hrs as decimal(5,2))) [SPCHLD],"
		qry &= "SUM(CAST(a.RD_SNW_REG_HOURS as decimal(5,2))) [RESTDAY_SPCHLD],"

		qry &= "SUM(CAST(a.RH_REG_Hrs as decimal(5,2))) [REGHLD],"
		qry &= "SUM(CAST(a.RD_RH_REG_HOURS as decimal(5,2))) [RESTDAY_REGHLD],"

		qry &= "SUM(CAST(a.Total_OT_Hrs as decimal(5,2))) [Reg_OT],"
		qry &= "SUM(CAST(a.SH_OT_Hrs as decimal(5,2))+CAST(a.RH_OT_Hrs as decimal(5,2))) [SPC/RHD/Rest_OT],"

		qry &= "SUM(CAST(a.Total_ND_Hrs as decimal(5,2))) [ND_REG],"
		qry &= "SUM(CAST(a.RD_RH_ND_HOURS as decimal(5,2)) + CAST(a.RD_SNW_ND_HOURS as decimal(5,2))) [ND SPC/RHD/REST],"

		qry &= "SUM(CAST(a.RH_ND_Hrs as decimal(5,2))) [ND_RD_RHD],"
		qry &= "SUM(CAST(a.SH_ND_Hrs as decimal(5,2))) [ND_RD_SPC] "

		qry &= "from tbl_HRMS_Payroll_Hours a join tbl_HRMS_Employee_Pay b on a.NTID = b.ntid "
		qry &= "where a.Cut_Off between CAST('" & data.dtfrom.Trim & "' as date) and CAST('" & data.dtto.Trim & "' as date) "
		qry &= "group by a.EmpID, a.ntid, a.empname, b.tax_status, b.monthly) "

		qry &= "vRaw join dbo.tbl_HRMS_Employee_Pay stat on vraw.NTID = stat.ntid "

		qry &= "outer apply(select 1.3 [RD],1.3 [SPCHLD], 1.5 [RESTDAY_SPCHLD],2[REGHLD],2.6 [RESTDAY_REGHLD],1.25[Reg_OT],1.3[SPC_RHD_Rest_OT],0.1[ND_REG],1.6[ND_RD_SPC]) Addrate "

		Return qry
	End Function

	Shared Function tbl_PayrollHours(data As PayrollMasterClass) As String
		Dim sb As New StringBuilder

		sb.Append("delete tbl_HRMS_Payroll_Hours where Cut_Off between CAST('" & data.dtfrom.Trim & "' as date) and CAST('" & data.dtto.Trim & "' as date) ")

		sb.Append("INSERT into tbl_HRMS_Payroll_Hours(Cut_Off,Status, EmpID, EmpName, NTID, MngrID, MngrName,ScheduleStart,ScheduleOut,LogInTime,LogOutTime, ")
		sb.Append("Total_ND_Hrs, Total_REG_Hrs, Total_OT_Hrs,RH_ND_Hrs, RH_REG_Hrs, RH_OT_Hrs, SH_ND_Hrs, SH_REG_Hrs, SH_OT_Hrs, ")
		sb.Append("PTOWholeDay,PTOHalfDay,Maternity,Paternity,SoloParent, ")
		sb.Append("NDRestDay, ")
		sb.Append("RestDay, ")
		sb.Append("RestDayOT, ")
		sb.Append("RD_RH_ND_HOURS, ")
		sb.Append("RD_RH_REG_HOURS, ")
		sb.Append("RD_RH_OT_HOURS, ")
		sb.Append("RD_SNW_ND_HOURS, ")
		sb.Append("RD_SNW_REG_HOURS, ")
		sb.Append("RD_SNW_OT_HOURS) ")

		sb.Append("Select sched.SchedDate [Cut_Off], ")
		sb.Append("Case When sched.SchedType = 'IN' Then (Case When sched.SchedIN is not null and EmpLogIn.Start_Time is null Then 'Absent' Else 'Present' end)  ")
		sb.Append("Else sched.SchedType  ")
		sb.Append("End as [Status], ")
		sb.Append("EMP.EmpID, EMP.EmpName, EMP.NTID, EMP.MngrID, EMP.MngrName, ")
		sb.Append("case when CONVERT(varchar(20), CAST(sched.SchedIN as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(sched.SchedIN as Time), 100) end [Scheduled Start], ")
		sb.Append("case when CONVERT(varchar(20), CAST(sched.SchedOUT as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(sched.SchedOUT as Time), 100) end [Scheduled Out], ")
		sb.Append("case when CONVERT(varchar(20), CAST(EmpLogIn.Start_Time as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(EmpLogIn.Start_Time as Time), 100) end [Log In Time], ")
		sb.Append("case when CONVERT(varchar(20), CAST(EmpLogOut.End_Time as Time), 100) is null then '--' else CONVERT(varchar(20), CAST(EmpLogOut.End_Time as Time), 100) end [Log Out Time], ")

		sb.Append("case when isApprovedLeave.LeaveType is null then ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0.00 ")
		sb.Append("else ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 0 then  ")
		sb.Append("case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then 0  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))  ")
		sb.Append("end ")
		sb.Append("else 0 ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end [TOTAL_ND_HRS], ")

		sb.Append("case when isApprovedLeave.LeaveType is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0  ")
		sb.Append("else  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 8 then 8 ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end  ")
		sb.Append("end  ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end [TOTAL_REG_HRS], ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when isApprovedLeave.LeaveType is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS NULL OR TOTALHRS.[TotTimeHour] = 0 then 0  ")
		sb.Append("else ")
		sb.Append("(case when SUM(CAST(isQualified.DaysPresent as decimal(15,2))) < RD.SetValue1 then (  ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then  ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) > 0 then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end  ")
		sb.Append("else 0  ")
		sb.Append("end )  ")
		sb.Append("else 0  ")
		sb.Append("end ) ")
		sb.Append("else ")
		sb.Append("(case when isApprovedLeave.isHalfDay is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > DO.SetValue1 then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0 ")
		sb.Append("else CAST(TOTALHRS.[TotTimeHour] as decimal(15,2)) - CAST(DO.SetValue1 as decimal(15,2))  ")
		sb.Append("end  ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end  ")
		sb.Append("else 0  ")
		sb.Append("end )  ")
		sb.Append("end )  ")
		sb.Append("end ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end else 0 end [TOTAL_OT_HRS], ")

		sb.Append("case when ifHoliday.HolType = 'Regular' then  ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )  ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then '0.00' ")
		sb.Append("else ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )  ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end as [RH_ND_HOURS],  ")

		sb.Append("case when ifHoliday.HolType = 'Regular' then ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'  ")
		sb.Append("else 8 ")
		sb.Append("end )  ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00 ")
		sb.Append("else ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'  ")
		sb.Append("else 8 ")
		sb.Append("end )  ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end as [RH_REG_HOURS],  ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end) ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00 ")
		sb.Append("else ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end) ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end else 0 end as [RH_OT_HOURS],  ")

		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null then 0  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))  ")
		sb.Append("end)  ")

		sb.Append("else 0  ")
		sb.Append("end as [SNW_ND_HOURS],  ")

		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then  ")

		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then 0  ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end)  ")

		sb.Append("else 0  ")
		sb.Append("end as [SNW_REG_HOURS],  ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then  ")

		sb.Append("( case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end )  ")

		sb.Append("else 0  ")
		sb.Append("end else 0 end [SNW_OT_HOURS], ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00 ")
		sb.Append("else  ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PTO' or isApprovedLeave.LeaveType = 'CTO' then  ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 8.00 else 0.00 end  ")
		sb.Append("else 0 end ")
		sb.Append("end [PTO Whole Day], ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00 ")
		sb.Append("else  ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PTO' or isApprovedLeave.LeaveType = 'CTO' then  ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 0.00 else 4.00 end  ")
		sb.Append("else 0.00 end ")
		sb.Append("end [PTO Half Day], ")

		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00 ")
		sb.Append("else  ")
		sb.Append("case when isApprovedLeave.LeaveType = 'MATERNITY LEAVE' then 8.00 else 0.00 end ")
		sb.Append("end [Maternity], ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00 ")
		sb.Append("else  ")
		sb.Append("case when isApprovedLeave.LeaveType = 'PATERNITY LEAVE' then 8.00 else 0.00 end ")
		sb.Append("end [Paternity], ")
		sb.Append("case when isApprovedLeave.LeaveType is null then 0.00 ")
		sb.Append("else  ")
		sb.Append("case when isApprovedLeave.LeaveType = 'SOLO PARENT' then  ")
		sb.Append("case when isApprovedLeave.isHalfDay = 0 then 8.00 else 0.00 end  ")
		sb.Append("else 0.00 end ")
		sb.Append("end [SoloParent], ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when isApprovedLeave.LeaveType is null then ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0.00 ")
		sb.Append("else ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 0 then  ")
		sb.Append("case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then 0  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))  ")
		sb.Append("end ")
		sb.Append("else 0 ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end ")
		sb.Append("else 0 end  [NDRestDay], ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when isApprovedLeave.LeaveType is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS null then 0  ")
		sb.Append("else  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > 8 then 8 ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end  ")
		sb.Append("end  ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end ")
		sb.Append("else 0 end  [RestDay], ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when isApprovedLeave.LeaveType is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] IS NULL OR TOTALHRS.[TotTimeHour] = 0 then 0  ")
		sb.Append("else ")
		sb.Append("(case when SUM(CAST(isQualified.DaysPresent as decimal(15,2))) < RD.SetValue1 then (  ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then  ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) > 0 then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end  ")
		sb.Append("else 0  ")
		sb.Append("end )  ")
		sb.Append("else 0  ")
		sb.Append("end ) ")
		sb.Append("else ")
		sb.Append("(case when isApprovedLeave.isHalfDay is null then  ")
		sb.Append("case when TOTALHRS.[TotTimeHour] > DO.SetValue1 then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then 0 ")
		sb.Append("else CAST(TOTALHRS.[TotTimeHour] as decimal(15,2)) - CAST(DO.SetValue1 as decimal(15,2))  ")
		sb.Append("end  ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end  ")
		sb.Append("else 0  ")
		sb.Append("end )  ")
		sb.Append("end )  ")
		sb.Append("end ")
		sb.Append("else  ")
		sb.Append("0 ")
		sb.Append("end ")
		sb.Append("else 0 end else 0 end [RestDayOT], ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then  ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )  ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then '0.00' ")
		sb.Append("else ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null or CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) < 0 then '0.00'  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) end )  ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end  ")
		sb.Append("else 0 ")
		sb.Append("end [RD_RH_ND_HOURS],  ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'  ")
		sb.Append("else 8 ")
		sb.Append("end )  ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00 ")
		sb.Append("else ")
		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then '0.00'  ")
		sb.Append("else 8 ")
		sb.Append("end )  ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end  ")
		sb.Append("else 0 end [RD_RH_REG_HOURS],  ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when ifHoliday.HolType = 'Regular' then ")
		sb.Append("case when ispresent.SD is not null then ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end) ")
		sb.Append("else ")
		sb.Append("case when isApprovedLeave.isHalfDay is null then 0.00 ")
		sb.Append("else ")
		sb.Append("(case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end) ")
		sb.Append("end ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end else 0 end as [RD_RH_OT_HOURS],  ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then ")
		sb.Append("(case when CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2)) IS null then 0  ")
		sb.Append("else CAST(CAST(DATEDIFF(MINUTE,ProcessForND1.ND1,ProcessForND2.ND2) as decimal(15,2))/60 as decimal(15,2))  ")
		sb.Append("end)  ")

		sb.Append("else 0  ")
		sb.Append("end  ")
		sb.Append("else 0 ")
		sb.Append("end as [RD_SNW_ND_HOURS],  ")

		sb.Append("case when sched.SchedType = 'RD' then  ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then  ")

		sb.Append("(case when TOTALHRS.[TotTimeHour] IS null then 0  ")
		sb.Append("else TOTALHRS.[TotTimeHour]  ")
		sb.Append("end)  ")

		sb.Append("else 0  ")
		sb.Append("end ")
		sb.Append("else 0  ")
		sb.Append("end as [RD_SNW_REG_HOURS],  ")
		sb.Append("case when DO.Status = 1 then ")
		sb.Append("case when sched.SchedType = 'RD' then ")
		sb.Append("case when ifHoliday.HolType = 'Special Non-Working' then  ")

		sb.Append("( case when CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) < 0 or CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2)) is null then 0  ")
		sb.Append("else CAST(((CAST(TOTALHRS.[TotTimeHour] as decimal(15,2))*60) - (CAST(DO.SetValue1 as decimal(15,2))*60))/60 as decimal(15,2))  ")
		sb.Append("end )  ")

		sb.Append("else 0  ")
		sb.Append("end  ")
		sb.Append("else 0  ")
		sb.Append("end else 0 end [RD_SNW_OT_HOURS] ")

		sb.Append("from tbl_HRMS_Employee_Schedule sched  ")
		sb.Append("inner join tbl_HRMS_EmployeeMaster Emp  ")
		sb.Append("on sched.LoginID=Emp.NTID  ")

		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='ND' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') ND  ")
		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='DO' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') DO ")
		sb.Append("outer apply(Select top 1 * from dbo.tbl_HRMS_MasterControl where Settings='RD' and Category = Emp.EmpPayHrsCat and EmpLevel = emp.EmpLevel and status = '1') RD ")

		sb.Append("outer apply(select top 1 scheddate, start_time, reasonid from tbl_HRMS_Employee_Activity where Loginid = Emp.NTID and scheddate = sched.SchedDate and reasonid = 1 order by start_time asc)  ")
		sb.Append("EmpLogIn  ")
		sb.Append("outer apply(select top 1 a.scheddate, a.end_time, a.reasonid from tbl_HRMS_Employee_Activity a left join tbl_HRMS_Employee_Schedule b on b.scheddate = a.scheddate where a.Loginid = Emp.NTID and a.scheddate = sched.SchedDate and a.reasonid in (14,16) order by a.end_time asc)  ")
		sb.Append("EmpLogOut  ")
		sb.Append("outer apply(Select EmpID,LeaveDate,isHalfDay,LeaveType from tbl_HRMS_LeaveMaster where empID = emp.NTID and LeaveDate = sched.SchedDate and isPaid='1' and LeaveStatus='Approved')  ")
		sb.Append("isApprovedLeave  ")

		sb.Append("outer apply(Select  ")
		sb.Append("case when CAST(sched.SchedIN as datetime) > CAST(EmpLogIn.Start_Time as datetime) then  ")
		sb.Append("case when sched.SchedIN > CAST(CAST(CAST(sched.SchedIN as date)as varchar) +' '+ nd.SetValue1 as datetime) then ( sched.SchedIN )  ")
		sb.Append("else CAST(CAST(sched.SchedIN as date)as varchar) +' '+ nd.SetValue1 end   ")
		sb.Append("else  ")
		sb.Append("case when EmpLogIn.Start_Time > CAST(CAST(CAST(EmpLogIn.Start_Time as date)as varchar) +' '+ nd.SetValue1 as datetime) then ( EmpLogIn.Start_Time )  ")
		sb.Append("else CAST(CAST(EmpLogIn.Start_Time as date)as varchar) +' '+ nd.SetValue1 end  ")
		sb.Append("end [ND1]) ProcessForND1  ")

		sb.Append("outer apply(Select case when EmpLogOut.End_Time < CAST(CAST(CAST(EmpLogOut.End_Time as date)as varchar) +' '+ nd.SetValue2 as datetime) then EmpLogOut.End_Time else CAST(CAST(EmpLogOut.End_Time as date)as varchar) +' '+ nd.SetValue2 end [ND2])  ")
		sb.Append("ProcessForND2   ")

		sb.Append("outer apply(Select   ")
		sb.Append("case when SUM(CAST(TotalTimeHour as decimal(15,2))) is not null then   ")
		sb.Append("case when emp.EmpLevel = 'EE' then  ")
		sb.Append("(SUM(case when EEApproval is not null then CAST(TotalTimeHour as decimal(15,2)) else 0 end))  ")
		sb.Append("else  ")
		sb.Append("(SUM(CAST(TotalTimeHour as decimal(15,2))))  ")
		sb.Append("end  ")
		sb.Append("else   ")
		sb.Append("(case when isApprovedLeave.isHalfDay is not null then   ")
		sb.Append("(case when isApprovedLeave.isHalfDay = 1 then   ")
		sb.Append("(case when Emp.EmpType = 'Regular' then 4.00 else 4.50 end)   ")
		sb.Append("else  ")
		sb.Append("(case when Emp.EmpType = 'Regular' then 8.00 else 9.00 end)   ")
		sb.Append("end)   ")
		sb.Append("else 0 end)  ")
		sb.Append("end [TotTimeHour]  ")
		sb.Append("from dbo.tbl_HRMS_Employee_Activity   ")
		sb.Append("where   ")
		sb.Append("LoginID = EMP.NTID   ")
		sb.Append("and SchedDate = sched.SchedDate   ")
		sb.Append("and isPaid='YES'   ")
		sb.Append("and Activity_Tag <> 'ADJ' or   ")
		sb.Append("LoginID = EMP.NTID   ")
		sb.Append("and SchedDate = sched.SchedDate   ")
		sb.Append("and isPaid='YES'   ")
		sb.Append("and Activity_Tag is null)  ")
		sb.Append("TOTALHRS  ")


		sb.Append("outer apply(Select * from dbo.tbl_HRMS_HolidayMaster where HolDate = sched.SchedDate and DeletedBy is null)  ")
		sb.Append("ifHoliday ")
		sb.Append("outer apply(Select sched.SchedDate, (Select case when SUM(CAST(b.TotalTimeHour as decimal(15,2))) > 0 then '1' else(case when a.SchedType = 'RD' then '0' else '0' end) end from dbo.tbl_HRMS_Employee_Activity b where b.LoginID = a.LoginID and b.SchedDate = a.SchedDate group by b.LoginID ) as [DaysPresent] from dbo.tbl_HRMS_Employee_Schedule a where a.LoginID = Emp.NTID and a.SchedDate between dateadd(d,(RD.SetValue1-1)*-1,sched.SchedDate) and sched.SchedDate )  ")
		sb.Append("isQualified ")
		sb.Append("outer apply(Select top 1 IPb.SchedDate [SD] from dbo.tbl_HRMS_Employee_Activity IPa inner join dbo.tbl_HRMS_Employee_Schedule IPb on IPa.LoginID = IPb.LoginID and IPa.SchedDate = IPb.SchedDate where CAST(IPb.SchedDate as DATE) < CAST(sched.SchedDate as DATE) and IPb.LoginID = Emp.NTID order by IPb.SchedDate DESC ) ")
		sb.Append("isPresent ")
		sb.Append("where  ")
		sb.Append("sched.SchedDate between '" & data.dtfrom.Trim & "' and '" & data.dtto.Trim & "' ")

		If data.bs <> "" Then
			sb.Append("and Emp.BusinessSegment = '" & data.bs & "'  ")
		End If

		If data.bu <> "" Then
			sb.Append("and Emp.BusinessUnit = '" & data.bu & "'  ")
		End If

		If data.elvl = "TA" Then
			sb.Append("and Emp.EmpLevel not in ('EE')  ")
		ElseIf data.elvl <> "" Then
			sb.Append("and Emp.EmpLevel = '" & data.elvl & "'  ")
		End If

		sb.Append("and Emp.empType is not null and Emp.AccessLevel is not null ")

		sb.Append("group by EMP.NTID, EMP.MngrID, EMP.MngrName, EMP.EmpID, EMP.EmpName, sched.SchedDate, ProcessForND1.ND1, ProcessForND2.ND2, TOTALHRS.[TotTimeHour], DO.SetValue1, ifHoliday.HolType, EmpLogIn.Start_Time, EmpLogOut.End_Time, isApprovedLeave.isHalfDay, sched.SchedIN, sched.SchedOUT,RD.SetValue1,ispresent.SD,isApprovedLeave.LeaveType,sched.SchedType ")
		sb.Append(",nd.SetValue1,do.Status,rd.Id,isQualified.SchedDate ")

		sb.Append("order by Emp.NTID, sched.SchedDate; ")

		Return sb.ToString
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function ProcessRawData(data As PayrollMasterClass) As PayrollMasterClass
		Try

			Dim cls As New clsConnection

			Dim qry As String = ""
			Dim da As New DataSet
			Dim dt As New DataTable
			Dim rCutOff As String = ""
			Dim adj As New Adjustments_Data


			qry &= tbl_PayrollHours(data)

			'REMOVE NEGATIVE
			qry &= "update tbl_HRMS_Payroll_Hours set Total_REG_Hrs = '0' where Total_REG_Hrs < '0';"

			qry &= tbl_PaySlipMaster(data, rCutOff)

			adj.cutoff_date = rCutOff

			qry &= generate_adjustments(adj)

			da = cls.GetDataSet(qry)


			Return data


		Catch ex As Exception
			Debug.WriteLine(ex)
			Throw ex
		End Try

	End Function

	Shared Function generate_adjustments(data As Adjustments_Data) As String

		'Dim cls As New clsConnection
		Dim qry As String = ""

		qry &= "insert into tbl_hrms_Adjustments Select "
		qry &= "@cutoff_date [cutoff_date],"
		qry &= "PM.NTID [payid],"
		qry &= "GOVT [deduct_desc],"

		qry &= "CASE "
		qry &= "WHEN GOVT = 'Employee HDMF' THEN "
		qry &= "CASE WHEN CAST(PM.monthly AS DECIMAL(9,2)) * (CAST(HDMF.emp AS DECIMAL(9,2)) / 100) > CAST(HDMF.max_deduct AS DECIMAL(9,2)) THEN "
		qry &= "CAST(HDMF.max_deduct AS DECIMAL(9,2)) "
		qry &= "ELSE "
		qry &= "CAST(CAST(PM.monthly AS DECIMAL(9,2)) * (CAST(HDMF.emp AS DECIMAL(9,2)) / 100) AS DECIMAL(9,2)) "
		qry &= "End "
		qry &= "WHEN GOVT = 'Employee PhilHealth' THEN "
		qry &= "CAST(PH.ee_share AS DECIMAL(9,2)) "
		qry &= "WHEN GOVT = 'Employee Social Security' THEN "
		qry &= "CAST(SSS.ee_contrib AS DECIMAL(9,2)) "
		qry &= "ELSE 0 "
		qry &= "END [deduct_cost] "

		qry &= "FROM("
		qry &= "SELECT * "
		qry &= "FROM(VALUES('Employee HDMF'),"
		qry &= "('Employee PhilHealth'),"
		qry &= "('Employee Social Security')) G(govt)) GOVT "

		qry &= "OUTER APPLY(SELECT * FROM tbl_HRMS_PayslipMaster where cutoff_date = @cutoff_date)PM "
		qry &= "OUTER APPLY(SELECT * FROM dbo.tbl_hrms_HDMFTable WHERE ID = 2) HDMF "
		qry &= "OUTER APPLY(SELECT TOP 1 * FROM dbo.tbl_hrms_PHTable WHERE r_to >= CAST(PM.monthly AS FLOAT)) PH "
		qry &= "OUTER APPLY(SELECT TOP 1 * FROM dbo.tbl_hrms_SSSTable WHERE r_to >= CAST(PM.monthly AS FLOAT)) SSS "

		qry &= "ORDER BY PM.NTID,GOVT ;"

		'-------------------

		qry &= "INSERT INTO dbo.tbl_hrms_payroll_tax "

		qry &= "SELECT @cutoff_date [cutoff_date], "

		qry &= "pm.NTID [payid],"

		qry &= "total_salary.d [total_salary],"

		qry &= "case when taxable_amount.total_before_tax_deduct is null then 0 "
		qry &= "else taxable_amount.total_before_tax_deduct end [total_before_tax_deduction],"

		qry &= "case when taxable_amount.d IS null then 0 "
		qry &= "else taxable_amount.d end [taxable_amount],"

		qry &= "BRACKET.d [bracket],"
		qry &= "TAXOVER.d [over_percent],"
		qry &= "TAXINITIAL.d [initial],"

		qry &= "case when OVER_AMOUNT.d IS NULL then 0 "
		qry &= "else OVER_AMOUNT.d end [over_amount],"

		qry &= "case when TAXINITIAL.d + OVER_AMOUNT.d is null then 0 "
		qry &= "else TAXINITIAL.d + OVER_AMOUNT.d end [deduction] "

		qry &= "FROM tbl_HRMS_PayslipMaster PM join tbl_HRMS_Employee_Pay EP "

		qry &= "on pm.NTID = ep.ntid "

		qry &= "OUTER APPLY("
		qry &= "Select "
		qry &= "CAST(PM.reg AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.rest AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.spchld AS DECIMAL(9,2)) +  "
		qry &= "CAST(PM.rest_spday AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.reg_hld AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.restday_reghld AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.reg_ot AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.rest_ot AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.nd_reg AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.nd_rest AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.nd_hrd AS DECIMAL(9,2)) + "
		qry &= "CAST(PM.nd_spc AS DECIMAL(9,2)) [d] "
		qry &= ") total_salary "

		qry &= "OUTER APPLY("

		qry &= "SELECT CAST(total_salary.d AS DECIMAL(9,2)) - d [d],"
		qry &= "d [total_before_tax_deduct] "
		qry &= "FROM ("
		qry &= "SELECT SUM(CAST(deduct_cost AS DECIMAL(9,2))) [d] "
		qry &= "FROM tbl_hrms_Adjustments "
		qry &= "WHERE payid = pm.NTID AND cutoff_date = @cutoff_date "
		qry &= ") BEFORE_TAX	"
		qry &= ") taxable_amount "

		qry &= "OUTER APPLY("
		qry &= "Select top 1 * from dbo.tbl_hrms_taxTable "
		qry &= "where (EP.tax_status = 'Z' AND Z <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'S' AND S <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'ME' AND ME <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'ME1' AND ME1 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'ME2' AND ME2 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'ME3' AND ME3 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'ME4' AND ME4 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'S1' AND S1 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'S2' AND S2 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'S3' AND S3 <= CAST(taxable_amount.d as float) OR "
		qry &= "EP.tax_status = 'S4' AND S4 <= CAST(taxable_amount.d as float)) order by id desc "
		qry &= ") TAX "

		qry &= "OUTER APPLY(Select top 1 * from dbo.tbl_hrms_taxTable  where id = 9) MaxTax "
		qry &= "OUTER APPLY(Select top 1 * from dbo.tbl_hrms_taxTable  where id = 2) MinTax "

		qry &= "OUTER APPLY(SELECT CASE "
		qry &= "WHEN EP.tax_status = 'Z' THEN "
		qry &= "case when TAX.Z IS null then MinTax.Z "
		qry &= "else case when tax.id = 10 then MaxTax.Z else tax.Z "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'S' THEN "
		qry &= "case when TAX.S IS null then MinTax.S "
		qry &= "else case when tax.id = 10 then MaxTax.S else tax.S "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'ME' THEN "
		qry &= "case when TAX.ME IS null then MinTax.ME "
		qry &= "else case when tax.id = 10 then MaxTax.ME else tax.ME "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'ME1' THEN "
		qry &= "case when TAX.ME1 IS null then MinTax.ME1 "
		qry &= "else case when tax.id = 10 then MaxTax.ME1 else tax.ME1 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'ME2' THEN "
		qry &= "case when TAX.ME2 IS null then MinTax.ME2 "
		qry &= "else case when tax.id = 10 then MaxTax.ME2 else tax.ME2 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'ME3' THEN "
		qry &= "case when TAX.ME3 IS null then MinTax.ME3 "
		qry &= "else case when tax.id = 10 then MaxTax.ME3 else tax.ME3 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'ME4' THEN "
		qry &= "case when TAX.ME4 IS null then MinTax.ME4 "
		qry &= "else case when tax.id = 10 then MaxTax.ME4 else tax.ME4 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'S1' THEN "
		qry &= "case when TAX.S1 IS null then MinTax.S1 "
		qry &= "else case when tax.id = 10 then MaxTax.S1 else tax.S1 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'S2' THEN "
		qry &= "case when TAX.S2 IS null then MinTax.S2 "
		qry &= "else case when tax.id = 10 then MaxTax.S2 else tax.S2 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'S3' THEN "
		qry &= "case when TAX.S3 IS null then MinTax.S3 "
		qry &= "else case when tax.id = 10 then MaxTax.S3 else tax.S3 "
		qry &= "end end "

		qry &= "WHEN EP.tax_status = 'S4' THEN "
		qry &= "case when TAX.S4 IS null then MinTax.S4 "
		qry &= "else case when tax.id = 10 then MaxTax.S4 else tax.S4 "
		qry &= "end end "

		qry &= "END [d]) BRACKET "

		qry &= "OUTER APPLY(select case when TAX.[+Over] is null then "
		qry &= "Mintax.[+Over] "
		qry &= "else "
		qry &= "case when TAX.id = 10 then  maxTax.[+Over]	else TAX.[+Over] end "
		qry &= "end [d]) TAXOVER "

		qry &= "OUTER APPLY(select case when TAX.initial is null then 	MinTax.initial "
		qry &= "else "
		qry &= "case when tax.id=10 then maxtax.initial "
		qry &= "else TAX.initial end "
		qry &= "end [d]) TAXINITIAL "

		qry &= "OUTER APPLY(SELECT "
		qry &= "CAST((CAST(taxable_amount.d AS DECIMAL(9,2)) - CAST(BRACKET.d AS DECIMAL(9,2))) * CAST((SUBSTRING(TAXOVER.d,1,LEN(TAXOVER.d)-1)) AS DECIMAL(9,2))/100 AS DECIMAL(9,2)) "
		qry &= "[d]) OVER_AMOUNT  where PM.cutoff_date = @cutoff_date; "

		qry = Replace(qry, "@cutoff_date", " '" & data.cutoff_date & "' ")

		Return qry

	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function viewPayslip(data As PayrollMasterClass) As PayrollMasterClass

		Dim cls As New clsConnection

		Dim qry As String = ""

		Dim da As New DataSet
		Dim dt As New DataTable
		qry = "select *,empID from dbo.tbl_HRMS_PayslipMaster a join dbo.tbl_HRMS_EmployeeMaster b on a.ntid = b.ntid where a.ntid = '" & data.ntid.Trim & "' and a.cutoff_date = '" & data.cutoff_date & "' order by payslip_id"


		da = cls.GetDataSet(qry)

		dt = da.Tables(0)

		Dim emps As New List(Of PayrollBreakdown)
		For i = 0 To dt.Rows.Count - 1
			Dim emp As New PayrollBreakdown

			emp.empId = dt.Rows(i)("empID")
			emp.ntid = dt.Rows(i)("NTID")
			emp.empname = dt.Rows(i)("EmpName")
			emp.cutoff_date = dt.Rows(i)("cutoff_date")

			emp.tax_status = dt.Rows(i)("tax_status")
			emp.monthly_rate = FormatNumber(dt.Rows(i)("monthly"), 2)


			emp.semi_rate = FormatNumber(dt.Rows(i)("semi_monthly"), 2)
			emp.daily_rate = FormatNumber(dt.Rows(i)("daily"), 2)
			emp.hourly_rate = FormatNumber(dt.Rows(i)("hourly"), 2)

			emp.reg = FormatNumber(dt.Rows(i)("reg"), 2)
			emp.restday = FormatNumber(dt.Rows(i)("rest"), 2)
			emp.spchld = FormatNumber(dt.Rows(i)("spchld"), 2)
			emp.rd_spchld = FormatNumber(dt.Rows(i)("rest_spday"), 2)

			emp.reghld = FormatNumber(dt.Rows(i)("reg_hld"), 2)
			emp.rd_reghld = FormatNumber(dt.Rows(i)("restday_reghld"), 2)
			emp.regOt = FormatNumber(dt.Rows(i)("reg_ot"), 2)
			emp.spc_rh_res_OT = FormatNumber(dt.Rows(i)("rest_ot"), 2)
			emp.ndReg = FormatNumber(dt.Rows(i)("nd_reg"), 2)
			emp.nd_spc_rh_rest = FormatNumber(dt.Rows(i)("nd_rest"), 2)
			emp.nd_rd_rhd = FormatNumber(dt.Rows(i)("nd_hrd"), 2)
			emp.nd_rd_spc = FormatNumber(dt.Rows(i)("nd_spc"), 2)



			emp.reg_hrs = FormatNumber(dt.Rows(i)("reg_hrs"), 2)
			emp.restday_hrs = FormatNumber(dt.Rows(i)("rest_hrs"), 2)
			emp.spchld_hrs = FormatNumber(dt.Rows(i)("spchld_hrs"), 2)
			emp.rd_spchld_hrs = FormatNumber(dt.Rows(i)("rest_spday_hrs"), 2)

			emp.reghld_hrs = FormatNumber(dt.Rows(i)("reg_hld_hrs"), 2)
			emp.rd_reghld_hrs = FormatNumber(dt.Rows(i)("restday_reghld_hrs"), 2)

			emp.regOt_hrs = FormatNumber(dt.Rows(i)("reg_ot_hrs"), 2)
			emp.spc_rh_res_OT_hrs = FormatNumber(dt.Rows(i)("rest_ot_hrs"), 2)

			emp.ndReg_hrs = FormatNumber(dt.Rows(i)("nd_reg_hrs"), 2)
			emp.nd_spc_rh_rest_hrs = FormatNumber(dt.Rows(i)("nd_rest_hrs"), 2)

			emp.nd_rd_rhd_hrs = FormatNumber(dt.Rows(i)("nd_hrd_hrs"), 2)
			emp.nd_rd_spc_hrs = FormatNumber(dt.Rows(i)("nd_spc_hrs"), 2)

			emp.total_salary = FormatNumber(CDbl(emp.reg) + CDbl(emp.restday) + CDbl(emp.spchld) + CDbl(emp.rd_spchld) + CDbl(emp.reghld) + CDbl(emp.rd_reghld) + CDbl(emp.regOt) + CDbl(emp.spc_rh_res_OT) + CDbl(emp.ndReg) + CDbl(emp.nd_spc_rh_rest) + CDbl(emp.nd_rd_rhd) + CDbl(emp.nd_rd_spc), 2)


			Dim adj As New Adjustments_Data

			adj.total_salary = emp.total_salary
			adj.tax_status = emp.tax_status
			adj.basic_salary = emp.monthly_rate
			adj.cutoff_date = emp.cutoff_date
			adj.payid = emp.ntid

			Dim gen_adj = New generate_adjustments

			gen_adj = get_adjustments(adj)


			emp.adjustments = gen_adj.adjustments

			emp.total_before_tax_deduct = FormatNumber(gen_adj.total_before_tax_deduct, 2)
			emp.taxable_amount = FormatNumber(gen_adj.taxable_amount, 2)
			emp.tax_bracket = FormatNumber(gen_adj.tax_bracket, 2)
			emp.tax_over = gen_adj.tax_over_prcnt
			emp.tax_initial = FormatNumber(gen_adj.tax_initial, 2)
			emp.tax_over_amt = FormatNumber(gen_adj.tax_over_amount, 2)
			emp.tax_deduction = FormatNumber(gen_adj.tax_deduction, 2)

			emp.net_pay = FormatNumber(CDbl(emp.taxable_amount) - CDbl(emp.tax_deduction), 2)

			emps.Add(emp)

		Next

		data.tblPayrollBreakdown = emps

		Return data
	End Function

	Shared Function get_adjustments(data As Adjustments_Data) As generate_adjustments
		Dim cls As New clsConnection
		Dim qry As String = ""

		Dim dt As New DataTable

		Dim gen_adj As New generate_adjustments

		Dim adjustments As New List(Of adjustment_table)
		Dim total_before_tax_deduct As Double = 0

		Dim da As New DataSet

		qry = "select * from dbo.tbl_hrms_Adjustments where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.payid & "';"
		qry &= "select * from tbl_hrms_payroll_tax where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.payid & "';"
		da = cls.GetDataSet(qry)

		dt = da.Tables(0)

		For i = 0 To dt.Rows.Count - 1
			Dim adjustment As New adjustment_table

			adjustment = New adjustment_table

			adjustment.cutoff_date = dt.Rows(i)(1)
			adjustment.payid = dt.Rows(i)(2)
			adjustment.deduct_desc = dt.Rows(i)(3)
			adjustment.deduct_cost = FormatNumber(dt.Rows(i)(4), 2)

			adjustments.Add(adjustment)

		Next

		gen_adj.adjustments = adjustments

		dt = da.Tables(1)

		gen_adj.total_before_tax_deduct = dt.Rows(0)(4)

		gen_adj.taxable_amount = dt.Rows(0)(5)

		gen_adj.tax_bracket = dt.Rows(0)(6)
		gen_adj.tax_over_prcnt = dt.Rows(0)(7)

		gen_adj.tax_initial = dt.Rows(0)(8)

		gen_adj.tax_over_amount = dt.Rows(0)(9)
		gen_adj.tax_deduction = dt.Rows(0)(10)

		Return gen_adj
	End Function

	'Protected Sub btnCreate_Click(sender As Object, e As EventArgs)
	'    Try
	'        Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")
	'        Dim pdfReader As New PdfReader(Server.MapPath("~/pdf/Template.pdf"))

	'        Using stream As New FileStream(String.Concat(Server.MapPath("~/export/"), filename), FileMode.Create)
	'            Dim pdfStamper As New PdfStamper(pdfReader, stream)

	'            Dim formFields As AcroFields = pdfStamper.AcroFields
	'            formFields.SetField("txtForename", txtForename.Text.Trim())
	'            formFields.SetField("txtSurname", txtSurname.Text.Trim())

	'            pdfStamper.FormFlattening = True
	'            pdfStamper.Close()

	'            Dim script As String = String.Format("window.open('{0}');", String.Concat("/export/", filename))
	'            ClientScript.RegisterClientScriptBlock(Me.[GetType](), "newPDF", script, True)
	'        End Using
	'    Catch ex As Exception
	'        lblMessage.Text = ex.Message
	'    End Try

	'End Sub

	'Protected Sub btnGenerate_Click(sender As Object, e As EventArgs)
	'    Try
	'        Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")
	'        Dim pdfReader As New PdfReader(Server.MapPath("~/pdf/Template.pdf"))

	'        Using stream As New MemoryStream()
	'            Dim pdfStamper As New PdfStamper(pdfReader, stream)

	'            Dim formFields As AcroFields = pdfStamper.AcroFields
	'            formFields.SetField("txtForename", txtForename.Text.Trim())
	'            formFields.SetField("txtSurname", txtSurname.Text.Trim())

	'            pdfStamper.FormFlattening = True
	'            pdfStamper.Writer.CloseStream = False
	'            pdfStamper.Close()

	'            Response.ContentType = "application/pdf"
	'            Response.AddHeader("Content-disposition", String.Format("attachment; filename={0};", filename))
	'            stream.WriteTo(Response.OutputStream)
	'        End Using
	'    Catch ex As Exception
	'        lblMessage.Text = ex.Message
	'    End Try
	'End Sub

	<WebMethod(EnableSession:=True)> _
	Public Shared Function viewPSPDF(data As viewPSPDF) As String
		'Dim filename As String = fn & ".pdf"
		'Dim rt As String = HttpContext.Current.Server.MapPath(filename)

		'Dim fs As New FileStream(rt, FileMode.Create, FileAccess.Write, FileShare.None)

		'Dim doc As New Document()

		'Dim writer As PdfWriter = PdfWriter.GetInstance(doc, fs)

		'doc.Open()
		'doc.Add(New Paragraph("Hello Altisource!"))
		'doc.Close()
		'Dim filename As String = ""

		Try
			Dim filename As String = String.Concat(Guid.NewGuid().ToString(), ".pdf")
			Dim pdfReader As New PdfReader(HttpContext.Current.Server.MapPath("~/PDF Template/PaySlip.pdf"))

			Using stream As New FileStream(String.Concat(HttpContext.Current.Server.MapPath("~/PDF Export/"), filename), FileMode.Create)
				Dim pdfStamper As New PdfStamper(pdfReader, stream)


				Dim cls As New clsConnection
				Dim da As New DataSet
				Dim emp As New DataTable, pay As New DataTable, slip As New DataTable, adj As New DataTable, tax As New DataTable, tSalary As New DataTable

				Dim qry = "Select *,govt.PagIbig,govt.PhilHealth,govt.SSS,govt.TIN from dbo.tbl_HRMS_EmployeeMaster a outer apply(select * from tbl_HRMS_Employee_ConfidentialInfo where NTID = a.NTID) govt where a.empid = '" & data.eid & "';"
				qry &= "select * from dbo.tbl_HRMS_PayslipMaster where cutoff_date = '" & data.cutoff_date & "' and ntid ='" & data.ntid & "';"
				qry &= "select * from dbo.tbl_HRMS_Employee_Pay where ntid = '" & data.ntid & "';"
				qry &= "select * from dbo.tbl_hrms_Adjustments where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.ntid & "';"
				qry &= "select * from dbo.tbl_hrms_payroll_tax where cutoff_date = '" & data.cutoff_date & "' and payid = '" & data.ntid & "';"

				qry &= "select payday, reg [txttbs], 0.00 [txttnta],nd_reg [txttrnd],reg_hld [txttrh],nd_rest+nd_hrd [txttrhnd],0.00 [txttpto],reg_ot+rest_ot+rest[txttro],restday_reghld[txttrhot],spchld[txttsh],rest_spday[txttshot],nd_spc[txttshnd],reg+rest+spchld+rest_spday+reg_hld+restday_reghld+reg_ot+rest_ot+nd_reg+nd_rest+nd_hrd+nd_spc [txtttotalsal]"
				qry &= "from("
				qry &= "select payday,ntid, SUM(CAST(reg as float))[reg], "
				qry &= "SUM(CAST(rest as float))[rest],"
				qry &= "SUM(CAST(spchld as float))[spchld],"
				qry &= "SUM(CAST(rest_spday as float))[rest_spday],"
				qry &= "SUM(CAST(reg_hld as float))[reg_hld],"
				qry &= "SUM(CAST(restday_reghld as float))[restday_reghld],"
				qry &= "SUM(CAST(reg_ot as float))[reg_ot],"
				qry &= "SUM(CAST(rest_ot as float))[rest_ot],"
				qry &= "SUM(CAST(nd_reg as float))[nd_reg],"
				qry &= "SUM(CAST(nd_rest as float))[nd_rest],"
				qry &= "SUM(CAST(nd_hrd as float))[nd_hrd],"
				qry &= "SUM(CAST(nd_spc as float))[nd_spc]"
				qry &= "from tbl_HRMS_PayslipMaster where ntid = '" & data.ntid & "' and cutoff_date = '" & data.cutoff_date & "' group by ntid,payday) tot;"

				qry &= "select payid,deduct_desc, SUM(CAST(deduct_cost as float))[TotalContrib] from dbo.tbl_hrms_Adjustments where payid='" & data.ntid & "' and cutoff_date = '" & data.cutoff_date & "' group by payid,deduct_desc order by payid;"

				qry &= "select payid,txttwtax,case when txttenetpay <0 then 0 else txttenetpay end [txttenetpay] from("
				qry &= "select payid, SUM(CAST(deduction as float)) [txttwtax], "
				qry &= "SUM(CAST(taxable_amount as float)-CAST(deduction as float))[txttenetpay] "
				qry &= "from tbl_hrms_payroll_tax where payid='" & data.ntid & "' and cutoff_date = '" & data.cutoff_date & "' group by payid) tax;"

				da = cls.GetDataSet(qry)
				emp = da.Tables(0) : slip = da.Tables(1) : pay = da.Tables(2) : adj = da.Tables(3) : tax = da.Tables(4) : tSalary = da.Tables(5)

				Dim total_salary As String = CDbl(slip.Rows(0)("reg")) + CDbl(slip.Rows(0)("rest")) + CDbl(slip.Rows(0)("spchld")) + CDbl(slip.Rows(0)("rest_spday")) + CDbl(slip.Rows(0)("reg_hld")) + CDbl(slip.Rows(0)("restday_reghld")) + CDbl(slip.Rows(0)("reg_ot")) + CDbl(slip.Rows(0)("rest_ot")) + CDbl(slip.Rows(0)("nd_reg")) + CDbl(slip.Rows(0)("nd_rest")) + CDbl(slip.Rows(0)("nd_hrd")) + CDbl(slip.Rows(0)("nd_spc"))

				Dim formFields As AcroFields = pdfStamper.AcroFields

				formFields.SetField("untitled32", emp.Rows(0)("JobDesc").ToString.Trim())
				formFields.SetField("untitled33", emp.Rows(0)("EmpName").ToString.Trim())
				formFields.SetField("txtempid", data.eid)

				formFields.SetField("txtjoined", DateValue(emp.Rows(0)("DateJoined")).ToString("MM/dd/yyyy"))
				'formFields.SetField("txtresigned", "--")

				formFields.SetField("txtpagibig", IIf(IsDBNull(emp.Rows(0)("PAGIBIG")), "--", emp.Rows(0)("PAGIBIG")))
				formFields.SetField("txtph", IIf(IsDBNull(emp.Rows(0)("PhilHealth")), "--", emp.Rows(0)("PhilHealth")))
				formFields.SetField("txtsss", IIf(IsDBNull(emp.Rows(0)("SSS")), "--", emp.Rows(0)("SSS")))
				formFields.SetField("txttax", IIf(IsDBNull(emp.Rows(0)("TIN")), "--", emp.Rows(0)("TIN")))

				formFields.SetField("txtPayPeriod", data.cutoff_date)

				formFields.SetField("txtpayday", tSalary.Rows(0)("payday"))

				formFields.SetField("txthourly", FormatNumber(pay.Rows(0)("hourly").ToString.Trim(), 2))
				formFields.SetField("txtcat", pay.Rows(0)("tax_status").ToString.Trim())


				formFields.SetField("txtbasic", FormatNumber(slip.Rows(0)("reg"), 2))
				formFields.SetField("txtnontax", "0.00")

				formFields.SetField("txtrdnd", FormatNumber(slip.Rows(0)("nd_reg"), 2))
				formFields.SetField("txtrh", FormatNumber(slip.Rows(0)("reg_hld"), 2))
				formFields.SetField("txtrhnd", FormatNumber(CDbl(slip.Rows(0)("nd_rest")) + CDbl(slip.Rows(0)("nd_hrd")), 2))

				formFields.SetField("txtpto", "0.00")

				formFields.SetField("txtreghld", FormatNumber(CDbl(slip.Rows(0)("reg_ot")) + CDbl(slip.Rows(0)("rest_ot")) + CDbl(slip.Rows(0)("rest")), 2))
				formFields.SetField("txtreghldOT", FormatNumber(slip.Rows(0)("restday_reghld"), 2))
				formFields.SetField("txtspcl", FormatNumber(slip.Rows(0)("spchld"), 2))
				formFields.SetField("txtspclOT", FormatNumber(slip.Rows(0)("rest_spday"), 2))
				formFields.SetField("txtspclnd", FormatNumber(slip.Rows(0)("nd_spc"), 2))

				If slip.Rows(0)("reg_hrs") > 0 Then formFields.SetField("txtbasichr", "(" & FormatNumber(slip.Rows(0)("reg_hrs"), 2) & ")") Else formFields.SetField("txtbasichr", "")
				'formFields.SetField("txtnontaxhrs", "(" & FormatNumber(0, 2) & ")")

				If slip.Rows(0)("nd_reg_hrs") > 0 Then formFields.SetField("txtregNDhrs", "(" & FormatNumber(slip.Rows(0)("nd_reg_hrs"), 2) & ")") Else formFields.SetField("txtregNDhrs", "")
				If slip.Rows(0)("reg_hld_hrs") > 0 Then formFields.SetField("txtregHhrs", "(" & FormatNumber(slip.Rows(0)("reg_hld_hrs"), 2) & ")") Else formFields.SetField("txtregHhrs", "")
				If CDbl(slip.Rows(0)("nd_rest_hrs")) + CDbl(slip.Rows(0)("nd_hrd_hrs")) > 0 Then formFields.SetField("txtregHNdHrs", "(" & FormatNumber(CDbl(slip.Rows(0)("nd_rest_hrs")) + CDbl(slip.Rows(0)("nd_hrd_hrs")), 2) & ")") Else formFields.SetField("txtregHNdHrs", "")

				If CDbl(slip.Rows(0)("reg_ot_hrs")) + CDbl(slip.Rows(0)("rest_ot_hrs")) + CDbl(slip.Rows(0)("rest_hrs")) > 0 Then formFields.SetField("txtRegOverT", "(" & FormatNumber(CDbl(slip.Rows(0)("reg_ot_hrs")) + CDbl(slip.Rows(0)("rest_ot_hrs")) + CDbl(slip.Rows(0)("rest_hrs")), 2) & ")") Else formFields.SetField("txtRegOverT", "")
				If slip.Rows(0)("restday_reghld_hrs") Then formFields.SetField("txtregHOtHrs", "(" & FormatNumber(slip.Rows(0)("restday_reghld_hrs"), 2) & ")") Else formFields.SetField("txtregHOtHrs", "")
				If slip.Rows(0)("spchld_hrs") > 0 Then formFields.SetField("txtspclHolHrs", "(" & FormatNumber(slip.Rows(0)("spchld_hrs"), 2) & ")") Else formFields.SetField("txtspclHolHrs", "")
				If slip.Rows(0)("rest_spday_hrs") > 0 Then formFields.SetField("txtspclHolOOTHrs", "(" & FormatNumber(slip.Rows(0)("rest_spday_hrs"), 2) & ")") Else formFields.SetField("txtspclHolOOTHrs", "")
				If slip.Rows(0)("nd_spc_hrs") > 0 Then formFields.SetField("txtspclHolNDHrs", "(" & FormatNumber(slip.Rows(0)("nd_spc_hrs"), 2) & ")") Else formFields.SetField("txtspclHolNDHrs", "")


				formFields.SetField("txtTotalSalary", FormatNumber(total_salary, 2))

				For i = 0 To adj.Rows.Count - 1
					If adj.Rows(i)(3) = "Employee HDMF" Then formFields.SetField("txthdmf", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
					If adj.Rows(i)(3) = "Employee PhilHealth" Then formFields.SetField("txteph", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
					If adj.Rows(i)(3) = "Employee Social Security" Then formFields.SetField("txtesss", "(" & FormatNumber(adj.Rows(i)(4), 2) & ")")
				Next

				formFields.SetField("txtwighTax", "(" & FormatNumber(tax.Rows(0)("deduction"), 2) & ")")
				formFields.SetField("txtnetpay", FormatNumber(CDbl(tax.Rows(0)("taxable_amount")) - CDbl(tax.Rows(0)("deduction")), 2))

				formFields.SetField("txttbs", FormatNumber(tSalary.Rows(0)("txttbs"), 2))
				formFields.SetField("txttnta", FormatNumber(tSalary.Rows(0)("txttnta"), 2))
				formFields.SetField("txttrnd", FormatNumber(tSalary.Rows(0)("txttrnd"), 2))
				formFields.SetField("txttrh", FormatNumber(tSalary.Rows(0)("txttrh"), 2))
				formFields.SetField("txttrhnd", FormatNumber(tSalary.Rows(0)("txttrhnd"), 2))
				formFields.SetField("txttpto", FormatNumber(tSalary.Rows(0)("txttpto"), 2))
				formFields.SetField("txttro", FormatNumber(tSalary.Rows(0)("txttro"), 2))
				formFields.SetField("txttrhot", FormatNumber(tSalary.Rows(0)("txttrhot"), 2))
				formFields.SetField("txttsh", FormatNumber(tSalary.Rows(0)("txttsh"), 2))
				formFields.SetField("txttshot", FormatNumber(tSalary.Rows(0)("txttshot"), 2))
				formFields.SetField("txttshnd", FormatNumber(tSalary.Rows(0)("txttshnd"), 2))
				formFields.SetField("txtttotalsal", FormatNumber(tSalary.Rows(0)("txtttotalsal"), 2))

				tSalary.Dispose() : tSalary = da.Tables(6)

				For i = 0 To tSalary.Rows.Count - 1
					If tSalary.Rows(i)(1) = "Employee HDMF" Then formFields.SetField("txttehdmf", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
					If tSalary.Rows(i)(1) = "Employee PhilHealth" Then formFields.SetField("txtteph", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
					If tSalary.Rows(i)(1) = "Employee Social Security" Then formFields.SetField("txttsss", "(" & FormatNumber(tSalary.Rows(i)(2), 2) & ")")
				Next

				tSalary.Dispose() : tSalary = da.Tables(7)

				formFields.SetField("txttwtax", "(" & FormatNumber(tSalary.Rows(0)("txttwtax"), 2) & ")")
				formFields.SetField("txttenetpay", FormatNumber(tSalary.Rows(0)("txttenetpay"), 2))

				formFields.SetField("txtemplyrHDMF", "0.00")
				formFields.SetField("txtemplyrPH", "0.00")
				formFields.SetField("txtemplyrSSS", "0.00")
				formFields.SetField("txtemplyrSSSEC", "0.00")

				formFields.SetField("txtemplyrtHDMF", "0.00")
				formFields.SetField("txtemplyrtPH", "0.00")
				formFields.SetField("txtemplyrtSSS", "0.00")
				formFields.SetField("txtemplyrtSSSEC", "0.00")

				'formFields.SetField("txtcat", "")
				pdfStamper.FormFlattening = True
				pdfStamper.Close()

				emp.Dispose() : pay.Dispose() : slip.Dispose() : adj.Dispose() : tax.Dispose() : tSalary.Dispose() : da.Dispose()

				'Dim script As String = String.Format("window.open('{0}');", String.Concat("/export/", filename))
				'ClientScript.RegisterClientScriptBlock(Me.[GetType](), "newPDF", script, True)

				Return String.Concat("PDF Export/", filename)
			End Using
		Catch ex As Exception
			Debug.WriteLine(ex.HResult)
			Return ex.ToString
		End Try

	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function processedData(data As PayrollMasterClass) As PayrollMasterClass

		Dim cls As New clsConnection

		Dim qry As String = ""

		Dim da As New DataSet
		Dim dt As New DataTable

		'Dim data As New PayrollMasterClass
		'qry &= tbl_PayrollHours(Data.dtfrom, Data.dtto)

		'qry &= tbl_PaySlipMaster(Data.dtfrom, Data.dtto)

		qry = "select *,empID from dbo.tbl_HRMS_PayslipMaster a join dbo.tbl_HRMS_EmployeeMaster b on a.ntid = b.ntid " & _
			" where businessSegment = '" & data.bs & "' and payday = '" & data.pyday & "' "

		'If data.bu <> "" Then
		'	qry &= " and businessUnit = '" & data.bu & "' "
		'End If

		If data.bu <> "" Then
			qry &= " and businessUnit = '" & data.bu & "' "
		End If

		If data.elvl = "TA" Then

			qry &= " and empLevel not in ('EE') "


		ElseIf data.elvl <> "" Then
			qry &= " and empLevel = '" & data.elvl & "' "
		End If

		qry &= " order by b.businessSegment, b.businessUnit, a.payslip_id"

		da = cls.GetDataSet(qry)

		dt = da.Tables(0)


		Dim emps As New List(Of PayrollBreakdown)

		data.fCount = dt.Rows.Count

		For i = 0 To dt.Rows.Count - 1
			Dim emp As New PayrollBreakdown

			emp.bs = dt.Rows(i)("BusinessSegment")
			emp.bu = dt.Rows(i)("BusinessUnit")
			emp.elvl = dt.Rows(i)("EmpLevel")

			emp.pyday = dt.Rows(i)("payday")
			emp.dtfrom = dt.Rows(i)("cutoff_from")
			emp.dtto = dt.Rows(i)("cutoff_to")
			emp.mcut = dt.Rows(i)("gmonth")
			emp.mcutoff = dt.Rows(i)("runindex")

			emp.empId = dt.Rows(i)("empID")
			emp.ntid = dt.Rows(i)("NTID")
			emp.empname = dt.Rows(i)("EmpName")

			emp.cutoff_date = dt.Rows(i)("cutoff_date")
			emp.tax_status = dt.Rows(i)("tax_status")
			emp.monthly_rate = dt.Rows(i)("monthly")

			emp.reg = FormatNumber(dt.Rows(i)("reg"), 2)
			emp.restday = FormatNumber(dt.Rows(i)("rest"), 2)
			emp.spchld = FormatNumber(dt.Rows(i)("spchld"), 2)
			emp.rd_spchld = FormatNumber(dt.Rows(i)("rest_spday"), 2)

			emp.reghld = FormatNumber(dt.Rows(i)("reg_hld"), 2)
			emp.rd_reghld = FormatNumber(dt.Rows(i)("restday_reghld"), 2)
			emp.regOt = FormatNumber(dt.Rows(i)("reg_ot"), 2)
			emp.spc_rh_res_OT = FormatNumber(dt.Rows(i)("rest_ot"), 2)
			emp.ndReg = FormatNumber(dt.Rows(i)("nd_reg"), 2)
			emp.nd_spc_rh_rest = FormatNumber(dt.Rows(i)("nd_rest"), 2)
			emp.nd_rd_rhd = FormatNumber(dt.Rows(i)("nd_hrd"), 2)
			emp.nd_rd_spc = FormatNumber(dt.Rows(i)("nd_spc"), 2)

			emp.com = "0.00"

			emp.total_salary = FormatNumber(CDbl(emp.reg) + CDbl(emp.restday) + CDbl(emp.spchld) + CDbl(emp.rd_spchld) + CDbl(emp.reghld) + CDbl(emp.rd_reghld) + CDbl(emp.regOt) + CDbl(emp.spc_rh_res_OT) + CDbl(emp.ndReg) + CDbl(emp.nd_spc_rh_rest) + CDbl(emp.nd_rd_rhd) + CDbl(emp.nd_rd_spc), 2)

			emps.Add(emp)

			'Dim adj As New Adjustments_Data

			'adj.total_salary = emp.total_salary
			'adj.tax_status = emp.tax_status
			'adj.basic_salary = emp.monthly_rate
			'adj.cutoff_date = emp.cutoff_date
			'adj.payid = emp.ntid

			'Dim gen_adj As New generate_adjustments
			'gen_adj =

			'generate_adjustments(adj)

			'govt_contribution
			'emp.adjustments = gen_adj.adjustments
			'emp.total_before_tax_deduct = gen_adj.total_before_tax_deduct
			'emp.taxable_amount = gen_adj.taxable_amount

		Next

		data.tblPayrollBreakdown = emps

		Return data
	End Function

	<WebMethod(EnableSession:=True)> _
	Public Shared Function deletePayroll(data As PayrollMasterClass) As Integer
		Dim cls As New clsConnection
		Dim qry As String = ""
		Dim rt As Integer
		qry = "delete tbl_hrms_Adjustments where cutoff_date = '" & data.cutoff_date & "';"
		qry &= "delete tbl_hrms_payroll_tax where cutoff_date = '" & data.cutoff_date & "';"
		qry &= "delete tbl_HRMS_PayslipMaster where cutoff_date = '" & data.cutoff_date & "';"
		rt = cls.ExecuteQuery(qry)
		Return rt
	End Function

End Class