﻿Imports System.Data
Imports System.Web.Services
Imports Newtonsoft.Json

Public Class News
    Inherits System.Web.UI.Page

    Dim cls As New clsConnection

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    '    If Not IsPostBack Then
    '        CreateNewsPanel()
    '    End If
    'End Sub

    <WebMethod>
    Public Shared Function CreateNewsPanel() As String
        Dim str As String = ""
        Dim sql As String = ""
        Dim cls As New clsConnection
        Dim dtNews As New DataTable

        sql = "select * from dbo.tbl_HRMS_News where RemoveBy is null"

        Try
            dtNews = cls.GetData(sql)

            If dtNews.Rows.Count > 0 Then
                For x As Integer = 0 To dtNews.Rows.Count - 1
                    str &= "<li class='news-item'>"
                    str &= "<table cellpadding='4'>"
                    str &= "<tr>"
                    str &= "<td>"
                    str &= "<img src='" & dtNews.Rows(x)("imgNews") & "' width='60' height='60' class='img-circle' /></td>"
                    str &= "<td>" & dtNews.Rows(x)("newsSubject") & " &nbsp;<a data-src = """ & dtNews.Rows(x)("imgNews") & """ class=""readMore"" >Read more...</a></td>"
                    str &= "<tr>"
                    str &= "</table>"
                    str &= "</li>"
                Next

                'lt1.Text = str
            End If

            Return JsonConvert.SerializeObject(New With {Key .status = True, .message = "Success", Key .return = str})

        Catch ex As Exception

            Return JsonConvert.SerializeObject(New With {Key .status = False, .message = "Something went wrong: " & ex.Message})

        End Try
    End Function

End Class