﻿Imports System.Web
Imports System.Web.Services
Imports System.IO

Public Class SampleHandler
    Implements System.Web.IHttpHandler
    Implements IRequiresSessionState

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        'Dim dirFullPath As String = HttpContext.Current.Server.MapPath("~/news/images/")
        'Dim files As String()
        'Dim numFiles As Integer
        'files = System.IO.Directory.GetFiles(dirFullPath)
        'numFiles = files.Length
        'numFiles = numFiles + 1

        Dim str_image As String = ""
        Dim fileName As String
        Dim fileExtension As String
        Dim file_name As String = Trim(Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Millisecond.ToString)
        Dim pathToSave As String = ""
        For Each s As String In context.Request.Files
            Dim file As HttpPostedFile = context.Request.Files(s)
            '  int fileSizeInBytes = file.ContentLength;
            fileName = file.FileName
            fileExtension = file.ContentType

            If Not String.IsNullOrEmpty(fileName) Then
                fileExtension = Path.GetExtension(fileName)
                str_image = Convert.ToString(file_name) & fileExtension
                'pathToSave_100 = HttpContext.Current.Server.MapPath("~/news/images/") & str_image
                'pathToSave = "~\news\images\HRMSImages\" & str_image
                'Dim myrul As String = HttpContext.Current.Request.Url.Authority
                'iframe.Attributes("src") = "http://" & myrul & "/newfolder1/HUD_Settlement_Statement_-_franz-108_West.pdf"

                'pathToSave = "http://" & myrul & "/news/images/" & str_image

                pathToSave = HttpContext.Current.Server.MapPath("~/news/images/") & str_image
                file.SaveAs(pathToSave)
            End If

        Next

        context.Response.ContentType = "text/plain"
        context.Session("ImageName") = pathToSave
        context.Response.Write(str_image)
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class