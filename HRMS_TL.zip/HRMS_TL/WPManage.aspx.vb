﻿Imports System.Data.SqlClient

Public Class WPManage
    Inherits System.Web.UI.Page

    Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
    Dim sqlConn As SqlConnection = New SqlConnection(connStr)

    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand

        Select Case e.CommandName
            Case "Delete"

                Dim cmdUpdate As New SqlCommand

                cmdUpdate.CommandText = "Delete tbl_HRMS_Functions where id = '" & e.CommandArgument & "'"

                cmdUpdate.Connection = sqlConn

                sqlConn.Open()
                cmdUpdate.ExecuteNonQuery()
                sqlConn.Close()

                'Alert("Deleted Successfully!")
                'ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
                '"javascript:alert('Successfully Deleted!');window.location.href = 'SegmentEditor.aspx';", True)

                ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
        "javascript:alert('Deleted!');window.location.href = 'WPManage.aspx';", True)
        End Select
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim str As String = ""

        If txtDesc.Text = "" Then str += "Description is blank!\n\n"
        If txtControl.Text = "" Then str += "Controlid is blank!\n\n"

        If str <> "" Then ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('" & str & "');", True) : Exit Sub

        Dim query As String = "insert into tbl_HRMS_Functions values ('" & txtDesc.Text.Trim & "','" & txtControl.Text.Trim & "')"

        Dim cmdUpdate As New SqlCommand

        cmdUpdate.CommandText = query

        cmdUpdate.Connection = sqlConn

        sqlConn.Open()
        cmdUpdate.ExecuteNonQuery()
        sqlConn.Close()


        ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
        "javascript:alert('Successfully Added!');window.location.href = 'WPManage.aspx';", True)
    End Sub
End Class