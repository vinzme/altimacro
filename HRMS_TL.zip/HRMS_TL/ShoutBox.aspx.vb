﻿Imports System.Data.SqlClient
Imports System.Data

Public Class ShoutBox
	Inherits System.Web.UI.Page

	Dim pubUser As String
	Dim cls As New clsConnection
	Dim strNTID As String

	Dim dtBSegment As New DataTable
	Dim dtBU As New DataTable
	Dim dtEmplevel As New DataTable
	Dim dtManager As New DataTable
	Dim dtMessage As New DataTable

	Dim connString As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connString)

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		If pubUser Is Nothing Then
			Session("page") = "~/ShoutBox.aspx"
			Response.Redirect("~/Home.aspx")
		End If

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		userNTID.Text = pubUser

		If Not IsPostBack Then
			txtEmployeeName.Attributes.Add("placeholder", "Search")
			PopulateBSegment()
			ddlBusinessUnit.Items.Add("--Select One Below--")
			PopulateLevel()
			ddlImmediateSuperior.Items.Add("--Select One Below--")
		End If

		'If IsPostBack Then
		'    Page.ClientScript.RegisterStartupScript(Me.GetType(), "IsPostBack", "var isPostBack = true;", True)
		'End If
	End Sub

	Private Sub PopulateBSegment()
		Dim query As String

		query = "select Distinct BusinessSegment from tbl_HRMS_EmployeeMaster (nolock) order by BusinessSegment"

		dtBSegment = cls.GetData(query)

		ddlBusinessSegment.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtBSegment.Rows.Count - 1
			ddlBusinessSegment.Items.Add(dtBSegment.Rows(x)("BusinessSegment"))
		Next
	End Sub

	Private Sub PopulateBU()
		Dim query As String

		query = "select Distinct BusinessUnit from tbl_HRMS_EmployeeMaster (nolock) where BusinessUnit is not null and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' order by BusinessUnit"

		dtBU = cls.GetData(query)

		ddlBusinessUnit.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtBU.Rows.Count - 1
			ddlBusinessUnit.Items.Add(dtBU.Rows(x)("BusinessUnit"))
		Next
	End Sub

	Private Sub PopulateLevel()

		ddlEmpLevel.Items.Add("--Select One Below--")
		ddlEmpLevel.Items.Add("VP")
		ddlEmpLevel.Items.Add("DIR")
		ddlEmpLevel.Items.Add("MGR")
		ddlEmpLevel.Items.Add("SR. MGR")
		ddlEmpLevel.Items.Add("AM")
		ddlEmpLevel.Items.Add("TL")
		ddlEmpLevel.Items.Add("EE")

	End Sub

	Private Sub PopulateManager()
		Dim empLevel As String
		Dim levels As String = ""

		Dim sb1 As New StringBuilder

		sb1.Append("select Distinct  ")
		sb1.Append("MngrNTID  ")
		sb1.Append("from tbl_HRMS_EmployeeMaster (nolock)  ")
		sb1.Append("where  ")

		If ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below--" Then
			sb1.Append("EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' and ")
		End If

		sb1.Append("BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' and ")
		sb1.Append("MngrNTID is not null ")
		sb1.Append("order by  ")
		sb1.Append("MngrNTID ")

		empLevel = sb1.ToString()

		dtEmplevel = cls.GetData(empLevel)

		For x As Integer = 0 To dtEmplevel.Rows.Count - 1
			If x = dtEmplevel.Rows.Count - 1 Then
				levels += "'" & dtEmplevel.Rows(x)("MngrNTID") & "'"
			Else
				levels += "'" & dtEmplevel.Rows(x)("MngrNTID") & "',"
			End If
		Next

		Dim query As String

		Dim sb2 As New StringBuilder

		sb2.Append("select ")
		sb2.Append("EmpName, ")
		sb2.Append("EmpLevel ")
		sb2.Append("from tbl_HRMS_EmployeeMaster (nolock) ")
		sb2.Append("where ")
		sb2.Append("NTID in (" & levels.Trim & ")")
		sb2.Append("order by ")
		sb2.Append("EmpName ")

		query = sb2.ToString()

		dtManager = cls.GetData(query)

		ddlImmediateSuperior.Items.Add("--Select One Below--")
		For x As Integer = 0 To dtManager.Rows.Count - 1
			ddlImmediateSuperior.Items.Add(dtManager.Rows(x)("EmpName"))
		Next
	End Sub

	Private Sub ddlBusinessSegment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessSegment.SelectedIndexChanged
		ddlBusinessUnit.Items.Clear()
		PopulateBU()
	End Sub

	Private Sub ddlBusinessUnit_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlBusinessUnit.SelectedIndexChanged
		'ddlEmpLevel.Items.Clear()
		'PopulateLevel()
		ddlImmediateSuperior.Items.Clear()
		PopulateManager()
	End Sub

	Private Sub ddlEmpLevel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlEmpLevel.SelectedIndexChanged
		ddlImmediateSuperior.Items.Clear()
		PopulateManager()
	End Sub

	Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
		Dim sb As New StringBuilder
		Dim sb2 As New StringBuilder

		sb.Append("select  ")
		sb.Append("EmpName,  ")
		sb.Append("JobDesc,  ")
		sb.Append("NTID  ")
		sb.Append("from tbl_HRMS_EmployeeMaster ")
		sb2.Append("where ")
		sb2.Append("NTID is not null ")
		If txtEmployeeName.Text.Trim <> "" Then
			sb2.Append("and Empname like '%" & txtEmployeeName.Text.Trim & "%' ")
		End If
		If ddlBusinessSegment.SelectedItem.Text <> "--Select One Below--" Then
			sb2.Append("and BusinessSegment = '" & ddlBusinessSegment.SelectedItem.Text.Trim & "' ")
		End If
		If ddlBusinessUnit.SelectedItem.Text.Trim <> "--Select One Below--" Then
			sb2.Append("and BusinessUnit = '" & ddlBusinessUnit.SelectedItem.Text.Trim & "' ")
		End If

		If ddlEmpLevel.SelectedItem.Text.Trim <> "--Select One Below--" Then
			sb2.Append("and EmpLevel = '" & ddlEmpLevel.SelectedItem.Text.Trim & "' ")
		End If

		If ddlImmediateSuperior.SelectedItem.Text.Trim <> "--Select One Below--" Then
			sb2.Append("and MngrName = '" & ddlImmediateSuperior.SelectedItem.Text.Trim & "' ")
		End If

		If sb2.Length > 0 Then
			sb.Append(sb2.ToString())
		End If
		sb.Append("order by ")
		sb.Append("EmpName ")

		'Dim query As String

		'query = sb.ToString()

		newMsgDatasource.SelectCommand = sb.ToString()
		newMsgDatasource.DataBind()
	End Sub

	Private Sub btnSubmitMsg_Click(sender As Object, e As EventArgs) Handles btnSubmitMsg.Click

		Dim cmdInsert As New SqlCommand

		For Each row As GridViewRow In newMsgGrid.Rows
			If row.RowType = DataControlRowType.DataRow Then
				Dim chkBox As CheckBox = TryCast(row.Cells(0).FindControl("chkBox"), CheckBox)

				If chkBox.Checked Then
					Dim NTID As Label = TryCast(row.Cells(3).FindControl("lblNTID"), Label)
					strNTID = NTID.Text
					'txtBoxMessage.Text = NTID.Text.Trim + " " + txtBoxSubject.Text.Trim + " " + txtBoxMessage.Text.Trim
					GetMessage()

					If dtMessage.Rows.Count > 0 Then
						Dim lastMsgEndTime As String = dtMessage.Rows(0)("EndTime")
						cmdInsert.CommandText = "insert into tbl_HRMS_Shoutbox " & _
											"values('" & NTID.Text.Trim & "', '" & pubUser.Trim & "', '" & txtBoxSubject.Text.Trim & "', '" & txtBoxMessage.Text.Trim & "', 0, '" & txtBoxDuration.Text.Trim & "', '" & lastMsgEndTime.Trim & "', DATEADD(MI, +" & txtBoxDuration.Text.Trim & ", '" & lastMsgEndTime.Trim & "'), GETDATE() )"
					Else
						cmdInsert.CommandText = "insert into tbl_HRMS_Shoutbox " & _
											"values('" & NTID.Text.Trim & "', '" & pubUser.Trim & "', '" & txtBoxSubject.Text.Trim & "', '" & txtBoxMessage.Text.Trim & "', 0, '" & txtBoxDuration.Text.Trim & "', GETDATE(), DATEADD(MI, +" & txtBoxDuration.Text.Trim & ", GETDATE()), GETDATE() )"
					End If

					Try
						sqlConn.Open()
						cmdInsert.Connection = sqlConn
						cmdInsert.ExecuteNonQuery()
					Catch ex As Exception
					Finally
						sqlConn.Close()
					End Try
				End If
			End If
		Next

		txtBoxSubject.Text = ""
		txtBoxMessage.Text = ""
		txtBoxDuration.Text = ""

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('ShoutOut Successfully Sent!');", True)

	End Sub

	Private Sub GetMessage()
		Dim query As String

		query = "select * from tbl_HRMS_Shoutbox (nolock) where Recipient = '" & strNTID.Trim & "' and Status = 0 Order by EndTime desc"

		dtMessage = cls.GetData(query)
	End Sub

End Class