﻿Imports System.Data.SqlClient
Imports System.Data

Public Class SegmentAdd
	Inherits System.Web.UI.Page

	Dim cls As New clsConnection
	Dim dtCategory As DataTable

	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)
	Dim pubUser As String = ""

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

		If Not IsPostBack Then


			Dim query As String = "select DISTINCT Category from tbl_HRMS_PAY_Reason where Category <> 'None'"

			dtCategory = cls.GetData(query)

			If dtCategory.Rows.Count Then

				ddlCat.Items.Add(New ListItem("--Select One Below--", "opt1"))

				For x As Integer = 0 To dtCategory.Rows.Count - 1
					ddlCat.Items.Add(New ListItem(dtCategory.Rows(x)("Category"), dtCategory.Rows(x)("Category")))
				Next

			End If

			ddlCatType.Items.Add(New ListItem("--Select One Below--", "opt1"))
			ddlCatType.Items.Add(New ListItem("Paid", "No"))
			ddlCatType.Items.Add(New ListItem("UnPaid", "Yes"))

			ddlStatus.Items.Add(New ListItem("--Select One Below--", "opt1"))
			ddlStatus.Items.Add(New ListItem("Active", "1"))
			ddlStatus.Items.Add(New ListItem("InActive", "0"))

		Else


		End If
	End Sub

	Protected Sub btnAddSeg_Click(sender As Object, e As EventArgs) Handles btnAddSeg.Click
		Dim sb As New StringBuilder
		Dim newCode As String = ""


		If ddlCat.SelectedIndex = 0 Then sb.Append("Please Select Category!\n")
		If txtSubCat.Text = "" Then sb.Append("Sub Category is Blank!\n")
		If txtDesc.Text = "" Then sb.Append("Description is Blank!\n")

		If ddlCatType.SelectedIndex = 0 Then sb.Append("Please Select Category Type!\n")

		If ddlStatus.SelectedIndex = 0 Then sb.Append("Please Select Status!\n")

		If sb.ToString <> "" Then Alert(sb.ToString) : Exit Sub

		newCode = getNewCode()

		Dim query As String = "insert into tbl_HRMS_PAY_Reason values ('" & newCode.Trim & "','" & txtSubCat.Text.Trim & "','" & ddlCatType.SelectedValue.Trim & "','" & ddlCat.SelectedValue.Trim & "','" & txtDesc.Text.Trim & "','" & pubUser.Trim & "','" & ddlStatus.SelectedValue & "',CAST(GETDATE() as varchar))"

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = query

		cmdUpdate.Connection = sqlConn

		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
		"javascript:alert('Successfully Added!');opener.location='MasterControl.aspx?tab=SE';window.close();", True)

	End Sub

	Function Alert(str As String) As Boolean
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
		"javascript:alert('" & str & "');", True)
		Return True
	End Function

	Function getNewCode() As String
		Dim dtPayReason As DataTable

		Dim query As String = "select TOP 1 ReasonID from dbo.tbl_HRMS_PAY_Reason order by ReasonID DESC"

		dtPayReason = cls.GetData(query)

		Return CDbl(dtPayReason.Rows(0)("ReasonID")) + 1

	End Function

End Class