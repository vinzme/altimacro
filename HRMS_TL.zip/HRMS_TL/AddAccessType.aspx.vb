﻿Imports System.Data.SqlClient

Public Class AddAccessType
	Inherits System.Web.UI.Page

	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)
	Dim pubUser As String

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		pubUser = Session("userID")

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

	End Sub

	Private Sub btnAddAccess_Click(sender As Object, e As EventArgs) Handles btnAddAccess.Click
		If txtAccess.Text = "" Then ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('Access Description is Required!');opener.location.reload();window.close();", True) : Exit Sub


		Dim query As String = "INSERT INTO dbo.tbl_HRMS_AccesType(Access, AddedBy, DateAdded) VALUES('" & txtAccess.Text.Trim & "','" & pubUser.Trim & "',GETDATE())"

		Dim cmdUpdate As New SqlCommand

		cmdUpdate.CommandText = query

		cmdUpdate.Connection = sqlConn

		sqlConn.Open()
		cmdUpdate.ExecuteNonQuery()
		sqlConn.Close()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
		"javascript:alert('Successfully Added!');opener.location='MasterControl.aspx?tab=AT';window.close();", True)

	End Sub
End Class