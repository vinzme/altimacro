﻿Imports System.Data.SqlClient

Public Class SegmentEditor
	Inherits System.Web.UI.Page

	Dim connStr As String = ConfigurationManager.ConnectionStrings("MISConnectionString").ConnectionString.ToString()
	Dim sqlConn As SqlConnection = New SqlConnection(connStr)
	Dim pubUser As String

	Sub OnDSUpdatedHandler(ByVal source As Object, ByVal e As SqlDataSourceStatusEventArgs)
		If e.AffectedRows > 0 Then
			' Perform any additional processing, 
			' such as setting a status label after the operation.        
			'MsgBox(Request.LogonUserIdentity.Name & _
			'" changed user information successfully!")

			Alert(Request.LogonUserIdentity.Name & " changed user information successfully!")
		Else
			Alert("No data updated!")
		End If
	End Sub

	Protected Sub OnRowDeleteHandler(sender As Object, e As SqlDataSourceStatusEventArgs)
		If e.AffectedRows > 0 Then
			' Perform any additional processing, 
			' such as setting a status label after the operation.        

			Alert(Request.LogonUserIdentity.Name & " Removed information successfully!")
		Else
			Alert("No data updated!")
		End If
	End Sub

	Function Alert(str As String) As Boolean
		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
		"javascript:alert('" & str & "');", True)
		Return True
	End Function


	'Protected Sub GridView1_RowEditing(sender As Object, e As GridViewEditEventArgs)

	'    Dim dr As GridViewRow
	'    Dim gIndex As Integer = -1
	'    For Each dr In GridView1.Rows
	'        If gIndex = -1 Then
	'            gIndex = 0
	'        End If

	'        'ChecKValue 
	'        Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView1.Rows(gIndex).FindControl("chkStatus"), CheckBox)
	'        Session("ChecKValue") = lblHrsWorkedSeriesID.Checked

	'        gIndex += 1

	'    Next

	'    'Dim checkBoxStatus As CheckBox = sender
	'    'Dim status As Boolean = checkBoxStatus.Checked
	'    'Dim row As GridViewRow = checkBoxStatus.NamingContainer
	'    'Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView1.Rows(row.RowIndex).FindControl("chkStatus"), CheckBox)

	'End Sub

	Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
		'Alert(e.CommandName)
		Select Case e.CommandName
			'Case "Edit"

			'    Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView1.Rows(row.RowIndex).FindControl("chkStatus"), CheckBox)

			'    Session("ChecKValue") = lblHrsWorkedSeriesID.Checked

			'    Dim lblCategoryType As Label = DirectCast(GridView1.Rows(row.RowIndex).FindControl("lblCategoryType"), Label)

			'    Session("CategoryValue") = lblCategoryType.Text
			Case "Edit"
				Dim rowindex As Integer = CInt(e.CommandArgument)
				Dim row As GridViewRow = GridView1.Rows(rowindex)

				Dim ImgBtnDel As ImageButton = DirectCast(GridView1.Rows(row.RowIndex).FindControl("imgBtnDelete"), ImageButton)
				ImgBtnDel.Enabled = False

				UpdatePanel6.Update()

			Case "Update"
				Dim rowindex As Integer = CInt(e.CommandArgument)
				Dim row As GridViewRow = GridView1.Rows(rowindex)

				Dim findMyControl As DropDownList = DirectCast(GridView1.Rows(row.RowIndex).FindControl("ddlPaid"), DropDownList)
				Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView1.Rows(row.RowIndex).FindControl("chkStatus"), CheckBox)

				If findMyControl.SelectedValue = "Paid" Then Session("ExCludeOnPayment") = "NO" Else Session("ExCludeOnPayment") = "YES"
				If lblHrsWorkedSeriesID.Checked = True Then Session("ChecKValue") = "1" Else Session("ChecKValue") = "0"

			Case "Delete"

				'Dim cmdUpdate As New SqlCommand

				'cmdUpdate.CommandText = "Update tbl_HRMS_PAY_Reason set Active = 'Deleted' where ReasonID = '" & e.CommandArgument & "'"

				'cmdUpdate.Connection = sqlConn

				'sqlConn.Open()
				'cmdUpdate.ExecuteNonQuery()
				'sqlConn.Close()

				'Alert("Deleted Successfully!")
				'ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID,
				'"javascript:alert('Successfully Deleted!');window.location.href = 'SegmentEditor.aspx';", True)

				'Response.Redirect("SegmentEditor.aspx")

				SqlDataSource1.DeleteCommand = "Update tbl_HRMS_PAY_Reason set Active = 'Deleted' where ReasonID = '" & e.CommandArgument & "'"
				SqlDataSource1.DataBind()

				'SqlDataSource1.SelectCommand = "SELECT ReasonID,ReasonDesc,Category,ReasonDescription,CASE WHEN ExcludeonPayment = 'YES' then 'UnPaid' else 'Paid' end [CategoryType],ModifiedBy,Active FROM [tbl_HRMS_PAY_Reason] WHERE Category <> 'None'"
				'SqlDataSource1.DataBind()
		End Select

	End Sub



	'Protected Sub ddlPaid_SelectedIndexChanged(sender As Object, e As EventArgs)

	'    Dim MyControlId As DropDownList = sender
	'    'Dim MyControl As String = MyControlId.Text
	'    'Dim row As GridViewRow = MyControlId.NamingContainer

	'    'Session("ChecKValue") = row.Cells(5).Text
	'    'Dim findMyControl As DropDownList = DirectCast(GridView1.Rows(row.RowIndex).FindControl("ddlPaid"), DropDownList)

	'    'Dim findMyControl As DropDownList = DirectCast(GridView1.Rows(row.RowIndex).FindControl("ddlPaid"), DropDownList)

	'    If MyControlId.SelectedValue = "Paid" Then
	'        Session("ExCludeOnPayment") = "NO"
	'    Else
	'        Session("ExCludeOnPayment") = "YES"
	'    End If

	'End Sub

	'Protected Sub UpdateStatus(ByVal sender As Object, ByVal e As EventArgs)

	'    Dim checkBoxStatus As CheckBox = sender
	'    'Dim status As Boolean = checkBoxStatus.Checked
	'    'Dim row As GridViewRow = checkBoxStatus.NamingContainer

	'    'Session("ChecKValue") = row.Cells(5).Text
	'    'Dim lblHrsWorkedSeriesID As CheckBox = DirectCast(GridView1.Rows(row.RowIndex).FindControl("chkStatus"), CheckBox)

	'    If checkBoxStatus.Checked = True Then
	'        Session("ChecKValue") = "1"
	'    Else
	'        Session("ChecKValue") = "0"
	'    End If

	'    'Dim value As Boolean
	'    'value = DirectCast(GridView1.Rows(e.RowIndex).FindControl("CheckBox1"), CheckBox).Checked

	'End Sub

	Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs)
		If e.Row.RowType = DataControlRowType.DataRow AndAlso GridView1.EditIndex <> e.Row.RowIndex Then

			'Dim findMyControl As DropDownList = DirectCast(GridView1.Rows(row.RowIndex).FindControl("ddlPaid"), DropDownList)


			'TryCast(e.Row.Cells(7).Controls(2), ImageButton).Attributes("OnClick") = "return confirm('Do you want to delete this row?');"



			'TryCast(e.Row.Cells(7).Controls(2), ImageButton).Attributes("data-toggle") = "modal"
			'TryCast(e.Row.Cells(7).Controls(2), ImageButton).Attributes("data-target") = "#myModal"

		End If
	End Sub

	Private Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

		pubUser = Session("userID")

		'Try
		'	Dim DomainUser As String = System.Web.HttpContext.Current.User.Identity.Name.Replace("\", "/")
		'	'Dim DomainUser As String = System.Security.Principal.WindowsIdentity.GetCurrent.Name.Replace("\", "/")

		'	Dim sUser() As String = Split(DomainUser, "/")

		'	'Dim sDomain As String = suser(0)
		'	Dim sUserId As String = LCase(sUser(1))

		'	pubUser = sUserId
		'	pubUser = "sainibha"
		'Catch ex As Exception
		'	pubUser = "sainibha"
		'End Try

	End Sub

	Protected Sub GridView1_RowDeleted(sender As Object, e As GridViewDeletedEventArgs)

		SqlDataSource1.SelectCommand = "SELECT ReasonID,ReasonDesc,Category,ReasonDescription,CASE WHEN ExcludeonPayment = 'YES' then 'UnPaid' else 'Paid' end [CategoryType],ModifiedBy,Active FROM [tbl_HRMS_PAY_Reason] WHERE Category <> 'None' and active <> 'Deleted'"
		SqlDataSource1.DataBind()

		ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), UniqueID, "javascript:alert('Deletion Success..');", True)
	End Sub

End Class