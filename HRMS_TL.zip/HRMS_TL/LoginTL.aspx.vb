﻿Imports System.Web.Services

Public Class LoginTL
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		If Not IsPostBack Then
			Session.Clear()
			Session("userID") = Request.Params("ntid")
		End If
	End Sub

	'<WebMethod(EnableSession:=True)> _
	'Public Shared Function authentication(data As LogInForm) As String
	'	Dim rt As String = ""
	'	Dim cls As New clsConnection
	'	Dim dt As New DataTable

	'	'Dim qry = "Select * from dbo.tbl_HRMS_EmployeeMaster where ntid = '" & Data.user.Trim & "'"
	'	'dt = cls.GetData(qry)

	'	If data.user = "sainibha" Then
	'		If data.pw = "password" Then
	'			rt = "success"
	'			'HttpContext.Current.Session("auth") = "1"

	'			'HttpContext.Current.Session.Add("auth", "1")

	'		Else
	'			rt = "password incorect"
	'		End If
	'	Else
	'		rt = "invalid log in"
	'	End If

	'	Return rt
	'End Function

End Class